﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class DisburseBankHandler : IDisburseBankHandler
    {
        public IDisburseBankDao DisburseBankDao { get; set; }

        public CommonTResult<T_PL_DisburseBankMaker> GetDisburseBankList(int limit, int start, string name, string alias, string status)
        {
            CommonTResult<T_PL_DisburseBankMaker> result = null;
            CommonTResult<T_PL_DisburseBankMaker> resultDao = DisburseBankDao.GetDisburseBankList(limit, start, name,alias, status);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_DisburseBankMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public int AddOrUpdateDisburseBank(string name, string alias, string id, int optype, string soeid)
        {
            return DisburseBankDao.AddOrUpdateDisburseBank(name, alias, id, optype, soeid);            
        }

        public bool DeleteDisburseBank(string id)
        {
            return DisburseBankDao.DeleteDisburseBank(id);            
        }
        public bool ApproveItem(string ids, string checker)
        {
            return DisburseBankDao.ApproveItem(ids, checker);            
        }
        public bool RejectItem(string ids, string checker)
        {
            return DisburseBankDao.RejectItem(ids, checker);            
        }
    }
}
