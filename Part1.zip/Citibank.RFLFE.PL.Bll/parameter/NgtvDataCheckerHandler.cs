﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class NgtvDataCheckerHandler : INgtvDataCheckerHandler
    {
        public INgtvDataCheckerDao NgtvDataCheckerDao { get; set; }
        /// <summary>
        /// Get Fraud data
        /// </summary>
        /// <returns></returns>
        public CommonTResult<T_RP_NegativeDataCheckerView> GetNgtvData(int start, int limit, string CustName, string CompanyName, string AgentName, string IDNo, string DOB, string SalesName, string OtherCertID, string Reason, string Status, string Maker, string Checker, string ModifiedTime)
        {
            CommonTResult<T_RP_NegativeDataCheckerView> result = null;
            CommonTResult<T_RP_NegativeDataCheckerView> resultDao = NgtvDataCheckerDao.GetNgtvData(start,limit,CustName, CompanyName, AgentName, IDNo, DOB, SalesName, OtherCertID, Reason, Status, Maker, Checker, ModifiedTime);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_NegativeDataCheckerView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_RP_NegativeDataCheckerView> GetNgtvDataByID(int TID)
        {
            return NgtvDataCheckerDao.GetNgtvDataByID(TID);
        }

        public bool ApproveNgtvData(string TID, string approveresult, string soeID)
        {
            return NgtvDataCheckerDao.ApproveNgtvData(TID, approveresult, soeID);
        }
        
        public bool RejectData(string TID, string approveresult, string soeID)
        {
            return NgtvDataCheckerDao.RejectData(TID, approveresult, soeID);
        }
    }
}
