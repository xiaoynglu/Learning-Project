﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class RPRulesHandler : IRPRulesHandler
    {
        public IRPRulesMakerDao RPRulesMakerDao { get; set; }
        public IRuleResultDao RuleResultDao { get; set; }

        public CommonTResult<T_RP_RulesMaker> GetRPRulesMaker(T_RP_RulesMaker entity, int limit, int start)
        {
            CommonTResult<T_RP_RulesMaker> result = null;
            CommonTResult<T_RP_RulesMaker> resultDao = RPRulesMakerDao.GetRP_RulesMaker(entity, limit, start);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_RulesMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public bool UpdateExpireDay(string ids, string expiredays,string maker)
        {
            try
            {
                return RPRulesMakerDao.UpdateExpireDay(ids, expiredays, maker);
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public CommonTResult<T_RP_RulesMaker> GetRPRulesPendingChecker(T_RP_RulesMaker entity, int limit, int start)
        {
            throw new NotImplementedException();
        }

        public bool ApproveExpireDay(string ids, int approveType, string checker)
        {
            return RPRulesMakerDao.ApproveExpireDay(ids, approveType, checker);
        }

        public CommonTResult<RuleParamAlistView> GetRuleParamAlistMaker(int start, int limit,string orgcode,string STATUS)
        {
            return RPRulesMakerDao.GetRuleParamAlistMaker(start, limit, orgcode, STATUS);
        }
        public CommonTResult<RuleParamBlistView> GetRuleParamBlistMaker(int start, int limit, string orgcode, string STATUS)
        {
            return RPRulesMakerDao.GetRuleParamBlistMaker(start, limit, orgcode, STATUS);
        }

        public CommonTResult<T_RP_RulesMaker> GetRPRulesChecker(string RuleID)
        {
            CommonTResult<T_RP_RulesMaker> result = null;
            CommonTResult<T_RP_RulesMaker> resultDao = RPRulesMakerDao.GetRPRulesChecker(RuleID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_RulesMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonResult UpdateRPRulesMaker(T_RP_RulesMaker entity)
        {
            CommonResult result = new CommonResult();
            int tid = RPRulesMakerDao.UpdateRP_RulesMaker(entity);
            if (tid > 0)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_UPDATE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_UPDATE_FAILED;
            }
            return result;
        }

        public CommonResult ApproveRPRulesMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = RPRulesMakerDao.ApproveRP_RulesMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_APPROVE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_APPROVE_FAILED;
            }
            return result;            
        }

        public CommonResult RejectRPRulesMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = RPRulesMakerDao.RejectRP_RulesMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_REJECT_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_REJECT_FAILED;
            }
            return result;            
        }

        public IList<T_RP_RulesMaker> GetRuleNamesMaker()
        {
            return RPRulesMakerDao.GetRuleNamesMaker();
        }

        public CommonTResult<T_RP_RuleResultDetail> GetRPResultDetails(string appId, int prodId)
        {
            CommonTResult<T_RP_RuleResultDetail> resultDao = RuleResultDao.GetRPResultDetails(appId, prodId);
            CommonTResult<T_RP_RuleResultDetail> result = new CommonTResult<T_RP_RuleResultDetail>()
            {
                ResultCount = resultDao.ResultCount,
                ResultList = resultDao.ResultList,
                IsSuccess = true,
                Message = ""
            };
            return result;
        }

        public IList<T_RP_ADR> GetApplicationADR(Guid appId, int prodId)
        {
            return RuleResultDao.GetApplicationADR(appId, prodId);
        }

        public int SaveApplicationADR(T_RP_ADR entity)
        {
            return RuleResultDao.SaveApplicationADR(entity);
        }

        public IList<T_RP_Params> GetRuleParamListMaker(string RuleID)
        {
            return RPRulesMakerDao.GetRuleParamListMaker(RuleID);
        }

        public bool RejectRPRuleParamValueMaker(string RuleIDs, string ParamIDs, string OrgCodes, string checker)
        {
            return RPRulesMakerDao.RejectRPRuleParamValueMaker(RuleIDs, ParamIDs, OrgCodes, checker);
        }

        public CommonTResult<T_PL_AppExpireDateMaker> GetExpireDateList()
        {
            return RPRulesMakerDao.GetExpireDateList();
        }

        public CommonTResult<T_RP_RuleParamValuePivot> GetRuleParamValuePivotListMaker(T_RP_RuleParamValuePivot entity, int limit, int start)
        {
            //return RPRulesMakerDao.GetRuleParamValuePivotListMaker(entity, limit, start);


            CommonTResult<T_RP_RuleParamValuePivot> result = null;
            CommonTResult<T_RP_RuleParamValuePivot> resultDao = RPRulesMakerDao.GetRuleParamValuePivotListMaker(entity, limit, start);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_RuleParamValuePivot>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_RP_RuleParamValuePivot> GetRuleParamValuePivotListChecker(T_RP_RuleParamValuePivot entity, int limit, int start)
        {
            //return RPRulesMakerDao.GetRuleParamValuePivotListMaker(entity, limit, start);


            CommonTResult<T_RP_RuleParamValuePivot> result = null;
            CommonTResult<T_RP_RuleParamValuePivot> resultDao = RPRulesMakerDao.GetRuleParamValuePivotListChecker(entity, limit, start);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_RuleParamValuePivot>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }        

        /// <summary>
        /// Is application price deviated
        /// </summary>
        /// <param name="appId">application id</param>
        /// <param name="prodId">product id</param>
        /// <returns>true/false</returns>
        public bool ApplicationIsPricingDeviationed(Guid appId, int prodId)
        {
            bool returnValue = false;
            IList<T_RP_ADR> deviatedADRs = RuleResultDao.GetApplicationADR(appId, prodId);
            if (deviatedADRs.Any())
            {
                if (!string.IsNullOrEmpty(deviatedADRs[0].ProposalDeviated))
                {
                    if (deviatedADRs[0].ProposalDeviated == "1")
                    {
                        returnValue = true;
                    }
                }
            }
            return returnValue;
        }

        public CommonResult SaveRPRuleParamValueMaker(string RuleIDs, string ParamIDs, string OrgCodes, string UPL_Gs, string UPL_Qs, string HE_Gs, string HE_Qs, string CRE_Gs, string CRE_Qs, string MO_Gs, string MO_Qs,string maker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = RPRulesMakerDao.SaveRPRuleParamValueMaker(RuleIDs, ParamIDs, OrgCodes, UPL_Gs, UPL_Qs, HE_Gs, HE_Qs, CRE_Gs, CRE_Qs, MO_Gs, MO_Qs,maker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_SAVE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_SAVE_FAILED;
            }
            return result;
        }

        public CommonResult ApproveRPRuleParamValueMaker(string RuleIDs, string ParamIDs, string OrgCodes, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = RPRulesMakerDao.ApproveRPRuleParamValueMaker(RuleIDs, ParamIDs, OrgCodes, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_APPROVE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_APPROVE_FAILED;
            }
            return result;
        }

        public bool SaveLTVParamMaker(string ProdIds, string OrgCodes, string Factors, string Values, string maker)
        {
            return RPRulesMakerDao.SaveLTVParamMaker(ProdIds, OrgCodes, Factors, Values, maker);
        }

        public bool SaveLTVValueMaker(string ProdIds, string OrgCodes, string CollateralTypes, string BaseLTVs, string MaxDelLTVs, string maker)
        {
            return RPRulesMakerDao.SaveLTVValueMaker(ProdIds, OrgCodes, CollateralTypes, BaseLTVs,MaxDelLTVs, maker);
        }

        public bool ApproveLTVParamMaker(string ProdIds, string OrgCodes, string Factors, string checker, int approvetype)
        {
            return RPRulesMakerDao.ApproveLTVParamMaker(ProdIds, OrgCodes, Factors, checker, approvetype);
        }

        public bool ApproveLTVValueMaker(string ProdIds, string OrgCodes, string CollateralTypes, string checker, int approvetype)
        {
            return RPRulesMakerDao.ApproveLTVValueMaker(ProdIds, OrgCodes, CollateralTypes, checker, approvetype);
        }
    }
}
