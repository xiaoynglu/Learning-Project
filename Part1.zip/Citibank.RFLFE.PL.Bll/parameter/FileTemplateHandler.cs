﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class FileTemplateHandler : IFileTemplateHandler
    {
        public IFileTemplateDao FileTemplateDao { get; set; }

        public CommonTResult<T_PL_FileTemplateMaker> GetFileTemplateMakerList(int limit, int start, int? prodID, int? status)
        {
            CommonTResult<T_PL_FileTemplateMaker> result = null;
            CommonTResult<T_PL_FileTemplateMaker> resultDao = FileTemplateDao.GetFileTemplateMakerList(limit, start, prodID, status);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_FileTemplateMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_PL_ConfigConditionMaker> GetTemplateConditionMakerList(int limit, int start, int? prodID, int? status)
        {
            CommonTResult<T_PL_ConfigConditionMaker> result = null;
            CommonTResult<T_PL_ConfigConditionMaker> resultDao = FileTemplateDao.GetTemplateConditionMakerList(limit, start, prodID, status);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_ConfigConditionMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public IList<T_PL_ConditionColumns> GetConditionDisplayNames(string tableName)
        {
            return FileTemplateDao.GetConditionDisplayNames(tableName);
        }

        public IList<T_PL_ConfigConditionMaker> GetConditionGroupNames(int tid, int parentID, int prodID)
        {
            return FileTemplateDao.GetConditionGroupNames(tid, parentID, prodID);
        }

        public IList<T_PL_FileTemplateMaker> GetTemplateFileNames(int fileType) {
            return FileTemplateDao.GetTemplateFileNames(fileType);
        }

        public T_PL_FileTemplateMaker GetTemplateFilePathByTID(int tid) {
            return FileTemplateDao.GetTemplateFilePathByTID(tid);
        }

        public int ChangeTemplateName(int tid, string fileName)
        {
            return FileTemplateDao.ChangeTemplateName(tid, fileName);
        }

        public int SaveTemplateConditionMaker(T_PL_ConfigConditionMaker entity)
        {
            return FileTemplateDao.SaveTemplateConditionMaker(entity);
        }

        public int SaveFileTemplateMaker(T_PL_FileTemplateMaker entity) {
            return FileTemplateDao.SaveFileTemplateMaker(entity);
        }

        public int DeleteFileTemplateMaker(int tid)
        {
            return FileTemplateDao.DeleteFileTemplateMaker(tid);
        }

        public int DeleteConfigConditionMaker(int cid)
        {
            return FileTemplateDao.DeleteConfigConditionMaker(cid);
        }

        public bool ApproveFileTemplateMaker(string ids, string checker) {
            return FileTemplateDao.ApproveFileTemplateMaker(ids, checker);
        }

        public bool RejectFileTemplateMaker(string ids, string checker)
        {
            return FileTemplateDao.RejectFileTemplateMaker(ids, checker);
        }

        public bool ApproveConfigConditionMaker(string ids, string checker)
        {
            return FileTemplateDao.ApproveConfigConditionMaker(ids, checker);
        }

        public bool RejectConfigConditionMaker(string ids, string checker)
        {
            return FileTemplateDao.RejectConfigConditionMaker(ids, checker);
        }

        public IList<Mvc.Models.ComboxDataView> GetUploadedProd()
        {
            return FileTemplateDao.GetUploadedProd();
        }

        public Dictionary<object, object> GetUploadedFileNameAndAttachmentListByProdID(string prodId)
        {
            return FileTemplateDao.GetUploadedFileNameAndAttachmentListByProdID(prodId);
        }
    }
}
