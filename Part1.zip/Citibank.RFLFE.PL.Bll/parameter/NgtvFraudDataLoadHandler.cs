﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class NgtvFraudDataLoadHandler : INgtvFraudDataLoadHandler
    {
        public INgtvFraudDataLoadDao NgtvFraudDataLoadDao { get; set; }

        public CommonTResult<T_RP_NegativeDataMaker> GetNgtvData()
        {
            CommonTResult<T_RP_NegativeDataMaker> result = null;
            CommonTResult<T_RP_NegativeDataMaker> resultDao = NgtvFraudDataLoadDao.GetNgtvData();
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_NegativeDataMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_RP_FraudDataMaker> GetFraudData()
        {
            CommonTResult<T_RP_FraudDataMaker> result = null;
            CommonTResult<T_RP_FraudDataMaker> resultDao = NgtvFraudDataLoadDao.GetFraudData();
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_FraudDataMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
    }
}
