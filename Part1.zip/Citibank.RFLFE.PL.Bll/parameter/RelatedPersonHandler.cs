﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class RelatedPersonHandler : IRelatedPersonHandler
    {
        #region all Dao
        public IRelatedPersonDao RelatedPersonDao { get; set; }
        public IRelatedPersonMakerDao RelatedPersonMakerDao { get; set; }
        #endregion

        /// <summary>
        /// Get related person
        /// </summary>
        /// <returns>T_RP_RelatedPerson list</returns>
        public CommonTResult<T_RP_RelatedPerson> GetRelatedPersonByID(int tid)
        {
            CommonTResult<T_RP_RelatedPerson> result = null;
            CommonTResult<T_RP_RelatedPerson> resultDao = RelatedPersonDao.GetRelatedPersonByID(tid);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_RelatedPerson>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
      
        /// <summary>
        /// Get related person maker
        /// </summary>
        /// <returns>T_RP_RelatedPersonMaker list</returns>
        public CommonTResult<T_RP_RelatedPersonMaker> GetRelatedPersonMaker(T_RP_RelatedPersonMaker entity, int limit, int start)
        {
            CommonTResult<T_RP_RelatedPersonMaker> result = null;
            CommonTResult<T_RP_RelatedPersonMaker> resultDao = RelatedPersonMakerDao.GetRelatedPersonMaker(entity, limit, start);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_RelatedPersonMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        /// <summary>
        /// Add new related person maker data
        /// </summary>
        /// <param name="entity">T_RP_RelatedPersonMaker entity</param>
        /// <returns>TID</returns>
        public CommonResult SaveRelatedPersonMaker(T_RP_RelatedPersonMaker entity)
        {
            CommonResult result = new CommonResult();
            int tid = RelatedPersonMakerDao.SaveRelatedPersonMaker(entity);
            if (tid > 0)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_ADD_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_ADD_FAILED;
            }
            return result;
        }

        /// <summary>
        /// Delete related person maker by id
        /// </summary>
        /// <param name="tid">id</param>
        /// <returns>success flag</returns>
        public CommonResult DeleteRelatedPersonMaker(int tid)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = RelatedPersonMakerDao.DeleteRelatedPersonMaker(tid);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_DELETE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_DELETE_FAILED;
            }
            return result;
        }

        /// <summary>
        /// Approve related person maker requests
        /// </summary>
        /// <param name="ids">TIDs which need to approve</param>
        /// <param name="checker">current user</param>
        /// <returns>successed flag</returns>
        public CommonResult ApproveRelatedPersonMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = RelatedPersonMakerDao.ApproveRelatedPersonMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_APPROVE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_APPROVE_FAILED;
            }
            return result;
        }

        /// <summary>
        /// Reject related person maker requests
        /// </summary>
        /// <param name="ids">TIDs which need to approve</param>
        /// <param name="checker">current user</param>
        /// <returns>successed flag</returns>
        public CommonResult RejectRelatedPersonMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = RelatedPersonMakerDao.RejectRelatedPersonMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_REJECT_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_REJECT_FAILED;
            }
            return result;
        }
    }
}
