﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class BranchCreationHandler : IBranchCreationHandler
    {
        public IBranchCreationDao BranchCreationDao { get; set; }

        public bool AddBranch(T_Sys_BranchMaker branchentity, string soeID)
        {
            return BranchCreationDao.AddBranch(branchentity,soeID);
        }

        public CommonTResult<ComboboxEntity> GetBranchType()
        {
            CommonTResult<ComboboxEntity> result = null;
            CommonTResult<ComboboxEntity> resultDao = BranchCreationDao.GetBranchType();
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<ComboboxEntity>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
    }
}
