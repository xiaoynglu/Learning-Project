﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class ProductParameterHandler : IProductParameterHandler
    {
        public IProductParameterDao ProductParameterDao { get; set; }

        #region "BaseRate"
        public CommonTResult<T_PL_BaseRateMaker> GetBaseRateByProdID(int? prodID)
        {
            return ProductParameterDao.GetBaseRateByProdID(prodID);
        }
        public CommonTResult<T_PL_BaseRateMaker> GetBaseRateMOByOrgCode(string orgCode)
        {
            return ProductParameterDao.GetBaseRateMOByOrgCode(orgCode);
        }
        public int MakeProdBaseRate(string[] baseRates, string maker)
        {
            int effectRows = 0;
            T_PL_BaseRateMaker baseRateEntity = null;

            foreach (string baseRate in baseRates)
            {
                string[] rec = baseRate.Split(',');
                baseRateEntity = new T_PL_BaseRateMaker();

                if (rec.Length > 2)
                {
                    baseRateEntity.ProdID = 5;
                    baseRateEntity.OrgCode = rec[0];
                    baseRateEntity.Value = Convert.ToDecimal(rec[1]);
                    baseRateEntity.ValueOverFive = Convert.ToDecimal(rec[2]);
                    baseRateEntity.FirstPayRate = Convert.ToDecimal(rec[3]);
                    baseRateEntity.SecondPayRate = Convert.ToDecimal(rec[4]);
                    baseRateEntity.Maker = maker;
                }
                else
                {
                    baseRateEntity.ProdID = Convert.ToInt32(rec[0]);
                    baseRateEntity.Value = Convert.ToDecimal(rec[1]);
                    baseRateEntity.Maker = maker;
                }
                
                if (!IsSameBaseRate(baseRateEntity))
                {

                    effectRows += ProductParameterDao.MakeProdBaseRate(baseRateEntity);
                }

            }
            return effectRows;
        }
        public bool ApproveBaseRateMaker(string ids, string checker)
        {
            return ProductParameterDao.ApproveBaseRateMaker(ids, checker);
        }
        public bool RejectBaseRateMaker(string ids, string checker)
        {
            return ProductParameterDao.RejectBaseRateMaker(ids, checker);
        }
        #endregion

        #region "RateAndFee"
        public int MakeRateAndFee(string[] critis, string maker)
        {
            int effectRows = 0;

            foreach (string rf in critis)
            {
                string[] rec = rf.Split(',');
                if (rec.Length > 8)
                {
                    T_PL_RateMaker rate = new T_PL_RateMaker();
                    rate.TID = Convert.ToInt32(rec[0]);
                    rate.Value = Convert.ToDecimal(rec[1]);
                    rate.Spread = Convert.ToDecimal(rec[2]);
                    rate.ProdID = Convert.ToInt32(rec[3]);
                    rate.CollateralType = rec[4];
                    rate.OrgCode = rec[5];                    
                    rate.IsOverFive = Convert.ToBoolean(rec[7]);
                    rate.IsSecond = Convert.ToBoolean(rec[8]);
                    rate.EmploymentType = rec[9];
                    rate.Segment = rec[10];
                    rate.Maker = maker;
                    
                        effectRows += ProductParameterDao.SaveRateMaker(rate);                                       
                }
                else
                {
                    T_PL_FeeMaker fee = new T_PL_FeeMaker();
                    fee.TID = Convert.ToInt32(rec[0]);
                    fee.Value = Convert.ToDecimal(rec[1]);
                    fee.ProdID = Convert.ToInt32(rec[2]);
                    fee.CollateralType = rec[3];
                    fee.OrgCode = rec[4];
                    fee.FeeType = rec[5];
                    fee.EmploymentType = rec[6];
                    fee.Segment = rec[7];
                    fee.Maker = maker;
                                        
                    effectRows += ProductParameterDao.SaveFeeMaker(fee);
                   
                }

            }

            return effectRows;
        }

        public CommonTResult<T_PL_FeeMaker> GetFees(T_PL_FeeMaker fee)
        {
            return ProductParameterDao.GetFees(fee);
        }

        public CommonTResult<T_PL_RateMaker> GetRates(T_PL_RateMaker rate)
        {
            return ProductParameterDao.GetRates(rate);
        }

        public CommonResult UploadRateData(Stream stream, string maker)
        {
            CommonResult result = new CommonResult();
            string message = "";
    
            ExcelUtility ExcelUtility = new ExcelUtility();
            ExcelUtility.ListInitial();
            List<DataTable> rateTables = ExcelUtility.ReadAllSheetToList(stream);
            result.IsSuccess = true;
            if(!(rateTables == null || rateTables.Count == 0)){

                foreach (DataTable rateTable in rateTables)
                {
                    if (!(rateTable == null || rateTable.Rows.Count == 0))
                    {
                        message = message + this.ImportRates(rateTable, maker);                       
                    }
                    else{
                        result.IsSuccess = false;
                        switch (rateTable.TableName)
                        {
                            case ("Base"):
                                message = message + "(1): " + rateTable.TableName + "利率数据为空。<br>";
                                break;
                            case ("UPL"):
                                message = message + "(2): " + rateTable.TableName + "利率数据为空。<br>";
                                break;
                            case ("HE"):
                                message = message + "(3): " + rateTable.TableName + "利率数据为空。<br>";
                                break;
                            case ("CRE"):
                                message = message + "(4): " + rateTable.TableName + "利率数据为空。<br>";
                                break;
                            case ("MixUse CRE"):
                                message = message + "(5): " + rateTable.TableName + "利率数据为空。<br>";
                                break;
                            case ("MO"):
                                message = message + "(6): " + rateTable.TableName + "利率数据为空。<br>";
                                break;
                        }
                    }
                }
            }else{
                result.IsSuccess = false;
                message = "未读取任何数据，请检查导入的数据文件!";
            }
            result.Message = message;
            return result;
        }

        public bool ApproveRateAndFeeMaker(string ids, string channel, string checker)
        {
            if (channel == "1")
            {
                return ProductParameterDao.ApproveFeeMaker(ids, checker);
            }
            if (channel == "2")
            {
                return ProductParameterDao.ApproveRateMaker(ids, checker);
            }
            return false;
        }

        public bool RejectRateAndFeeMaker(string ids, string channel, string checker)
        {
            if (channel == "1")
            {
                return ProductParameterDao.RejectFeeMaker(ids, checker);
            }
            if (channel == "2")
            {
                return ProductParameterDao.RejectRateMaker(ids, checker);
            }
            return false;
        }
        #endregion

        #region "DocumentList"
        public IList<T_Sys_Parameters> GetCustSegments(string employType)
        {
            return ProductParameterDao.GetCustSegments(employType);
        }
        public CommonTResult<T_PL_DocListMaker> GetDocListMaker(int limit, int start, T_PL_DocListMaker docList)
        {
            CommonTResult<T_PL_DocListMaker> result = null;
            CommonTResult<T_PL_DocListMaker> resultDao = ProductParameterDao.GetDocListMaker(limit, start, docList);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_DocListMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
        public int AddDocListMaker(T_PL_DocListMaker entity)
        {
            return ProductParameterDao.AddDocListMaker(entity);
        }
        public int SaveDocListMaker(T_PL_DocListMaker entity)
        {
            return ProductParameterDao.SaveDocListMaker(entity);
        }
        public bool DelDocListMaker(string ids, string maker)
        {
            return ProductParameterDao.DelDocListMaker(ids, maker);
        }
        public bool UploadDocList(Stream stream, T_PL_DocListMaker docListMaker)
        {
            bool result = false;
            int effectRows = 0;
            //String.IsNullOrEmpty(entity.IsRequired)
            //ExcelUtility excelHelper = new ExcelUtility();
            //excelHelper.ReadExcelFromStream(stream, false);
            //int sum = excelHelper.GetRowCount();
            //for (int i = 0; i <= sum; i++)
            //{
            //    docListMaker.DocName = excelHelper.GetCellValue("文档名称", i);
            //    docListMaker.IsRequired = excelHelper.GetCellValue("是否必需", i);
            //    docListMaker.GroupNo = excelHelper.GetCellValue("分组编号", i);
            //    //this.AddDocListMaker(docListMaker);
            //}
            string isRequired = "";
            ExcelUtility ExcelUtility = new ExcelUtility();
            DataTable dt = ExcelUtility.ReadFirstSheetData(stream);
            if (!(dt == null || dt.Rows.Count == 0))
            {
                foreach (DataRow dr in dt.Rows)
                {
                    if (dr[0] == null || String.IsNullOrEmpty(Convert.ToString(dr[0])))
                    {
                        continue;
                    }
                    docListMaker.DocName = dr[0].ToString();
                    isRequired = dr[1].ToString();
                    if (isRequired == "Y")
                    {
                        docListMaker.IsRequired = "True";
                    }
                    if (isRequired == "N")
                    {
                        docListMaker.IsRequired = "False";
                    }
                    docListMaker.GroupNo = Convert.ToString(dr[2]);
                    effectRows += this.AddDocListMaker(docListMaker);
                    //foreach (DataColumn dc in dt.Columns)
                    //{
                    //    System.Diagnostics.Debug.WriteLine(dr[dc].ToString());
                    //}
                }
                if (effectRows > 0)
                {
                    result = true;
                }
            }
            return result;
        }
        public bool ApproveDocListMaker(string ids, string checker)
        {
            return ProductParameterDao.ApproveDocListMaker(ids, checker);
        }
        public bool RejectDocListMaker(string ids, string checker)
        {
            return ProductParameterDao.RejectDocListMaker(ids, checker);
        }
        #endregion

        private bool IsSameBaseRate(T_PL_BaseRateMaker baseRateEntity)
        {
            CommonTResult<T_PL_BaseRateMaker> baseRate = null;
            decimal orgValue,orgValueOverFile,orgFirstPayRate,orgSecondPayRate;

            if (baseRateEntity.ProdID == 5)
            {
                baseRate = this.GetBaseRateMOByOrgCode(baseRateEntity.OrgCode);
                if (baseRate.ResultList.Count != 0)
                {
                    orgValue = baseRate.ResultList[0].Value;
                    orgValueOverFile = baseRate.ResultList[0].ValueOverFive;
                    orgFirstPayRate = baseRate.ResultList[0].FirstPayRate;
                    orgSecondPayRate = baseRate.ResultList[0].SecondPayRate;
                    return baseRateEntity.Value == orgValue &&
                           baseRateEntity.ValueOverFive == orgValueOverFile &&
                           baseRateEntity.FirstPayRate == orgFirstPayRate &&
                           baseRateEntity.SecondPayRate == orgSecondPayRate ? true : false;
                }
                else
                {
                    return false;
                }
            }
            else {
                baseRate = this.GetBaseRateByProdID(baseRateEntity.ProdID);
                orgValue = baseRate.ResultList[0].Value;
                return baseRateEntity.Value == orgValue  ? true : false;
            }
        }

        private string ImportRates(DataTable dt,string maker) {
            string message = "";
            int effectRows = 0;
            string errormessage = "";
            Dictionary<string, string> dicEmploymentType = new Dictionary<string, string>();
            dicEmploymentType.Add("签约企业职员", "G");
            dicEmploymentType.Add("优质企业职员", "G");
            dicEmploymentType.Add("一般企业职员", "G");
            dicEmploymentType.Add("优质个体户", "Q");
            dicEmploymentType.Add("一般个体户", "Q");
            Dictionary<string, string> dicSegment = new Dictionary<string, string>();
            dicSegment.Add("签约企业职员", "GC");
            dicSegment.Add("优质企业职员", "GP");
            dicSegment.Add("一般企业职员", "GS");
            dicSegment.Add("优质个体户", "QP");
            dicSegment.Add("一般个体户", "QS");
            Dictionary<int, bool> dicMOIsFive = new Dictionary<int, bool>();
            dicMOIsFive.Add(1, false);
            dicMOIsFive.Add(2, true);
            dicMOIsFive.Add(3, false);
            dicMOIsFive.Add(4, true);
            Dictionary<int, bool> dicMOIsSecond = new Dictionary<int, bool>();
            dicMOIsSecond.Add(1, false);
            dicMOIsSecond.Add(2, false);
            dicMOIsSecond.Add(3, true);
            dicMOIsSecond.Add(4, true);

            switch (dt.TableName)
            {
                case ("Base"):
                    T_PL_BaseRateMaker baseRate = new T_PL_BaseRateMaker();
                    baseRate.ProdID = 5;
                    var baseValue = ConvertUtility.StringToDecimal(dt.Rows[0][0].ToString());
                    var baseValue5 = ConvertUtility.StringToDecimal(dt.Rows[1][0].ToString());
                    baseRate.Value = baseValue == null ? 0 : ConvertUtility.CutDecimalWithN((decimal)baseValue, 2);
                    baseRate.ValueOverFive = baseValue5 == null ? 0 : ConvertUtility.CutDecimalWithN((decimal)baseValue5,2);
                    baseRate.Maker = maker;
                    effectRows += ProductParameterDao.MakeProdBaseRate(baseRate);
                    message = "-- 已更新" + effectRows + "条MO" + dt.TableName + "利率。<br>";
                    break;
                case ("HE"):
                case ("UPL"):
                case ("CRE"):
                case ("MixUse CRE"):
                case ("MO"):
                    {
                        int prodid = 1;
                        if (dt.TableName == "UPL") prodid = 1;
                        if (dt.TableName == "HE") prodid = 2;
                        if (dt.TableName == "CRE") prodid = 3;
                        if (dt.TableName == "MixUse CRE") prodid = 3;
                        if (dt.TableName == "MO") prodid = 5;
                        CommonTResult<T_PL_BaseRateMaker> Product = new CommonTResult<T_PL_BaseRateMaker>();
                        decimal baseValueUPL = 0;

                        for (int i = 1; i < dt.Rows.Count; i++)
                        {
                            for (int j = 1; j < dt.Columns.Count; j++)
                            {
                                if (!String.IsNullOrEmpty(dt.Rows[i][j].ToString()))
                                {
                                    string branchcode = dt.Rows[0][j].ToString();

                                    string orgcode = ProductParameterDao.GetOrgCodeByBranchCode(branchcode);
                                    if (prodid != 5)
                                    {
                                        Product = ProductParameterDao.GetBaseRate(prodid, "");
                                        baseValueUPL = Product.ResultList[0].Value;
                                    }
                                    else if (prodid == 5)
                                    {
                                        Product = ProductParameterDao.GetBaseRate(prodid, orgcode);
                                        baseValueUPL = Product.ResultList[0].Value;
                                    }
                                    if (orgcode == "")
                                    {
                                        if (errormessage.IndexOf(branchcode) == -1)
                                        {
                                            errormessage += "," + branchcode;
                                        }
                                        continue;
                                    }
                                        
                                    T_PL_RateMaker Cell_RateMaker = new T_PL_RateMaker();
                                    decimal? Cell_Rate = ConvertUtility.StringToDecimal(dt.Rows[i][j].ToString());
                                    if (Cell_Rate != null)
                                    {
                                        Cell_RateMaker.Value = ConvertUtility.CutDecimalWithN(Convert.ToDecimal(Cell_Rate), 6);
                                        if (prodid != 5)
                                        {
                                            Cell_RateMaker.Spread = ConvertUtility.CutDecimalWithN(Convert.ToDecimal(Cell_Rate) - baseValueUPL, 6);
                                        }
                                        else
                                        {
                                            Cell_RateMaker.Spread = ConvertUtility.CutDecimalWithN(Convert.ToDecimal(Cell_Rate) / baseValueUPL, 6);
                                        }
                                        Cell_RateMaker.Maker = maker;
                                        Cell_RateMaker.ProdID = prodid;
                                        Cell_RateMaker.OrgCode = orgcode;
                                        Cell_RateMaker.EmploymentType = dicEmploymentType[dt.Rows[i][0].ToString()];
                                        Cell_RateMaker.Segment = dicSegment[dt.Rows[i][0].ToString()];
                                        if (prodid == 5)
                                        {
                                            int MOType = 1;
                                            if (i >= 1 && i <= 5) MOType = 1;
                                            if (i >= 6 && i <= 10) MOType = 2;
                                            if (i >= 11 && i <= 15) MOType = 3;
                                            if (i >= 16 && i <= 20) MOType = 4;
                                            Cell_RateMaker.IsSecond = dicMOIsSecond[MOType];
                                            Cell_RateMaker.IsOverFive = dicMOIsFive[MOType];
                                        }
                                        effectRows += ProductParameterDao.SaveRateMaker(Cell_RateMaker);
                                    }
                                }
                            }
                        }
                        if (errormessage.Length > 0)
                        {
                            errormessage = errormessage.Substring(1);
                            message = "-- 已上传" + effectRows + "条" + dt.TableName + "利率。<br>";
                            message += "-- 上传" + dt.TableName + "利率时,无法找到银行编号为" + errormessage + "对应的分行。<br>";
                        }
                        else
                        {
                            message = "-- 已上传" + effectRows + "条" + dt.TableName + "利率。<br>";
                        }
                    }
                    break;
                default: break;
            }
            return message;
        }
    }
}
