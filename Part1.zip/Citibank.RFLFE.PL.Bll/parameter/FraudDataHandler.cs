﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class FraudDataHandler : IFraudDataHandler
    {
        #region all Dao
        public IFraudDataDao FraudDataDao { get; set; }
        public IFraudDataMakerDao FraudDataMakerDao { get;set;}
        #endregion

        /// <summary>
        /// Get Fraud data
        /// </summary>
        /// <returns>T_RP_FraudData list</returns>
        public CommonTResult<T_RP_FraudData> GetFraudDataByID(int tid)
        {
            CommonTResult<T_RP_FraudData> result = null;
            CommonTResult<T_RP_FraudData> resultDao = FraudDataDao.GetFraudDataByID(tid);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_FraudData>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        /// <summary>
        /// Get Fraud data maker
        /// </summary>
        /// <returns>T_RP_FraudDataMaker list</returns>
        public CommonTResult<T_RP_FraudDataMaker> GetFraudDataMaker(T_RP_FraudDataMaker entity, int limit, int start)
        {
            CommonTResult<T_RP_FraudDataMaker> result = null;
            CommonTResult<T_RP_FraudDataMaker> resultDao = FraudDataMakerDao.GetFraudDataMaker( entity, limit,  start);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_FraudDataMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        /// <summary>
        /// Add new Fraud maker data
        /// </summary>
        /// <param name="entity">T_RP_FraudDataMaker entity</param>
        /// <returns>TID</returns>
        public CommonResult SaveFraudDataMaker(T_RP_FraudDataMaker entity)
        {
            CommonResult result = new CommonResult();
            int tid = FraudDataMakerDao.SaveFraudDataMaker(entity);
            if (tid>0)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_ADD_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_ADD_FAILED;
            }
            return result;
        }

        /// <summary>
        /// Delete fraund data maker by id
        /// </summary>
        /// <param name="tid">id</param>
        /// <returns>success flag</returns>
        public CommonResult DeleteFraudDataMaker(int tid)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = FraudDataMakerDao.DeleteFraudDataMaker(tid);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_DELETE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_DELETE_FAILED;
            }
            return result;
        }

        /// <summary>
        /// Approve the fraud data maker requests
        /// </summary>
        /// <param name="ids">TIDs which need to approve</param>
        /// <param name="checker">current user</param>
        /// <returns>successed flag</returns>
        public CommonResult ApproveFraudDataMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = FraudDataMakerDao.ApproveFraudDataMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_APPROVE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_APPROVE_FAILED;
            }
            return result;
        }

        /// <summary>
        /// Reject the fraud data maker requests
        /// </summary>
        /// <param name="ids">TIDs which need to approve</param>
        /// <param name="checker">current user</param>
        /// <returns>successed flag</returns>
        public CommonResult RejectFraudDataMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = FraudDataMakerDao.RejectFraudDataMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_REJECT_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_REJECT_FAILED;
            }
            return result;
        }
    }
}
