﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class NgtvDataHandler : INgtvDataHandler
    {
        public INgtvDataDao NgtvDataDao { get; set; }
        /// <summary>
        /// Get Fraud data
        /// </summary>
        /// <returns></returns>
        public CommonTResult<T_RP_NegativeDataMaker> GetNgtvData(int start, int limit, string CustName, string CompanyName, string AgentName, string IDNo, string DOB, string SalesName, string OtherCertID, string Reason, string Status)
        {
            CommonTResult<T_RP_NegativeDataMaker> result = null;
            CommonTResult<T_RP_NegativeDataMaker> resultDao = NgtvDataDao.GetNgtvData(start,limit,CustName, CompanyName, AgentName, IDNo, DOB, SalesName, OtherCertID, Reason, Status);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_NegativeDataMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_RP_NegativeDataCheckerView> GetNgtvDataByID(int TID)
        {
            return NgtvDataDao.GetNgtvDataByID(TID);
        }

        public CommonTResult<T_RP_NegativeDataMaker> AddDoc(T_RP_NegativeDataMaker entity,string soeID)
        {
            CommonTResult<T_RP_NegativeDataMaker> result = null;
            CommonTResult<T_RP_NegativeDataMaker> resultDao = NgtvDataDao.AddDoc(entity, soeID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_NegativeDataMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.OPERATION_ADD_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_RP_NegativeDataMaker> UpdateDoc(T_RP_NegativeDataMaker entity, string soeID)
        {
            CommonTResult<T_RP_NegativeDataMaker> result = null;
            CommonTResult<T_RP_NegativeDataMaker> resultDao = NgtvDataDao.UpdateDoc(entity,soeID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_NegativeDataMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.UPTDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_RP_NegativeDataMaker> DeleteDoc(string TID, string soeID)
        {
            CommonTResult<T_RP_NegativeDataMaker> result = null;
            CommonTResult<T_RP_NegativeDataMaker> resultDao = NgtvDataDao.DeleteDoc(TID,soeID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_RP_NegativeDataMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.OPERATION_DELETE_SUCCESS
                };
            }
            return result;
        }
    }
}
