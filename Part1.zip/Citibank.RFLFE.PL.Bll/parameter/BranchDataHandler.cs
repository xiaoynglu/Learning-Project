﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class BranchDataHandler :  IBranchDataHandler
    {
        public IBranchMakerDao BranchMakerDao { get; set; }

        public Entities.CommonTResult<Entities.T_Sys_BranchMaker> GetBranchDataMaker(Entities.T_Sys_BranchMaker entity, int limit, int start)
        {
            CommonTResult<T_Sys_BranchMaker> result = null;
            CommonTResult<T_Sys_BranchMaker> resultDao = BranchMakerDao.GetBranchDataMaker(entity, limit, start);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_Sys_BranchMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_Sys_BranchMaker> GetSysBranchPendingChecker(Entities.T_Sys_BranchMaker entity, int limit, int start)
        {
            CommonTResult<T_Sys_BranchMaker> result = null;
            CommonTResult<T_Sys_BranchMaker> resultDao = BranchMakerDao.GetSysBranchPendingChecker(entity, limit, start);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_Sys_BranchMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonResult UpdateBranchDataMaker(T_Sys_BranchMaker entity)
        {
            CommonResult result = new CommonResult();
            int tid = BranchMakerDao.UpdateBranchDataMaker(entity);
            if (tid > 0)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_UPDATE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_UPDATE_FAILED;
            }
            return result;
        }

        public CommonResult ApproveBranchDataMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = BranchMakerDao.ApproveBranchDataMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_APPROVE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_APPROVE_FAILED;
            }
            return result;
        }

        public CommonResult RejectBranchDataMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = BranchMakerDao.RejectBranchDataMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_REJECT_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_REJECT_FAILED;
            }
            return result;
        }

        public CommonTResult<T_PL_BranchCompanyMaker> GetBranchCompanyMaker(T_PL_BranchCompanyMaker entity, int limit, int start)
        {
            CommonTResult<T_PL_BranchCompanyMaker> result = null;
            CommonTResult<T_PL_BranchCompanyMaker> resultDao = BranchMakerDao.GetBranchCompanyMaker(entity, limit, start);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_BranchCompanyMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonResult MergeBranchCompanyMaker(T_PL_BranchCompanyMaker view)
        {
            CommonResult result = new CommonResult();
            int tid = BranchMakerDao.MergeBranchCompanyMaker(view);
            if (tid > 0)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_UPDATE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_UPDATE_FAILED;
            }
            return result;
        }

        public CommonResult ApproveBranchCompanyMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = BranchMakerDao.ApproveBranchCompanyMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_APPROVE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_APPROVE_FAILED;
            }
            return result;
        }

        public CommonResult RejectBranchCompanyMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = BranchMakerDao.RejectBranchCompanyMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_REJECT_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_REJECT_FAILED;
            }
            return result;
        }

        public CommonResult DeleteBranchCompanyMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = BranchMakerDao.DeleteBranchCompanyMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_DELETE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_DELETE_FAILED;
            }
            return result;
        }

        public CommonTResult<T_PL_EvaluationCompanyMaker> GetEvaluationCompanyMaker(T_PL_EvaluationCompanyMaker entity, int limit, int start)
        {
            CommonTResult<T_PL_EvaluationCompanyMaker> result = null;
            CommonTResult<T_PL_EvaluationCompanyMaker> resultDao = BranchMakerDao.GetEvaluationCompanyMaker(entity, limit, start);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_EvaluationCompanyMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonResult MergeBranchEvaluationCompanyMaker(T_PL_EvaluationCompanyMaker view)
        {
            CommonResult result = new CommonResult();
            int tid = BranchMakerDao.MergeBranchEvaluationCompanyMaker(view);
            if (tid > 0)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_UPDATE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_UPDATE_FAILED;
            }
            return result;
        }

        public CommonResult ApproveBranchEvaluationCompanyMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = BranchMakerDao.ApproveBranchEvaluationCompanyMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_APPROVE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_APPROVE_FAILED;
            }
            return result;
        }

        public CommonResult RejectBranchEvaluationCompanyMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = BranchMakerDao.RejectBranchEvaluationCompanyMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_REJECT_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_REJECT_FAILED;
            }
            return result;
        }

        public CommonResult DeleteBranchEvaluationCompanyMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            bool hasEffectRows = BranchMakerDao.DeleteBranchEvaluationCompanyMaker(ids, checker);
            if (hasEffectRows)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_DELETE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message = StringResources.OPERATION_DELETE_FAILED;
            }
            return result;
        }

        public IList<T_Sys_Branch> GetBranchNamesMaker()
        {
            return BranchMakerDao.GetBranchNamesMaker();
        }
    }
}
