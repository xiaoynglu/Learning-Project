﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.parameter
{
    public class BranchCreationCheckerHandler : IBranchCreationCheckerHandler
    {
        public IBranchCreationCheckerDao BranchCreationCheckerDao { get; set; }

        public CommonTResult<T_Sys_BranchMaker> GetBranch(int start, int limit, string BranchCode, string BranchName, string Status, string SoeID)
        {
            CommonTResult<T_Sys_BranchMaker> result = null;
            CommonTResult<T_Sys_BranchMaker> resultDao = BranchCreationCheckerDao.GetBranch(start,limit,BranchCode, BranchName, Status, SoeID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_Sys_BranchMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<ComboboxEntity> GetBranchName()
        {
            CommonTResult<ComboboxEntity> result = null;
            CommonTResult<ComboboxEntity> resultDao = BranchCreationCheckerDao.GetBranchName();
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<ComboboxEntity>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public bool RejectData(string TID, string approveresult, string SoeID)
        {
            return BranchCreationCheckerDao.RejectData(TID, approveresult, SoeID); 
        }

        public bool ApproveData(string TID, string approveresult, string SoeID)
        {
            return BranchCreationCheckerDao.ApproveData(TID, approveresult, SoeID); 
        }

       

    }
}
