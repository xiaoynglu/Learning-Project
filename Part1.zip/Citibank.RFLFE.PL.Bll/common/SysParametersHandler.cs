﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using System.Reflection;
using System.Timers;
using System.Web;
using CommonUtility = Citibank.RFLFE.PL.Framework.CommonUtility;

namespace Citibank.RFLFE.PL.Bll.common
{
    public class SysParametersHandler : ISysParametersHandler
    {
        public ISysParametersDao SysParametersDao { get; set; }
        private System.Timers.Timer AutoDayTimer;
        Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);

        public IList<T_Sys_Parameters> GetSysParamListByParamDesc(string paramDesc)
        {
            var paramId = ParamKeyDictionary.paramsDictionary[paramDesc].ToString();
            var paramsList = HttpRuntime.Cache.Get(paramId);
            if (paramsList == null)
            {
                if (HttpRuntime.Cache.Count == 0) {
                    SetParametersCache();
                }
                return SysParametersDao.GetSysParamListByID(paramId);
            }
            else {
                return (IList<T_Sys_Parameters>)paramsList;
            }
            
        }

        public IList<T_Sys_Parameters> GetSysParamListByID(string paramID)
        {
            var paramsList = HttpRuntime.Cache.Get(paramID);
            if (paramsList == null)
            {
                if (HttpRuntime.Cache.Count == 0)
                {
                    SetParametersCache();
                }
                return SysParametersDao.GetSysParamListByID(paramID);
            }
            else
            {
                return (IList<T_Sys_Parameters>)paramsList;
            }

            return SysParametersDao.GetSysParamListByID(paramID);
        }

        public IList<T_Sys_Parameters> GetSysParamListByIDKey(string paramID, string key)
        {
            return SysParametersDao.GetSysParamListByIDKey(paramID, key);
        }
        
        public IList<T_Sys_Products> GetSysProdNames(int? prodID)
        {
            return SysParametersDao.GetSysProdNames(prodID);
        }
      
        public IList<T_Sys_Branch> GetSysBranchNames(string orgCode)
        {
            return SysParametersDao.GetSysBranchNames(orgCode);
        }

        public IList<T_Sys_Region> GetCities(string parentCode)
        {
            var cityList = HttpRuntime.Cache.Get(parentCode);
            if (cityList == null)
            {
                if (HttpRuntime.Cache.Count == 0)
                {
                    SetParametersCache();
                }
                return SysParametersDao.GetCities(parentCode);
            }
            else
            {
                return (IList<T_Sys_Region>)cityList;
            }
        }

        public IList<T_Sys_Region> GetProvinces()
        {
            var provincesList = HttpRuntime.Cache.Get(ParamKeyDictionary.ProvinceCacheKey);
            if (provincesList == null)
            {
                if (HttpRuntime.Cache.Count == 0)
                {
                    SetParametersCache();
                }
                return SysParametersDao.GetProvinces();
            }
            else
            {
                return (IList<T_Sys_Region>)provincesList;
            }
        }

        public string GetParamKeyByIDAndValue(string paramId,string paramValue)
        {
            return SysParametersDao.GetParamKeyByIDAndValue(paramId,paramValue);
        }

        public string GetRegionCode(string regionName, string parentCode)
        {
            return SysParametersDao.GetRegionCode(regionName, parentCode);
        }
        
        public IList<T_PL_Customers> GetBorrowerNames(Guid appId)
        {
            return SysParametersDao.GetBorrowerNames(appId);
        }
      
        public IList<T_PL_EvaluationCompany> GetEvaluationCompanys()
        {
            return SysParametersDao.GetEvaluationCompanys();
        }

        public IList<T_Sys_Parameters> GetColleraterTypeByPropertyType(string propertyType)
        {
            var colleraterTypeList = SysParametersDao.GetSysParamListByID(Constants.SysParamID.CollateralType);
            List<T_Sys_Parameters> resultList = new List<T_Sys_Parameters>();
            foreach (var item in colleraterTypeList) {
                if (propertyType == "MO") {
                    if (item.Key == "MO1" || item.Key == "MO2" || item.Key == "MO3") {
                        resultList.Add(item);
                    }
                }
                else if (propertyType == "CRE") {
                    if (item.Key == "C") {
                        resultList.Add(item);
                    }
                }
                else if (propertyType == "HE") {
                    if (item.Key == "H")
                    {
                        resultList.Add(item);
                    }
                }
            }
            return resultList;
        }
  
        public void SetParametersCache()
        {
            //菜单
            log.DebugLog("Begin to SetParametersCache 菜单", "SetParametersCache");
            var treeDic = SysParametersDao.GetAllMenuTree();
            foreach (var item in treeDic) {
                //将每一种roleType对应的Menu全都加入到Cache,Key为"TreeMenuRoleType"+RoleType 对应的值
                if (!(HttpRuntime.Cache.Get(ParamKeyDictionary.RoleTypeCacheKeyPrefix + item.Key) != null && HttpRuntime.Cache.Get(ParamKeyDictionary.RoleTypeCacheKeyPrefix + item.Key) != ""))
                {
                    CacheHelper.SetCache((ParamKeyDictionary.RoleTypeCacheKeyPrefix + item.Key), item.Value, Int32.Parse(CommonUtility.GetRefreshCachePeriod()) * 24, 0, 0);
                } 
            }
            log.DebugLog("End to SetParametersCache 菜单", "SetParametersCache");
            log.DebugLog("Begin to SetParametersCache T_SYS_parameters 表", "SetParametersCache");
            //T_SYS_parameters 表
            var parametersList = SysParametersDao.GetAllParamters();
            foreach (var item in parametersList.GroupBy(i=>i.ParamID)) {
                if (!(HttpRuntime.Cache.Get(item.Key) != null && HttpRuntime.Cache.Get(item.Key) != ""))
                {
                    CacheHelper.SetCache(item.Key, item.ToList(), Int32.Parse(CommonUtility.GetRefreshCachePeriod()) * 24, 0, 0);
                }
            }
            log.DebugLog("End to SetParametersCache T_SYS_parameters 表", "SetParametersCache");
            log.DebugLog("Begin to SetParametersCache T_SYS_REGION (省市表)", "SetParametersCache");
            //T_SYS_REGION(省市表)
            var regionList = SysParametersDao.GetAllRegionInfo();
            //市
            foreach (var item in regionList.Where(i=>i.ParentCode!="").GroupBy(i => i.ParentCode))
            {
                if (!(HttpRuntime.Cache.Get(item.Key) != null && HttpRuntime.Cache.Get(item.Key) != ""))
                {
                    CacheHelper.SetCache(item.ToList().FirstOrDefault().ParentCode, item.ToList(), Int32.Parse(CommonUtility.GetRefreshCachePeriod()) * 24, 0, 0);
                }
            }
            log.DebugLog("End to SetParametersCache T_SYS_REGION (省市表)", "SetParametersCache");
            log.DebugLog("Begin to SetParametersCache 省", "SetParametersCache");
            //省
            var provinceList = regionList.Where(i => i.ParentCode == "").ToList();
            if (!(HttpRuntime.Cache.Get(ParamKeyDictionary.ProvinceCacheKey) != null && HttpRuntime.Cache.Get(ParamKeyDictionary.ProvinceCacheKey) != ""))
            {
                CacheHelper.SetCache(ParamKeyDictionary.ProvinceCacheKey, provinceList, Int32.Parse(CommonUtility.GetRefreshCachePeriod()) * 24, 0, 0);
            }
            log.DebugLog("End to SetParametersCache 省", "SetParametersCache");
        }

        public void DayTimerStart()
        {
            log.DebugLog("Begin to Start Timer", "SetParametersCache");
            AutoDayTimer = new System.Timers.Timer(1000 * 60 * 60 * 24);//每天
            AutoDayTimer.Elapsed += new ElapsedEventHandler(AutoDayTimer_Elapsed);
            AutoDayTimer.Enabled = true;
            AutoDayTimer.Start();
            log.DebugLog("AutoDayTimer.Interval: " + Convert.ToString(AutoDayTimer.Interval), "DayTimerStart");
            log.DebugLog("End to Start Timer", "SetParametersCache");
        }

        protected void AutoDayTimer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {   
            try
            {
                log.DebugLog("start to call load cache", "AutoDayTimer_Elapsed");
                SetParametersCache();
                log.DebugLog("End  to call load cache", "AutoDayTimer_Elapsed");
            }
            catch (Exception ex)
            {
                log.ErrorLog(ex, "AutoDayTimer_Elapsed");
            }
        }

    }
}
