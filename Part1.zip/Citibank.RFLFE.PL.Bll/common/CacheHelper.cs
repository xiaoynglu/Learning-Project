﻿using System;
using System.Web;


namespace Citibank.RFLFE.PL.Bll
{
    
    #region CacheHelper
    public class CacheHelper
    {
        /// <summary>
        /// 构造器
        /// </summary>
        public CacheHelper() { }

        /// <summary>
        /// 获取值根据键
        /// </summary>
        /// <param name="key">键</param>
        /// <returns>值</returns>
        #region GetCache
        public static object GetCache(string key)
        {
            return HttpRuntime.Cache.Get(key);
        }
        #endregion

        /// <summary>
        /// 设置缓存键值对
        /// </summary>
        /// <param name="key">键</param>
        /// <param name="value">值</param>
        /// <param name="day">天数</param>
        /// <param name="hours">小时</param>
        /// <param name="minutes">分钟</param>
        /// <param name="seconds">秒数</param>
        #region SetCache
        public static void SetCache(string key, object value, int days, int hours, int minutes, int seconds)
        {
            HttpRuntime.Cache.Insert(key
                    , value
                    , null
                    , DateTime.Now.AddDays(days).AddHours(hours).AddMinutes(minutes).AddSeconds(seconds)
                    , TimeSpan.Zero);

        }
        #endregion

        /// <summary>
        /// 设置缓存键值对
        /// </summary>
        /// <param name="key">键</param>
        /// <param name="value">值</param>
        /// <param name="hours">小时</param>
        /// <param name="minutes">分钟</param>
        /// <param name="seconds">秒数</param>
        #region SetCache
        public static void SetCache(string key, object value, int hours, int minutes, int seconds)
        {
            HttpRuntime.Cache.Insert(key
                  , value
                  , null
                  , DateTime.Now.AddHours(hours).AddMinutes(minutes).AddSeconds(seconds)
                  , TimeSpan.Zero);

        }
        #endregion

        /// <summary>
        /// 设置缓存键值对
        /// </summary>
        /// <param name="key">键</param>
        /// <param name="value">值</param>
        /// <param name="minutes">分钟</param>
        /// <param name="seconds">秒数</param>
        #region SetCache
        public static void SetCache(string key, object value, int minutes, int seconds)
        {
            if (!string.IsNullOrEmpty(key)
                && value != null)
            {
                HttpRuntime.Cache.Insert(key
                  , value
                  , null
                  , DateTime.Now.AddMinutes(minutes).AddSeconds(seconds)
                  , TimeSpan.Zero);
            }

        }
        #endregion

        /// <summary>
        /// 设置缓存键值对
        /// </summary>
        /// <param name="key">键</param>
        /// <param name="value">值</param>
        /// <param name="seconds">秒数</param>
        #region SetCache
        public static void SetCache(string key, object value, int seconds)
        {
            HttpRuntime.Cache.Insert(key
                  , value
                  , null
                  , DateTime.Now.AddSeconds(seconds)
                  , TimeSpan.Zero);

        }
        #endregion

        /// <summary>
        /// 移除缓存值
        /// </summary>
        /// <param name="key">键</param>
        #region RemoveCache
        public static void RemoveCache(string key)
        {
            HttpRuntime.Cache.Remove(key);
        }
        #endregion

    }
    #endregion
}
