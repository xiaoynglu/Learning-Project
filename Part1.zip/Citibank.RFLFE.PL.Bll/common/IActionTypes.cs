﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Bll.common
{
    public class IActionTypes
    {

        /// <summary>
        /// 提交
        /// </summary>
        public const string Submit = "SUBMIT";

        /// <summary>
        /// 拒绝
        /// </summary>
        public const string Reject = "REJECT";
        /// <summary>
        /// 返回
        /// </summary>
        public const string Return = "RETURN";

        /// <summary>
        /// 通过
        /// </summary>
        public const string Approve = "APPROVE";

        /// <summary>
        /// 未开启
        /// </summary>
        public const string Initiate = "INITIATE";

        /// <summary>
        /// 取消
        /// </summary>
        public const string Cancelled = "CANCEL";

        /// <summary>
        /// 等待
        /// </summary>
        public const string Pending = "PENDING";

        /// <summary>
        /// 开启
        /// </summary>
        public const string Pickup = "PICKUP";

        /// <summary>
        /// 申请复查返回至补充申请信息
        /// </summary>
        public const string ReturnToLoan = "Return to Loan Ops";        //for dbm review in application creation

        /// <summary>
        /// 申请复查返回至申请提交检查
        /// </summary>
        public const string ReturnToCredit = "Return to Loan Officer";    //for dbm review in application creation

        /// <summary>
        /// 回到当前POOL
        /// </summary>
        public const string ReturnToPool = "RETURN TO POOL";    //for dbm review in credit processing 2nd

        /// <summary>
        /// 过账成功
        /// </summary>
        public const string Complete = "COMPLETE";

        /// <summary>
        /// 经理签字至修改付款帐户信息(FR)
        /// </summary>
        public const string ReturnToPayment = "Return to Payment";   //for dbm review from BM Sign-off to Payment Info Revision 

        /// <summary>
        ///退票返回至经理签字 
        /// </summary>
        public const string ReturnToBM = "Return to BM";   //for dbm review from Fund Return to BM Sign-off

        /// <summary>
        /// 退票返回至开户检查
        /// </summary>
        public const string ReturnToCheck = "Return to Check";  //for dbm review from Fund Return to Disbursement Check

        /// <summary>
        /// 第二审批至正式评估报告(HE)
        /// </summary>
        public const string ApproveToCall = "Approve to Call";  //for second approve to call full Valuation

        /// <summary>
        /// 批量解锁
        /// </summary>
        public const string Unlocked = "RETURN TO POOL(BM)";

        /// <summary>
        /// 放款开户回退1stApprove
        /// </summary>
        public const string ReturnTo1ST = "Return to 1ST";


        //added by wangzheng 2008/12/30
        /// <summary>
        /// 申请复查到异常审批
        /// </summary>
        public const string SubmitToPDA = "SUBMIT TO PDA";

        /// <summary>
        /// 重新激活拒绝的申请
        /// </summary>
        public const string RetrieveReject = "RETRIEVE REJECT";

        /// <summary>
        /// 重新激活取消的申请
        /// </summary>
        public const string RetrieveCancel = "RETRIEVE CANCEL";

        public const string ReturnCustacceptance = "RETURN TO CustAcceptance";

        public const string ReturnDBMRivew = "RETURN TO DBMRivew";

        public const string ReturnDisburseReview = "RETURN TO DisburseRivew";

        public const string ReturnToTopupVerification = "Return to Topup Verification";
    }
}
