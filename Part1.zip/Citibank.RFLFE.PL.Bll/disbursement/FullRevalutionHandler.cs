﻿using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;
using Contants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;

namespace Citibank.RFLFE.PL.Bll.disbursement
{
    public class FullRevalutionHandler : IFullRevalutionHandler
    {
        public IFullRevalutionDao FullRevalutionDao { get; set; }

        public CommonTResult<FullRevalutionView> GetFullRevalutionView(int start, int limit, string appId)
        {
            CommonTResult<FullRevalutionView> result = null;
            CommonTResult<FullRevalutionView> resultDao = FullRevalutionDao.GetFullRevalutionView(start, limit,appId);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<FullRevalutionView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

       public  CommonTResult<FullRevalutionValuesView> GetValues(string appid)
        {
            CommonTResult<FullRevalutionValuesView> result = null;
            CommonTResult<FullRevalutionValuesView> resultDao = FullRevalutionDao.GetValues(appid);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<FullRevalutionValuesView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

       public CommonTResult<T_PL_EvaluationCompany> GetEvaluationCompany(string appid)
       {
           CommonTResult<T_PL_EvaluationCompany> result = null;
           CommonTResult<T_PL_EvaluationCompany> resultDao = FullRevalutionDao.GetEvaluationCompany(appid);
           if (resultDao.ResultList != null)
           {
               result = new CommonTResult<T_PL_EvaluationCompany>()
               {
                   ResultList = resultDao.ResultList,
                   ResultCount = resultDao.ResultCount,
                   IsSuccess = true,
                   Message = StringResources.GETDATA_SUCCESS
               };
           }
           return result;
       }

       public bool SaveEvl(T_PL_OralAppraisal entity, string itemoperator)
       {
           return FullRevalutionDao.SaveEvl(entity, itemoperator);          
       }

       public bool DeleteEvl(string TID)
       {
           return FullRevalutionDao.DeleteEvl(TID);
       }

       public bool ApplyEvl(string appid, string TID)
       {
           return FullRevalutionDao.ApplyEvl(appid,TID);
       }

       public bool IsApplied(Guid appid)
       {
           return FullRevalutionDao.IsApplied(appid);
       }

       public int getLoanSizeByPropertyValueMO(Guid appID, decimal buySellPrice, decimal payAmount, decimal tailAmount)
       {
           return FullRevalutionDao.getLoanSizeByPropertyValueMO(appID,buySellPrice,payAmount,tailAmount);
       }
       public int getLoanSizeByPropertyValue(Guid appID)
       {
           return FullRevalutionDao.getLoanSizeByPropertyValue(appID);
       }
       public bool GetISMO(string appid)
       {
           return FullRevalutionDao.GetISMO(appid);
       }
       public long GetCallFullValByAppId(Guid AppId)
       {
           return FullRevalutionDao.GetCallFullValByAppId(AppId);
       }
       public CommonTResult<FullRevalutionApproveView> GetCreditInfo_2ndAppoval(Guid guidAPPID)
       {
           CommonTResult<FullRevalutionApproveView> result = null;
           CommonTResult<FullRevalutionApproveView> resultDao = FullRevalutionDao.GetCreditInfo_2ndAppoval(guidAPPID,Contants.Stage.SecondndApproval);
           if (resultDao.ResultList != null)
           {
               result = new CommonTResult<FullRevalutionApproveView>()
               {
                   ResultList = resultDao.ResultList,
                   ResultCount = resultDao.ResultCount,
                   IsSuccess = true,
                   Message = StringResources.GETDATA_SUCCESS
               };
           }
           return result;
       }

       public CommonTResult<EvlReportListView> GetEvlReportList(string APPIDs)
       {
           CommonTResult<EvlReportListView> result = null;
           CommonTResult<EvlReportListView> resultDao = FullRevalutionDao.GetEvlReportList(APPIDs);
           if (resultDao.ResultList != null)
           {
               result = new CommonTResult<EvlReportListView>()
               {
                   ResultList = resultDao.ResultList,
                   ResultCount = resultDao.ResultCount,
                   IsSuccess = true,
                   Message = StringResources.GETDATA_SUCCESS
               };
           }
           return result;
       }

       public CommonTResult<T_PL_RunResult> GetEvlApprovalList(string appid)
       {
           CommonTResult<T_PL_RunResult> result = null;
           CommonTResult<T_PL_RunResult> resultDao = FullRevalutionDao.GetEvlApprovalList(appid);
           if (resultDao.ResultList != null)
           {
               result = new CommonTResult<T_PL_RunResult>()
               {
                   ResultList = resultDao.ResultList,
                   ResultCount = resultDao.ResultCount,
                   IsSuccess = true,
                   Message = StringResources.GETDATA_SUCCESS
               };
           }
           return result;
       }

       public bool updateAggreateRunResultInCallFullValuation(Guid appID, int newApprovedLoanSize)
       {
           return FullRevalutionDao.updateAggreateRunResultInCallFullValuation(appID,ConvertUtility.Int32TryParse(Contants.PreCheckStageId), newApprovedLoanSize);
       }

       public string GetFirstPercent(string appid, string OrgCode)
       {
           return FullRevalutionDao.GetFirstPercent(appid, OrgCode);
       }

       public bool UpdateFullRevalutionInfo(string appId, string completedYear, string housePrice, string firstPayment, string tailAmount)
       {
           return FullRevalutionDao.UpdateFullRevalutionInfo(appId, completedYear, housePrice,firstPayment,tailAmount);
       }
    }
}
