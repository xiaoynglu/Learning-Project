﻿using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.disbursement
{
    public class DataEntryHandler : IDataEntryHandler
    {
        public IDataEntryDao DataEntryDao { get; set; }
        
        public CommonTResult<DataEntryView> QueryHistoryDataEntry(int start, int limit, DataEntryView entity)
        {
            CommonTResult<DataEntryView> result = null;
            CommonTResult<DataEntryView> resultDao = DataEntryDao.QueryHistoryDataEntry(start, limit, entity);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<DataEntryView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<DataEntryView> QueryWaitDataEntry(int start, int limit, DataEntryView entity)
        {
            CommonTResult<DataEntryView> result = null;
            CommonTResult<DataEntryView> resultDao = DataEntryDao.QueryHistoryDataEntry(start, limit, entity);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<DataEntryView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
    }
}
