﻿using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
namespace Citibank.RFLFE.PL.Bll.disbursement
{
    public class DisburseRegistHandler : IDisburseRegistHandler
    {
        public IDisburseRegistDao DisburseRegistDao { get; set; }
        
        private int FirstDueDay = 10;

        public string GetSecondApproveOPDate(string appId)
        {
            return DisburseRegistDao.GetSecondApproveOPDate(appId);
        }

        public DataTable GetFeeCode(string appid)
        {
            return DisburseRegistDao.GetFeeCode(appid);
        }

        public CommonTResult<T_PL_ALSCOLView> GetALSCOL(string appid, bool istopup, string productname)
        {
            return DisburseRegistDao.GetALSCOL(appid, istopup, productname);
        }

        public Dictionary<string, string> GetFeeData(string appid)
        {
            return DisburseRegistDao.GetFeeData(appid);
        }
        
        public bool IsTopupBatch(string appid)
        {
            return DisburseRegistDao.IsTopupBatch(appid);
        }
        
        public DataTable GetParamForCLMS(string appid)
        {
            return DisburseRegistDao.GetParamForCLMS(appid);
        }
        
        public string GetAppNoByAppId(string appId)
        {
            return DisburseRegistDao.GetAppNoByAppId(appId);
        }
        public decimal GetCallFullValByAppId(string appId)
        {
            return DisburseRegistDao.GetCallFullValByAppId(appId);
        }
        
        public string GetOwnerByAppID(string appId)
        {
            return DisburseRegistDao.GetOwnerByAppID(appId);
        }
       
        public DataTable GetCollateral(string appid)
        {
            return DisburseRegistDao.GetCollateral(appid);
        }
       
        public string GetProvinceByCode(string procode)
        {
            return DisburseRegistDao.GetProvinceByCode(procode);
        }
       
        public string GetCityByCode(string procode, string citycode)
        {
            return DisburseRegistDao.GetCityByCode(procode,citycode);
        }
       
        public string GetNewLoanSize(string AppID)
        {
            return DisburseRegistDao.GetNewLoanSize(AppID); 
        }
       
        public bool SaveCLMS(T_PL_CLMSHandover entity)
        {
            return DisburseRegistDao.SaveCLMS(entity);
        }
       
        public void SetCLMSDate(string appid)
        {
            DisburseRegistDao.SetCLMSDate(appid);
        }

        public Dictionary<string, string> GetDetails(string appid)
        {
            
            return DisburseRegistDao.GetDetails(appid);
        }

        public bool DoProcess(string islock,string appid,string soeid,string appno,string stageid)
        {            
            return DisburseRegistDao.DoProcess(islock,appid,soeid,appno,stageid);
        }

        public DataTable GetALsShowInfo(string appid)
        {
            return DisburseRegistDao.GetALsShowInfo(appid);
        }

        public Dictionary<string, string> GetCountPackage(string appid)
        {
            return DisburseRegistDao.GetCountPackage(appid);
        }

        public CustNOForDisburseView GetCustNOs(string appid)
        {
            return DisburseRegistDao.GetCustNOs(appid);
        }

        public CommonTResult<T_PL_EclipseHandover> ExportReport(string IDType, string appid)
        {
            CommonTResult<T_PL_EclipseHandover> result = null;
            CommonTResult<T_PL_EclipseHandover> resultDao = DisburseRegistDao.ExportReport(IDType,appid);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_EclipseHandover>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result; 
        }
       
        public bool SaveNumber(string appId, string customerNumber,string custID, string co1CustNumber,string cust1ID, string co2CustNumber,string cust2ID, string GuaNo,string GuaID, string relationshipNumber, string Mo1No,string Mo1ID, string Mo2No,string Mo2ID, string Mo3No,string Mo3ID)
        { 
            return DisburseRegistDao.SaveNumber( appId,  customerNumber, custID,  co1CustNumber, cust1ID,  co2CustNumber, cust2ID,  GuaNo, GuaID,  relationshipNumber,  Mo1No, Mo1ID,  Mo2No, Mo2ID,  Mo3No, Mo3ID);
        }

        public void GenerateALS(string appId, string accOpenDate)
        {
            string lineId, collateralId, custNo, relnNo;
            lineId = collateralId = custNo = relnNo = string.Empty;
            string prodId = "0";

            CommonTResult<T_PL_CLMSHandover> dt_clms = DisburseRegistDao.GetCLMS(appId);

            if (dt_clms.ResultList.Count > 0)
            {
                lineId = dt_clms.ResultList[0].LineID;
                collateralId = dt_clms.ResultList[0].CollateralID;
            }
            CommonTResult<ApplicationInofView> dt_app = DisburseRegistDao.GetApplicationInof(appId);
            if (dt_app.ResultList.Count > 0)
            {
                prodId = dt_app.ResultList[0].ProdID == "" ? string.Empty : dt_app.ResultList[0].ProdID;
                custNo = dt_app.ResultList[0].CustNo == "" ? string.Empty : dt_app.ResultList[0].CustNo;
                relnNo = dt_app.ResultList[0].RelnNo == "" ? string.Empty : dt_app.ResultList[0].RelnNo;
            }

            if ((prodId ==Constants.ProdID.UPL_ID.ToString() || !string.IsNullOrEmpty(lineId)) && !string.IsNullOrEmpty(custNo) && !string.IsNullOrEmpty(relnNo))
            {
                DisburseRegistDao.SaveAccOpenDate(appId, accOpenDate);

                bool IsTopup = DisburseRegistDao.IsTopupBatch(appId.ToString());

                if (DisburseRegistDao.GetProductName(appId) ==Constants.ProdName.UPL)
                {
                    this.InitALSUPL(appId, custNo, relnNo, lineId, collateralId, IsTopup, prodId);
                }
                else
                {
                    this.InitALSHE(appId, custNo, relnNo, lineId, collateralId, IsTopup, prodId);
                }
            }
        }

        public CommonTResult<DisburseItemDetail> GetItemDetailInfo(string appid, string itemtype, string itemid)
        {
            DataTable dt = DisburseRegistDao.GetItemDetailInfo(appid,itemtype,itemid);
            List<DisburseItemDetail> rlist = new List<DisburseItemDetail>();
            foreach (DataRow dr in dt.Rows)
            { 
                DisburseItemDetail oneitem= new DisburseItemDetail();
                oneitem.column=dr["colname"].ToString();
                oneitem.value=dr["value"].ToString();
                rlist.Add(oneitem);
            }
            CommonTResult<DisburseItemDetail> result = new CommonTResult<DisburseItemDetail>();
            result.ResultList = rlist;
            return result;

        }

        public void SaveDetails(string appid, string remarks, string accopendate, string paymethods)
        {
            DisburseRegistDao.SaveDetails(appid,remarks,accopendate,paymethods);
        }

        private void InitALSHE(string appId, string customerNumber, string relationshipNumber, string lineId, string collateralId, bool IsTopup, string ProdId)    //HE,CRE,MO
        {
            string prodName = string.Empty;

            if (appId != null && appId != string.Empty)
            {
                string soeId = DisburseRegistDao.GetSalesIdByAppID(appId);

                if (string.IsNullOrEmpty(customerNumber) || string.IsNullOrEmpty(relationshipNumber))
                    return;

                string idNumber = string.Empty;
                idNumber = DisburseRegistDao.GetMBCertID(appId);

                decimal baseRate = 0m;

                baseRate = DisburseRegistDao.GetTopUpBaseRate(appId);

                CommonTResult<T_PL_LoanApproval> mapSaleAndAppList = DisburseRegistDao.GetSaleAndAppByAppId(appId);
                T_PL_LoanApproval mapSaleAndApp = new T_PL_LoanApproval();
                if (mapSaleAndAppList.ResultList.Count > 0)
                    mapSaleAndApp = mapSaleAndAppList.ResultList[0];

                CommonTResult<T_PL_EclipseHandover> mapOscarList = DisburseRegistDao.GetOscarByAppId(appId, idNumber);
                T_PL_EclipseHandover mapOscar = new T_PL_EclipseHandover();
                if (mapOscarList.ResultList.Count > 0)
                    mapOscar = mapOscarList.ResultList[0];

                Dictionary<string, string> mapAppProdDtl = DisburseRegistDao.GetAppProdDtlByAppId(appId);
                Dictionary<string, string> mapApplication = DisburseRegistDao.GetApplicationMap(appId);

                T_PL_ALS_COL mapALS = new T_PL_ALS_COL();
                

                mapALS.AppID = new Guid(appId);
                mapALS.ProductCode = DisburseRegistDao.GetProdCodeByAppId(appId);
                mapALS.LoanAmount = mapSaleAndApp.ApprovedLoanSize;
                if (mapAppProdDtl["PRODID"] == Constants.ProdID.MO_ID.ToString())// for MO
                {
                    mapALS.InterestRate = mapSaleAndApp.InterestRate / baseRate;
                }
                else
                {
                    mapALS.InterestRate = mapSaleAndApp.InterestRate - baseRate;//mapSaleAndApp.RateForYear;
                }
                mapALS.CustomerNumber = customerNumber;
                mapALS.RelationshipNumber = relationshipNumber;
               // mapALS.RCNumber = DisburseRegistDao.GetRCNumberByAppId(appId);
                mapALS.RCNumber = DisburseRegistDao.GetRCNumberByAppId(appId);                
                mapALS.SegmentID = DisburseRegistDao.GetSegmentID(appId.ToString(), soeId);
                mapALS.IndustryCode = mapOscar.IndustryCode;
                mapALS.Purpose = DisburseRegistDao.GetLoanPurpose(appId);
                mapALS.SourceCode = DisburseRegistDao.GetSourceCode(soeId, appId);
                mapALS.AgentCode = DisburseRegistDao.GetAgentCodeByAppId(appId);
                mapALS.CityCode = DisburseRegistDao.GetALSCityCodeBySoeId(soeId);
                mapALS.IncomeType = DisburseRegistDao.GetALSIncomeType(appId);
                mapALS.EmployerCD = DisburseRegistDao.GetALSEmployerCD(appId);

                if (mapAppProdDtl != null)
                {
                    mapALS.CACSCity = mapAppProdDtl["CACSCityCode"];

                    mapALS.CACSLoc = mapAppProdDtl["CACSLocCode"];

                    prodName = DisburseRegistDao.GetProdName(appId);

                    decimal rateACF = Convert.ToDecimal(Double.Parse(mapSaleAndApp.InterestRate.ToString()) * 1.5);

                    //mapALS.ACF = Math.Round(rateACF, 2, MidpointRounding.AwayFromZero);
                    mapALS.ACF = rateACF;

                    mapALS.Rate_Index = mapAppProdDtl["RateIndex"];
                }
                if (mapApplication != null)
                {
                    if (!string.IsNullOrEmpty(mapApplication["SigningDate"]))
                    {
                        mapALS.ContractDate = Convert.ToDateTime( mapApplication["SigningDate"].Trim()).ToString(Constants.DateTimeFormat.DateTimeFormat8);

                        DateTime conDate = DateTime.Now;
                        DateTime maturityDate = DateTime.Now;
                        DateTime firstDueDate = DateTime.Now;

                        string accOpendate = mapApplication["AccOpenDate"];

                        if (accOpendate.Contains("/"))
                        {
                            string[] strSplit = accOpendate.Split('/');

                            if (strSplit.Length == 3)
                            {
                                accOpendate = strSplit[2] + "-" + strSplit[1] + "-" + strSplit[0];
                            }
                        }

                        DateTime.TryParse(accOpendate, out conDate);

                        int firstYear = conDate.Year;
                        int firsMonth = 1;
                        int firstDay = this.FirstDueDay;
                        if (conDate.Day >= 1 && conDate.Day <= 15)
                        {
                            if (conDate.Month == 12)
                            {
                                firsMonth = 1;
                                firstYear = conDate.Year + 1;
                            }
                            else
                                firsMonth = conDate.Month + 1;
                        }
                        else
                        {
                            if (conDate.Month == 11)
                                firsMonth = 1;
                            if (conDate.Month == 12)
                                firsMonth = 2;
                            if (conDate.Month < 11)
                                firsMonth = conDate.Month + 2;
                            else
                                firstYear = conDate.Year + 1;
                        }
                        firstDueDate = new DateTime(firstYear, firsMonth, firstDay);

                        mapALS.FirstDueDate = Convert.ToDateTime(firstDueDate.Date.ToString()).ToString(Constants.DateTimeFormat.DateTimeFormat8);

                        int aTenor = mapSaleAndApp.ApprovedLoanTenor!=""?Int32.Parse(mapSaleAndApp.ApprovedLoanTenor):0;
                        
                        maturityDate = (aTenor == 0) ? firstDueDate : firstDueDate.AddMonths(aTenor - 1);

                        mapALS.MaturityDate = Convert.ToDateTime(maturityDate.Date.ToString()).ToString(Constants.DateTimeFormat.DateTimeFormat8);
                    }
                }
                mapALS.AccountNumber = GenerateAccountNumber(soeId, appId);

                T_PL_Collateral mapColl = DisburseRegistDao.GetCollByAppId(appId);

                mapALS.PropertyAddress1 = mapColl.Region;
                mapALS.PropertyAddress2 = mapColl.CommunityName;
                mapALS.PropertyAddress3 = mapColl.Address;

                decimal outLoanProceeds = 0;
                decimal.TryParse(DisburseRegistDao.GetLastLoan(appId), out outLoanProceeds);
                mapALS.LoanProceeds = outLoanProceeds;

                mapALS.Term = mapSaleAndApp.ApprovedLoanTenor!=""?Int32.Parse(mapSaleAndApp.ApprovedLoanTenor):0;

                mapALS.PrimBranch = DisburseRegistDao.GetOrgRcCodeBySoeId(soeId);
               // mapALS.FI1 = mapApplication.InsuranceFee;

                //Add TopUp and Loan Industry Info

                DataTable TopUpDt = DisburseRegistDao.IsTopUp(appId);

                if (TopUpDt != null && TopUpDt.Rows.Count > 0)
                {
                    mapALS.OriginalAccNo = Convert.ToInt64(TopUpDt.Rows[0]["Orgloannumber"]);
                    mapALS.OriginalSegmentId = Convert.ToInt64(TopUpDt.Rows[0]["orgsegment"]);
                }

                string SubLoanIndustry = DisburseRegistDao.GetLoanIndustry(appId);

                if (!String.IsNullOrEmpty(SubLoanIndustry))
                {
                    mapALS.LoanDirection = Convert.ToInt32(SubLoanIndustry);
                }
                //TopUp and Loan Industry Ending

                if (mapApplication["PayType"].Equals(Constants.PayTypeValue.A))    //受托支付
                {
                    mapALS.DisbursementMethod =Constants.DisbursementMethodValue.E;
                }
                else if (mapApplication["PayType"].Equals(Constants.PayTypeValue.B))    //部分受托支付
                {
                    mapALS.DisbursementMethod = Constants.DisbursementMethodValue.P;
                }
                else if (mapApplication["PayType"].Equals(Constants.PayTypeValue.C))    //自主支付
                {
                    mapALS.DisbursementMethod = string.Empty;
                }

                mapALS.LineID = lineId;
                mapALS.CollateralID = collateralId;

                DisburseRegistDao.SaveALSHE(mapALS);
            }
        }

        private void InitALSUPL(string appId, string customerNumber, string relationshipNumber, string lineId, string collateralId, bool IsTopup, string prodId)
        {
            string soeId = DisburseRegistDao.GetSalesIdByAppID(appId);

            if (string.IsNullOrEmpty(customerNumber) || string.IsNullOrEmpty(relationshipNumber))
                return;
            string idNumber = string.Empty;
            idNumber = DisburseRegistDao.GetMBCertID(appId);
            decimal baseRate = 0m;
            baseRate = DisburseRegistDao.GetTopUpBaseRate(appId);
            
            CommonTResult<T_PL_LoanApproval> mapSaleAndAppList = DisburseRegistDao.GetSaleAndAppByAppId(appId);
            T_PL_LoanApproval mapSaleAndApp=new T_PL_LoanApproval();
            if(mapSaleAndAppList.ResultList.Count>0)
                mapSaleAndApp=mapSaleAndAppList.ResultList[0];

            CommonTResult<T_PL_EclipseHandover> mapOscarList = DisburseRegistDao.GetOscarByAppId(appId, idNumber);
            T_PL_EclipseHandover mapOscar = new T_PL_EclipseHandover();
            if (mapOscarList.ResultList.Count > 0)
                mapOscar = mapOscarList.ResultList[0];

            Dictionary<string, string> mapAppProdDtl = DisburseRegistDao.GetAppProdDtlByAppId(appId);
            Dictionary<string, string> mapApplication = DisburseRegistDao.GetApplicationMap(appId);

            T_PL_ALS_UPL mapALS = new T_PL_ALS_UPL();
            //CitiBank.LFE.DataMapping.FM.Map_T_Application mapApplication = this.GetApplicationMap(appId);

            mapALS.AppID = new Guid(appId);
            mapALS.ProductCode = DisburseRegistDao.GetProdCodeByAppId(appId);
            mapALS.LoanAmount = mapSaleAndApp.ApprovedLoanSize.ToString();
            mapALS.InterestRate = (mapSaleAndApp.InterestRate - baseRate).ToString();
            mapALS.CustomerNumber = customerNumber;
            mapALS.RelationshipNumber = relationshipNumber;
            mapALS.RCNumber = DisburseRegistDao.GetRCNumberByAppId(appId);
            mapALS.IndustryCode = mapOscar.IndustryCode;
            mapALS.Purpose = DisburseRegistDao.GetLoanPurpose(appId);
            mapALS.SegmentID = DisburseRegistDao.GetSegmentID(appId.ToString(), soeId);
            mapALS.SourceCode = DisburseRegistDao.GetSourceCode(soeId, appId);
            mapALS.AgentCode = DisburseRegistDao.GetAgentCodeByAppId(appId);
            mapALS.IncomeType = DisburseRegistDao.GetALSIncomeType(appId);
            mapALS.EmployerCD = DisburseRegistDao.GetALSEmployerCD(appId);
            mapALS.CityCode = DisburseRegistDao.GetALSCityCodeBySoeId(soeId);

            if (mapAppProdDtl != null)
            {
                mapALS.CACSCity = mapAppProdDtl["CACSCityCode"];
                mapALS.CACSLoc = mapAppProdDtl["CACSLocCode"];

                decimal rateACF = Convert.ToDecimal(Double.Parse(mapSaleAndApp.InterestRate.ToString()) * 1.5);
                //mapALS.ACF = Math.Round(rateACF, 2, MidpointRounding.AwayFromZero);
                mapALS.ACF = rateACF.ToString();
                mapALS.RateIndex = mapAppProdDtl["RateIndexCode"];
            }
            if (mapApplication != null)
            {
                if (!string.IsNullOrEmpty(mapApplication["SigningDate"]))
                {
                    mapALS.ContractDate = Convert.ToDateTime(mapApplication["SigningDate"].Trim()).ToString(Constants.DateTimeFormat.DateTimeFormat8);

                    DateTime conDate = DateTime.Now;
                    DateTime maturityDate = DateTime.Now;
                    DateTime firstDueDate = DateTime.Now;

                    string accOpendate = mapApplication["AccOpenDate"];

                    if (accOpendate.Contains("/"))
                    {
                        string[] strSplit = accOpendate.Split('/');
                        if (strSplit.Length == 3)
                        {
                            accOpendate = strSplit[2] + "-" + strSplit[1] + "-" + strSplit[0];
                        }
                    }

                    DateTime.TryParse(accOpendate, out conDate);

                    int firstYear = conDate.Year;
                    int firsMonth = 1;
                    int firstDay = this.FirstDueDay;
                    if (conDate.Day >= 1 && conDate.Day <= 15)
                    {
                        if (conDate.Month == 12)
                        {
                            firsMonth = 1;
                            firstYear = conDate.Year + 1;
                        }
                        else
                            firsMonth = conDate.Month + 1;
                    }
                    else
                    {
                        if (conDate.Month == 11)
                            firsMonth = 1;
                        if (conDate.Month == 12)
                            firsMonth = 2;
                        if (conDate.Month < 11)
                            firsMonth = conDate.Month + 2;
                        else
                            firstYear = conDate.Year + 1;
                    }
                    firstDueDate = new DateTime(firstYear, firsMonth, firstDay);
                    mapALS.FirstDueDate = Convert.ToDateTime(firstDueDate.Date.ToString()).ToString(Constants.DateTimeFormat.DateTimeFormat8);

                    int aTenor = mapSaleAndApp.ApprovedLoanTenor!=""?Int32.Parse(mapSaleAndApp.ApprovedLoanTenor):0;                    

                    maturityDate = (aTenor == 0) ? firstDueDate : firstDueDate.AddMonths(aTenor - 1);
                    mapALS.MaturityDate = Convert.ToDateTime(maturityDate.Date.ToString()).ToString(Constants.DateTimeFormat.DateTimeFormat8);
                }
            }
            mapALS.AccountNumber = this.GenerateAccountNumber(soeId, appId);

            decimal outLoanProceeds = 0;

            decimal.TryParse(DisburseRegistDao.GetLastLoan(appId), out outLoanProceeds);
            mapALS.LoanProceeds = outLoanProceeds.ToString();
            mapALS.Term = mapSaleAndApp.ApprovedLoanTenor.ToString();
            mapALS.PrimBranch = DisburseRegistDao.GetOrgRcCodeBySoeId(soeId);

            //Add TopUp and Loan Industry Info
            DataTable TopUpDt = DisburseRegistDao.IsTopUp(appId);

            if (TopUpDt != null && TopUpDt.Rows.Count > 0)
            {
                mapALS.OriginalAccNo = Convert.ToInt64(TopUpDt.Rows[0]["OrgLoanNumber"]);
                mapALS.OriginalSegmentId = Convert.ToInt64(TopUpDt.Rows[0]["OrgSegment"]);
            }

            string SubLoanIndustry = DisburseRegistDao.GetLoanIndustry(appId);

            if (!String.IsNullOrEmpty(SubLoanIndustry))
            {
                mapALS.LoanDirection = Convert.ToInt32(SubLoanIndustry);
            }
            //TopUp and Loan Industry Ending

            if (mapApplication["PayType"].Equals(Constants.PayTypeValue.A))    //受托支付
            {
                mapALS.DisbursementMethod = Constants.DisbursementMethodValue.E;
            }
            else if (mapApplication["PayType"].Equals(Constants.PayTypeValue.B))    //部分受托支付
            {
                mapALS.DisbursementMethod = Constants.DisbursementMethodValue.P;
            }
            else if (mapApplication["PayType"].Equals(Constants.PayTypeValue.C))    //自主支付
            {
                mapALS.DisbursementMethod = string.Empty;
            }

            mapALS.LineID = lineId;
            mapALS.CollateralID = collateralId;

            DisburseRegistDao.SaveALSUPL(mapALS);
        }

        private string GenerateAccountNumber(string soeId, string appId)
        {
            string ean = DisburseRegistDao.GetExisitAccountNumber(appId);
            if (string.IsNullOrEmpty(ean))
            {
                string digit = DisburseRegistDao.GetCityCodeBySoeId(soeId);
                digit = "3" + digit;
                string branch = DisburseRegistDao.GetBranchCodeByAppId(appId);
                branch = branch.Substring(branch.Length - 2);
                int nouse = 0;
                if (!int.TryParse(branch, out nouse))
                {
                    string tempBranch = DisburseRegistDao.GetAppNoByAppId(appId.ToString()).Substring(2, 2);
                    if (int.TryParse(tempBranch, out nouse))
                    {
                        branch = tempBranch;
                    }
                    else
                        branch = "01";
                }

                string prodType = DisburseRegistDao.GetProdTypeByAppID(appId);

                string sequence = GetAccountSequence(digit + branch);

                string sum = digit + branch + prodType + sequence;
                char[] sums = sum.ToCharArray();
                int nSum = 0;
                foreach (char ch in sums)
                {
                    nSum += int.Parse(ch.ToString());
                }
                string check = nSum.ToString().Substring(nSum.ToString().Length - 1);
                return sum + check;
            }
            else
            {
                return ean;
            }
        }

        public static object instance;

        public string GetAccountSequence(string code)
        {
            try
            {
                lock (instance)
                {
                    string preSeq = DisburseRegistDao.GetSequence(code);
                    string currSeq;
                    if (preSeq == "")
                    {
                        currSeq = "000001";
                    }
                    else
                    {
                        int nPreSeq = int.Parse(preSeq);
                        if (nPreSeq < 999999)
                        {
                            nPreSeq++;
                            currSeq = nPreSeq.ToString().PadLeft(6, '0');
                        }
                        else
                            return "";
                    }
                    DisburseRegistDao.SaveAccountNumber(code, currSeq);
                    return currSeq;
                }
            }
            catch
            {
                return "";
            }
        }

        public CommonTResult<ApplicationInofView> GetApplicationInof(string appid)
        {
            CommonTResult<ApplicationInofView> result = null;
            CommonTResult<ApplicationInofView> resultDao = DisburseRegistDao.GetApplicationInof(appid);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<ApplicationInofView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result; 
        }

        public CommonTResult<T_PL_EclipseHandover> GetEclipse(string AppId)
        {
            CommonTResult<T_PL_EclipseHandover> result = null;
            CommonTResult<T_PL_EclipseHandover> resultDao = DisburseRegistDao.GetEclipse(AppId);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_EclipseHandover>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result; 
        }

        public string GetProdName(string appid)
        {
            return DisburseRegistDao.GetProdName(appid);
        }

        public CommonTResult<T_PL_CLMSHandover> GetCLMS(string AppId)
        {
            CommonTResult<T_PL_CLMSHandover> result = null;
            CommonTResult<T_PL_CLMSHandover> resultDao = DisburseRegistDao.GetCLMS(AppId);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_CLMSHandover>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public string GetExpireDay(string appid)
        {
            return DisburseRegistDao.GetExpireDay(appid);
        }
        
        public CommonTResult<T_PL_ALSView> GetALS(string appid, bool istopup, string productname)
        {
            CommonTResult<T_PL_ALSView> result = null;
            CommonTResult<T_PL_ALSView> resultDao = DisburseRegistDao.GetALS(appid, istopup, productname);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_ALSView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public void SaveCLMSInfor(string appId, string accOpenDate, string CLMSLineID, string CLMSCollateralID)
        {
            DisburseRegistDao.SaveCLMSInfor(appId, accOpenDate, CLMSLineID, CLMSCollateralID);
        }

        public void SaveRemarks(string appId, string remarks)
        {
            DisburseRegistDao.SaveRemarks(appId, remarks);
        }
       
        public Dictionary<string, string> GetCLMSInfor(string appId)
        {
            return DisburseRegistDao.GetCLMSInfor(appId);
        }

        public T_PL_SelfPay GetSelfPayInfo(string AppID)
        {
            return DisburseRegistDao.GetSelfPayInfo(AppID);
        }
    }
}
