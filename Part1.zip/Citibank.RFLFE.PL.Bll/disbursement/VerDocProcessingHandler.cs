﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IBll;

namespace Citibank.RFLFE.PL.Bll.disbursement
{
    public class VerDocProcessingHandler : IVerDocProcessingHandler
    {
         public IVerDocProcessingDao VerDocProcessingDao { get; set; }

         public CommonTResult<T_PL_DocSubmitted> GetDocListByAppID(string AppId, int stageid)
         {
             CommonTResult<T_PL_DocSubmitted> result = new CommonTResult<T_PL_DocSubmitted>();
             try
             {
                 result = VerDocProcessingDao.GetDocListByAppID(AppId, stageid);
             }
             catch (Exception ex)
             {
                 result.IsSuccess = false;
                 result.Message = ex.Message;
             }
             return result;
         }

         public CommonTResult<T_PL_AppraisalFee> GetAppraisalFeeByAppID(string AppId)
         {
             CommonTResult<T_PL_AppraisalFee> result = new CommonTResult<T_PL_AppraisalFee>();
             try
             {
                 result = VerDocProcessingDao.GetAppraisalFeeByAppID(AppId);
             }
             catch (Exception ex)
             {
                 result.IsSuccess = false;
                 result.Message = ex.Message;
             }
             return result;
         }

         public CommonResult SaveAppraisalFee(T_PL_AppraisalFee fees)
         {
             CommonResult result = new CommonResult();
             try
             {
                 result = VerDocProcessingDao.SaveAppraisalFee(fees);
             }
             catch (Exception ex)
             {
                 result.IsSuccess = false;
                 result.Message = ex.Message;
             }
             return result;
         }
    }
}
