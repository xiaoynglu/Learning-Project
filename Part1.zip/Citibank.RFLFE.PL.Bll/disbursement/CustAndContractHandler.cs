﻿using System.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Bll.application;
using System.Configuration;
using DocumentFormat.OpenXml.Packaging;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Wordprocessing;
using System.IO;
using Word = Microsoft.Office.Interop.Word;
using Microsoft.Office.Interop.Word;
using OpenXmlPowerTools;
using DocumentFormat.OpenXml;
using System.Xml;
using System.Reflection;
using Citibank.RFLFE.PL.Bll.common;
using CommonUtility = Citibank.RFLFE.PL.Framework.CommonUtility;

namespace Citibank.RFLFE.PL.Bll.disbursement
{
    public class CustAndContractHandler : ICustAndContractHandler
    {
        #region
      
        public IApplicationDao ApplicationDao { get; set; }
        public ICustAndContractDao CustAndContractDao { get; set; }
        #endregion

        Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);

        object oMissing = Type.Missing;
        object wdWhat = Word.WdGoToItem.wdGoToPage;
        object wdWhich = Word.WdGoToDirection.wdGoToAbsolute;
        Object oTrue = true;
        Object oFalse = false;
        string docSuffixName = ".docx";
        object pageBreak = Word.WdBreakType.wdPageBreak;
        int totalAttachmentNumber = 0;//附件的总数

        public IDictionary<string, string> GetApplicationAndLoanInfoByAppID(string appId)
        {
          return CustAndContractDao.GetApplicationAndLoanInfoByAppID(appId);
        }

        public CommonTResult<T_PL_Customers> GetCustAndContractCustInfoByAppID(string appId)
        {
            return CustAndContractDao.GetCustAndContractCustInfoByAppID(appId);
        }

        public bool SaveCustAndContractContacts(T_PL_CustomerContact Entity)
        {
            return CustAndContractDao.SaveCustAndContractContacts(Entity);
        }

        public IDictionary<string, string> GetCustConfirmInfoAndFeeByAppId(string appId)
        {
            return CustAndContractDao.GetCustConfirmInfoAndFeeByAppId(appId);
        }


        public bool SaveCustAndContractPayMethodCustConfirmInfoAndFee(CustAndContractPayMethodCustConfirmInfoAndFeeView Entity)
        {
            return CustAndContractDao.SaveCustAndContractPayMethodCustConfirmInfoAndFee(Entity);
        }

        public DownloadFileResult PrintContract(string appId, string appNo, string prodId, string stageId)
        {
            string docSaveFile = string.Empty;
            string ServicePath = CommonUtility.ProposalAppFormPath();
            string txtClientPath = CommonUtility.ClientPath();
            string docfileName = String.Empty;
            string MergeDoc = String.Empty;            
            string strMbFlag = "";
            string docServiceFile = string.Empty;
            string docClientPath = string.Empty;
            string HEContractMergedDoc = "CNRFHE_Contract";
            string CREContractMergedDoc = "CNRFCRE_Contract";
            string MOContractMergedDoc = "CNRFMO_Contract";
            string UPLContractMergedDoc = "CNRFUPL_Contract";
            var mergeSourceDS = new DataSet();
            var singleCount = 0;
            var MbFlagPostfix = 0;
            var docPostfix = CommonUtility.GetWord2007Postfix();
             NewProposalHandler NewProposalHandler = new NewProposalHandler();
             DownloadFileResult fileResult = new DownloadFileResult();

            try
            {
                mergeSourceDS = CustAndContractDao.GetMergeDataSourceByAppNo(appNo);
                if (mergeSourceDS != null&&mergeSourceDS.Tables.Count>0) {
                   singleCount =  Int32.Parse(mergeSourceDS.Tables[0].Rows[0]["SingleCount"].ToString());
                   MbFlagPostfix = Int32.Parse(mergeSourceDS.Tables[0].Rows[0]["MbFlag"].ToString()); 
                }
                string ProductName = ApplicationDao.GetProdNameByProdId(prodId);
                DataSet ds_Gua = CustAndContractDao.getGuarantorInfo(appId);
                DataTable dt_Gua = ds_Gua.Tables[0];
                int rowCount = dt_Gua.Rows.Count;
                bool IsPartMo = CustAndContractDao.IsPartMo(appId);
                if (String.IsNullOrEmpty(ProductName))
                {
                    return fileResult;
                }
               
                switch (ProductName)
                {
                    case "HE":
                        docfileName = CommonUtility.ContractHEDocName();
                        MergeDoc = HEContractMergedDoc;
                        break;
                    case "CRE":
                        docfileName = CommonUtility.ContractHEDocName();
                        MergeDoc = CREContractMergedDoc;
                        break;
                    case "UPL":
                        docfileName = CommonUtility.ContractUPLDocName();
                        MergeDoc = UPLContractMergedDoc;
                        break;
                    case "MO":
                        docfileName = CommonUtility.ContractMODocName();
                        MergeDoc = MOContractMergedDoc;
                        break;
                }

                if (ProductName.Equals("HE") || ProductName.Equals("CRE"))
                {
                    int Tenor =CustAndContractDao.CompareTenor(appId);

                    if (Tenor == 2)  //>=18
                    {
                        if (IsPartMo)
                        {
                           docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + "4" + singleCount.ToString() + ".docx";
                        }
                        else
                        {
                           docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + "2" + singleCount.ToString() + ".docx";
                        }
                    }
                    else if (Tenor == 1)  //6-18
                    {
                        if (IsPartMo)
                        {
                            docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + "6" + singleCount.ToString() + ".docx";
                        }
                        else
                        {
                            docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + "5" + singleCount.ToString() + ".docx";
                        }
                    }
                    else if (Tenor == -1)
                    {
                        if (IsPartMo)
                        {
                            docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + "3" + singleCount.ToString() + ".docx";
                        }
                        else
                        {
                            docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + "1" + singleCount.ToString() + ".docx";
                        }
                    }
                }
                else if (ProductName.Equals("MO"))
                {
                    int Tenor =CustAndContractDao.CompareTenor(appId);
                    if (rowCount == 0)
                    {
                        if (Tenor == 1)
                        {
                            docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + "2" + singleCount.ToString() + ".docx";
                             
                        }
                        else if (Tenor == -1)
                        {
                            docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + "1" + singleCount.ToString() + ".docx";
                        }
                    }
                    else
                    {
                        if (Tenor == 1)
                        {
                            docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + "4" + singleCount.ToString() + ".docx";
                              
                        }
                        else if (Tenor == -1)
                        {
                            docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + "3" + singleCount.ToString() + ".docx";
                        }
                    }

                }
                else if (ProductName.Equals("UPL"))
                { 
                    strMbFlag = "0" + MbFlagPostfix;
                    docServiceFile = ServicePath + docfileName.Substring(0, docfileName.Length - 5) + strMbFlag + ".docx";
                }

                docClientPath = txtClientPath + DateTime.Now.ToString("yyyyMMddHHmmss") + docfileName;
                
                File.Copy(docServiceFile, docClientPath, true);

                new CommonUtility(docServiceFile).MailMerge(mergeSourceDS.Tables[0], docClientPath, false);

                docSaveFile = String.Format("{0}{1}_{2}_{3}{4}", txtClientPath, MergeDoc, appNo, DateTime.Now.ToString("yyyyMMddHHmmss"), docPostfix);

                File.Copy(docClientPath, docSaveFile);

                FileInfo file = new FileInfo(docSaveFile);
                if (System.IO.File.Exists(file.FullName))
                {
                    fileResult.ContentType = "application/ms-word";
                    fileResult.FileContents = FileDownloadUtility.DownloadFile(file.FullName);
                    fileResult.FileDownloadName = file.FullName;
                }
                File.Delete(docClientPath);
                return fileResult;
            }
            catch (Exception ex)
            {
                log.ErrorLog(ex, MethodBase.GetCurrentMethod().Name);
                return fileResult;
            }
        }

       // public DownloadFileResult PrintContract(string appId, string appNo, string prodId, string stageId)
        //{
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract begin ");
          //  NewProposalHandler NewProposalHandler = new NewProposalHandler();
           // DownloadFileResult fileResult = new DownloadFileResult();
            //string rootPath = ContractPath();
            //var mergeSourceDS = new DataSet();
            //string docPath = "";//todo
            //string docfileName = String.Empty;
            //string resultDocName = "";//最终生成的word的全路径
            //var templateName = "";//根据产品获取的模板的名称
            //var tempTemplateName = "";
            //var mainBodyTemplateName = rootPath + "MainBody_" + DateTime.Now.ToString("yyyyMMddHHmmss") + "_template" + docSuffixName;
            //var mergeMainBody = "";
            //var mergeMainBodyReuse = "";
            //var firstPageOfWordTemplateName = rootPath + "FirstPage_" + DateTime.Now.ToString("yyyyMMddHHmmss") + "_template" + docSuffixName;
            //var mergeFirstPageOfWord = "";
            //var categoryOfWordTemplateName = rootPath + "Category_" + DateTime.Now.ToString("yyyyMMddHHmmss") + "_template" + docSuffixName;

            //var attachmentItemName = "";
            //var replaceTextInAttachment = GetRelaceTextInAttachment();//附件中用来替换为序号的字段
            //string productName = ApplicationDao.GetProdNameByProdId(prodId);
            //var fileNameAndPath = CustAndContractDao.GetFileNameAndPathByProdID(prodId);//根据产品获取对应的模板的名字和相对路径
            //var mergeFileList = new List<string>();//合并文件的list,暂时包含"首页"和"目录"
            //var CAPAmountColumnsList = new List<string>();

            //var wordApplication = new Word.Application();
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "first step Lu Xiao Yong");
            //Word.Document wordDoc = null;

            //object templatePath;
            //object firstPageStartIndex = 1;//首页的起始页
            //object categoryStartIndex = 2;//目录的起始页
            //object mainBodyStartIndex = 3;//正文的起始页
            //object newFirstPageDocName = (object)firstPageOfWordTemplateName;
            //object newCategoryDocName = (object)categoryOfWordTemplateName;
            //object newMainBodyDocName = (object)mainBodyTemplateName;
            //var splitDoc = new Word.Document();
            //Microsoft.Office.Interop.Word.Document templateDoc = new Word.Document();
            //object totalPagesCount;

            //var attachmentFileAndConditionList = CustAndContractDao.GetAttachmentFilesAndConditionListByProdID(prodId);//根据产品获取附件列表和条件列表
            //switch (productName)
            //{
            //    case "HE":
            //        totalAttachmentNumber = 3;
            //        break;
            //    case "UPL":
            //        totalAttachmentNumber = 2;
            //        break;
            //    case "MO":
            //        totalAttachmentNumber = 3;
            //        break;
            //}
            //mergeSourceDS = CustAndContractDao.GetMergeDataSourceByAppNo(appNo);
            //if (string.IsNullOrEmpty(productName))
            //{
            //    return fileResult;
            //}

            //if (fileNameAndPath.Count > 0)
            //{
            //    docfileName = fileNameAndPath["FileName"].ToString();
            //    docPath = fileNameAndPath["FilePath"].ToString();
            //}
            //templateName = rootPath + docfileName;
            //tempTemplateName = rootPath + docfileName.Substring(0, docfileName.Length - 5) + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + "_temp" + docSuffixName;
            //resultDocName = ContractOutputPath() + docfileName.Substring(0, docfileName.Length - 5) + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") + docSuffixName;
            //mergeFirstPageOfWord = rootPath + "FirstPage_" + DateTime.Now.ToString("yyyyMMddHHmmss") + docSuffixName;
            //mergeMainBody = rootPath + "MainBody_" + DateTime.Now.ToString("yyyyMMddHHmmss") + docSuffixName;
            //mergeMainBodyReuse = mergeMainBody.Substring(0, mergeMainBody.Length - 5) + "_reuse" + docSuffixName;

            //File.Copy(templateName, tempTemplateName, true);
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract begin  split");
            //#region  将主模板拆粉为首页(FirstPage),目录(Category）和正文(MainBody)三部分
            //templatePath = (object)tempTemplateName;
            //templateDoc = wordApplication.Documents.Open(ref (templatePath), ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
            //                                    ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            //totalPagesCount = (object)(templateDoc.ComputeStatistics(Word.WdStatistic.wdStatisticPages, ref oMissing));

            //Word.Range range = templateDoc.Range(ref oMissing, ref oMissing);
            //Word.Range pageRange = templateDoc.Range(ref oMissing, ref oMissing);

            //pageRange.Start = range.GoTo(ref wdWhat, ref wdWhich, ref firstPageStartIndex, ref oMissing).Start;
            //pageRange.End = range.GoTo(ref wdWhat, ref wdWhich, ref categoryStartIndex, ref oMissing).Start - 1;
            //pageRange.Copy();

            //splitDoc = wordApplication.Documents.Add(ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            ////newDoc.Content.FormattedText = pageRange.FormattedText;
            //splitDoc.PageSetup.PageWidth = templateDoc.PageSetup.PageWidth;
            //splitDoc.PageSetup.PageHeight = templateDoc.PageSetup.PageHeight;
            //wordApplication.Selection.PasteAndFormat(Microsoft.Office.Interop.Word.WdRecoveryType.wdPasteDefault);

            //splitDoc.SaveAs(ref newFirstPageDocName, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
            //                    ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            //((Microsoft.Office.Interop.Word._Document)splitDoc).Close(ref oMissing, ref oMissing, ref oMissing);
            //splitDoc = null;
            ///////////////////category doc ////////////////////////////////
            //pageRange.Start = range.GoTo(ref wdWhat, ref wdWhich, ref categoryStartIndex, ref oMissing).Start;
            //pageRange.End = range.GoTo(ref wdWhat, ref wdWhich, ref mainBodyStartIndex, ref oMissing).Start - 1;
            //pageRange.Copy();
            //splitDoc = wordApplication.Documents.Add(ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            ////newDoc.Content.FormattedText = pageRange.FormattedText;
            //splitDoc.PageSetup.PageWidth = templateDoc.PageSetup.PageWidth;
            //splitDoc.PageSetup.PageHeight = templateDoc.PageSetup.PageHeight;
            //wordApplication.Selection.PasteAndFormat(Microsoft.Office.Interop.Word.WdRecoveryType.wdPasteDefault);

            //splitDoc.SaveAs(ref newCategoryDocName, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
            //                    ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            //((Microsoft.Office.Interop.Word._Document)splitDoc).Close(ref oMissing, ref oMissing, ref oMissing);
            //splitDoc = null;
            //////////////////main body //////////////
            //pageRange.Start = range.GoTo(ref wdWhat, ref wdWhich, ref mainBodyStartIndex, ref oMissing).Start;
            //pageRange.End = range.GoTo(ref wdWhat, ref wdWhich, ref totalPagesCount, ref oMissing).Start - 1;
            //pageRange.Copy();
            //splitDoc = wordApplication.Documents.Add(ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            ////newDoc.Content.FormattedText = pageRange.FormattedText;
            //splitDoc.PageSetup.PageWidth = templateDoc.PageSetup.PageWidth;
            //splitDoc.PageSetup.PageHeight = templateDoc.PageSetup.PageHeight;
            //wordApplication.Selection.PasteAndFormat(Microsoft.Office.Interop.Word.WdRecoveryType.wdPasteDefault);

            //splitDoc.SaveAs(ref newMainBodyDocName, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
            //                    ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            //((Microsoft.Office.Interop.Word._Document)splitDoc).Close(ref oMissing, ref oMissing, ref oMissing);
            //splitDoc = null;
            //templateDoc.Close();
            //#endregion
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract end  split");

            //File.Copy(firstPageOfWordTemplateName, mergeFirstPageOfWord, true);
            //File.Copy(mainBodyTemplateName, mergeMainBody, true);

            //CAPAmountColumnsList.Add("LoanSizeAMT_CAP");
            //CAPAmountColumnsList.Add("EntrustAMT_CAP");
            //CAPAmountColumnsList.Add("Amount_Cap");

            //for (var a = 0; a < mergeSourceDS.Tables[0].Columns.Count; a++)
            //{
            //    if (CAPAmountColumnsList.Contains(mergeSourceDS.Tables[0].Columns[a].ToString()))
            //    {
            //        if (mergeSourceDS.Tables[0].Rows[0][a].ToString() != "" && mergeSourceDS.Tables[0].Rows[0][a].ToString() != null)
            //        {
            //            mergeSourceDS.Tables[0].Rows[0][a] = Arabia_to_Chinese(decimal.Parse(mergeSourceDS.Tables[0].Rows[0][a].ToString()));
            //        }
            //    }
            //}
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract begin  append attachment to body");
            //#region 遍历每个附件和它对应的条件，把符合条件的附件附加到正文(MainBody)中
            //if (mergeSourceDS != null && mergeSourceDS.Tables[0] != null && mergeSourceDS.Tables[0].Rows.Count > 0)
            //{
            //    if (attachmentFileAndConditionList != null)
            //    {
            //        var attachmentFileList = new List<string>();
            //        log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract begin  get all attachment");
            //        //获取所有的附件
            //        for (var i = 0; i < attachmentFileAndConditionList.ResultList.Count; i++)
            //        {
            //            if (!attachmentFileList.Contains(attachmentFileAndConditionList.ResultList[i].FileName.ToString()))
            //            {
            //                attachmentFileList.Add(attachmentFileAndConditionList.ResultList[i].FileName.ToString());
            //            }
            //        }
            //        log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract end  get all attachment");
            //        for (var i = 0; i < attachmentFileList.Count; i++)
            //        {
            //            //根据每条附件获取其所有的条件
            //            var conditionList = new List<AttachmentFilesAndConditionsEntity>();
            //            var conditionColumns = CustAndContractDao.GetConditionColumnsName();
            //            var sameTemplateCount = 0;


            //            for (var j = 0; j < attachmentFileAndConditionList.ResultList.Count; j++)
            //            {
            //                if (attachmentFileAndConditionList.ResultList[j].FileName == attachmentFileList[i])
            //                {
            //                    conditionList.Add(attachmentFileAndConditionList.ResultList[j]);
            //                }
            //            }
            //            if (attachmentFileList[i] == "单身声明.docx")
            //            {
            //                foreach (var item in conditionColumns.Where(c => c.Key == "MarriageStatus").ToList())
            //                {
            //                    if (ValidateEachConditionOfAttachementFile(conditionList, mergeSourceDS, conditionColumns, item.Value))
            //                    {
            //                        sameTemplateCount++;
            //                    }
            //                }
            //            }
            //            else
            //            {
            //                if (ValidateEachConditionOfAttachementFile(conditionList, mergeSourceDS, conditionColumns, ""))
            //                {
            //                    sameTemplateCount = 1;
            //                };
            //            }

            //            attachmentItemName = rootPath + attachmentFileList[i].ToString();
            //            if (sameTemplateCount != 0) AppendDocument((object)mergeMainBody, sameTemplateCount, attachmentItemName);
            //        }
            //    }
            //}
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract end  append attachment to body");
            //#endregion
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract end  append attachment to body");
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract begin  merge field to body");
            //#region 将正文(MainBody)和首页(FirstPage)中的MergeField 用值Merge
            //File.Copy(mergeMainBody, mergeMainBodyReuse);
            //new CommonUtility(mergeMainBodyReuse).MailMerge(mergeSourceDS.Tables[0], mergeMainBody, false);
            //new CommonUtility(firstPageOfWordTemplateName).MailMerge(mergeSourceDS.Tables[0], mergeFirstPageOfWord, false);

            //#endregion
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract end  merge field to body");
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract begin insert first page and category to body");
            //#region 将首页和目录添加到正文的开始位置

            //mergeFileList.Add(categoryOfWordTemplateName);
            //mergeFileList.Add(mergeMainBody);
            //MergeServeralWordsIntoSingle(mergeFileList, mergeFirstPageOfWord, false, mergeMainBody);
            ////MergeServeralWordsIntoSingle(mergeFirstPageOfWord, categoryOfWordTemplateName, mergeMainBody, false, mergeMainBody);

            //#endregion
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract end insert first page and category to body");
            //#region 更新目录
            //wordDoc = wordApplication.Documents.Open(mergeFirstPageOfWord);
            //wordDoc.TablesOfContents[1].Update();
            //wordDoc.Save();
            //wordDoc.Close();
            //wordApplication.Quit();
            //#endregion

            //#region apply protection

            //using (WordprocessingDocument wordDocument = WordprocessingDocument.Open(mergeMainBody, true))
            //{
            //    new CommonUtility(tempTemplateName).ApplyDocumentProtection(wordDocument, DocumentProtectionValues.Forms);
            //}

            //#endregion

            //File.Copy(mergeMainBody, resultDocName);

            //FileInfo file = new FileInfo(mergeMainBody);
            //if (System.IO.File.Exists(file.FullName))
            //{
            //    fileResult.ContentType = "application/ms-word";
            //    fileResult.FileContents = FileDownloadUtility.DownloadFile(file.FullName);
            //    fileResult.FileDownloadName = file.FullName;
            //}

            //#region 删除文件

            //File.Delete(tempTemplateName);
            //File.Delete(mergeFirstPageOfWord);
            //File.Delete(mergeMainBodyReuse);
            //File.Delete(mergeMainBody);
            //File.Delete(mainBodyTemplateName);
            //File.Delete(firstPageOfWordTemplateName);
            //File.Delete(categoryOfWordTemplateName);

            //#endregion
            //log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "PrintContract end");
          //  return fileResult;
          //}

        //public static void ReplaceStyles(string fromDoc, string toDoc)
        //{
        //    // Extract and replace the styles part.
        //    var node = ExtractStylesPart(fromDoc, false);
        //    if (node != null)
        //        ReplaceStylesPart(toDoc, node, false);

        //    // Extract and replace the stylesWithEffects part. To fully support 
        //    // round-tripping from Word 2010 to Word 2007, you should 
        //    // replace this part, as well.
        //    node = ExtractStylesPart(fromDoc);
        //    if (node != null)
        //        ReplaceStylesPart(toDoc, node);
        //    return;
        //}

        //public static void ReplaceStylesPart(string fileName, XDocument newStyles,bool setStylesWithEffectsPart = true)
        //{
        //    // Open the document for write access and get a reference.
        //    using (var document =
        //        WordprocessingDocument.Open(fileName, true))
        //    {
        //        // Get a reference to the main document part.
        //        var docPart = document.MainDocumentPart;

        //        // Assign a reference to the appropriate part to the
        //        // stylesPart variable.
        //        StylesPart stylesPart = null;
        //        if (setStylesWithEffectsPart)
        //            stylesPart = docPart.StylesWithEffectsPart;
        //        else
        //            stylesPart = docPart.StyleDefinitionsPart;

        //        // If the part exists, populate it with the new styles.
        //        if (stylesPart != null)
        //        {
        //            newStyles.Save(new StreamWriter(stylesPart.GetStream(
        //              FileMode.Create, FileAccess.Write)));
        //        }
        //    }
        //}

        //public static XDocument ExtractStylesPart( string fileName,bool getStylesWithEffectsPart = true)
        //{
        //    // Declare a variable to hold the XDocument.
        //    XDocument styles = null;

        //    // Open the document for read access and get a reference.
        //    using (var document =
        //        WordprocessingDocument.Open(fileName, false))
        //    {
        //        // Get a reference to the main document part.
        //        var docPart = document.MainDocumentPart;

        //        // Assign a reference to the appropriate part to the
        //        // stylesPart variable.
        //        StylesPart stylesPart = null;
        //        if (getStylesWithEffectsPart)
        //            stylesPart = docPart.StylesWithEffectsPart;
        //        else
        //            stylesPart = docPart.StyleDefinitionsPart;

        //        // If the part exists, read it into the XDocument.
        //        if (stylesPart != null)
        //        {
        //            using (var reader = XmlNodeReader.Create(
        //              stylesPart.GetStream(FileMode.Open, FileAccess.Read)))
        //            {
        //                // Create the XDocument.
        //                styles = XDocument.Load(reader);
        //            }
        //        }
        //    }
        //    // Return the XDocument instance.
        //    return styles;
        //}

        
        
        public Boolean ValidateEachConditionOfAttachementFile(List<AttachmentFilesAndConditionsEntity> conditionList, DataSet mergeSourceDS,  IList<T_Sys_Parameters>  conditionColumns ,string conditionColumnName)
        {
            var finalConditionValidation = false;
            var columnsValue = "";
            var conditionListGroupList = conditionList.GroupBy(c => c.GroupID).ToList();
            var dataRow = mergeSourceDS.Tables[0].Rows[0];
            var columns = mergeSourceDS.Tables[0].Columns; 

                foreach (var groupItem in conditionListGroupList)
                {
                    var groupItemList = groupItem.ToList();
                    var isValid = false;
                    //遍历每个条件
                    for (var k = 0; k < groupItemList.Count; k++)
                    {
                        var tabID = groupItemList[k].TabID;
                        var op = "";
                        var value = "";
                        var groupId = "";
                        op = groupItemList[k].OP.ToString();
                        value = groupItemList[k].Value.ToString();
                        groupId = groupItemList[k].GroupID.ToString();
                        if (conditionColumnName == "")
                        {
                            conditionColumnName = conditionColumns.Where(item => item.Key == tabID).ToList().FirstOrDefault().Value;
                        }
                        for (var s = 0; s < columns.Count; s++)
                        {
                            if (value.Contains("Variable"))
                            {
                                if (columns[s].ToString() == value.Substring(9, value.Length - 9).ToString())
                                {
                                    value = dataRow[s].ToString();
                                }
                            }
                            if (columns[s].ToString() == conditionColumnName)
                            {
                                columnsValue = dataRow[s].ToString();
                            }
                        }


                        if (op == ">")
                        {
                            #region 大于
                            if (Int32.Parse(columnsValue) > Int32.Parse(value)) isValid = true;
                            else { isValid = false; break; }
                            #endregion
                        }
                        else if (op == "=")
                        {
                            #region 等于
                            if (columnsValue == value) isValid = true;
                            else { isValid = false; break; }
                            #endregion
                        }
                        else if (op == "<")
                        {
                            #region 小于
                            if (Int32.Parse(columnsValue) < Int32.Parse(value)) isValid = true;
                            else { isValid = false; break; }
                            #endregion
                        }
                        else if (op == "<>")
                        {
                            #region 不等于
                            if (columnsValue != value) isValid = true;
                            else { isValid = false; break; }
                            #endregion
                        }
                        finalConditionValidation = finalConditionValidation || isValid;
                    }
                }
            return finalConditionValidation;

        }

       

        //将模板中附件的序号从数字转换成中文
        public string convertAttachmentNumberChinese(int number){

         switch (number)
            {
                case 3:
                    return "三"; break;
                case 4:
                    return "四"; break;
                case 5:
                    return "五"; break;
                case 6:
                    return "六"; break;
                case 7:
                    return "七"; break;
                case 8:
                    return "八"; break;
                case 9:
                    return "九"; break;
                case 10:
                    return "十"; break;
            }
            return "";
        }

        //将多个word文档合并为一个
        public void MergeServeralWordsIntoSingle(List<string> filesToMerge, string outputFilename, bool insertPageBreaks, string documentTemplate)
        {
            //object defaultTemplate = documentTemplate;
            //object outputFile = outputFilename;
            //Word._Application wordApplication = new Word.Application();
            //Word._Document wordDocument = wordApplication.Documents.Add(ref defaultTemplate, ref oMissing, ref oMissing, ref oMissing);
            //Word.Selection selection = wordApplication.Selection;
            
            //foreach (string file in filesToMerge)
            //{
            //    selection.InsertFile(file, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
            //    if (insertPageBreaks)
            //    {
            //        selection.InsertBreak(ref pageBreak);
            //    }
            //}
            //wordDocument.SaveAs( ref outputFile, ref oMissing, ref oMissing, ref oMissing
            //            , ref oMissing, ref oMissing, ref oMissing , ref oMissing , ref oMissing
            //            , ref oMissing  , ref oMissing, ref oMissing , ref oMissing  , ref oMissing , ref oMissing);
            //wordDocument.Close();
            //wordApplication.Quit(ref oMissing, ref oMissing, ref oMissing);

            using (WordprocessingDocument OutPutFile = WordprocessingDocument.Open(outputFilename, true))
            {
                foreach (var item in filesToMerge)
                {
                    using (WordprocessingDocument output = WordprocessingDocument.Open(item, true))
                    {
                        XElement newBody = XElement.Parse(output.MainDocumentPart.Document.Body.OuterXml);
                        Body bo = new Body(newBody.ToString());
                        OutPutFile.MainDocumentPart.Document.Body.AppendChild<Body>(bo);
                        OutPutFile.MainDocumentPart.Document.Save();
                    }
                }
            }
        }

        //将附件附加在主文档后面
        public void AppendDocument(object parentFileName, int sameTemplateCount, string attachmentFile)
        {
            log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "AppendDocument begin ");
            List<string> childFileList = new List<string>();
            object replace = Word.WdReplace.wdReplaceOne;
            //附件中用来替换为序号的字段
            object FindText, ReplaceWith, Replace;//
            object wdSectionBreakN = Word.WdBreakType.wdSectionBreakNextPage;
            FindText = (object)CommonUtility.GetRelaceTextInAttachment();//要查找的文本
            Replace = Word.WdReplace.wdReplaceOne;
            var oWordApp = new Microsoft.Office.Interop.Word.Application();

            for (var i = 1; i <= sameTemplateCount;i++ ){
              childFileList.Add(attachmentFile.Substring(0, attachmentFile.Length - 5) + "_" + DateTime.Now.ToString("yyyyMMddHHmmss") +"_"+i+ docSuffixName);
              File.Copy(attachmentFile,childFileList[i-1]);
            }
            Word.Document oWordDoc = oWordApp.Documents.Open(ref  parentFileName, ref  oMissing, ref  oMissing,
                 ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing,
                 ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing);

            for (var i = 0; i < childFileList.Count; i++) {
                object DocumentEnd = oWordDoc.Content.End - 1;
                Word.Range InsertRange = oWordDoc.Range(ref  DocumentEnd, ref  DocumentEnd);
                InsertRange.InsertBreak(ref  wdSectionBreakN);
                object CollEnd = Word.WdCollapseDirection.wdCollapseEnd;
                InsertRange.Collapse(ref  CollEnd);
                object items = (object)childFileList[i];
                Word.Document InsertDocument = oWordApp.Documents.Open(ref  items, ref  oMissing, ref  oMissing,
                   ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing,
                   ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing, ref  oMissing);
                //begin replace
                totalAttachmentNumber =  totalAttachmentNumber +i;
                ReplaceWith = (object)convertAttachmentNumberChinese(totalAttachmentNumber);
                InsertDocument.Content.Find.ClearFormatting();
                InsertDocument.Content.Find.Execute(ref FindText, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing,
                ref oMissing, ref oMissing, ref oMissing, ref ReplaceWith, ref Replace, ref oMissing, ref oMissing, ref oMissing, ref oMissing);
                // end replace
                Word.Range testrange = InsertDocument.Content;
                testrange.Copy();
                InsertRange.Paste();
                oWordDoc.Save();
                InsertDocument.Close(ref  oMissing, ref  oMissing, ref  oMissing);
                File.Delete(childFileList[i].ToString());
            }
            oWordDoc.Close(ref  oMissing, ref  oMissing, ref  oMissing);
            oWordApp.Quit(ref  oMissing, ref  oMissing, ref  oMissing);

            log.DebugLog(DateTime.Now.ToString() + DateTime.Now.Millisecond.ToString(), "AppendDocument end ");
        }

        public static string Arabia_to_Chinese(decimal Money) 
        {
            if (Money < 0)
            {
                Money = 0 - Money;
            }

            return ConvertSum(Convert.ToString(Money));
        
        }

        /// <summary>
        /// 转换数字金额主函数（包括小数）
        /// </summary>
        /// <param name="str">数字字符串</param>
        /// <returns>转换成中文大写后的字符串或者出错信息提示字符串</returns>
        public static string ConvertSum(string str)
        {
            if (!IsPositveDecimal(str))
                return "输入的不是正数字！";
            if (Double.Parse(str) > 999999999999.99)
                return "数字太大，无法换算，请输入一万亿元以下的金额";
            char[] ch = new char[1];
            ch[0] = '.'; //小数点
            string[] splitstr = null; //定义按小数点分割后的字符串数组
            splitstr = str.Split(ch[0]);//按小数点分割字符串
            if (splitstr.Length == 1) //只有整数部分
                return ConvertData(str) + "圆整";
            else //有小数部分
            {
                string rstr;
                rstr = ConvertData(splitstr[0]) + "圆";//转换整数部分
                rstr += ConvertSDigit(splitstr[1]);//转换小数部分
                return rstr;
            }

        }

        /// 
        /// 判断是否是正数字字符串
        /// 
        /// 判断字符串
        /// 如果是数字，返回true，否则返回false
        public static bool IsPositveDecimal(string str)
        {
            Decimal d;
            try
            {
                d = Decimal.Parse(str);

            }
            catch (Exception)
            {
                return false;
            }
            if (d >= 0)
                return true;
            else
                return false;
        }

        /// 
        /// 转换数字（整数）
        /// 
        /// 需要转换的整数数字字符串
        /// 转换成中文大写后的字符串
        public static string ConvertData(string str)
        {
            string tmpstr = "";
            string rstr = "";
            int strlen = str.Length;
            if (strlen <= 4)//数字长度小于四位
            {
                rstr = ConvertDigit(str);

            }
            else
            {

                if (strlen <= 8)//数字长度大于四位，小于八位
                {
                    tmpstr = str.Substring(strlen - 4, 4);//先截取最后四位数字
                    rstr = ConvertDigit(tmpstr);//转换最后四位数字
                    tmpstr = str.Substring(0, strlen - 4);//截取其余数字
                    //将两次转换的数字加上萬后相连接
                    rstr = String.Concat(ConvertDigit(tmpstr) + "萬", rstr);
                    rstr = rstr.Replace("零萬", "萬");
                    rstr = rstr.Replace("零零", "零");

                }
                else
                    if (strlen <= 12)//数字长度大于八位，小于十二位
                    {
                        tmpstr = str.Substring(strlen - 4, 4);//先截取最后四位数字
                        rstr = ConvertDigit(tmpstr);//转换最后四位数字
                        tmpstr = str.Substring(strlen - 8, 4);//再截取四位数字
                        rstr = String.Concat(ConvertDigit(tmpstr) + "萬", rstr);
                        tmpstr = str.Substring(0, strlen - 8);
                        rstr = String.Concat(ConvertDigit(tmpstr) + "億", rstr);
                        rstr = rstr.Replace("零億", "億");
                        rstr = rstr.Replace("零萬", "零");
                        rstr = rstr.Replace("零零", "零");
                        rstr = rstr.Replace("零零", "零");
                    }
            }
            strlen = rstr.Length;
            if (strlen >= 2)
            {
                switch (rstr.Substring(strlen - 2, 2))
                {
                    case "佰零": rstr = rstr.Substring(0, strlen - 2) + "佰"; break;
                    case "仟零": rstr = rstr.Substring(0, strlen - 2) + "仟"; break;
                    case "萬零": rstr = rstr.Substring(0, strlen - 2) + "萬"; break;
                    case "億零": rstr = rstr.Substring(0, strlen - 2) + "億"; break;

                }
            }

            return rstr;
        }

        /// 
        /// 转换数字（小数部分）
        /// 
        /// 需要转换的小数部分数字字符串
        /// 转换成中文大写后的字符串
        public static string ConvertSDigit(string str)
        {
            int strlen = str.Length;
            string rstr;
            if (strlen == 1)
            {
                rstr = ConvertChinese(str) + "角";
                return rstr;
            }
            else
            {
                string tmpstr = str.Substring(0, 1);
                rstr = ConvertChinese(tmpstr) + "角";
                tmpstr = str.Substring(1, 1);
                rstr += ConvertChinese(tmpstr) + "分";
                rstr = rstr.Replace("零分", "");
                rstr = rstr.Replace("零角", "");
                return rstr;
            }


        }

        /// 
        /// 转换数字
        /// 
        /// 转换的字符串（四位以内）
        /// 
        public static string ConvertDigit(string str)
        {
            int strlen = str.Length;
            string rstr = "";
            switch (strlen)
            {
                case 1: rstr = ConvertChinese(str); break;
                case 2: rstr = Convert2Digit(str); break;
                case 3: rstr = Convert3Digit(str); break;
                case 4: rstr = Convert4Digit(str); break;
            }
            rstr = rstr.Replace("拾零", "拾");
            strlen = rstr.Length;

            return rstr;
        }

        /// 
        /// 转换四位数字
        /// 
        public static string Convert4Digit(string str)
        {
            string str1 = str.Substring(0, 1);
            string str2 = str.Substring(1, 1);
            string str3 = str.Substring(2, 1);
            string str4 = str.Substring(3, 1);
            string rstring = "";
            rstring += ConvertChinese(str1) + "仟";
            rstring += ConvertChinese(str2) + "佰";
            rstring += ConvertChinese(str3) + "拾";
            rstring += ConvertChinese(str4);
            rstring = rstring.Replace("零仟", "零");
            rstring = rstring.Replace("零佰", "零");
            rstring = rstring.Replace("零拾", "零");
            rstring = rstring.Replace("零零", "零");
            rstring = rstring.Replace("零零", "零");
            rstring = rstring.Replace("零零", "零");
            return rstring;
        }
        /// 
        /// 转换三位数字
        /// 
        public static string Convert3Digit(string str)
        {
            string str1 = str.Substring(0, 1);
            string str2 = str.Substring(1, 1);
            string str3 = str.Substring(2, 1);
            string rstring = "";
            rstring += ConvertChinese(str1) + "佰";
            rstring += ConvertChinese(str2) + "拾";
            rstring += ConvertChinese(str3);
            rstring = rstring.Replace("零佰", "零");
            rstring = rstring.Replace("零拾", "零");
            rstring = rstring.Replace("零零", "零");
            rstring = rstring.Replace("零零", "零");
            return rstring;
        }
        /// 
        /// 转换二位数字
        /// 
        public static string Convert2Digit(string str)
        {
            string str1 = str.Substring(0, 1);
            string str2 = str.Substring(1, 1);
            string rstring = "";
            rstring += ConvertChinese(str1) + "拾";
            rstring += ConvertChinese(str2);
            rstring = rstring.Replace("零拾", "零");
            rstring = rstring.Replace("零零", "零");
            return rstring;
        }
        /// 
        /// 将一位数字转换成中文大写数字
        /// 
        public static string ConvertChinese(string str)
        {
            //"零壹贰叁肆伍陆柒捌玖拾佰仟萬億圆整角分"
            string cstr = "";
            switch (str)
            {
                case "0": cstr = "零"; break;
                case "1": cstr = "壹"; break;
                case "2": cstr = "贰"; break;
                case "3": cstr = "叁"; break;
                case "4": cstr = "肆"; break;
                case "5": cstr = "伍"; break;
                case "6": cstr = "陆"; break;
                case "7": cstr = "柒"; break;
                case "8": cstr = "捌"; break;
                case "9": cstr = "玖"; break;
            }
            return (cstr);
        }

        

    }
}
