﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.Bll.application;
using System.Data.OleDb;
using System.Data;

namespace Citibank.RFLFE.PL.Bll.report
{
    public class MISReportHandler : IMISReportHandler
    {
        public IMISReportDao MISReportDao { get; set; }
        private string filePath;
        private string fileName;
        private OleDbConnection conn;
        private string connString;
        private FileType fileType;

        public CommonTResult<T_Sys_Branch> GetBranchByOrg(T_Sys_Branch brs)
        {
            CommonTResult<T_Sys_Branch> result = new CommonTResult<T_Sys_Branch>();
            try
            {
                result = MISReportDao.GetBranchByOrg(brs);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public Boolean UploadHoliday(string filePath, string uploadType, T_Sys_Users loginUser)
        {
            try
            {
                var dataSet = GetExcelData(filePath);
                return MISReportDao.UploadHoliday(dataSet.Tables[0], uploadType, loginUser);
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public Boolean DeleteHoliday()
        {
            try
            {
                return MISReportDao.DeleteHoliday();
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public DataSet ExportTimeQueryByStages(string Stages, string BeginDate, string EndDate, string ProdIDs, string UserID)
        {
            try
            {
                DataSet resultdt = MISReportDao.ExportTimeQueryByStages(Stages, BeginDate, EndDate, ProdIDs, UserID);
                return resultdt;
            }
            catch (Exception ex)
            {
                return null;
            } 
        }

        public DataTable ExportProcessHistoryReport(string Stages, string StartDate, string EndDate)
        {
            try
            {
                DataTable resultdt = MISReportDao.ExportProcessHistoryReport(Stages, StartDate, EndDate);
                return resultdt;
            }
            catch (Exception ex)
            {
                return null;
            } 
        }

        public CommonTResult<T_PL_TempDefination> GetMISReportTempDefination(int role, int gird, string userID, string repName)
        {
            CommonTResult<T_PL_TempDefination> result = new CommonTResult<T_PL_TempDefination>();
            try
            {
                result = MISReportDao.GetMISReportTempDefination(role, gird, userID, repName);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_MISReportTemplate> GetTemplateByUserId(string userID)
        {
            CommonTResult<T_PL_MISReportTemplate> result = new CommonTResult<T_PL_MISReportTemplate>();
            try
            {
                result = MISReportDao.GetTemplateByUserId(userID);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public bool SaveTemplateSetting(string templateName, string ColumnIds, string userID)
        {
            try
            {
                return MISReportDao.SaveTemplateSetting(templateName, ColumnIds, userID);
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool DeleteTemplateSetting(string templateName, string userID)
        {
            try
            {
                return MISReportDao.DeleteTemplateSetting(templateName, userID);
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public CommonTResult<T_PL_MISReport_TempColumns> GetMSIReportByCondition(string OrgCode, string RepNo, string SoeId, string ProdID, string BeginDate, string EndDate, string TimeFlag, int RepFlag, int Start, int Limit)
        {
            CommonTResult<T_PL_MISReport_TempColumns> result = new CommonTResult<T_PL_MISReport_TempColumns>();
            try
            {
                result = MISReportDao.GetMSIReportByCondition(OrgCode, RepNo, SoeId, ProdID, BeginDate, EndDate, TimeFlag, RepFlag, Start, Limit);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public DataTable ExportMSIReportByCondition(string OrgCode, string RepNo, string SoeId, string ProdID, string BeginDate, string EndDate, string TimeFlag, int RepFlag)
        {
            try
            {
                DataTable resultdt = MISReportDao.ExportMSIReportByCondition(OrgCode, RepNo, SoeId, ProdID, BeginDate, EndDate, TimeFlag, RepFlag);
                return resultdt;
            }
            catch (Exception ex)
            {
                return null;
            } 
        }

        private DataSet GetExcelData(string path)
        {
            DataSet dsExcelData = new DataSet();
            if (System.IO.File.Exists(path))
            {
                SetFileInfo(path);
                OleDbDataAdapter adapter;
                using (conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    DataTable dtSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    String[] excelSheets = new String[dtSchema.Rows.Count];
                    for (int i = 0; i < dtSchema.Rows.Count; i++)
                    {
                        excelSheets[i] = dtSchema.Rows[i]["TABLE_NAME"].ToString();
                        if (excelSheets[i].IndexOf("_") != -1)
                        {
                            continue;
                        }
                        string strSQL = "select * from [" + excelSheets[i] + "]";
                        adapter = new OleDbDataAdapter(strSQL, conn);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dt.TableName = excelSheets[i].Replace("_", "").Replace("$", "").Replace("'", "");
                        dsExcelData.Tables.Add(dt);
                    }
                }
            }
            return dsExcelData;
        }


        private void SetFileInfo(string path)
        {
            filePath = path;
            fileName = filePath.Remove(0, filePath.LastIndexOf("\\") + 1);
            switch (fileName.Split('.')[fileName.Split('.').Length - 1])
            {
                case "xls": connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                    fileType = FileType.xls; break;
                case "xlsx": connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source =" + filePath + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1'";
                    fileType = FileType.xlsx; break;
            }
        }

        private enum FileType
        {
            noset, xls, xlsx, csv
        }
    }
}
