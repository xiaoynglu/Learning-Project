﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Mvc.Models;
using System.Reflection;
using System.Configuration;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Wordprocessing;
using Citibank.RFLFE.PL.Bll.disbursement;
using Citibank.RFLFE.PL.Bll.common;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using SystemFrameworks.Util;
using System.Collections;

namespace Citibank.RFLFE.PL.Bll.pboc
{
    public class TxtWriter : IWriter
    {
        StreamWriter swriterTxt = null;
        FileStream fstreamTxt = null;
        string txtName = string.Empty;
        #region property
        private string path = string.Empty;
        public string Path
        {
            set
            {
                path = value;
            }
            get
            {
                return path;
            }
        }
        private string key = string.Empty;
        public string Key
        {
            set
            {
                key = value;
            }
            get
            {
                return key;
            }
        }
        #endregion
        public TxtWriter(string TxtName)
        {
            txtName = TxtName;
            GenerateExportTxtFile();
        }
        /// <summary>
        /// write a line of content
        /// </summary>
        /// <param name="_strLine"></param>
        public void WriteLine(string _strLine)
        {
            this.swriterTxt.WriteLine(_strLine);
            this.swriterTxt.Flush();

        }
        /// <summary>
        /// ready work
        /// </summary>
        public void Ready()
        {
            //open the export with stream objects to ready to write

            fstreamTxt = new FileStream(Path, FileMode.OpenOrCreate, FileAccess.Write);
            Encoding encoding = Encoding.GetEncoding(CommonUtility.TextEncoding());
            swriterTxt = new StreamWriter(fstreamTxt, encoding);
        }
        /// <summary>
        /// generate the txt export file 
        /// </summary>
        /// <returns></returns>
        public string GenerateExportTxtFile()
        {
            string strBulkInsertFile = string.Empty;


#if DEBUG
            strBulkInsertFile = AppDomain.CurrentDomain.BaseDirectory;

#else
           strBulkInsertFile = AppDomain.CurrentDomain.BaseDirectory;
#endif



            //log.Debug(strBulkInsertFile);
            if (strBulkInsertFile.Substring(strBulkInsertFile.Length - 1, 1).Equals("\\"))
            {
                strBulkInsertFile = strBulkInsertFile + string.Format("PBOC{0}{1}.txt", txtName, System.DateTime.Now.ToString("yyyyMMdd"));
            }
            else
            {
                strBulkInsertFile = strBulkInsertFile + "\\" + string.Format("PBOC{0}{1}.txt", txtName, System.DateTime.Now.ToString("yyyyMMdd"));
            }

            if (File.Exists(strBulkInsertFile))
            {
                File.Delete(strBulkInsertFile);
            }
            this.Path = strBulkInsertFile;
            return strBulkInsertFile;
        }

        public void Close()
        {
            this.swriterTxt.Close();
            this.fstreamTxt.Close();
        }
    }
}
