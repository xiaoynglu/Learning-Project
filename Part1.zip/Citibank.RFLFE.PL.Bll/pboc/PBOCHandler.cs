﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Mvc.Models;
using System.Reflection;
using System.Configuration;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Wordprocessing;
using Citibank.RFLFE.PL.Bll.disbursement;
using Citibank.RFLFE.PL.Bll.common;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using SystemFrameworks.Util;
using System.Collections;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Office.Excel;
using System.Drawing;

namespace Citibank.RFLFE.PL.Bll.pboc
{
    public class PBOCHandler : IPBOCHandler
    {

        #region properties
        public IPBOCDao PBOCDao { get; set; }
        public int _codePage = 936;
        Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);

        IDictionary<string, IWriter> listTxtWriter = new Dictionary<string, IWriter>();
        IDictionary<string, IWriter> listCvsWriter = new Dictionary<string, IWriter>();
        IDictionary<string, IWriter> listTempWriter = new Dictionary<string, IWriter>();

        string globalExportPBOCPath = "C:\\FPP\\Export";
        string globalStrData_YM = "";
        public  DateTime dt = DateTime.Now;
        private string[] keys = null;
        public string[] Keys
        {
            get
            {
                if (keys == null)
                {
                    keys = new string[] { "1", "2", "3", "4" };
                }
                return keys;
            }
        }
        Encoding fileEncoding = Encoding.GetEncoding(CommonUtility.TextEncoding());

        public Hashtable KeyNamePairs
        {
            get
            {
                return hashKeyNamePairs;
            }
        }
        static PBOCHandler()
        {
            hashKeyNamePairs = new Hashtable();
            hashKeyNamePairs.Add("1", "GA");
            hashKeyNamePairs.Add("2", "CB");
            hashKeyNamePairs.Add("3", "WFD");
            hashKeyNamePairs.Add("4", "BB");
        }
        public static Hashtable hashKeyNamePairs = null;
         
        private readonly int ReportType = 1;
        private readonly int Prd_Code = 1;
        #endregion

        public string ImportRate()
        {
            var errorMessage = "";
            string strSourcePathForRate = CommonUtility.PBOCSourcePathForRate();
            string strRateYM = "";
            int codePage = Encoding.Unicode.CodePage;
            string[] strings;
            string strLine = "";
            string strHeader = "";
            string strYM = "";
            bool flg = false;
            string strServerTempPath = CommonUtility.PBOCTempFilePath();
            string currentPath = "";
            char charSeparatedChar = char.Parse(CommonUtility.PBOCSeparatedCharForRate());
            
            #region copy rate.txt from server to local
            if (!strServerTempPath.Substring(strServerTempPath.Length - 1, 1).Equals("\\"))
            {
                strServerTempPath = strServerTempPath + "\\";
            }
            currentPath = strServerTempPath;
            if (CommonUtility.PBOCSeparatedCharForRate().Length == 0)
            {
                errorMessage = "have no separatedchar for rate";
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }           
            if (!File.Exists(strSourcePathForRate))
            {
                errorMessage = string.Format("The rate file ({0}) does not exist", strSourcePathForRate);
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            if (!(currentPath.IndexOf("\\", currentPath.Length - 1) >= 0))
            {
                currentPath = string.Format("{0}\\rate{1}.txt", currentPath, DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat10));
            }
            else
            {
                currentPath = string.Format("{0}rate{1}.txt", currentPath, DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat10));
            }
            if (File.Exists(currentPath))
            {
                log.DebugLog("delete the currentPath:"+currentPath, MethodBase.GetCurrentMethod().Name);
                File.Delete(currentPath);
            }
            FileInfo filewr = new FileInfo(currentPath);
            StreamWriter sw = filewr.CreateText();
            #endregion

            FileInfo fileIn = new FileInfo(strSourcePathForRate);
            StreamReader sr = fileIn.OpenText();
            while (true)
            {
                strLine = sr.ReadLine();
                if (strLine == null)
                {
                    break;
                }
                strings = strLine.Split(charSeparatedChar);
                if (strings.Length >= 4)
                {
                    strRateYM = strings[3];
                    if (!strYM.Equals(strRateYM))
                    {
                        if (!PBOCDao.DeleteExchRateByDataYM(strRateYM))
                        {
                            errorMessage = string.Format("no rate data on ", strRateYM);
                            log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                            return errorMessage;
                        }
                        strYM = strRateYM;
                    }
                    for (int i = 0; i < strings.Length; i++)
                    {
                        if (i == 0)
                        {
                            if (!flg)
                            {
                                strHeader = string.Format("i{0}", i);
                            }
                            strLine = strings[i];
                        }
                        else
                        {
                            if (!flg)
                            {
                                strHeader = strHeader + "\t" + string.Format("i{0}", i);
                            }
                            strLine = strLine + "\t" + strings[i];
                        }
                    }
                    if (!flg)
                    {
                        sw.WriteLine(strHeader);
                        flg = true;
                    }
                    sw.WriteLine(strLine);
                    sw.Flush();
                }
            }
            sr.Close();
            sw.Close();
            string cmdText = string.Format(Constants.SQLInsertCmdWithCodePage, Constants.T_PL_PR_ExchRate, currentPath, codePage);
            log.DebugLog("begin bulk insert :" + cmdText, MethodBase.GetCurrentMethod().Name);
           // ExecuteNonQuery(cmdText);TODO
            //if (!ExecuteNonQuery(cmdText)) {
            //     errorMessage = "导入ALS数据出现失败,请重试!";
            //     log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
            //     return errorMessage;
            //}
            log.DebugLog("end bulk insert :" + cmdText, MethodBase.GetCurrentMethod().Name);
            if (File.Exists(currentPath))
            {
                File.Delete(currentPath);
            }
            return errorMessage;
        }

        /// <summary>
        /// Step1:如果页面上选择的时间和当前系统的时间相同
        /// Step1.1:删除T_PL_PR_ALS表中当月的数据
        /// Step1.2:将PBOCCNRF.txt中的数据拷贝到AMPBOC.txt文件中,并且bulk insert 到T_PL_PR_ALS表中
        /// Step1.3:备份PBOCCNRF.txt到C:\FPP\Export\bk\(日期)\
        /// Step2:判断备份路径存不存在,不存在则抛出error Message:Have no history ALS file
        /// Step2.1:根据月份删除T_PL_PR_ALS表中的数据
        /// Step2.2 PBOCCNRF.txt中的数据拷贝到AMPBOC.txt文件中,并且bulk insert 到T_PL_PR_ALS表中
        /// </summary>
        /// <param name="strData_YM"></param>
        /// <returns></returns>
        public string ImportALS(string strData_YM)
        {
            var errorMessage = "";
            var strSourcePathForALS = CommonUtility.PBOCSourcePathForALS();
            var strBackupPathALS = CommonUtility.PBOCBackupPathForALS();
            string strBackupPath = "";
            string strSYS_YM = DateTime.Now.AddMonths(-1).ToString("yyyyMM");
            log.DebugLog("strSourcePathForALS:" + strSourcePathForALS,MethodBase.GetCurrentMethod().Name);
            log.DebugLog("strBackupPathALS:" + strBackupPathALS, MethodBase.GetCurrentMethod().Name);
            log.DebugLog("strSYS_YM:" + strSYS_YM, MethodBase.GetCurrentMethod().Name);
            //import ALS record
            if (strSYS_YM.Equals(strData_YM))
            {
                log.DebugLog("strSYS_YM is equals strData_YM", MethodBase.GetCurrentMethod().Name);
                if (!PBOCDao.ClearImportData(strData_YM))
                {
                    errorMessage = "there is no data in T_PL_RP_ALS table";
                    log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                    return errorMessage;
                }

                //import ALS record
                log.DebugLog("before splitReport  ALS:" + strSourcePathForALS, MethodBase.GetCurrentMethod().Name);
                errorMessage = SplitReport(strSourcePathForALS, Constants.ALSPrefixfileName, Constants.ReportFileMode.BinaryFile, ConvertUtility.Int32TryParse(CommonUtility.PBOCLineLengthForALS()), "", strBackupPathALS, strData_YM);
                if (errorMessage != "")
                {
                    log.ErrorLog("splitReport ALS false", MethodBase.GetCurrentMethod().Name);
                    log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                    return errorMessage;
                }
                log.DebugLog(" splitReport ALS ture :", MethodBase.GetCurrentMethod().Name);
                log.DebugLog("after splitReport  ALS:", MethodBase.GetCurrentMethod().Name);
                if (strBackupPathALS.Length > 0)
                {
                    if (!Directory.Exists(strBackupPathALS))
                    {
                        Directory.CreateDirectory(strBackupPathALS);
                    }
                    string[] strArray = strSourcePathForALS.Split('\\');
                    if (strBackupPathALS.Substring(strBackupPathALS.Length - 1, 1).Equals("\\"))
                    {
                        strBackupPath = strBackupPathALS + strData_YM + strArray[strArray.Length - 1];
                    }
                    else
                    {
                        strBackupPath = strBackupPathALS + "\\" + strData_YM + strArray[strArray.Length - 1];
                    }
                    File.Copy(strSourcePathForALS, strBackupPath, true);

                }
            }
            else
            {
                log.DebugLog("strSYS_YM is not equals strData_YM", MethodBase.GetCurrentMethod().Name);
                if (strBackupPathALS.Length > 0)
                {
                    log.DebugLog("strBackupPathALS's length is more than 0", MethodBase.GetCurrentMethod().Name);
                    string[] strArray = strSourcePathForALS.Split('\\');
                    if (strBackupPathALS.Substring(strBackupPathALS.Length - 1, 1).Equals("\\"))
                    {
                        strBackupPath = strBackupPathALS + strData_YM + strArray[strArray.Length - 1];
                    }
                    else
                    {
                        strBackupPath = strBackupPathALS + "\\" + strData_YM + strArray[strArray.Length - 1];
                    }
                    if (!File.Exists(strBackupPath))
                    {
                        errorMessage = "Have no history ALS file";
                        log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                        return errorMessage;
                    }
                }
                else
                {
                    log.DebugLog("strBackupPathALS's length is less than or equal with 0", MethodBase.GetCurrentMethod().Name);
                    errorMessage = "Have no history ALS file";
                    log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                    return errorMessage;
                }
                log.DebugLog("begin to clear importData", MethodBase.GetCurrentMethod().Name);
                ClearImportData(strData_YM);
                log.DebugLog("end to clear importData", MethodBase.GetCurrentMethod().Name);
                errorMessage = SplitReport(strBackupPath, Constants.PrefixFileName, ParamKeyDictionary.ReportFileMode.BinaryFile, ConvertUtility.Int32TryParse(CommonUtility.PBOCLineLengthForALS()), "", strBackupPathALS, strData_YM);
                if (errorMessage != "")
                {
                    log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                    return errorMessage;
                }
            }
            return errorMessage;
        }

        public string ImportChargeOffAccount(string strData_YM)
        {
            var errorMessage = "";
            string path = AppDomain.CurrentDomain.BaseDirectory; 
            DateTime dt = DateTime.MinValue;
            string sourceFile = "";
            string IsDev = CommonUtility.IsDev(); 
            if (path.Substring(path.Length - 1, 1).Equals("\\"))
            {
                path = path + "temp\\";
            }
            else
            {
                path = path + "\\temp\\";
            }
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            path = path + string.Format("RM charge off account list_CC{0}.xlsx", DateTime.Now.ToString("yyyyMMddHHmmss"));
            if (File.Exists(path))
            {
                File.Delete(path);
            }
            log.DebugLog("ReadChargeOffCount: " + IsDev + " - IP:" + CommonUtility.RMIP(), MethodBase.GetCurrentMethod().Name);
            log.DebugLog("ReadChargeOffCount - SourceFile: " + CommonUtility.RMSourceFile(), MethodBase.GetCurrentMethod().Name);
            if (string.IsNullOrEmpty(IsDev))
            {
                if (CommonUtility.RMIP() == "169.181.242.69" || CommonUtility.RMIP().ToLower() == "apacciticn010" ||
                    CommonUtility.RMIP() == "169.181.242.186" || CommonUtility.RMIP().ToLower() == "apacciticn018")
                {
                    sourceFile = Path.Combine(CommonUtility.RMSourceFile(), "RM charge off account list_CC.xlsx");
                }
                else
                {
                    sourceFile = Path.Combine(CommonUtility.RMSourceFile(), "RM charge off account list_CC.xlsx");
                }
            }
            else
            {
                sourceFile = Path.Combine(CommonUtility.RMSourceFile(), "RM charge off account list_CC.xlsx");
            }

            log.DebugLog("ReadChargeOffCount - sourceFile: " + sourceFile, MethodBase.GetCurrentMethod().Name);
            byte[] bytes = null;
            DownloadFile(sourceFile, ref bytes, true);
            if (bytes == null)
            {
                errorMessage = "RM charge off account list_CC.xls does not exist!";
                log.DebugLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            errorMessage = WriteChargeOffFile(bytes, path);
            if (!string.IsNullOrEmpty(errorMessage))
            {
                return errorMessage;
            }
            log.DebugLog("begin to truncate table T_PL_PR_Charge_OFF_Account", MethodBase.GetCurrentMethod().Name);
            ExecuteNonQuery("truncate table T_PL_PR_Charge_Off_Account");
            log.DebugLog("begin to truncate table T_PL_PR_Charge_OFF_Account", MethodBase.GetCurrentMethod().Name);
            Stream stream = File.Open(path, FileMode.Open);
            ExcelUtility excelUtility = new ExcelUtility();
            var data = excelUtility.ReadFirstSheetData(stream);
            if (!PBOCDao.SaveChangeOffAmount(data))
            {
                errorMessage = "保存数据出错，请重新操作!";
            }
            return errorMessage;
        }

        public string ImportRemaingMonth()
        {
            var errorMessage="";
            string strVal = "";         
            string path = AppDomain.CurrentDomain.BaseDirectory;           
            if (path.Substring(path.Length - 1, 1).Equals("\\"))
            {
                path = path + "temp\\";
            }
            else
            {
                path = path + "\\temp\\";
            }
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            path = path + string.Format("remaining month and total month{0}.xlsx", DateTime.Now.ToString("yyyyMMddHHmmss"));
            if (File.Exists(path))
            {
                File.Delete(path);
            }
            string sourceFile = "";
            string IsDev = CommonUtility.IsDev(); 
            if (string.IsNullOrEmpty(IsDev))
            {
                if (CommonUtility.PBOCIP() == "169.181.242.69" || CommonUtility.PBOCIP().ToLower() == "apacciticn010")
                {
                    sourceFile = @"\\169.181.242.69\ebs205\ALS\PBOCBureau\remaining month and total month.xlsx";
                }
                else
                {
                    sourceFile = @"\\169.181.242.107\ebs205\ALS\PBOCBureau\remaining month and total month.xlsx";
                }
            }
            else
            {
                sourceFile = @"C:\FPP\Export\remaining month and total month.xlsx";//todo
              //  sourceFile = @"\\dbddev03\App\pboc data\remaining month and total month.xls";
            }
            errorMessage = DownloadFile(sourceFile, path, true);
            if (!string.IsNullOrEmpty(errorMessage)) {
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            log.DebugLog("begin to truncate the T_PL_RemainingMonth",MethodBase.GetCurrentMethod().Name);
            ExecuteNonQuery("truncate table T_PL_RemainingMonth");
            //if(!ExecuteNonQuery("truncate table T_PL_RemainingMonth")){
            //    errorMessage = "导入RemainingMonth失败,请重试!";
            //        log.ErrorLog("删除T_PL_RemainingMonth表数据失败",MethodBase.GetCurrentMethod().Name);
            //        return errorMessage;
            //}
            log.DebugLog("end to truncate the T_PL_RemaingMonth",MethodBase.GetCurrentMethod().Name);
            DataSet ds = ExcelLibrary.DataSetHelper.CreateDataSet(path);
            if (!PBOCDao.SaveRemainingMonth(ds.Tables[0])) {
                errorMessage = "导入RemainingMonth失败,请重试!";
                log.ErrorLog(errorMessage,MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            //for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            //{
            //    if (ds.Tables[0].Rows[i][0].ToString().Length == 0)
            //    {
            //        break;

            //    }
            //    cmdText = "INSERT INTO  [CNRFRemainingMonth] values(";
            //    for (int j = 0; j < 4; j++)
            //    {
            //        cmdText = cmdText + string.Format("'{0}',", ds.Tables[0].Rows[i][j].ToString());

            //    }
            //    cmdText = cmdText.Substring(0, cmdText.Length - 1) + ")";
            //    splitFile.executeNonQuery(ref errMessage, cmdText);
            //    if (errMessage.Length > 0)
            //    {
            //        return;
            //    }

            //}
            return errorMessage;
        }

        public Boolean ClearImportData(string strData_YM)
        {
            return PBOCDao.ClearImportData(strData_YM);
        }

        public string SplitReport(string sourceFile, string strPreFileName, ParamKeyDictionary.ReportFileMode rptFileMode, int lineLength, string strDestPath, string strBackupPath, string strData_YM)
        {
            var errorMessage = "";
            string strFieldCaption = "";
            string strCmdText = "";
            string currentPath = CommonUtility.PBOCTempFilePath(); ;
            int codePage = 0;          

            if (!File.Exists(sourceFile))
            {
                errorMessage = string.Format("The file '{0}' does not exist (Method splitReport)", sourceFile);
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            T_PL_ReportDefination reportDef = GetReportDefinationByPreFileName(strPreFileName);
            if (reportDef == null)
            {
                errorMessage = "The report \"" + strPreFileName + " has not been setting in the system";
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            if (!(currentPath.IndexOf("\\", currentPath.Length - 1) >= 0))
            {
                currentPath = string.Format("{0}\\{1}", currentPath, reportDef.SaveFileName);
            }
            else
            {
                currentPath = string.Format("{0}{1}", currentPath, reportDef.SaveFileName);
            }
            log.DebugLog("currentPath:" + currentPath, MethodBase.GetCurrentMethod().Name);
            List<T_PL_ReportDefinationDetail> listDataSetting = GetReportDefinationDetail(reportDef.PreFilename,(int)ParamKeyDictionary.DataSource.Body);
            List<T_PL_ReportDefinationDetail> listDataSettingForHead = GetReportDefinationDetail(reportDef.PreFilename,(int)ParamKeyDictionary.DataSource.ReportHead);
            strFieldCaption = GetFieldCaption(listDataSetting, listDataSettingForHead);
            using (FileStream fileSTream1 = File.Open(sourceFile, System.IO.FileMode.Open, System.IO.FileAccess.Read))
            {
                log.DebugLog("read the source File:" + sourceFile, MethodBase.GetCurrentMethod().Name);
                if (File.Exists(currentPath))
                {
                    File.Delete(currentPath);
                }
                using (System.IO.FileStream fileSTream2 = File.Open(currentPath, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.Write))
                {
                    string[] strFileName = sourceFile.Split('\\');
                    codePage = fileEncoding.CodePage;
                    _codePage = codePage;
                    System.IO.StreamWriter wt = new StreamWriter(fileSTream2, fileEncoding);
                    System.IO.StreamReader rd;
                    BinaryReader br;
                    switch ((ParamKeyDictionary.ReportType)reportDef.ReportType)
                    {
                        case ParamKeyDictionary.ReportType.ByRows:
                            if (rptFileMode == ParamKeyDictionary.ReportFileMode.TextFile)
                            {
                                rd = new StreamReader(fileSTream1, fileEncoding);
                                SplitFileByRows(reportDef, listDataSetting, listDataSettingForHead, wt, rd, strFileName[strFileName.Length - 1]);
                            }
                            else
                            {
                                br = new BinaryReader(fileSTream1, fileEncoding);
                                SplitFileByRows(reportDef, listDataSetting, listDataSettingForHead, wt, br, strFileName[strFileName.Length - 1], lineLength);

                            }
                            break;
                        case ParamKeyDictionary.ReportType.ByFieldCaption:
                            rd = new StreamReader(fileSTream1);
                            SplitFileByFieldCaption(reportDef, listDataSetting, listDataSettingForHead, wt, rd, strFileName[strFileName.Length - 1]);
                            break;
                    }
                }
            }
            if (reportDef.TableName.Length > 0)
            {
                log.DebugLog("begin truncate table:" + reportDef.TableName, MethodBase.GetCurrentMethod().Name);
              //  ExecuteNonQuery(string.Format("truncate table {0}", reportDef.TableName));
                log.DebugLog("end truncate table:" + reportDef.TableName, MethodBase.GetCurrentMethod().Name);

                FileInfo MyFileInfo = new FileInfo(currentPath);
                float MyFileSize = (float)MyFileInfo.Length / (1024 * 1024);
                log.DebugLog(currentPath + "  File Size  " + MyFileSize.ToString(), MethodBase.GetCurrentMethod().Name);

                strCmdText = string.Format(Constants.SQLInsertCmdWithCodePage, reportDef.TableName, currentPath, codePage);
                log.DebugLog("begin bulk insert :" + strCmdText, MethodBase.GetCurrentMethod().Name);
               // ExecuteNonQuery(strCmdText);
                log.DebugLog("end bulk insert :" + strCmdText, MethodBase.GetCurrentMethod().Name);

                if (reportDef.DTSName.Length == 0)
                {
                    strFieldCaption = strFieldCaption.Replace("\t", "],[");
                    strFieldCaption = "[" + strFieldCaption + "]";
                    strCmdText = string.Format("insert into {0},[Data_YM] ({1}) Select {1},'{2}' from {3}", reportDef.TableName.Substring(4), strFieldCaption, strData_YM, reportDef.TableName);
                    log.DebugLog("begin  insert :" + strCmdText, MethodBase.GetCurrentMethod().Name);
                    ExecuteNonQuery(strCmdText);
                    log.DebugLog("end  insert :" + strCmdText, MethodBase.GetCurrentMethod().Name);
                }
                else
                {
                    strCmdText = string.Format("{0} '{1}'", reportDef.DTSName, strData_YM);
                    log.DebugLog("begin execute sp:" + reportDef.DTSName + ", parameters value is :" + strData_YM, MethodBase.GetCurrentMethod().Name);
                    ExecuteNonQuery(strCmdText);
                    log.DebugLog("end execute sp:" + reportDef.DTSName + ", parameters value is :" + strData_YM, MethodBase.GetCurrentMethod().Name);
                }
                strCmdText = string.Format("truncate table {0}", reportDef.TableName);
                log.DebugLog("begin truncate table :" + reportDef.TableName, MethodBase.GetCurrentMethod().Name);
                ExecuteNonQuery(strCmdText);
                log.DebugLog("end truncate table :" + reportDef.TableName, MethodBase.GetCurrentMethod().Name);
            }
            else
            {
                errorMessage = string.Format("The temp table {0} can not be found (Method:splitFile) ", reportDef.TableName);
                log.DebugLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            if (File.Exists(currentPath))
            {
                File.Delete(currentPath);
            }
            return errorMessage;
        }

        public T_PL_ReportDefination GetReportDefinationByPreFileName(string strPreFileName)
        {
            return PBOCDao.GetReportDefinationByPreFileName(strPreFileName);
        }

        public List<T_PL_ReportDefinationDetail> GetReportDefinationDetail(string strPreFileName, int dataSource)
        {
            List<T_PL_ReportDefinationDetail> list = new List<T_PL_ReportDefinationDetail>();
            var result = PBOCDao.GetReportDefinationDetail(strPreFileName, dataSource);
            if (result.ResultList.Count > 0)
            {
                list = result.ResultList.ToList();
            }
            return list;
        }

        public string GetFieldCaption(List<T_PL_ReportDefinationDetail> listDataSetting, List<T_PL_ReportDefinationDetail> listDataSettingForHead)
        {
            string strRtn = "";
            T_PL_ReportDefinationDetail colDataSetting;
            for (int i = 0; i < listDataSettingForHead.Count; i++)
            {
                colDataSetting = listDataSettingForHead[i];
                if (strRtn.Length > 0)
                {
                    strRtn = strRtn + "\t" + colDataSetting.ColName;
                }
                else
                {
                    strRtn = colDataSetting.ColName;
                }
            }
            for (int i = 0; i < listDataSetting.Count; i++)
            {
                colDataSetting = listDataSetting[i];
                if (strRtn.Length > 0)
                {
                    strRtn = strRtn + "\t" + colDataSetting.ColName;
                }
                else
                {
                    strRtn = colDataSetting.ColName;
                }
            }
            return strRtn;
        }

        public bool SplitFileByRows(T_PL_ReportDefination reportDef, List<T_PL_ReportDefinationDetail> listDataSetting, List<T_PL_ReportDefinationDetail> listDataSettingForHead,
                                    System.IO.StreamWriter wt, System.IO.StreamReader rd, string strFileName)
        {

            bool bReportHDStart = false;
            string strHeadData = "";
            int iReportHDRows = 0;
            int iLineRow = 1;
            bool bAvailableDataRow = false;
            int iAvailableDataRows = 0;
            string strData = "";
            string strTemp = "";
            int iMaxRows = 1;//todo 数据库里面的值都是1,可以写死
            string strFieldCaption = GetFieldCaption(listDataSetting, listDataSettingForHead);
            string line = rd.ReadLine();
            wt.WriteLine(strFieldCaption);
            while (line != null)
            {
                if (reportDef.ReportHDRows != 0)
                {
                    if (IsReportHeader(line, reportDef))
                    {
                        bReportHDStart = true;
                        bAvailableDataRow = false;
                        strHeadData = "";
                        iReportHDRows = 1;
                        if (listDataSettingForHead.Count > 0)
                        {
                            strTemp = "";
                            bAvailableDataRow = SplitLine(iReportHDRows - 1, line, listDataSettingForHead, ref strTemp);
                            if (bAvailableDataRow)
                            {
                                if (strTemp.Length > 0)
                                {
                                    if (strHeadData.Length > 0)
                                    {
                                        strHeadData = strHeadData + "\t" + strTemp;
                                    }
                                    else
                                    {
                                        strHeadData = strTemp;
                                    }

                                }
                            }

                        }
                        iLineRow = iLineRow + 1;
                        line = rd.ReadLine();
                        continue;
                    }
                    if (bReportHDStart)
                    {
                        if (iReportHDRows < reportDef.ReportHDRows)
                        {
                            iReportHDRows = iReportHDRows + 1;
                            if (listDataSettingForHead.Count > 0)
                            {
                                strTemp = "";
                                bAvailableDataRow = SplitLine(iReportHDRows - 1, line, listDataSettingForHead, ref strTemp);
                                if (bAvailableDataRow)
                                {
                                    if (strTemp.Length > 0)
                                    {
                                        if (strHeadData.Length > 0)
                                        {
                                            strHeadData = strHeadData + "\t" + strTemp;
                                        }
                                        else
                                        {
                                            strHeadData = strTemp;
                                        }
                                    }
                                }
                            }
                            iLineRow = iLineRow + 1;
                            line = rd.ReadLine();
                            continue;
                        }
                        bReportHDStart = false;
                    }
                }

                if (iAvailableDataRows == 0)
                {
                    strData = strHeadData;
                }
                strTemp = "";

                bAvailableDataRow = SplitLine(iAvailableDataRows, line, listDataSetting, ref strTemp);

                if (bAvailableDataRow)
                {
                    if (strTemp.Length > 0)
                    {
                        if (strData.Length > 0)
                        {
                            strData = strData + "\t" + strTemp;
                        }
                        else
                        {
                            strData = strTemp;
                        }
                    }
                    iAvailableDataRows = iAvailableDataRows + 1;
                    if (iAvailableDataRows == iMaxRows)
                    {
                        wt.WriteLine(strData);
                        strData = strHeadData;
                        iAvailableDataRows = 0;

                    }
                }
                else
                {
                    strTemp = line.Replace("\0", "");
                    strTemp = strTemp.Replace("\r", "");
                    strTemp = strTemp.Replace("\n", "");
                }
                iLineRow = iLineRow + 1;
                line = rd.ReadLine();
            }
            wt.Flush();
            wt.Close();
            rd.Close();
            return true;
        }

        private bool SplitFileByRows(T_PL_ReportDefination reportDef, List<T_PL_ReportDefinationDetail> listDataSetting, List<T_PL_ReportDefinationDetail> listDataSettingForHead,
                                    System.IO.StreamWriter wt, System.IO.BinaryReader rd, string strFileName, int lineLength)
        {

            bool bReportHDStart = false;
            string strHeadData = "";
            int iReportHDRows = 0;
            int iLineRow = 1;
            bool bAvailableDataRow = false;
            int iAvailableDataRows = 0;
            string strData = "";
            string strTemp = "";
            byte[] bytes = new byte[lineLength];
            int iRtn = 0;
            int iMaxRows = listDataSetting[listDataSetting.Count - 1].RowNo;
            string strFieldCaption = GetFieldCaption(listDataSetting, listDataSettingForHead);
            wt.WriteLine(strFieldCaption);
            string line = "";
            while (true)
            {
                iRtn = rd.Read(bytes, 0, lineLength);
                line = System.Text.Encoding.GetEncoding(_codePage).GetString(bytes);
                if (iRtn != lineLength)
                {
                    break;
                }
                if (reportDef.ReportHDRows != 0)
                {
                    if (IsReportHeader(line, reportDef))
                    {
                        bReportHDStart = true;
                        bAvailableDataRow = false;
                        strHeadData = "";
                        iReportHDRows = 1;
                        if (listDataSettingForHead.Count > 0)
                        {
                            strTemp = "";
                            bAvailableDataRow = SplitLine(iReportHDRows - 1, line, listDataSettingForHead, ref strTemp);
                            if (bAvailableDataRow)
                            {
                                if (strTemp.Length > 0)
                                {
                                    if (strHeadData.Length > 0)
                                    {
                                        strHeadData = strHeadData + "\t" + strTemp;
                                    }
                                    else
                                    {
                                        strHeadData = strTemp;
                                    }
                                }
                            }
                        }
                        iLineRow = iLineRow + 1;
                        continue;
                    }
                    if (bReportHDStart)
                    {
                        if (iReportHDRows < reportDef.ReportHDRows)
                        {
                            iReportHDRows = iReportHDRows + 1;
                            if (listDataSettingForHead.Count > 0)
                            {
                                strTemp = "";
                                bAvailableDataRow = SplitLine(iReportHDRows - 1, line, listDataSettingForHead, ref strTemp);
                                if (bAvailableDataRow)
                                {
                                    if (strTemp.Length > 0)
                                    {
                                        if (strHeadData.Length > 0)
                                        {
                                            strHeadData = strHeadData + "\t" + strTemp;
                                        }
                                        else
                                        {
                                            strHeadData = strTemp;
                                        }
                                    }
                                }
                            }
                            iLineRow = iLineRow + 1;
                            continue;
                        }
                        bReportHDStart = false;
                    }
                }
                if (iAvailableDataRows == 0)
                {
                    strData = strHeadData;
                }
                strTemp = "";
                bAvailableDataRow = SplitLine(iAvailableDataRows, bytes, listDataSetting, ref strTemp);
                if (bAvailableDataRow)
                {
                    if (strTemp.Length > 0)
                    {
                        if (strData.Length > 0)
                        {
                            strData = strData + "\t" + strTemp;
                        }
                        else
                        {
                            strData = strTemp;
                        }
                    }
                    iAvailableDataRows = iAvailableDataRows + 1;
                    if (iAvailableDataRows == iMaxRows)
                    {
                        wt.WriteLine(strData);
                        strData = strHeadData;
                        iAvailableDataRows = 0;
                    }
                }
                else
                {
                    strTemp = line.Replace("\0", "");
                    strTemp = strTemp.Replace("\r", "");
                    strTemp = strTemp.Replace("\n", "");
                }
                iLineRow = iLineRow + 1;
            }
            wt.Flush();
            wt.Close();
            rd.Close();
            return true;
        }

        public bool IsReportHeader(string line, T_PL_ReportDefination reportDef)
        {
            if (line == null)
            {
                return false;
            }
            if (line.Length < reportDef.ReportHDTagEndTPos)
            {
                return false;
            }
            if (line.Substring(reportDef.ReportHDTagStartPos - 1, reportDef.ReportHDTagEndTPos - reportDef.ReportHDTagStartPos + 1).Trim().Equals(reportDef.ReportHDStartTag))
            {
                return true;
            }
            return false;
        }

        private bool SplitLine(int currentRow, string line, List<T_PL_ReportDefinationDetail> listDataSetting, ref string strRtnValue)
        {
            T_PL_ReportDefinationDetail colDataSetting;
            int iRow = 0;
            string strColData = "";
            while (true)
            {
                if (iRow >= listDataSetting.Count)
                {
                    break;
                }
                colDataSetting = listDataSetting[iRow];
                if ((currentRow + 1) == colDataSetting.RowNo)
                {
                    byte[] bytes = Encoding.GetEncoding(_codePage).GetBytes(line);
                    if (bytes.Length < colDataSetting.EndPostion)
                    {
                        return false;
                    }
                    //judge length
                    if (!IsAVailableData(line, colDataSetting, ref strColData))
                    {
                        return false;
                    }
                    if (strRtnValue.Length == 0)
                    {
                        if (strColData.Length == 0)
                        {
                            strRtnValue = strColData + " ";
                        }
                        else
                        {
                            strRtnValue = strColData;
                        }
                    }
                    else
                    {
                        strRtnValue = strRtnValue + "\t" + strColData;
                    }
                }
                iRow = iRow + 1;
            }
            return true;
        }

        private bool SplitLine(int currentRow, byte[] bytes, List<T_PL_ReportDefinationDetail> listDataSetting, ref string strRtnValue)
        {
            T_PL_ReportDefinationDetail colDataSetting;
            int iRow = 0;
            string strColData = "";
            while (true)
            {
                if (iRow >= listDataSetting.Count)
                {
                    break;
                }
                colDataSetting = listDataSetting[iRow];
                if ((currentRow + 1) == colDataSetting.RowNo)
                {
                    if (bytes.Length < colDataSetting.EndPostion)
                    {
                        return false;
                    }
                    if (!IsAVailableData(bytes, colDataSetting, ref strColData))
                    {
                        return false;
                    }
                    if (strRtnValue.Length == 0)
                    {
                        if (strColData.Length == 0)
                        {
                            strRtnValue = strColData + " ";
                        }
                        else
                        {
                            strRtnValue = strColData;
                        }
                    }
                    else
                    {
                        strRtnValue = strRtnValue + "\t" + strColData;
                    }
                }
                iRow = iRow + 1;
            }
            return true;
        }

        private bool SplitLine(int currentRow, string line, List<T_PL_ReportDefinationDetail> listDataSetting, string[] strRtnValue, ref bool isLastRow)
        {
            T_PL_ReportDefinationDetail colDataSetting;
            int iRow = 0;
            string strColData = "";
            string strColCaption = "";
            int iMaxCol = listDataSetting[listDataSetting.Count - 1].ColNo;


            while (true)
            {
                if (iRow >= listDataSetting.Count)
                {
                    break;
                }
                colDataSetting = listDataSetting[iRow];
                if (!GetColCaption(colDataSetting, line, ref strColCaption))
                {
                    return false;
                }
                //if (strColCaption.Equals(colDataSetting.RowTag))　ColDataSetting.RowTag在数据库里面都是0
                if (strColCaption.Equals(0))
                {
                    if (!IsAVailableData(line, colDataSetting, ref strColData))
                    {
                        return false;
                    }
                    if (strRtnValue[colDataSetting.ColNo - 1].Length == 0)
                    {
                        strRtnValue[colDataSetting.ColNo - 1] = strColData;
                        break;
                    }
                    if (colDataSetting.ColNo == iMaxCol)
                    {
                        isLastRow = true;
                    }
                }
                iRow = iRow + 1;
            }
            return true;
        }

        private bool IsAVailableData(byte[] bytes, T_PL_ReportDefinationDetail bodyDef, ref string strRtn)
        {
            string errMessage = "";
            byte[] bUse = new byte[bodyDef.EndPostion - bodyDef.StartPostion + 1];
            for (int i = bodyDef.StartPostion - 1; i < bodyDef.EndPostion; i++)
            {
                if (i >= bytes.Length)
                    break;
                bUse[i - bodyDef.StartPostion + 1] = bytes[i];
            }
            strRtn = System.Text.Encoding.GetEncoding(_codePage).GetString(bUse);
            if (!(strRtn.Trim().Length >= bodyDef.MinLength && strRtn.Trim().Length <= bodyDef.MaxLength))
            {
                return false;
            }
            strRtn = strRtn.Trim();
            switch ((ParamKeyDictionary.DataType)bodyDef.DataType)
            {
                case ParamKeyDictionary.DataType.Int:
                    if (bodyDef.MinLength == 0)
                    {
                        if (strRtn.Length == 0)
                        {
                            strRtn = "0";
                            return true;
                        }
                    }
                    strRtn = strRtn.Replace(",", "");
                    if (CommonUtility.chkNumber(strRtn, false))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    break;
                case ParamKeyDictionary.DataType.Long:
                    if (bodyDef.MinLength == 0)
                    {
                        if (strRtn.Length == 0)
                        {
                            strRtn = "0";
                            return true;
                        }
                    }
                    strRtn = strRtn.Replace(",", "");
                    if (CommonUtility.chkNumber(strRtn, false))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    break;
                case ParamKeyDictionary.DataType.Double:
                    if (bodyDef.MinLength == 0)
                    {
                        if (strRtn.Length == 0)
                        {
                            strRtn = "0";
                            return true;
                        }
                    }
                    strRtn = strRtn.Replace(",", "");
                    if (CommonUtility.chkNumber(strRtn, true))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    break;
                case ParamKeyDictionary.DataType.Date:
                    if (strRtn.Trim().Length == 0 && bodyDef.MinLength == 0)
                        return true;
                    if (strRtn.Trim().Equals("12319999"))
                    {
                        strRtn = "9999/12/31";
                        return true;
                    }
                    strRtn = CommonUtility.chkDate(ref errMessage, strRtn, bodyDef.DataFormat);
                    if (errMessage.Length == 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    break;
                case ParamKeyDictionary.DataType.Text:
                    return true;
                    break;
                case ParamKeyDictionary.DataType.Time:
                    if (strRtn.Trim().Length == 0 && bodyDef.MinLength == 0)
                        return true;
                    strRtn = CommonUtility.chkTime(ref errMessage, strRtn, bodyDef.DataFormat);
                    if (errMessage.Length == 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    break;

            }
            return true;
        }

        private bool IsAVailableData(string strValue, T_PL_ReportDefinationDetail bodyDef, ref string strRtn)
        {
            string errMessage = "";
            byte[] bytes = Encoding.GetEncoding(_codePage).GetBytes(strValue);
            byte[] bUse = new byte[bodyDef.EndPostion - bodyDef.StartPostion + 1];
            for (int i = bodyDef.StartPostion - 1; i < bodyDef.EndPostion; i++)
            {
                if (i >= bytes.Length)
                    break;

                bUse[i - bodyDef.StartPostion + 1] = bytes[i];
            }
            strRtn = System.Text.Encoding.GetEncoding(_codePage).GetString(bUse);
            if (!(strRtn.Trim().Length >= bodyDef.MinLength && strRtn.Trim().Length <= bodyDef.MaxLength))
            {
                return false;
            }
            strRtn = strRtn.Trim();
            switch ((ParamKeyDictionary.DataType)bodyDef.DataType)
            {
                case ParamKeyDictionary.DataType.Int:
                    if (bodyDef.MinLength == 0)
                    {
                        if (strRtn.Length == 0)
                        {
                            strRtn = "0";
                            return true;
                        }
                    }
                    strRtn = strRtn.Replace(",", "");
                    if (CommonUtility.chkNumber(strRtn, false))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    break;
                case ParamKeyDictionary.DataType.Long:
                    if (bodyDef.MinLength == 0)
                    {
                        if (strRtn.Length == 0)
                        {
                            strRtn = "0";
                            return true;
                        }
                    }
                    strRtn = strRtn.Replace(",", "");
                    if (CommonUtility.chkNumber(strRtn, false))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    break;
                case ParamKeyDictionary.DataType.Double:
                    if (bodyDef.MinLength == 0)
                    {
                        if (strRtn.Length == 0)
                        {
                            strRtn = "0";
                            return true;
                        }
                    }
                    strRtn = strRtn.Replace(",", "");
                    if (CommonUtility.chkNumber(strRtn, true))
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    break;
                case ParamKeyDictionary.DataType.Date:
                    //judge later
                    if (strRtn.Trim().Length == 0 && bodyDef.MinLength == 0)
                        return true;
                    //12319999
                    if (strRtn.Trim().Equals("12319999"))
                    {
                        strRtn = "9999/12/31";
                        return true;
                    }
                    strRtn = CommonUtility.chkDate(ref errMessage, strRtn, bodyDef.DataFormat);
                    if (errMessage.Length == 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }

                    break;
                case ParamKeyDictionary.DataType.Text:
                    return true;
                    break;
                case ParamKeyDictionary.DataType.Time:
                    if (strRtn.Trim().Length == 0 && bodyDef.MinLength == 0)
                        return true;
                    strRtn = CommonUtility.chkTime(ref errMessage, strRtn, bodyDef.DataFormat);
                    if (errMessage.Length == 0)
                    {
                        return true;
                    }
                    else
                    {
                        return false;
                    }
                    break;

            }
            return true;
        }

        private bool SplitFileByFieldCaption(T_PL_ReportDefination reportDef, List<T_PL_ReportDefinationDetail> listDataSetting, List<T_PL_ReportDefinationDetail> listDataSettingForHead,
                                            System.IO.StreamWriter wt, System.IO.StreamReader rd, string strFileName)
        {
            bool bReportHDStart = false;
            string strHeadData = "";
            int iReportHDRows = 0;
            bool bAvailableDataRow = false;
            int iAvailableDataRows = 0;
            string strData = "";
            string strTemp = "";
            int iLineRow = 1;
            bool bflg = false;
            bool isLastRow = false;
            string strFieldCaption = GetFieldCaption(listDataSetting, listDataSettingForHead);
            string[] strFields = new string[listDataSetting.Count + listDataSettingForHead.Count];
            wt.WriteLine(strFieldCaption);
            string line = rd.ReadLine();
            while (line != null)
            {
                if (IsReportHeader(line, reportDef))
                {
                    bReportHDStart = true;
                    bAvailableDataRow = false;
                    strHeadData = "";
                    iReportHDRows = 1;
                    if (listDataSettingForHead.Count > 0)
                    {
                        strTemp = "";
                        bAvailableDataRow = SplitLine(iReportHDRows - 1, line, listDataSettingForHead, ref strTemp);
                        if (bAvailableDataRow)
                        {
                            if (strTemp.Length > 0)
                            {
                                if (strHeadData.Length > 0)
                                {
                                    strHeadData = strHeadData + "\t" + strTemp;
                                }
                                else
                                {
                                    strHeadData = strTemp;
                                }
                            }
                        }
                    }
                    iLineRow = iLineRow + 1;
                    line = rd.ReadLine();
                    continue;
                }
                if (bReportHDStart)
                {
                    if (iReportHDRows < reportDef.ReportHDRows)
                    {
                        iReportHDRows = iReportHDRows + 1;
                        if (listDataSettingForHead.Count > 0)
                        {
                            strTemp = "";
                            bAvailableDataRow = SplitLine(iReportHDRows - 1, line, listDataSettingForHead, ref strTemp);
                            if (bAvailableDataRow)
                            {
                                if (strTemp.Length > 0)
                                {
                                    if (strHeadData.Length > 0)
                                    {
                                        strHeadData = strHeadData + "\t" + strTemp;
                                    }
                                    else
                                    {
                                        strHeadData = strTemp;
                                    }
                                }
                            }
                        }
                        iLineRow = iLineRow + 1;
                        line = rd.ReadLine();
                        continue;

                    }
                    bReportHDStart = false;
                }
                if (iAvailableDataRows == 0)
                {
                    for (int i = 0; i < strFields.Length; i++)
                    {
                        strFields[i] = "";
                    }
                    if (strHeadData.Length > 0)
                    {
                        string[] strHeadFields = strHeadData.Split('\t');
                        for (int j = 0; j < strHeadFields.Length; j++)
                        {
                            strFields[j] = strHeadFields[j];
                        }
                    }
                    strData = strHeadData;
                }
                strTemp = "";
                isLastRow = false;
                if (IsFooter(line, reportDef))
                {
                    if (bflg)
                    {
                        if (VerifyData(strFields, listDataSetting))
                        {
                            for (int i = 0; i < strFields.Length; i++)
                            {
                                if (i == 0)
                                {
                                    strData = strFields[i];
                                }
                                else
                                {
                                    strData = strData + "\t" + strFields[i];
                                }
                            }
                            wt.WriteLine(strData);
                        }
                        else
                        {
                            for (int i = 0; i < strFields.Length; i++)
                            {
                                if (i == 0)
                                {
                                    strData = strFields[i];
                                }
                                else
                                {
                                    strData = strData + "\t" + strFields[i];
                                }
                            }
                        }
                        strData = strHeadData;
                        iAvailableDataRows = 0;
                    }
                    bflg = true;
                    for (int i = 0; i < strFields.Length; i++)
                    {
                        strFields[i] = "";
                    }
                    if (strHeadData.Length > 0)
                    {
                        string[] strHeadFields = strHeadData.Split('\t');
                        for (int j = 0; j < strHeadFields.Length; j++)
                        {
                            strFields[j] = strHeadFields[j];
                        }
                    }
                    strData = strHeadData;
                }

                bAvailableDataRow = SplitLine(iAvailableDataRows, line, listDataSetting, strFields, ref isLastRow);

                if (bAvailableDataRow)
                {

                    iAvailableDataRows = iAvailableDataRows + 1;
                    strData = "";


                }
                else
                {
                    strTemp = line.Replace("\0", "");
                    strTemp = strTemp.Replace("\r", "");
                    strTemp = strTemp.Replace("\n", "");
                }
                iLineRow = iLineRow + 1;
                line = rd.ReadLine();
            }

            if (bflg)
            {
                if (VerifyData(strFields, listDataSetting))
                {
                    for (int i = 0; i < strFields.Length; i++)
                    {
                        if (i == 0)
                        {
                            strData = strFields[i];
                        }
                        else
                        {
                            strData = strData + "\t" + strFields[i];
                        }
                    }
                    wt.WriteLine(strData);
                }
                else
                {
                    for (int i = 0; i < strFields.Length; i++)
                    {
                        if (i == 0)
                        {
                            strData = strFields[i];
                        }
                        else
                        {
                            strData = strData + "\t" + strFields[i];
                        }
                    }
                }
                strData = strHeadData;
                iAvailableDataRows = 0;
            }
            wt.Flush();
            wt.Close();
            rd.Close();
            return true;
        }

        public bool IsFooter(string line, T_PL_ReportDefination reportDef)
        {
            if (line == null)
            {
                return false;
            }
            if (line.Length < reportDef.FooterTagEndPos)
            {
                return false;
            }
            if (line.Substring(reportDef.FooterTagStartPos - 1, reportDef.FooterTagEndPos - reportDef.FooterTagStartPos + 1).Trim().Equals(reportDef.FooterTag))
            {
                return true;
            }
            return false;
        }

        private bool VerifyData(string[] Fields, List<T_PL_ReportDefinationDetail> listDataSetting)
        {
            T_PL_ReportDefinationDetail colDataSetting;
            int iRow = 0;
            string strRtn = "";
            int iMaxCol = listDataSetting[listDataSetting.Count - 1].ColNo;
            if (Fields[1].Equals("000641998"))
            {
                strRtn = "";
            }

            while (true)
            {
                if (iRow >= listDataSetting.Count)
                {
                    break;
                }
                colDataSetting = listDataSetting[iRow];
                strRtn = Fields[iRow];
                if (!(strRtn.Trim().Length >= colDataSetting.MinLength && strRtn.Trim().Length <= colDataSetting.MaxLength))
                {
                    return false;
                }


                iRow = iRow + 1;
            }
            return true;
        }

        private bool GetColCaption(T_PL_ReportDefinationDetail bodyDef, string line, ref string strValue)
        {
            byte[] bytes = Encoding.GetEncoding(_codePage).GetBytes(line);
            //if (bytes.Length < bodyDef.RowTagEndPostion)//bodyDef.RowTagEndPostion在数据库里面值
            if (bytes.Length < 0)
            {
                return false;
            }
            byte[] bUse = new byte[1];
            for (int i = -1; i < 0; i++)
            {
                bUse[i + 1] = bytes[i];
            }
            //bodyDef.RowTagEndPostion 和bodyDef.RowTagStartPostion都是0
            //byte[] bUse = new byte[bodyDef.RowTagEndPostion - bodyDef.RowTagStartPostion + 1];
            //for (int i = bodyDef.RowTagStartPostion - 1; i < bodyDef.RowTagEndPostion; i++)
            //{
            //    bUse[i - bodyDef.RowTagStartPostion + 1] = bytes[i];
            //}
            strValue = System.Text.Encoding.GetEncoding(_codePage).GetString(bUse);
            strValue = strValue.Trim();
            return true;
        }

        private string WriteChargeOffFile(byte[] bytes, string strFileName)
        {
            var errorMessage = "";
            try
            {
                string strOutFile = strFileName;

                if (File.Exists(strOutFile))
                {
                    File.Delete(strOutFile);
                }
                FileStream output = null;
                if (!File.Exists(strOutFile))
                    output = File.Create(strOutFile);
                else
                    output = new FileStream(strOutFile, FileMode.Open);
                long offset = 0;
                offset = output.Length;
                if (offset > 0)
                {
                    output.Seek(offset, SeekOrigin.Begin);
                }
                output.Write(bytes, 0, bytes.Length);
                output.Close();

                return errorMessage;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
        }

        public string DownloadFile(string strFileName, ref byte[] bytes, bool bShareFolder)
        {
            var errorMessage = "";
            try
            {
                if (bShareFolder)
                {
                    if (!CommonUtility.mapDriverPath(CommonUtility.RMMapDriver(), CommonUtility.RMShareFolder(), CommonUtility.RMDomainUser(), CommonUtility.RMPasswordForJob()))
                    {
                        errorMessage = "Failed mapping driver:";
                        log.DebugLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                        return errorMessage;
                    }
                }
                int bufferLength = 0;
                if (!File.Exists(strFileName))
                {
                    errorMessage = "The  file does not exist";
                    log.DebugLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                    return errorMessage;
                }
                FileInfo fi = new FileInfo(strFileName);
                bytes = new byte[fi.Length];
                FileStream input = fi.Open(FileMode.Open);
                bufferLength = input.Read(bytes, 0, bytes.Length);
                input.Close();
                return errorMessage;
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message.ToString();
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
        }

        private string DownloadFile(string srcFile, string destDir, bool isShareFolder)
        {
            var errorMessage = "";            
            int bufferLength = 0;
            if (!File.Exists(srcFile))
            {
                errorMessage = "The export file does not exist";
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            FileInfo fi = new FileInfo(srcFile);
            byte[] bytes = new byte[fi.Length];
            FileStream input = fi.Open(FileMode.Open);
            bufferLength = input.Read(bytes, 0, bytes.Length);
            input.Close();
            string strOutFile = destDir;
            int istrDirectory = strOutFile.LastIndexOf(@"\");
            string strDirectory = strOutFile.Substring(0, istrDirectory);
            if (!Directory.Exists(strDirectory))
            {
                Directory.CreateDirectory(strDirectory);
            }
            if (File.Exists(strOutFile))
            {
                File.Delete(strOutFile);
            }
            FileStream output = null;
            if (!File.Exists(strOutFile))
                output = File.Create(strOutFile);
            else
                output = new FileStream(strOutFile, FileMode.Open);
            long offset = 0;
            offset = output.Length;
            if (offset > 0)
            {
                output.Seek(offset, SeekOrigin.Begin);
            }
            output.Write(bytes, 0, bytes.Length);
            output.Close();
            return errorMessage;
        }

        public Dictionary<string, string> GetALSFileYearMonth()
        {
            var dictionary = new Dictionary<string, string>();
            var errorMessage = "";
            log.DebugLog("Map Path: " + CommonUtility.PBOCMapDriver(), MethodBase.GetCurrentMethod().Name);
            if (!CommonUtility.mapDriverPath(CommonUtility.PBOCMapDriver(), CommonUtility.PBOCShareFolder(), CommonUtility.PBOCDomainUser(), CommonUtility.PBOCPasswordForJob()))
            {
                errorMessage = "Map Failed;";
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
            }
            string strFileName = CommonUtility.PBOCSourcePathForALS();
            if (!File.Exists(strFileName))
            {
                errorMessage = string.Format("The ALS file '{0}' does not exist", strFileName);
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
            }
            FileInfo fileIn = new FileInfo(strFileName);
            dictionary.Add("errorMessage", errorMessage);
            dictionary.Add("DataYM", fileIn.LastWriteTime.ToString("yyyyMM"));
            return dictionary;
        }

        public Dictionary<string, object> CheckReportDataYM(string strData_YM)
        {
            var errorMessage = "";
            string strSYS_YM = DateTime.Now.AddMonths(-1).ToString("yyyyMM");
            string strFile_YM = "";
            var IsNeedConfirm = false;
            var dictionary = new Dictionary<string, object>();
            if (strSYS_YM.Equals(strData_YM))
            {
                if (GetALSFileYearMonth()["errorMessage"] != "")
                {
                    errorMessage = GetALSFileYearMonth()["errorMessage"];
                    log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                }
                else
                {
                    strFile_YM = GetALSFileYearMonth()["DataYM"];
                    if (string.IsNullOrEmpty(strFile_YM))
                    {
                        errorMessage = "The ALS file does not exist";
                        log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                    }
                    else
                    {
                        if (PBOCDao.GetHeaderDataByDataYM(strData_YM) == "")
                        {
                            IsNeedConfirm = true;
                        }
                        else {
                            errorMessage = PBOCDao.GetHeaderDataByDataYM(strData_YM);
                        }
                    }
                }
            }
            dictionary.Add("errorMessage", errorMessage);
            dictionary.Add("isNeedConfirm", IsNeedConfirm);
            return dictionary;
        }

        public void CreateAndReadyAllWriter(string _strData_YM)
        {
            CreateAllWriter(_strData_YM);
            GetAllWriterReady();
        }

        public void CreateAllWriter(string _strData_YM)
        {
            CreateTxtWriter();//create all TxtWriter.
            CreateCvsWriter(_strData_YM);
            CreateTempWriter();
        }

        public void CreateTxtWriter()
        {
            foreach (var v in Keys)
            {
                listTxtWriter.Add(v, new TxtWriter(KeyNamePairs[v].ToString()));
            }
        }

        public void CreateCvsWriter(string _strData_YM)
        {
            foreach (var v in Keys)
            {
                listCvsWriter.Add(v, new CvsWriter(_strData_YM, KeyNamePairs[v].ToString()));
            }
        }

        public void CreateTempWriter()
        {
            foreach (var v in Keys)
            {
                listTempWriter.Add(v, new TempWriter(KeyNamePairs[v].ToString()));
            }
        }

        public void GetAllWriterReady()
        {
            foreach (IWriter writer in listTxtWriter.Values)
            {
                writer.Ready();
            }
            foreach (IWriter writer in listCvsWriter.Values)
            {
                writer.Ready();
            }
            foreach (IWriter writer in listTempWriter.Values)
            {
                writer.Ready();
            }
        }

        public string leftByUnicode(string strsrc, int icount)
        {
            byte[] bytes = System.Text.Encoding.GetEncoding(_codePage).GetBytes(strsrc);

            if (strsrc == null || bytes.Length <= icount)
                return strsrc;
            byte[] tmpBytes = new byte[icount];
            for (int i = 0; i < icount; i++)
            {
                tmpBytes[i] = bytes[i];
            }
            return System.Text.Encoding.GetEncoding(_codePage).GetString(tmpBytes);
        }

        public string MakeString(string source, int length, string lor)
        {
            string mkString;

            int i = System.Text.Encoding.GetEncoding(_codePage).GetBytes(source).Length;
            if (i > length)
                mkString = leftByUnicode(source, length);
            else
                if (lor.Equals("L") == true)
                    mkString = source + CommonUtility.Space(length - i);
                else
                    mkString = CommonUtility.Space(length - i) + source;
            return mkString;
        }

        public string GetGeneratingReportHeader(int iRecordCount, string key, string strData_YM)
        {
            string FormatNo = CommonUtility.PBOCFormatNo().ToString().Trim();
            string FinInsCode = string.Empty;
            log.ErrorLog("ReportHeader1", MethodBase.GetCurrentMethod().Name);
            if (key.Equals("1"))
            {
                FinInsCode = CommonUtility.PBOCFinInsCode().ToString().Trim();
            }
            else if (key.Equals("2"))
            {
                FinInsCode = CommonUtility.PBOCFinInsCodeCB().ToString().Trim();
            }
            else if (key.Equals("3"))
            {
                FinInsCode = CommonUtility.PBOCFinInsCodeWCF().ToString().Trim();
            }
            else if (key.Equals("4"))
            {
                FinInsCode = CommonUtility.PBOCFinInsCodeBB().ToString().Trim();
            }
            log.ErrorLog("ReportHeader1", MethodBase.GetCurrentMethod().Name);
            string CrtDate = System.DateTime.Now.ToString("yyyyMMddhhmmss");
            string ContributionRefNo = CommonUtility.PBOCContributionRefNo().ToString().Trim();
            string ResubmissionCode = CommonUtility.PBOCResubmissionCode().ToString().Trim();
            string RptType = CommonUtility.PBOCReportType().ToString().Trim();
            string ContactPerson = MakeString(CommonUtility.PBOCContactPerson().ToString().Trim(), 30, "L");
            string ContactPhone = MakeString(CommonUtility.PBOCContactPhone().ToString().Trim(), 25, "L");
            string EDueDate = "";
            string LDueDate = "";

            //EDueDate = strData_YM + "09";
            EDueDate = strData_YM + "01";
            LDueDate = DateTime.Parse(strData_YM.Substring(0, 4) + "/" + strData_YM.Substring(4, 2) + "/01").AddDays(31).ToString("yyyy/MM/dd");
            LDueDate = DateTime.Parse(LDueDate.Substring(0, 8) + "01").AddDays(-1).ToString("yyyyMMdd");
            log.DebugLog("ReportHead2", MethodBase.GetCurrentMethod().Name);
            //insert record into CNRFPR_Header
            if (!PBOCDao.AddFileHeader(FormatNo, FinInsCode, CrtDate, ContributionRefNo, ResubmissionCode, RptType, iRecordCount.ToString(), EDueDate, LDueDate, ContactPerson, ContactPhone, "", strData_YM))
            {
                log.ErrorLog("insert into header failed", MethodBase.GetCurrentMethod().Name);
                return "";
            }
            log.DebugLog("ReportHead3:", MethodBase.GetCurrentMethod().Name);
            string strheader = FormatNo + FinInsCode + CrtDate + ContributionRefNo + ResubmissionCode + RptType + MakeString(iRecordCount.ToString(), 10, "R") + EDueDate + LDueDate + MakeString(ContactPerson, 30, "L") + MakeString(ContactPhone, 25, "L") + CommonUtility.Space(30);
            log.DebugLog("strheader:" + strheader, MethodBase.GetCurrentMethod().Name);
            return strheader;
        }

        public void WriteCvsLine(string fieldContainsKey, string content)
        {
            string key = fieldContainsKey;// get the key value,it decides whcih TxtWriter will be used
            if (listCvsWriter != null && listCvsWriter.Keys.Contains(key))
            {
                listCvsWriter[key].WriteLine(content);
            }
        }

        public PBOCData GetLastDeliHisStatus(string accountNo, string dataYM)
        {
            DataSet ds = PBOCDao.GetLastDeliHisStatus(accountNo, dataYM);
            if (ds.Tables[0].Rows.Count > 1)
            {
                ds.Clear();
                throw new Exception("More than one DeliHisStatus record");
            }
            else if (ds.Tables[0].Rows.Count == 0)
            {
                PBOCData PBOCda = new PBOCData();
                PBOCda.Delinq_History = string.Empty;
                return PBOCda;
            }
            else
            {
                return MakePBCOData(ds);
            }
        }

        private static PBOCData MakePBCOData(DataSet ds)
        {
            PBOCData PBOCDa = new PBOCData();
            if (ds.Tables[0].Rows.Count < 1)
            {
                return null;
            }
            else
            {
                //[BI_Cust_Name], [BI_ID_Type], [BI_ID_No]
                PBOCDa.Delinq_History = ds.Tables[0].Rows[0]["BI_Last_24Months_Delinq_History"].ToString();
                PBOCDa.Id = ds.Tables[0].Rows[0]["BI_ID_No"].ToString();
                PBOCDa.Name = ds.Tables[0].Rows[0]["BI_Cust_Name"].ToString();
                PBOCDa.Id_Type = ds.Tables[0].Rows[0]["BI_ID_Type"].ToString();
                PBOCDa.AccountNo = ds.Tables[0].Rows[0]["BI_Acc_No"].ToString();
                PBOCDa.ValidData = ds.Tables[0].Rows[0]["ValidData"].ToString();
            }
            return PBOCDa;
        }

        private string processCustName(string custName)
        {
            custName = custName.Replace("小姐", "");
            custName = custName.Replace("先生", "");
            custName = custName.Replace("MR.", "");
            custName = custName.Replace("Mr.", "");
            custName = custName.Replace("mr.", "");
            custName = custName.Replace("MS.", "");
            custName = custName.Replace("Ms.", "");
            custName = custName.Replace("ms.", "");
            custName = custName.Replace("MR", "");
            custName = custName.Replace("Mr", "");
            custName = custName.Replace("mr", "");
            custName = custName.Replace("MS", "");
            custName = custName.Replace("Ms", "");
            custName = custName.Replace("ms", "");
            custName = custName.Replace(" ", "");

            return custName;
        }

        public string MakeStrGrbMode(string s, int l, string lor)
        {
            int i;
            string grbModeString = s;
            i = System.Text.Encoding.GetEncoding(_codePage).GetBytes(s).Length;
            if (i > l)
                grbModeString = leftByUnicode(s, l);
            else
                if (lor == "L")
                    grbModeString = grbModeString + CommonUtility.Space(l - i);
                else
                    grbModeString = CommonUtility.Space(l - i) + grbModeString;
            return grbModeString;
        }

        public string GetNationid(string nation, string STRL)
        {
            string GetNationid = "";

            switch (nation)
            {
                case "CN":
                    if (STRL.Length != 18 && STRL.Trim().Length != 15)
                        GetNationid = "2";
                    else
                        GetNationid = "0";
                    break;
                case "TW":
                    GetNationid = "6";
                    break;
                case "HK":
                    GetNationid = "5";
                    break;
                case "MO":
                    GetNationid = "5";
                    break;
                default:
                    GetNationid = "2";
                    break;
            } return GetNationid;
        }

        public int GetLength(string strChar)
        {
            int i = System.Text.Encoding.GetEncoding(_codePage).GetBytes(strChar).Length;
            return i;
        }

        public double GetCNY(string CURR, double AMOUNT,System.Data.DataTable _rate)
        {
            double curr = 0.0;
            string errMessage = string.Empty;
            if (_rate.Rows.Count > 0)
            {
                foreach (DataRow row in _rate.Rows)
                {
                    if (row["Currency_Code"].ToString().CompareTo(CURR) == 0)
                    {
                        curr = AMOUNT / (double)row["Currency_Rate"];
                        break;
                    }
                }
            }
            else
                curr = AMOUNT;
            return curr;
        }

        private string GetSpecialSign(string sign, int len)
        {
            StringBuilder strBulider = new StringBuilder();
            for (int i = 1; i <= len; i++)
            {
                strBulider.Append(sign);
            }
            return strBulider.ToString();
        }

        private string MakeDeliHistoryStatus(string lastDeliHistoryStatus, string currentDeliStatus)
        {

            string currentDeliHistoryStatus = string.Empty;
            if (currentDeliStatus.Length == 1)
            {
                currentDeliHistoryStatus = lastDeliHistoryStatus.Substring(1, lastDeliHistoryStatus.Length - 1) + currentDeliStatus;
                return currentDeliHistoryStatus;
            }
            return currentDeliHistoryStatus;
        }

        private string right(string strsrc, int icount)
        {
            if (strsrc == null || strsrc.Length <= icount)
                return strsrc;
            return strsrc.Substring(strsrc.Length - icount);
        }

        public string GetDeliHistoryStatus(string accountNo, string currentDeliStatus, int diffMonths, string dataYM)
        {

            string currentDeliHistoryStatus = string.Empty;
            string lastDeliHistoryStatus = GetLastDeliHisStatus(accountNo, dataYM).Delinq_History;
            if (lastDeliHistoryStatus.Equals(string.Empty))
            {
                currentDeliHistoryStatus = GetSpecialSign(ParamKeyDictionary.LineSign, 24 - diffMonths - 1) + GetSpecialSign(ParamKeyDictionary.JingSign, diffMonths) + currentDeliStatus;
                if (!currentDeliHistoryStatus.Equals(string.Empty))
                {
                    if (currentDeliHistoryStatus.Length > 24)
                    {
                        return currentDeliHistoryStatus.Substring(currentDeliHistoryStatus.Length - 24, 24);
                    }
                    return currentDeliHistoryStatus;
                }
            }
            else
            {
                currentDeliHistoryStatus = MakeDeliHistoryStatus(lastDeliHistoryStatus, currentDeliStatus);
                if (!currentDeliHistoryStatus.Equals(string.Empty))
                {
                    if (currentDeliHistoryStatus.Length > 24)
                    {
                        return currentDeliHistoryStatus.Substring(currentDeliHistoryStatus.Length - 24, 24);
                    }
                    return currentDeliHistoryStatus;
                }
            }
            return currentDeliHistoryStatus;
        }

        public string MakeNum(string s, int l, string lor)
        {
            int i = System.Text.Encoding.GetEncoding(_codePage).GetBytes(s).Length;

            string makenum = "";
            if (i > l)
                makenum = leftByUnicode(s, l);
            else
                if (lor == "L")
                    makenum = s + Space(l - i, "0");
                else
                    makenum = Space(l - i, "0") + s;
            return makenum;
        }

        private string Space(int num, string strChar)
        {
            string strSpace = "";
            for (int i = 0; i < num; i++)
                strSpace = strSpace + strChar;
            return strSpace;
        }

        public string GetRC(string rc)
        {
            string getrc = "";
            switch (rc)
            {
                case "1":
                    getrc = "310000";
                    break;
                case "2":
                    getrc = "110000";
                    break;
                case "3":
                    getrc = "440100";
                    break;
                case "4":
                    getrc = "500109";
                    break;
                case "5":
                    getrc = "210200";
                    break;
                case "6":
                    getrc = "421200";
                    break;
                case "7":
                    getrc = "421000";
                    break;
                case "8":
                    getrc = "210200";
                    break;
                case "9":
                    getrc = "510100";
                    break;
                default:
                    getrc = "000000";
                    break;
            }
            return getrc;
        }

        public string GetCurr(string GEN,System.Data.DataTable _rate)
        {
            string getCurr = string.Empty;
            if (_rate.Rows.Count > 0)
            {
                foreach (DataRow row in _rate.Rows)
                {
                    if (row["Currency_Code"].ToString().CompareTo(GEN) == 0)
                    {
                        getCurr = row["Currency_Name"].ToString();
                        break;
                    }
                }
            }
            else
                getCurr = "";
            return getCurr;
        }

        public string GetGen(string GEN)
        {
            string getgen = "";
            if (GEN == "F")
                getgen = "2";
            else if (GEN == "M")
                getgen = "1";
            else
                getgen = "9";
            return getgen;
        }

        private string getLoanTypeByAcc(string strAcc)
        {
            if (strAcc.Substring(6, 1).Equals("5"))
            {
                return "11";
            }
            else
            {
                return "99";
            }
        }

        private string getResidentType(string residentType)
        {
            /*contain(S)=1
            contain(M)=2
            contain(L)=3
            contain(Q)=4
            contain(R)=5
            contain(O)=7*/
            if (residentType.Contains("S"))
            {
                return "1";
            }
            if (residentType.Contains("M"))
            {
                return "2";
            }
            if (residentType.Contains("L"))
            {
                return "3";
            }
            if (residentType.Contains("Q"))
            {
                return "4";
            }
            if (residentType.Contains("R"))
            {
                return "5";
            }
            if (residentType.Contains("O"))
            {
                return "7";
            }
            return "9";

        }

        public void WriteTempLine(string fieldContainsKey, string content)
        {

            string key = fieldContainsKey; //get the key value,it decides which TempWriter will be used
            if (listTempWriter != null && listTempWriter.Keys.Contains(key))
            {
                listTempWriter[key].WriteLine(content);
            }
        }

        public void WriteTxtLine(string fieldContainsKey, string Content)
        {
            string key = fieldContainsKey;// get the key value,which decide whcih TxtWriter will be used
            if (listTxtWriter != null && listTxtWriter.Keys.Contains(key))
            {
                listTxtWriter[key].WriteLine(Content);
            }
        }

        private string getGeneratingReportHeader(int iRecordCount, string key, ref string strCmdText, string strData_YM)
        {
            string FormatNo = CommonUtility.PBOCFormatNo().ToString().Trim();
            string FinInsCode = string.Empty;
            if (key.Equals("1"))
            {
                FinInsCode = CommonUtility.PBOCFinInsCode().ToString().Trim();
            }
            else if (key.Equals("2"))
            {
                FinInsCode = CommonUtility.PBOCFinInsCodeCB().ToString().Trim();
            }
            else if (key.Equals("3"))
            {
                FinInsCode = CommonUtility.PBOCFinInsCodeWCF().ToString().Trim();
            }
            else if (key.Equals("4"))
            {
                FinInsCode = CommonUtility.PBOCFinInsCodeBB().ToString().Trim();
            }
            string CrtDate = System.DateTime.Now.ToString("yyyyMMddhhmmss");
            string ContributionRefNo = CommonUtility.PBOCContributionRefNo().ToString().Trim();
            string ResubmissionCode = CommonUtility.PBOCResubmissionCode().ToString().Trim();
            string RptType = CommonUtility.PBOCReportType().ToString().Trim();
            string ContactPerson = MakeString(CommonUtility.PBOCContactPerson().ToString().Trim(), 30, "L");
            string ContactPhone = MakeString(CommonUtility.PBOCContactPhone().ToString().Trim(), 25, "L");
            string EDueDate = "";
            string LDueDate = "";

            EDueDate = strData_YM + "01";
            LDueDate = DateTime.Parse(strData_YM.Substring(0, 4) + "/" + strData_YM.Substring(4, 2) + "/01").AddDays(31).ToString("yyyy/MM/dd");
            LDueDate = DateTime.Parse(LDueDate.Substring(0, 8) + "01").AddDays(-1).ToString("yyyyMMdd");
            log.DebugLog("ReportHead2", MethodBase.GetCurrentMethod().Name);
            if (!PBOCDao.AddFileHeader(FormatNo, FinInsCode, CrtDate, ContributionRefNo, ResubmissionCode, RptType, iRecordCount.ToString(), EDueDate, LDueDate, ContactPerson, ContactPhone, "", strData_YM))
            {
                log.ErrorLog("insert into header failed", MethodBase.GetCurrentMethod().Name);
                return "";
            }
            log.DebugLog("ReportHead3", MethodBase.GetCurrentMethod().Name);
            string strheader = FormatNo + FinInsCode + CrtDate + ContributionRefNo + ResubmissionCode + RptType + MakeString(iRecordCount.ToString(), 10, "R") + EDueDate + LDueDate + MakeString(ContactPerson, 30, "L") + MakeString(ContactPhone, 25, "L") + CommonUtility.Space(30);
            log.DebugLog("strheader :" + strheader, MethodBase.GetCurrentMethod().Name);
            return strheader;

        }

        public string getExportFileName(string strData_YM)
        {
            string h = "";
            if (!Directory.Exists(CommonUtility.PBOCExportPath()))
            {
                Directory.CreateDirectory(CommonUtility.PBOCExportPath());
            }
            if (CommonUtility.PBOCExportPath().Substring(CommonUtility.PBOCExportPath().Length - 1, 1).Equals("\\"))
            {
                h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000.txt", CommonUtility.PBOCFinInsCode().ToString(), strData_YM);
            }
            else
            {
                h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000.txt", CommonUtility.PBOCFinInsCode().ToString(), strData_YM);
            }
            return h;
        }

        public string GetPathForTempFile(string key)
        {

            string rePaths = string.Empty;
            if (listTempWriter[key] != null)
            {
                rePaths = listTempWriter[key].Path;
            }
            return rePaths;
        }

        private bool processHeaderFormat(Hashtable hashTable, string strData_YM)
        {
            string strLine = "";
            string errMsg = "";
            int iRecordCount = 0;         
            foreach (object o in hashKeyNamePairs.Keys)
            {
                string key = o.ToString();
                string name = hashKeyNamePairs[key].ToString();

                if (hashTable[key] != null)
                {
                    iRecordCount = int.Parse(hashTable[key].ToString());
                }
                string strheader = GetGeneratingReportHeader(iRecordCount, key, strData_YM);//@@@here ,use the iRecordCount
                StreamWriter swReport;
                FileStream fsReport;
                if (!Directory.Exists(CommonUtility.PBOCExportPath()))
                {
                    Directory.CreateDirectory(CommonUtility.PBOCExportPath());
                }
                string strExportFile = GetExportFileName(name, strData_YM);
                if (File.Exists(strExportFile))
                {
                    File.Delete(strExportFile);
                }
                string tempFile = GetPathForTempFile(key);//get the temp file name

                fsReport = File.Open(strExportFile, FileMode.OpenOrCreate, FileAccess.Write);//C:\aaaa\W20472900B00022008090011000.txt
                swReport = new StreamWriter(fsReport, fileEncoding);
                swReport.WriteLine(strheader);
                swReport.WriteLine("");
                swReport.Flush();

                FileStream fsReader = File.Open(tempFile, FileMode.Open, FileAccess.Read);//read to read temp file
                StreamReader sr = new StreamReader(fsReader, fileEncoding);
                strLine = sr.ReadLine();
                while (strLine != null)
                {
                    swReport.WriteLine(strLine);
                    swReport.Flush();
                    strLine = sr.ReadLine();
                }
                sr.Close();
                System.IO.File.Delete(tempFile);
                swReport.Close();
            }
            return true;
        }

        public void CloseAllStream()
        {
            foreach (IWriter writer in listTxtWriter.Values)
            {
                writer.Close();
            }
            foreach (IWriter writer in listCvsWriter.Values)
            {
                writer.Close();
            }
            foreach (IWriter writer in listTempWriter.Values)
            {
                writer.Close();
            }
        }

        public string[] GetPathsForTxt()
        {
            string[] rePaths = new string[listTxtWriter.Count];
            int i = 0;
            foreach (IWriter writer in listTxtWriter.Values)
            {
                rePaths[i] = writer.Path;
                i++;
            }
            return rePaths;
        }

        public string GeneratePBOCReport(string strData_YM,string exportPBOCPath)
        {
            #region properties
            int dateBetw = 0;
            string twStatus = "";
            int weiyue = 0;
            string BI_Pay_Due_Date = "";
            string BI_Last_Pay_Due_Date = "";
            string BI_Class_Loan_Type = "";
            string BI_Acc_Status = " ";
            double BI_Last_Pay_Amt = 0.00d; //Last pay amount
            double BI_Act_Pay_Amt = 0.00d; //Due amount on this month
            string strLine = "";
            string accNo = "";
            int iRecordLength = 0;
            string currMonthStatus = "";
            int iAccCount = 0;
            Hashtable hashTableIAccCount = new Hashtable();
            string strheader = "";
            string strCmdText = "";
            string seprateChar = "";
            string address = "";
            string strBodyHeader = "";
            string strServerTemppath = @"c:\temp\";
            bool flg = false;
            int codePage = 0;
            string strAccStatus = "2";
            string strValidData = "1";
            bool bValidData = false;
            FileStream fsCSVFile;
            StreamWriter swCSVFile;
            bool bChange = false;
            bool cChange = false;
            bool dChange = false;
            int ExecuteCount = 0;
            var errorMessage = "";
         
            _codePage = fileEncoding.CodePage;

            System.Data.DataTable  _rate = null;
            System.Data.DataTable dtWord = new System.Data.DataTable();
            System.Data.DataTable dtPboc = new System.Data.DataTable();

            string[] keys = null;
            string[] strFileName = null;
            byte[][] buffer = null;
            DataSet ds;
            DataView dv;
            string[] strArray;
            int bufferLength = 0;
            string strOutFile = "";
            globalExportPBOCPath = exportPBOCPath;
            globalStrData_YM = strData_YM;
            #endregion  
            //clear export data
            //CNRFPR_Header
            PBOCDao.DeleteHeaderDataByDataYM(strData_YM);
            //if (!PBOCDao.DeleteHeaderDataByDataYM(strData_YM))
            //{
            //    errorMessage = "生成报表出错，请重试!";
            //    log.ErrorLog("there is no data on T_PL_PR_Header,delete error", MethodBase.GetCurrentMethod().Name);
            //    return errorMessage;
            //}
            //CNRFPR_Body
           // PBOCDao.DeleteBodyDataByDataYM(strData_YM);//todo
            //if (!PBOCDao.DeleteBodyDataByDataYM(strData_YM))
            //{
            //    errorMessage = "生成报表出错，请重试!";
            //    log.ErrorLog("there is no data on T_PL_PR_Body,delete error", MethodBase.GetCurrentMethod().Name);
            //    return errorMessage;
            //}
            strServerTemppath = CommonUtility.PBOCTempFilePath();
            if (strServerTemppath.Length == 0)
            {
                strServerTemppath = @"d:\temp\";
            }
            if (!strServerTemppath.Substring(strServerTemppath.Length - 1, 1).Equals("\\"))
            {
                strServerTemppath = strServerTemppath + "\\";
            }
            codePage = fileEncoding.CodePage;
            //temp file for generating report          
            CreateAndReadyAllWriter(strData_YM);
            foreach (object o in Keys)
            {
                hashTableIAccCount.Add(o, "0");//.add("1","0");
            }
            if (!Directory.Exists(CommonUtility.PBOCExportCVSPath()))//create path
            {
                Directory.CreateDirectory(CommonUtility.PBOCExportCVSPath());
            }
            //for cvs file
            dtPboc = PBOCDao.GetPBOCRecord(strData_YM);

            foreach (string strKey in Keys)
            {
                iAccCount = dtPboc.Select("substring(RT_ACCT_NUM,3,1)= '" + strKey + "'").Length;// iAccCount = dtPboc.Rows.Count;
                strheader = GetGeneratingReportHeader(iAccCount, strKey, strData_YM);
                WriteCvsLine(strKey, strheader);
                WriteCvsLine(strKey, "");
            }
            /*end  modify liu,zhihang    */
            iAccCount = 0;
            _rate = PBOCDao.GetExchRateByDataYM(strData_YM);
            dtWord = PBOCDao.GetMatchWord();

            string accountEffDate = "";
            string updateDate = "";
            long lRT_ORIG_LOAN_AMT = 0;
            long lLastRT_ORIG_LOAN_AMT = 0;
            string strCur_BI_Cust_Name = "";
            string strCur_BI_ID_Type = "";
            string strCur_BI_ID_No = "";
            string strPrev_BI_Cust_Name = "";
            string strPrev_BI_ID_Type = "";
            string strPrev_BI_ID_No = "";
            string _post_code = "";
            string _address = "";
            string strBOD = "";
            string ChargeOffDate = "";
            int iRT_CURR_TERM = 0;
            int iRT_NUM_PMTS_REM = 0;
            string Repayment_Frequency = "03";
            DataRow drRow = null;
            DataSet dsPBOC;
            string POST_CODE = "";
            int workYears = 0;
            decimal dcWorkyears = 0;
            string startYear = "";
            double ProvenIncome = 0;
            ExcelUtility excelUtility = new ExcelUtility();

            // GRB 性别
            // GRB 出生日期
            // GRB 住宅电话
            // GRB 手机号码
            // GRB 单位电话
            // GRB 电子邮箱
            // GRB 通讯地址
            // GRB 通讯地址邮编
            // GRB 居住地址
            // GRB 居住邮编

            string Cust_Gender = "";
            string Cust_Date_of_Birth = "";
            string Cust_Residential_Phone = "";
            string Cust_Mobile_Phone = "";
            string Cust_Employment_Phone = "";
            string Cust_Mail_Box = "";
            string Cust_Corresponding_Address = "";
            string Cust_ZIP_Code_of_Corresponding_Address = "";
            string Res_Residential_Address = "";
            string Res_ZIP_Code_of_Residential_Address = "";
            string Cur_Cust_Gender = "";
            string Cur_Cust_Date_of_Birth = "";
            string Cur_Cust_Residential_Phone = "";
            string Cur_Cust_Mobile_Phone = "";
            string Cur_Cust_Employment_Phone = "";
            string Cur_Cust_Mail_Box = "";
            string Cur_Cust_Corresponding_Address = "";
            string Cur_Cust_ZIP_Code_of_Corresponding_Address = "";
            string Cur_Res_Residential_Address = "";
            string Cur_Res_ZIP_Code_of_Residential_Address = "";

            PBOCData pbocData = null;
            int abc = 0;
            /// Month Begin
            string payduedate = strData_YM + "01";
            /// Month End
            string lastpayduedate = DateTime.Parse(strData_YM.Substring(0, 4) + "/" + strData_YM.Substring(4, 2) + "/01").AddMonths(1).AddDays(-1).ToString("yyyyMMdd");

            string RT_ACCT_EFF_DATE = String.Empty;

            #region
            foreach (DataRow dr in dtPboc.Rows)
            {
                RT_ACCT_EFF_DATE = CommonUtility.GetString(dr, "RT_ACCT_EFF_DATE");
                accountEffDate = RT_ACCT_EFF_DATE.Substring(0, 4) + "/" + RT_ACCT_EFF_DATE.Substring(4, 2) + "/" + "01";
                updateDate = CommonUtility.GetString(dr, "Data_YM").Substring(0, 4) + "/" + CommonUtility.GetString(dr, "Data_YM").Substring(4, 2) + "/" + "01";
                dateBetw = CommonUtility.DateDiff("m", Convert.ToDateTime(accountEffDate), Convert.ToDateTime(updateDate));
                accNo = CommonUtility.GetString(dr, "RT_Acct_Num");       // For i = 1 To dateBetw       //  twStatus = twStatus & "#"       //Next i  
                string writerKey = string.Empty;
                if (accNo.Length >= 3)
                {
                    writerKey = accNo.Substring(2, 1);
                }
                abc++;
                pbocData = GetLastDeliHisStatus(accNo, strData_YM);
                dsPBOC = PBOCDao.SELECTPBOC(accNo, strData_YM);
                strCur_BI_Cust_Name = MakeStrGrbMode(processCustName(CommonUtility.GetString(dr, "CUSTOMER_NAME")), 30, "L").Trim().ToUpper();
                strCur_BI_ID_Type = MakeString(GetNationid(CommonUtility.GetString(dr, "Nationality"), CommonUtility.GetString(dr, "CUST_ID")), 1, "R").Trim().ToUpper();
                strCur_BI_ID_No = MakeString(CommonUtility.GetString(dr, "CUST_ID"), 18, "L").Trim().ToUpper();
                if (pbocData.AccountNo == null && pbocData.Id == null && pbocData.ValidData == null && 
                    pbocData.Name == null && pbocData.Id_Type==null &&pbocData.Delinq_History==string.Empty)
                {
                    strAccStatus = "2";
                    bValidData = true;
                }
                else
                {
                    if (pbocData.ValidData.Trim().Length == 0)
                    {
                        bValidData = true;
                        strAccStatus = "2";
                    }
                    else
                    {
                        strPrev_BI_Cust_Name = pbocData.Name.Trim().ToUpper();
                        strPrev_BI_ID_Type = pbocData.Id_Type.Trim().ToUpper();
                        strPrev_BI_ID_No = pbocData.Id.Trim().ToUpper();
                        strAccStatus = "1";
                        if (pbocData.ValidData.Equals("1"))
                        {
                            bValidData = true;
                        }
                        else
                        {
                            bValidData = false;
                        }
                    }
                }
                address = CommonUtility.GetString(dr, "CITY") + CommonUtility.GetString(dr, "Address1") + " " +
                            CommonUtility.GetString(dr, "Address2") + " " + CommonUtility.GetString(dr, "Address3") + " " +
                            CommonUtility.GetString(dr, "Address4");
                int iLen = Convert.ToInt32(dtWord.Rows[0]["Length"]);
                if (GetLength(address) > iLen)
                {
                    if (dtWord.Rows.Count > 0)
                    {
                        foreach (DataRow dataRow in dtWord.Rows)
                        {
                            if (address.Contains(dataRow["Org_Value"].ToString()))
                            {
                                address = address.Replace(dataRow["Org_Value"].ToString(), dataRow["New_Value"].ToString().Trim());
                                break;
                            }
                        }
                    }
                }
                string RT_TOT_PRIN = CommonUtility.GetString(dr, "RT_TOT_PRIN").Replace("-", "");
                string RT_POFF_AMT = CommonUtility.GetString(dr, "RT_POFF_AMT").Contains('-') ? "-" +
                                    CommonUtility.GetString(dr, "RT_POFF_AMT").Replace("-", "").Trim() : CommonUtility.GetString(dr, "RT_POFF_AMT").Replace("-", "");
                if (double.Parse(RT_TOT_PRIN) > 0 && double.Parse(RT_POFF_AMT) < 0)
                {
                    RT_POFF_AMT = RT_POFF_AMT.Replace("-", "");
                }
                if (double.Parse(RT_TOT_PRIN) == 0 && double.Parse(RT_POFF_AMT) < 0)
                {
                    log.DebugLog(string.Format("RT_TOT_PRIN=0 and RT_POFF_AMT<0, please change RT_POFF_AMT to 0 ,RT_TOT_PRIN = {0},  RT_POFF_AMT = {1}", RT_TOT_PRIN, RT_POFF_AMT),
                                    MethodBase.GetCurrentMethod().Name);
                    RT_POFF_AMT = "0";
                }
                string DQ_NUM_PMTS_PDUE = CommonUtility.GetString(dr, "DQ_NUM_PMTS_PDUE").Replace("-", "");
                string DQ_HIGH_MONTH_DLQ = CommonUtility.GetString(dr, "DQ_HIGH_MONTH_DLQ");
                double dDQ_TOT_AMT_PDUE = System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(CommonUtility.GetString(dr, "DQ_TOT_AMT_PDUE")), _rate), 0);
                if (int.Parse(DQ_HIGH_MONTH_DLQ) < int.Parse(DQ_NUM_PMTS_PDUE))
                {
                    dr["DQ_HIGH_MONTH_DLQ"] = DQ_NUM_PMTS_PDUE;
                }
                if (RT_ACCT_EFF_DATE.CompareTo(payduedate) >= 0)
                {
                    currMonthStatus = "*";
                }
                else if (double.Parse(RT_TOT_PRIN) == 0 && double.Parse(RT_POFF_AMT) == 0)
                {
                    currMonthStatus = "C";
                }
                else if (double.Parse(RT_POFF_AMT) == 0 && double.Parse(RT_TOT_PRIN) != 0)
                {
                    currMonthStatus = "G";
                }
                else if (int.Parse(DQ_NUM_PMTS_PDUE) == 0)
                {
                    currMonthStatus = "N";
                    dDQ_TOT_AMT_PDUE = 0;
                }
                else if (int.Parse(DQ_NUM_PMTS_PDUE) != 0)
                {
                    if (int.Parse(DQ_NUM_PMTS_PDUE) > 7)
                    {
                        DQ_NUM_PMTS_PDUE = "7";
                    }
                    currMonthStatus = int.Parse(DQ_NUM_PMTS_PDUE).ToString();
                }
                twStatus = GetDeliHistoryStatus(accNo, currMonthStatus, dateBetw, strData_YM);
                if (CommonUtility.GetString(dr, "AccountNo") != null && !string.IsNullOrEmpty(CommonUtility.GetString(dr, "AccountNo")))
                {
                    string lastmonthstatus = dsPBOC.Tables[0].Rows[0]["BI_Last_24Months_Delinq_History"].ToString();
                    twStatus = lastmonthstatus.Substring(1, lastmonthstatus.Length - 1) + lastmonthstatus.Substring(lastmonthstatus.Length - 1, 1);
                }
                if (!accNo.Substring(6, 1).Equals("0"))
                {

                    if (right(twStatus, 1).CompareTo("C") == 0)
                        BI_Class_Loan_Type = "1";
                    else if (right(twStatus, 1).CompareTo("N") == 0 || right(twStatus, 1).CompareTo("1") == 0)
                        BI_Class_Loan_Type = "1";
                    else if (right(twStatus, 1).CompareTo("2") == 0 || right(twStatus, 1).CompareTo("3") == 0)
                        BI_Class_Loan_Type = "2";
                    else if (right(twStatus, 1).CompareTo("4") == 0 || right(twStatus, 1).CompareTo("5") == 0 || right(twStatus, 1).CompareTo("6") == 0)
                        BI_Class_Loan_Type = "3";
                    else if (right(twStatus, 1).CompareTo("7") == 0 || right(twStatus, 1).CompareTo("G") == 0)
                        BI_Class_Loan_Type = "4";
                    else
                    {
                        BI_Class_Loan_Type = "9";
                    }
                }
                else
                {
                    if (right(twStatus, 1).CompareTo("C") == 0)
                        BI_Class_Loan_Type = "1";
                    else if (right(twStatus, 1).CompareTo("N") == 0)
                        BI_Class_Loan_Type = "1";
                    else if (right(twStatus, 1).CompareTo("1") == 0 || right(twStatus, 1).CompareTo("2") == 0)
                        BI_Class_Loan_Type = "2";
                    else if (right(twStatus, 1).CompareTo("3") == 0)
                        BI_Class_Loan_Type = "3";
                    else if (right(twStatus, 1).CompareTo("4") == 0)
                        BI_Class_Loan_Type = "4";
                    else if (right(twStatus, 1).CompareTo("5") == 0 || right(twStatus, 1).CompareTo("6") == 0 || right(twStatus, 1).CompareTo("7") == 0 || right(twStatus, 1).CompareTo("G") == 0)
                        BI_Class_Loan_Type = "5";
                    else
                    {
                        BI_Class_Loan_Type = "9";
                    }
                }
                if (CommonUtility.GetString(dr, "AccountNo") != null && !string.IsNullOrEmpty(CommonUtility.GetString(dr, "AccountNo")))
                {
                    BI_Class_Loan_Type = dsPBOC.Tables[0].Rows[0]["BI_Class_Loan_Type"].ToString();
                }
                if (!accNo.Substring(6, 1).Equals("0"))
                {
                    if (right(twStatus, 1) == "C")
                        BI_Acc_Status = "3";
                    else if (right(twStatus, 1) == "N" || right(twStatus, 1) == "*")
                        BI_Acc_Status = "1";
                    else if (right(twStatus, 1).CompareTo("1") == 0 || right(twStatus, 1).CompareTo("2") == 0 || right(twStatus, 1).CompareTo("3") == 0 || right(twStatus, 1).CompareTo("4") == 0 || right(twStatus, 1).CompareTo("5") == 0 || right(twStatus, 1).CompareTo("6") == 0)
                        BI_Acc_Status = "2";
                    else if (right(twStatus, 1).CompareTo("7") == 0 || right(twStatus, 1).CompareTo("G") == 0)
                        BI_Acc_Status = "4";
                }
                else
                {
                    if (right(twStatus, 1) == "C")
                        BI_Acc_Status = "3";
                    else if (right(twStatus, 1) == "N" || right(twStatus, 1) == "*")
                        BI_Acc_Status = "1";
                    else if (right(twStatus, 1).CompareTo("1") == 0 || right(twStatus, 1).CompareTo("2") == 0 || right(twStatus, 1).CompareTo("3") == 0 || right(twStatus, 1).CompareTo("4") == 0)
                        BI_Acc_Status = "2";
                    else if (right(twStatus, 1).CompareTo("5") == 0 || right(twStatus, 1).CompareTo("6") == 0 || right(twStatus, 1).CompareTo("7") == 0 || right(twStatus, 1).CompareTo("G") == 0)
                        BI_Acc_Status = "4";                //for (int i = twStatus.Length + 1; i < 25; i++)                //    twStatus = "/" + twStatus;                
                }

                if (CommonUtility.GetString(dr, "AccountNo") != null && !string.IsNullOrEmpty(CommonUtility.GetString(dr, "AccountNo")))
                {
                    BI_Acc_Status = "4";
                }

                if (RT_ACCT_EFF_DATE.CompareTo(payduedate) >= 0)
                    BI_Pay_Due_Date = lastpayduedate;
                else if (CommonUtility.GetString(dr, "BD_PREV_DUE_DATE").CompareTo("00000000") == 0 && right(twStatus, 1).CompareTo("C") != 0)
                    BI_Pay_Due_Date = payduedate;
                else
                    BI_Pay_Due_Date = CommonUtility.GetString(dr, "BD_PREV_DUE_DATE");
                if (CommonUtility.GetString(dr, "RT_LST_PMT_DATE").CompareTo("00000000") == 0)
                    BI_Last_Pay_Due_Date = RT_ACCT_EFF_DATE;
                else if (CommonUtility.GetString(dr, "RT_LST_PMT_DATE").CompareTo(BI_Pay_Due_Date) > 0 && BI_Pay_Due_Date.CompareTo("00000000") != 0)
                    BI_Last_Pay_Due_Date = BI_Pay_Due_Date;
                else
                    BI_Last_Pay_Due_Date = CommonUtility.GetString(dr, "RT_LST_PMT_DATE");
                if (RT_ACCT_EFF_DATE.CompareTo(payduedate) >= 0)
                {
                    BI_Last_Pay_Amt = 0.00d; //No need to pay for it this month
                }
                else if (Convert.ToDouble(CommonUtility.GetString(dr, "RT_LST_PMT_AMT")) < Convert.ToDouble(CommonUtility.GetString(dr, "REG_PYMT_AMT")) && right(twStatus, 1).CompareTo("N") == 0)
                {
                    BI_Last_Pay_Amt = Convert.ToDouble(Convert.ToDecimal(CommonUtility.GetString(dr, "REG_PYMT_AMT")));
                }
                else
                {
                    BI_Last_Pay_Amt = Convert.ToDouble(Convert.ToDecimal(CommonUtility.GetString(dr, "RT_LST_PMT_AMT")));
                }

                if (RT_ACCT_EFF_DATE.CompareTo(payduedate) < 0) //Booking date on this month
                {
                    BI_Act_Pay_Amt = Convert.ToDouble(CommonUtility.GetString(dr, "REG_PYMT_AMT"));
                }
                else
                {
                    BI_Act_Pay_Amt = 0.00d;
                }

                if (Convert.ToInt32(CommonUtility.GetString(dr, "DQ_NO_OF_TIMES_DLQ")) < Convert.ToInt32(CommonUtility.GetString(dr, "DQ_HIGH_MONTH_DLQ")))
                    weiyue = Convert.ToInt32(CommonUtility.GetString(dr, "DQ_HIGH_MONTH_DLQ"));
                else
                    weiyue = Convert.ToInt32(CommonUtility.GetString(dr, "DQ_NO_OF_TIMES_DLQ"));

                lRT_ORIG_LOAN_AMT = (long)System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(CommonUtility.GetString(dr, "RT_ORIG_LOAN_AMT")), _rate), 0);
                if (CommonUtility.PBOCMaxValueStatus().Equals("1"))
                {
                    lLastRT_ORIG_LOAN_AMT = PBOCDao.getMAX_RT_ORIG_LOAN_AMT(accNo, strData_YM);
                    if (lRT_ORIG_LOAN_AMT < lLastRT_ORIG_LOAN_AMT)
                    {
                        lRT_ORIG_LOAN_AMT = lLastRT_ORIG_LOAN_AMT;
                    }
                }
                if (BI_Pay_Due_Date.Substring(0, 6).CompareTo(strData_YM) < 0)
                {
                    BI_Pay_Due_Date = lastpayduedate;
                }

                string strFinInsCoder = string.Empty;
                switch (writerKey)
                {
                    case "1":
                        strFinInsCoder = CommonUtility.PBOCFinInsCode().ToString();
                        break;
                    case "2":
                        strFinInsCoder = CommonUtility.PBOCFinInsCodeCB().ToString();
                        break;
                    case "3":
                        strFinInsCoder = CommonUtility.PBOCFinInsCodeWCF().ToString();
                        break;
                    case "4":
                        strFinInsCoder = CommonUtility.PBOCFinInsCodeBB().ToString();
                        break;
                }
                strLine = CommonUtility.PBOCInfoType() + seprateChar + strFinInsCoder + seprateChar + "1" + seprateChar + getLoanTypeByAcc(accNo) + seprateChar +
                            MakeString(CommonUtility.GetString(dr, "RT_ACCT_NUM"), 40, "L") + seprateChar +
                            GetRC(CommonUtility.GetString(dr, "RC_BASE").Substring(1, 1)) + seprateChar +
                            RT_ACCT_EFF_DATE + seprateChar +
                            CommonUtility.GetString(dr, "RT_CURR_MATUR_DATE") + seprateChar +
                            GetCurr(CommonUtility.GetString(dr, "CTL2"), _rate) + seprateChar +
                            MakeNum(Convert.ToString(lRT_ORIG_LOAN_AMT), 10, "R");
                strLine = strLine + seprateChar +
                MakeNum(Convert.ToString(lRT_ORIG_LOAN_AMT), 10, "R") + seprateChar +
                MakeNum(Convert.ToString(lRT_ORIG_LOAN_AMT), 10, "R") + seprateChar +
                (accNo.Substring(6, 1).Equals("0") ? "4" : "2") + seprateChar + "03" + seprateChar +// "2" + seprateChar + "03" + seprateChar +//  "2" + seprateChar + "03" + seprateChar +
                CommonUtility.MakeString(CommonUtility.GetString(dr, "RT_CURR_TERM"), 3, "L", " ") + seprateChar +//String.Format(GetString(dr, "RT_CURR_TERM"), "000") +         seprateChar+  
                CommonUtility.MakeString(CommonUtility.GetString(dr, "RT_NUM_PMTS_REM"), 3, "L", " ") + seprateChar +//String.Format(GetString(dr, "RT_NUM_PMTS_REM"), "000") +  
                    BI_Pay_Due_Date + seprateChar + BI_Last_Pay_Due_Date + seprateChar +//BI_Pay_Due_Date + seprateChar + BI_Last_Pay_Due_Date + seprateChar +
                MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), BI_Act_Pay_Amt, _rate), 0)), 10, "R") + seprateChar +
                MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), BI_Last_Pay_Amt, _rate), 0)), 10, "R");
                //余额   当前逾期期数 当前逾期总额
                if (CommonUtility.GetString(dr, "AccountNo") != null && !string.IsNullOrEmpty(CommonUtility.GetString(dr, "AccountNo")))
                {
                    string BI_Remaining_Balance = CommonUtility.GetString(dr, "CurrentOS");
                    strLine = strLine + seprateChar + MakeNum(BI_Remaining_Balance, 10, "R");

                    string BI_Install_Delinq_No = Convert.ToInt32(dsPBOC.Tables[0].Rows[0]["BI_Install_Delinq_No"].ToString()).ToString("00");
                    strLine = strLine + seprateChar + BI_Install_Delinq_No;
                    string BI_Total_Delinq_Balance = dsPBOC.Tables[0].Rows[0]["BI_Total_Delinq_Balance"].ToString();
                    strLine = strLine + seprateChar + MakeNum(Convert.ToString(BI_Total_Delinq_Balance), 10, "R");
                }
                else
                {
                    strLine = strLine + seprateChar + MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(RT_TOT_PRIN), _rate), 0)), 10, "R");
                    strLine = strLine + seprateChar + Convert.ToInt32(CommonUtility.GetString(dr, "DQ_NUM_PMTS_PDUE")).ToString("00");
                    strLine = strLine + seprateChar + MakeNum(Convert.ToString(dDQ_TOT_AMT_PDUE), 10, "R");
                }
                strLine = strLine + seprateChar +
                MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(CommonUtility.GetString(dr, "PRIN_PDUE31_60")), _rate), 0)), 10, "R") + seprateChar +
                MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(CommonUtility.GetString(dr, "PRIN_PDUE61_90")), _rate), 0)), 10, "R") + seprateChar +
                MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(CommonUtility.GetString(dr, "PRIN_PDUE91_180")), _rate), 0)), 10, "R") + seprateChar +
                MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(CommonUtility.GetString(dr, "PRIN_PDUE180_OVR")), _rate), 0)), 10, "R") + seprateChar +
                weiyue.ToString("000");
                //最高逾期期数
                if (CommonUtility.GetString(dr, "AccountNo") != null && !string.IsNullOrEmpty(CommonUtility.GetString(dr, "AccountNo")))
                {
                    string BI_Highest_No_of_Month_Delinq = Convert.ToInt32(dsPBOC.Tables[0].Rows[0]["BI_Highest_No_of_Month_Delinq"].ToString()).ToString("00");
                    strLine = strLine + seprateChar + CommonUtility.MakeString(BI_Highest_No_of_Month_Delinq, 2, "R", "0");
                }
                else
                {
                    strLine = strLine + seprateChar + CommonUtility.MakeString(CommonUtility.GetString(dr, "DQ_HIGH_MONTH_DLQ"), 2, "R", "0");
                }
                strLine = strLine + seprateChar +
                            CommonUtility.MakeString(BI_Class_Loan_Type, 1, "L") + seprateChar +
                            CommonUtility.MakeString(BI_Acc_Status, 1, "R") + seprateChar +
                            CommonUtility.MakeString(twStatus, 24, "R") + seprateChar +
                            "0000000000" + seprateChar + strAccStatus + seprateChar +
                            MakeStrGrbMode(processCustName(CommonUtility.GetString(dr, "CUSTOMER_NAME")), 30, "L");
                strLine = strLine + seprateChar +
                                MakeString(GetNationid(CommonUtility.GetString(dr, "Nationality"), CommonUtility.GetString(dr, "CUST_ID")), 1, "R") + seprateChar +
                                MakeString(CommonUtility.GetString(dr, "CUST_ID"), 18, "L") + seprateChar + CommonUtility.Space(30);
                strBOD = CommonUtility.GetString(dr, "DOB");
                if (strBOD.Length == 0)
                {
                    strBOD = "19010101";
                }
                POST_CODE = CommonUtility.GetString(dr, "POST_CODE");
                if (POST_CODE.Length != 6)
                {
                    POST_CODE = "999999";
                }
                _post_code = CommonUtility.GetString(dr, "POST_CODE").Length == 6 ? CommonUtility.GetString(dr, "POST_CODE") : "999999";
                _address = CommonUtility.GetString(dr, "Address1") + CommonUtility.GetString(dr, "Address2") + CommonUtility.GetString(dr, "Address3") + CommonUtility.GetString(dr, "Address4");
                _address = _address.Trim();
                _address = _address.Length > 0 ? _address : "暂缺";
                Cur_Cust_Date_of_Birth = strBOD;
                Cur_Cust_Gender = GetGen(CommonUtility.GetString(dr, "GENDER"));
                Cur_Cust_Residential_Phone = "";
                Cur_Cust_Mobile_Phone = "";
                Cur_Cust_Employment_Phone = "";
                //Cur_Cust_Residential_Phone = MakeString(CommonUtility.GetString(dr, "HOME_PH_NBR") == null ? "" : CommonUtility.GetString(dr, "HOME_PH_NBR"), 25, "L");//todo
                //Cur_Cust_Mobile_Phone = MakeString(CommonUtility.GetString(dr, "MOBILE_PH_NBR") == null ? "" : CommonUtility.GetString(dr, "MOBILE_PH_NBR"), 16, "L");
                //Cur_Cust_Employment_Phone = MakeString(CommonUtility.GetString(dr, "OFC_PH_NBR"), 25, "L");
                Cur_Cust_Mail_Box = MakeString(CommonUtility.GetString(dr, "MAIL_ADDRESS"), 30, "L");
                Cur_Cust_Corresponding_Address = MakeStrGrbMode(address, 60, "L");
                Cur_Cust_ZIP_Code_of_Corresponding_Address = POST_CODE;
                Cur_Res_Residential_Address = MakeStrGrbMode(_address, 60, "L");
                Cur_Res_ZIP_Code_of_Residential_Address = POST_CODE;
                bChange = false;
                cChange = false;
                dChange = false;
                if (dsPBOC.Tables[0].Rows.Count > 0)
                {
                    Cust_Gender = dsPBOC.Tables[0].Rows[0]["Cust_Gender"].ToString();
                    if (!Cur_Cust_Gender.Equals(Cust_Gender))
                    {
                        bChange = true;
                    }
                    Cust_Date_of_Birth = dsPBOC.Tables[0].Rows[0]["Cust_Date_of_Birth"].ToString();
                    if (!Cur_Cust_Date_of_Birth.Equals(Cust_Date_of_Birth))
                    {
                        bChange = true;
                    }
                    Cust_Residential_Phone = MakeString(dsPBOC.Tables[0].Rows[0]["Cust_Residential_Phone"].ToString(), 25, "L");
                    if (!Cur_Cust_Residential_Phone.Equals(Cust_Residential_Phone))
                    {
                        bChange = true;
                    }
                    Cust_Mobile_Phone = MakeString(dsPBOC.Tables[0].Rows[0]["Cust_Mobile_Phone"].ToString(), 16, "L");
                    if (!Cur_Cust_Mobile_Phone.Equals(Cust_Mobile_Phone))
                    {
                        bChange = true;
                    }
                    Cust_Employment_Phone = MakeString(dsPBOC.Tables[0].Rows[0]["Cust_Employment_Phone"].ToString(), 25, "L");
                    if (!Cur_Cust_Employment_Phone.Equals(Cust_Employment_Phone))
                    {
                        bChange = true;
                    }
                    Cust_Mail_Box = MakeString(dsPBOC.Tables[0].Rows[0]["Cust_Mail_Box"].ToString(), 30, "");
                    if (!Cur_Cust_Mail_Box.Equals(Cust_Mail_Box))
                    {
                        bChange = true;
                    }
                    Cust_Corresponding_Address = MakeString(dsPBOC.Tables[0].Rows[0]["Cust_Corresponding_Address"].ToString(), 60, "L");
                    if (!Cur_Cust_Corresponding_Address.Equals(Cust_Corresponding_Address))
                    {
                        bChange = true;
                    }
                    Cust_ZIP_Code_of_Corresponding_Address = MakeString(dsPBOC.Tables[0].Rows[0]["Cust_ZIP_Code_of_Corresponding_Address"].ToString(), 6, "L");
                    if (!Cur_Cust_ZIP_Code_of_Corresponding_Address.Equals(Cust_ZIP_Code_of_Corresponding_Address))
                    {
                        bChange = true;
                    }
                    Res_Residential_Address = MakeStrGrbMode(dsPBOC.Tables[0].Rows[0]["Res_Residential_Address"].ToString(), 60, "L");

                    if (!Cur_Res_Residential_Address.Equals(Res_Residential_Address))
                    {
                        dChange = true;
                    }
                    Res_ZIP_Code_of_Residential_Address = MakeString(dsPBOC.Tables[0].Rows[0]["Res_ZIP_Code_of_Residential_Address"].ToString(), 6, "L");
                    if (!Cur_Res_ZIP_Code_of_Residential_Address.Equals(Res_ZIP_Code_of_Residential_Address))
                    {
                        dChange = true;
                    }
                }
                if (dsPBOC.Tables[0].Rows.Count == 0)
                {
                    strLine = strLine + seprateChar + "B" + seprateChar +
                        Cur_Cust_Gender + seprateChar +
                        Cur_Cust_Date_of_Birth + seprateChar + CommonUtility.GetString(dr, "marrital") + seprateChar + CommonUtility.GetString(dr, "education") + seprateChar + "9" + seprateChar + //GetString(dr, "DOB") + seprateChar + getMarrital(GetString(dr, "marrital")) + seprateChar + getEducation(GetString(dr, "education")) + seprateChar + "9" + seprateChar + 
                        Cur_Cust_Residential_Phone;
                    strLine = strLine + seprateChar +
                        Cur_Cust_Mobile_Phone + seprateChar +
                        Cur_Cust_Employment_Phone + seprateChar +
                        Cur_Cust_Mail_Box + seprateChar +
                        Cur_Cust_Corresponding_Address;
                    strLine = strLine + seprateChar +
                                Cur_Cust_ZIP_Code_of_Corresponding_Address + seprateChar +
                                MakeString(CommonUtility.GetString(dr, "DomicAdd"), 60, "L") + seprateChar +
                                MakeString(CommonUtility.GetString(dr, "SpouseName"), 30, "L") + seprateChar +
                                MakeString(CommonUtility.GetString(dr, "SpouseIDType"), 1, "L") + seprateChar +
                                MakeString(CommonUtility.GetString(dr, "SpouseID"), 18, "L") + seprateChar +
                                MakeString(CommonUtility.GetString(dr, "SpouseEmployerName"), 60, "L") + seprateChar +
                                MakeString(CommonUtility.GetString(dr, "SpouseContactPhone"), 25, "L");
                    workYears = 0;
                    startYear = "";
                    ProvenIncome = 0;
                    dcWorkyears = 0;
                    if (decimal.TryParse(CommonUtility.GetString(dr, "WorkingYear"), out dcWorkyears))
                    {
                        startYear = Convert.ToString(int.Parse(strData_YM.Substring(0, 4)) - dcWorkyears).Substring(0, 4);
                    }
                    else
                    {
                        startYear = "";
                    }
                    if (!double.TryParse(CommonUtility.GetString(dr, "ProvenIncome"), out ProvenIncome))
                    {
                        ProvenIncome = 0;
                    }
                    ProvenIncome = ProvenIncome * 12;
                    //c start
                    strLine = strLine + seprateChar + "C" + seprateChar + "Z" + seprateChar +
                        MakeStrGrbMode(CommonUtility.GetString(dr, "company_name").Trim().Length == 0 ? "" : CommonUtility.GetString(dr, "company_name"), 60, "L") + seprateChar +
                        CommonUtility.GetString(dr, "industry") + seprateChar +
                        MakeString(CommonUtility.GetString(dr, "OfficeAdd"), 60, "L") + seprateChar +
                        MakeString(CommonUtility.GetString(dr, "OfficeZIPCode"), 6, "L") + seprateChar +
                        MakeString(startYear, 4, "L") + seprateChar +
                        CommonUtility.GetString(dr, "designation") + seprateChar + "9" + seprateChar +
                        MakeNum(ProvenIncome.ToString(), 10, "R") + seprateChar + CommonUtility.Space(40) + seprateChar + CommonUtility.Space(14);
                    //d start
                    strLine = strLine + seprateChar + "D" + seprateChar +
                        Cur_Res_Residential_Address + seprateChar +
                        Cur_Res_ZIP_Code_of_Residential_Address + seprateChar +
                        getResidentType(CommonUtility.GetString(dr, "ResidentType"));
                }
                else
                {
                    if (bChange)
                    {
                        strLine = strLine + seprateChar + "B" + seprateChar +
                        Cur_Cust_Gender + seprateChar +
                        Cur_Cust_Date_of_Birth + seprateChar + CommonUtility.GetString(dr, "marrital") + seprateChar + CommonUtility.GetString(dr, "education") + seprateChar + "9" + seprateChar +
                        Cur_Cust_Residential_Phone;
                        strLine = strLine + seprateChar +
                            Cur_Cust_Mobile_Phone + seprateChar +
                            Cur_Cust_Employment_Phone + seprateChar +
                            Cur_Cust_Mail_Box + seprateChar +
                            Cur_Cust_Corresponding_Address;
                        strLine = strLine + seprateChar +
                                    Cur_Cust_ZIP_Code_of_Corresponding_Address + seprateChar +
                                    MakeString(CommonUtility.GetString(dr, "DomicAdd"), 60, "L") + seprateChar +
                                    MakeString(CommonUtility.GetString(dr, "SpouseName"), 30, "L") + seprateChar +
                                    MakeString(CommonUtility.GetString(dr, "SpouseIDType"), 1, "L") + seprateChar +
                                    MakeString(CommonUtility.GetString(dr, "SpouseID"), 18, "L") + seprateChar +
                                    MakeString(CommonUtility.GetString(dr, "SpouseEmployerName"), 60, "L") + seprateChar +
                                    MakeString(CommonUtility.GetString(dr, "SpouseContactPhone"), 25, "L");
                    }

                    workYears = 0;
                    startYear = "";
                    ProvenIncome = 0;
                    dcWorkyears = 0;
                    if (decimal.TryParse(CommonUtility.GetString(dr, "WorkingYear"), out dcWorkyears))
                    {
                        startYear = Convert.ToString(int.Parse(strData_YM.Substring(0, 4)) - dcWorkyears).Substring(0, 4);
                    }
                    else
                    {
                        startYear = "";
                    }
                    if (!double.TryParse(CommonUtility.GetString(dr, "ProvenIncome"), out ProvenIncome))
                    {
                        ProvenIncome = 0;
                    }
                    ProvenIncome = ProvenIncome * 12;

                    if (dChange)
                    {
                        strLine = strLine + seprateChar + "D" + seprateChar +
                        Cur_Res_Residential_Address + seprateChar +
                        Cur_Res_ZIP_Code_of_Residential_Address + seprateChar +
                        getResidentType(CommonUtility.GetString(dr, "ResidentType"));
                    }
                }
                iRecordLength = System.Text.Encoding.GetEncoding(_codePage).GetBytes(strLine).Length + 4;
                strLine = iRecordLength.ToString("0000") + seprateChar + strLine;
                if ((CommonUtility.GetString(dr, "CTL2").CompareTo("702") != 0) && (CommonUtility.GetString(dr, "RT_CURR_TERM").CompareTo(CommonUtility.GetString(dr, "RT_NUM_PMTS_REM")) >= 0) && BI_Pay_Due_Date.CompareTo(accountEffDate) > 0
                    && right(pbocData.Delinq_History, 1).ToUpper() != "C" && bValidData)
                {
                    WriteTempLine(writerKey, strLine);//write to temp
                    if (hashTableIAccCount[writerKey] != null)//add liu,zhihang 
                    {
                        int count = int.Parse(hashTableIAccCount[writerKey].ToString());
                        count = count + 1;
                        hashTableIAccCount[writerKey] = count;
                    }
                }
                WriteCvsLine(writerKey, strLine);
                seprateChar = "\t";
                string strFinCode = string.Empty;
                switch (writerKey)
                {
                    case "1":
                        strFinCode = CommonUtility.PBOCFinInsCode().ToString();
                        break;
                    case "2":
                        strFinCode = CommonUtility.PBOCFinInsCodeCB().ToString();
                        break;
                    case "3":
                        strFinCode = CommonUtility.PBOCFinInsCodeWCF().ToString();
                        break;
                    case "4":
                        strFinCode = CommonUtility.PBOCFinInsCodeBB().ToString();
                        break;
                }
                strLine = CommonUtility.PBOCInfoType() + seprateChar + strFinCode + seprateChar + "1" + seprateChar +
                        getLoanTypeByAcc(accNo) +// "11"
                        seprateChar +
                            MakeString(CommonUtility.GetString(dr, "RT_ACCT_NUM"), 40, "L") + seprateChar +
                            GetRC(CommonUtility.GetString(dr, "RC_BASE").Substring(1, 1)) + seprateChar +
                            RT_ACCT_EFF_DATE + seprateChar +
                            CommonUtility.GetString(dr, "RT_CURR_MATUR_DATE") + seprateChar +
                            GetCurr(CommonUtility.GetString(dr, "CTL2"), _rate) + seprateChar +
                            MakeNum(Convert.ToString(lRT_ORIG_LOAN_AMT), 10, "R");
                strLine = strLine + seprateChar + MakeNum(Convert.ToString(lRT_ORIG_LOAN_AMT), 10, "R") + seprateChar +
                        MakeNum(Convert.ToString(lRT_ORIG_LOAN_AMT), 10, "R") + seprateChar +
                        (accNo.Substring(6, 1).Equals("0") ? "4" : "2") + seprateChar + "03" + seprateChar +//"2" + seprateChar + "03" + seprateChar + 
                        CommonUtility.MakeString(CommonUtility.GetString(dr, "RT_CURR_TERM"), 3, "L", " ") + seprateChar +//String.Format(GetString(dr, "RT_CURR_TERM"), "000") +         seprateChar+  
                        CommonUtility.MakeString(CommonUtility.GetString(dr, "RT_NUM_PMTS_REM"), 3, "L", " ") + seprateChar +//String.Format(GetString(dr, "RT_NUM_PMTS_REM"), "000") +  
                        BI_Pay_Due_Date + seprateChar + BI_Last_Pay_Due_Date + seprateChar +//BI_Pay_Due_Date + seprateChar + BI_Last_Pay_Due_Date + seprateChar +
                        MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), BI_Act_Pay_Amt, _rate), 0)), 10, "R") + seprateChar +
                        MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), BI_Last_Pay_Amt, _rate), 0)), 10, "R") + seprateChar +
                        MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(RT_TOT_PRIN), _rate), 0)), 10, "R");

                strLine = strLine + seprateChar +
                        Convert.ToInt32(CommonUtility.GetString(dr, "DQ_NUM_PMTS_PDUE")).ToString("00") + seprateChar +
                        MakeNum(Convert.ToString(dDQ_TOT_AMT_PDUE), 10, "R") + seprateChar +
                        MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(CommonUtility.GetString(dr, "PRIN_PDUE31_60")), _rate), 0)), 10, "R") + seprateChar +
                        MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(CommonUtility.GetString(dr, "PRIN_PDUE61_90")), _rate), 0)), 10, "R") + seprateChar +
                        MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(CommonUtility.GetString(dr, "PRIN_PDUE91_180")), _rate), 0)), 10, "R") + seprateChar +

                        MakeNum(Convert.ToString(System.Math.Round(GetCNY(CommonUtility.GetString(dr, "CTL2"), Convert.ToDouble(CommonUtility.GetString(dr, "PRIN_PDUE180_OVR")), _rate), 0)), 10, "R") + seprateChar +
                        weiyue.ToString("000") + seprateChar + CommonUtility.MakeString(CommonUtility.GetString(dr, "DQ_HIGH_MONTH_DLQ"), 2, "R", "0");

                strLine = strLine + seprateChar +
                            MakeString(BI_Class_Loan_Type, 1, "L") + seprateChar +
                            MakeString(BI_Acc_Status, 1, "R") + seprateChar +
                            MakeString(twStatus, 24, "R") + seprateChar +
                            "0000000000" + seprateChar + strAccStatus + seprateChar +
                            MakeStrGrbMode(processCustName(CommonUtility.GetString(dr, "CUSTOMER_NAME")), 30, "L");

                strLine = strLine + seprateChar +
                                MakeString(GetNationid(CommonUtility.GetString(dr, "Nationality"), CommonUtility.GetString(dr, "CUST_ID")), 1, "R") + seprateChar +
                                MakeString(CommonUtility.GetString(dr, "CUST_ID"), 18, "L") + seprateChar + CommonUtility.Space(30);

                Cur_Cust_Date_of_Birth = strBOD;
                Cur_Cust_Gender = GetGen(CommonUtility.GetString(dr, "GENDER"));
                //Cur_Cust_Residential_Phone = MakeString(CommonUtility.GetString(dr, "HOME_PH_NBR") == null ? "" : CommonUtility.GetString(dr, "HOME_PH_NBR"), 25, "L");//todo
                Cur_Cust_Residential_Phone = "";
                Cur_Cust_Mobile_Phone = MakeString(CommonUtility.GetString(dr, "MOBILE_PH_NBR") == null ? "" : CommonUtility.GetString(dr, "MOBILE_PH_NBR"), 16, "L");
                //Cur_Cust_Employment_Phone = MakeString(CommonUtility.GetString(dr, "OFC_PH_NBR"), 25, "L");//todo
                Cur_Cust_Employment_Phone = "";
                Cur_Cust_Mail_Box = MakeString(CommonUtility.GetString(dr, "MAIL_ADDRESS"), 30, "L");
                Cur_Cust_Corresponding_Address = MakeStrGrbMode(address, 60, "L");
                Cur_Cust_ZIP_Code_of_Corresponding_Address = POST_CODE;
                Cur_Res_Residential_Address = MakeStrGrbMode(_address, 60, "L");
                Cur_Res_ZIP_Code_of_Residential_Address = POST_CODE;
                strLine = strLine + seprateChar + "B" + seprateChar +
                    Cur_Cust_Gender + seprateChar +
                    Cur_Cust_Date_of_Birth + seprateChar + CommonUtility.GetString(dr, "marrital") + seprateChar + CommonUtility.GetString(dr, "education") + seprateChar + "9" + seprateChar +
                    Cur_Cust_Residential_Phone;
                strLine = strLine + seprateChar +
                    Cur_Cust_Mobile_Phone + seprateChar +
                    Cur_Cust_Employment_Phone + seprateChar +
                    Cur_Cust_Mail_Box + seprateChar +
                    Cur_Cust_Corresponding_Address;
                strLine = strLine + seprateChar +
                            Cur_Cust_ZIP_Code_of_Corresponding_Address + seprateChar +
                            MakeString(CommonUtility.GetString(dr, "DomicAdd"), 60, "L") + seprateChar +
                            MakeString(CommonUtility.GetString(dr, "SpouseName"), 30, "L") + seprateChar +
                            MakeString(CommonUtility.GetString(dr, "SpouseIDType"), 1, "L") + seprateChar +
                            MakeString(CommonUtility.GetString(dr, "SpouseID"), 18, "L") + seprateChar +
                            MakeString(CommonUtility.GetString(dr, "SpouseEmployerName"), 60, "L") + seprateChar +
                            MakeString(CommonUtility.GetString(dr, "SpouseContactPhone"), 25, "L");
                workYears = 0;
                startYear = "";
                ProvenIncome = 0;
                dcWorkyears = 0;
                if (decimal.TryParse(CommonUtility.GetString(dr, "WorkingYear"), out dcWorkyears))
                {
                    startYear = Convert.ToString(int.Parse(strData_YM.Substring(0, 4)) - dcWorkyears).Substring(0, 4);
                }
                else
                {
                    startYear = "";
                }
                if (!double.TryParse(CommonUtility.GetString(dr, "ProvenIncome"), out ProvenIncome))
                {
                    ProvenIncome = 0;
                }
                ProvenIncome = ProvenIncome * 12;
                //c start
                strLine = strLine + seprateChar + "C" + seprateChar + "Z" + seprateChar +
                    MakeStrGrbMode(CommonUtility.GetString(dr, "company_name").Trim().Length == 0 ? "" : CommonUtility.GetString(dr, "company_name"), 60, "L") + seprateChar +
                    CommonUtility.GetString(dr, "industry") + seprateChar +
                    MakeString(CommonUtility.GetString(dr, "OfficeAdd"), 60, "L") + seprateChar +
                    MakeString(CommonUtility.GetString(dr, "OfficeZIPCode"), 6, "L") + seprateChar +
                    MakeString(startYear, 4, "L") + seprateChar +
                    CommonUtility.GetString(dr, "designation") + seprateChar + "9" + seprateChar +
                    MakeNum(ProvenIncome.ToString(), 10, "R") + seprateChar + CommonUtility.Space(40) + seprateChar + CommonUtility.Space(14);
                strLine = strLine + seprateChar + "D" + seprateChar +
                    Cur_Res_Residential_Address + seprateChar +
                    Cur_Res_ZIP_Code_of_Residential_Address + seprateChar +
                    getResidentType(CommonUtility.GetString(dr, "ResidentType"));
                iRecordLength = System.Text.Encoding.GetEncoding(_codePage).GetBytes(strLine).Length + 4;
                strLine = iRecordLength.ToString("0000") + seprateChar + strLine;
                if (!flg)//first line
                {
                    string[] keys2 = Keys;
                    string[] strs = strLine.Split('\t');
                    foreach (string strKey in keys2)
                    {
                        for (int i = 0; i < strs.Length; i++)
                        {
                            if (i == 0)
                            {
                                strBodyHeader = string.Format("i{0}", i);
                            }
                            else
                            {
                                strBodyHeader = strBodyHeader + "\t" + string.Format("i{0}", i);
                            }
                        }
                        strBodyHeader = strBodyHeader + "\t" + "temp";
                        WriteTxtLine(strKey, strBodyHeader);//write to text file
                    }
                    flg = true;
                }
                //for CSV
                if ((CommonUtility.GetString(dr, "CTL2").CompareTo("702") != 0) && (CommonUtility.GetString(dr, "RT_CURR_TERM").CompareTo(CommonUtility.GetString(dr, "RT_NUM_PMTS_REM")) >= 0)
                    && BI_Pay_Due_Date.CompareTo(accountEffDate) > 0 && right(pbocData.Delinq_History, 1).ToUpper() != "C" && bValidData)
                {
                    strValidData = "1";
                }
                else
                {
                    strValidData = "0";
                }
                strLine = strLine + seprateChar + strValidData;
                WriteTxtLine(writerKey, strLine);
                seprateChar = "";
                strLine = "";
            }
            #endregion
            CloseAllStream();
            processHeaderFormat(hashTableIAccCount, strData_YM);
            // errMsg = "";
            strCmdText = "truncate table T_PL_TempPR_Body";
            ExecuteNonQuery(strCmdText);           
            string[] strBulkInsertFiles = GetPathsForTxt();
            foreach (string strBulkInsertFile in strBulkInsertFiles)
            {
                string[] strArray2 = strBulkInsertFile.Split('\\');
               //ExecuteNonQuery(string.Format(Constants.SQLInsertCmdWithCodePage, Constants.T_PL_TempPR_Body, strBulkInsertFile, codePage));//todo
               // uploadFile.BulkInsertGRBFie(ref errMsg, "CNRFTempPR_Body", strBulkInsertFile, codePage);               
                File.Delete(strBulkInsertFile);//@@@delete the Text file
            }           
            strCmdText = string.Format("exec sp_PL_insert_CNRFPR_Body '{0}',{1},{2}", strData_YM, ReportType, Prd_Code);
            //ExecuteNonQuery(strCmdText);           //todo
            string strExportExcelFile = GetExportFileForExcel(strData_YM);
            if (File.Exists(strExportExcelFile))
            {
                File.Delete(strExportExcelFile);
            }
            fsCSVFile = File.Open(strExportExcelFile, FileMode.OpenOrCreate, FileAccess.Write);
            swCSVFile = new StreamWriter(fsCSVFile, fileEncoding);
            //strCmdText = string.Format(SelectReport, strData_YM);
            //DataSet ds = splitFile.executeDataSet(ref errMsg, strCmdText);//@@@get the data into ds
            DataSet reportDS = PBOCDao.SelectReport(strData_YM);
            //DataView dv = ds.Tables[0].DefaultView;
            strLine = "";
            int ii = 0;
            int j = 0;
            for (ii = 0; ii < reportDS.Tables[0].Columns.Count; ii++)
            {
                if (ii == 0)
                {
                    strLine = reportDS.Tables[0].Columns[0].ColumnName;
                }
                else
                {
                    strLine = strLine + "\t" + reportDS.Tables[0].Columns[ii].ColumnName;
                }
            }
            swCSVFile.WriteLine(strLine);
            swCSVFile.Flush();
            for (ii = 0; ii < reportDS.Tables[0].Rows.Count; ii++)
            {
                strLine = "";
                for (j = 0; j < reportDS.Tables[0].Columns.Count; j++)
                {
                    if (j == 0)
                    {
                        strLine = reportDS.Tables[0].Rows[ii][j].ToString();
                    }
                    else
                    {
                        strLine = strLine + "\t" + reportDS.Tables[0].Rows[ii][j].ToString();
                    }
                }
                swCSVFile.WriteLine(strLine);
                swCSVFile.Flush();
            }
            swCSVFile.Close();

            //downloadtxtreport
            //!! report.downloadTXTReport(ref strFileName, ref buffer, ref keys, bufferLength, strData_YM, ref errMessage);
            RefValues values = new RefValues();
            values.ReportName = strFileName;
            values.BytesArray = buffer;
            values.Keys = keys;
            values = DownloadTXTReport(values, bufferLength, strData_YM);
            //if (values.errMessage.Length > 0)
            //{
            //    MessageBox.Show("Error:" + values.errMessage);
            //    message.Close();
            //    return;
            //}
            //!!writeFile(buffer, strFileName, ref errMessage);//@ write the file you generate in report class to the path in the text box you selected
            WriteFile(values.BytesArray, values.ReportName, ref errorMessage);
            if (errorMessage!="")
            {
                log.ErrorLog("error:" + errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            //!! report.downloadCSVReport(ref strFileName, ref buffer, bufferLength, strData_YM, ref errMessage);
            string[] reportName = values.ReportName;
            var bytesArray = values.BytesArray;
            DownloadCSVReport(ref reportName, ref bytesArray, bufferLength, strData_YM, ref errorMessage);
            values.ReportName = reportName;
            values.BytesArray = bytesArray;
            //public bool DownloadCSVReport(ref string[] strReportName, ref byte[][] bytes, int bufferLength, string strData_YM, ref string errMessage)
            if (errorMessage != "")
            {
                log.ErrorLog("error:" + errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            //!!writeFile(buffer, strFileName, ref errMessage);//strFilename[] 1.W20472900B00022008090011000GA.csv,W20472900B00022008090011000CB.csv
            WriteFile(values.BytesArray, values.ReportName, ref errorMessage);
            //if (errMessage.Length > 0)
            //{
            //    MessageBox.Show("Error:" + errMessage);
            //    message.Close();
            //    return;
            //}
            int k = 0;
            foreach (string fileName in values.ReportName)//generate ForALS.xls
            {
                if (globalExportPBOCPath.Substring(globalExportPBOCPath.Length - 1, 1).Equals("\\"))
                {
                    strOutFile = globalExportPBOCPath + fileName;
                }
                else
                {
                    strOutFile = globalExportPBOCPath + "\\" + fileName;
                }
                strArray = strOutFile.Split('.');
                strOutFile = strOutFile.Substring(0, strOutFile.Length - 3) + "xls";

                if (File.Exists(strOutFile))
                {
                    File.Delete(strOutFile);
                }
                ds = PBOCDao.GetBodyDataByDataYM(strData_YM);
                //ds = proxy.executeDataSet(SELECT_CNRFPR_Body);//!!  splitReport.executeDataSet(ref errMessage, string.Format(SELECT_CNRFPR_Body, strData_YM));
                excelUtility.CreateExcel(strOutFile, ds.Tables[0], string.Format("{1}({0}) ", DateTime.Now.ToString("yyyyMMdd)"), "PBOC"));
                //CreateExcel("PBOC", strOutFile, dv, ref errorMessage);
                if (errorMessage!="")
                {
                    log.DebugLog("Error:" + errorMessage, MethodBase.GetCurrentMethod().Name);
                    return errorMessage;
                }
                strArray = strOutFile.Split('.');
                strOutFile = strOutFile.Substring(0, strOutFile.Length - 4) + "ForALS.xls";
                if (File.Exists(strOutFile))
                {
                    File.Delete(strOutFile);
                }
                ds = PBOCDao.GetALSDataByDataYM(strData_YM, values.Keys[k]);
                //ds = proxy.executeDataSet(string.Format(SelectReport, strData_YM, values.Keys[k]));
                // dv = ds.Tables[0].DefaultView;
                excelUtility.CreateExcel(strOutFile, ds.Tables[0], string.Format("{1}({0}) ", DateTime.Now.ToString("yyyyMMdd)"), "ALS Data"));
                //CreateExcel("ALS Data", strOutFile, dv, ref errorMessage);
                if (errorMessage.Length > 0)
                {
                    log.DebugLog("Error:" + errorMessage, MethodBase.GetCurrentMethod().Name);
                    return errorMessage;
                }
                k++;
            }

            return errorMessage;
        }

        #region create excel
        //public static string CreateExcel(string title, string fileName, DataView dv, ref string errMessage)
        //{
        //    string str = string.Empty;
        //    string str2 = DateTime.Now.ToString("dd MMM yyyy HHmmss");
        //    string filePath = fileName;
        //    string strTemplateFile = "";
        //    errMessage = "";
        //    CreateTemplate(ref errMessage, ref strTemplateFile);
        //    if (errMessage.Length > 0)
        //    {
        //        return "";
        //    }
        //    ExcelHelper excelHelper = new ExcelHelper
        //    {
        //        FileNamePath = filePath,
        //        TemplateReportNamePath = strTemplateFile
        //    };
        //    excelHelper.openExcelObject(1);
        //    try
        //    {
        //        excelHelper.setSheetActive(1);
        //        int startRow = 1;
        //        string[] colDataFormat = MakeDateArrayForExcel(dv);
        //        string[][] itemArray = MakeArrayForExcel(dv);
        //        ConvertDate(itemArray, colDataFormat);
        //        writeExcelByArray(excelHelper, title, colDataFormat, itemArray, ref startRow, title);
        //        excelHelper.saveExcel();
        //        excelHelper.destroyExcelObject();
        //        str = ParseFileName(filePath);
        //    }
        //    catch (Exception exception)
        //    {
        //        errMessage = exception.Message;
        //    }
        //    return str;
        //}

        //public static string ParseFileName(string filePath)
        //{
        //    string str = string.Empty;
        //    string directoryName = Path.GetDirectoryName(filePath);
        //    string[] files = Directory.GetFiles(directoryName, Path.GetFileName(filePath) + ".*");
        //    if (files.Length > 0)
        //    {
        //        str = files[0];
        //    }
        //    return str;
        //}

        //public static bool writeExcelByArray(ExcelHelper excelHelper, string title, string[] colDataFormat, string[][] reportData, ref int startRow, string sheetName)
        //{
        //    bool flag = true;
        //    try
        //    {
        //        string str = DateTime.Now.ToString("yyyyMMdd)");
        //        sheetName = string.Format("{1}({0}) ", str, title);
        //        sheetName = sheetName.Replace("/", "");
        //        if (sheetName.Length > 0x20)
        //        {
        //            sheetName = sheetName.Substring(0, 0x20);
        //        }
        //        excelHelper.setSheetName(sheetName);
        //        int startCol = 1;
        //        writeExcelByArrayBody(excelHelper, colDataFormat, reportData, ref startRow, startCol);
        //    }
        //    catch (Exception exception)
        //    {
        //        string message = exception.Message;
        //        flag = false;
        //    }
        //    return flag;
        //}

        //public static void ConvertDate(string[][] itemArray, string[] colDataFormat)
        //{
        //    for (int i = 0; i < colDataFormat.Length; i++)
        //    {
        //        if (colDataFormat[i].Equals("COLDATE") && (itemArray.Length > 1))
        //        {
        //            for (int j = 1; j < itemArray.Length; j++)
        //            {
        //                itemArray[j][i] = FormHelp.FormatDate(itemArray[j][i], FormHelp.StandDataFormat);
        //            }
        //        }
        //    }
        //}

        //public static string[] MakeDateArrayForExcel(DataView dv)
        //{
        //    string[] strArray = new string[dv.Table.Columns.Count];
        //    for (int i = 0; i < dv.Table.Columns.Count; i++)
        //    {
        //        strArray[i] = "";
        //    }
        //    return strArray;
        //}

        //private static string[][] MakeArrayForExcel(DataView dv)
        //{
        //    int num4;
        //    int count = dv.Table.Columns.Count;
        //    int num2 = dv.Count + 1;
        //    string[][] strArray = new string[num2][];
        //    int index = 0;
        //    string[] strArray2 = new string[count];
        //    for (num4 = 0; num4 < dv.Table.Columns.Count; num4++)
        //    {
        //        strArray2[num4] = dv.Table.Columns[num4].ColumnName;
        //    }
        //    strArray[0] = strArray2;
        //    for (num4 = 0; num4 < dv.Count; num4++)
        //    {
        //        string[] strArray3 = new string[count];
        //        for (index = 0; index < dv.Table.Columns.Count; index++)
        //        {
        //            strArray3[index] = dv[num4][index].ToString();
        //        }
        //        strArray[num4 + 1] = strArray3;
        //    }
        //    return strArray;
        //}

        //public static bool CreateTemplate(ref string errMessage, ref string strTemplateFile)
        //{
        //    strTemplateFile = AppDomain.CurrentDomain.BaseDirectory;
        //    if (strTemplateFile.Substring(strTemplateFile.Length - 1, 1).Equals(@"\"))
        //    {
        //        strTemplateFile = strTemplateFile + @"TemplatePath\Template.xls";
        //    }
        //    else
        //    {
        //        strTemplateFile = strTemplateFile + @"\TemplatePath\Template.xls";
        //    }
        //    if (File.Exists(strTemplateFile))
        //    {
        //        return true;
        //    }
        //    return true;
        //Application application = new ApplicationClass();
        //try
        //{
        //    string path = "";
        //    string[] strArray = strTemplateFile.Split(new char[] { '\\' });
        //    path = strTemplateFile.Substring(0, (strTemplateFile.Length - strArray[strArray.Length - 1].Length) - 1);
        //    if (!Directory.Exists(path))
        //    {
        //        Directory.CreateDirectory(path);
        //    }
        //    Workbook workbook = application.Workbooks.Add(XlWBATemplate.xlWBATWorksheet);
        //    Sheets sheets = workbook.Sheets;
        //    Worksheet worksheet = (Worksheet)sheets.get_Item(1);
        //    workbook.SaveAs(strTemplateFile, XlFileFormat.xlWorkbookNormal, Type.Missing, Type.Missing, Type.Missing, Type.Missing, XlSaveAsAccessMode.xlNoChange, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
        //    application.Quit();
        //    releaseObject(sheets);
        //    releaseObject(worksheet);
        //    releaseObject(workbook);
        //    releaseObject(application);
        //    GC.Collect();
        //    return true;
        //}
        //catch (Exception exception)
        //{
        //    errMessage = exception.Message;
        //    return false;
        //}
        // }

        //public RefValues DownloadCSVReport(string[] p, byte[][] p_2, int bufferLength, string strData_YM, ref string errorMessage)
        //{
        //    throw new NotImplementedException();
        //}

        //public static void writeExcelByArrayBody(ExcelHelper excelHelper, string[] colDataFormat, string[][] reportData, ref int startRow, int startCol)
        //{
        //    int length = reportData.Length;
        //    int num2 = reportData[0].Length;
        //    int num3 = ColorTranslator.FromWin32(0).ToArgb();
        //    int num4 = ColorTranslator.FromWin32(0xffffff).ToArgb();
        //    Range range = null;
        //    for (int i = 0; i < length; i++)
        //    {
        //        range = excelHelper.setRange(startRow + i, startCol, startRow + i, (startCol + num2) - 1);
        //        range.Value2 = reportData[i];
        //        excelHelper.releaseObject(range);
        //    }
        //    setRangeCellsFormat(excelHelper, colDataFormat, startRow, startCol, length);
        //    startRow += length + 2;
        //    range = excelHelper.setRange(1, 1, 1, 1);
        //    range.Select();
        //    excelHelper.releaseObject(range);
        //}

        //public static void setRangeCellsFormat(ExcelHelper excelFile, string[] colsDataFormat, int startRow, int startCol, int totalRows)
        // {
        //     for (int i = 0; i < colsDataFormat.Length; i++)
        //     {
        //         Range range;
        //         if (colsDataFormat[i].Equals("COLDATE"))
        //         {
        //             range = excelFile.setRange(startRow, startCol + i, startRow + totalRows, startCol + i);
        //             range.NumberFormat = FormHelp.DateFormat;
        //             range.TextToColumns(range, XlTextParsingType.xlFixedWidth, XlTextQualifier.xlTextQualifierNone, Type.Missing, Type.Missing, Type.Missing, false, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
        //             excelFile.releaseObject(range);
        //         }
        //         else if (colsDataFormat[i].Equals("COLTOTALCOST"))
        //         {
        //             range = excelFile.setRange(startRow, startCol + i, startRow + totalRows, startCol + i);
        //             range.NumberFormat = FormHelp.DollarFormat;
        //             range.TextToColumns(range, XlTextParsingType.xlFixedWidth, XlTextQualifier.xlTextQualifierNone, Type.Missing, Type.Missing, Type.Missing, false, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
        //             excelFile.releaseObject(range);
        //         }
        //     }
        //}

        //public static void releaseObject(object obj)
        //{
        //    System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
        //}
        #endregion

        public bool DownloadCSVReport(ref string[] strReportName, ref byte[][] bytes, int bufferLength, string strData_YM, ref string errMessage)
        {
            try
            {
                int i = 0;
                foreach (object o in hashKeyNamePairs.Keys)
                {
                    string key = o.ToString();
                    string name = hashKeyNamePairs[key].ToString();
                
                    string strFileName = GetExportFileForCVS(name);// generateReport.getExportFileForCVS();

                    log.DebugLog(strFileName + " Method:downloadCSVReport()", MethodBase.GetCurrentMethod().Name);
                    if (!File.Exists(strFileName))
                    {
                        errMessage = "The export CSV file does not exist";
                        return false;
                    }
                    string[] strArray = strFileName.Split('\\');
                    strReportName[i] = strArray[strArray.Length - 1];
                    FileInfo fi = new FileInfo(strFileName);
                    bytes[i] = new byte[fi.Length];
                    FileStream input = fi.Open(FileMode.Open);
                    bufferLength = input.Read(bytes[i], 0, bytes[i].Length);
                    input.Close();
                    i++;
                }
                return true;
            }
            catch (Exception ex)
            {
                errMessage = ex.Message;
                return false;
            }
        }

        public bool DownloadCSVReport(ref string strReportName, ref byte[] bytes, int bufferLength, string strData_YM, ref string errMessage)
        {
            try
            {
                string strFileName =GetExportFileForCVS();
                log.DebugLog(strFileName + " Method:downloadCSVReport()", MethodBase.GetCurrentMethod().Name);
                if (!File.Exists(strFileName))
                {
                    errMessage = "The export CSV file does not exist";
                    return false;
                }
                string[] strArray = strFileName.Split('\\');
                strReportName = strArray[strArray.Length - 1];
                FileInfo fi = new FileInfo(strFileName);
                bytes = new byte[fi.Length];
                FileStream input = fi.Open(FileMode.Open);
                bufferLength = input.Read(bytes, 0, bytes.Length);
                input.Close();
                return true;
            }
            catch (Exception ex)
            {
                errMessage = ex.Message;
                return false;
            }
        }

        public string GetExportFileForCVS()
        {
            string h = "";
            if (!Directory.Exists(CommonUtility.PBOCExportPath()))
            {
                Directory.CreateDirectory(CommonUtility.PBOCExportPath());
            }
            if (CommonUtility.PBOCExportPath().Substring(CommonUtility.PBOCExportPath().Length - 1, 1).Equals("\\"))
            {
                h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000.csv", CommonUtility.PBOCFinInsCode().ToString(), globalStrData_YM);
            }
            else
            {
                h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000.csv", CommonUtility.PBOCFinInsCode().ToString(), globalStrData_YM);
            }
            return h;

        }

        public string GetExportFileForCVS(string suffixName)
        {
            string h = "";
            if (!Directory.Exists(CommonUtility.PBOCExportPath()))
            {
                Directory.CreateDirectory(CommonUtility.PBOCExportPath());
            }
            if (CommonUtility.PBOCExportPath().Substring(CommonUtility.PBOCExportPath().Length - 1, 1).Equals("\\"))
            {
                if (suffixName.ToLower().Equals("ga"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + suffixName + ".csv", CommonUtility.PBOCFinInsCode().ToString(), globalStrData_YM);
                }
                else if (suffixName.ToLower().Equals("cb"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + suffixName + ".csv", CommonUtility.PBOCFinInsCodeCB().ToString(), globalStrData_YM);
                }
                else if (suffixName.ToLower().Equals("wfd"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + suffixName + ".csv", CommonUtility.PBOCFinInsCodeWCF().ToString(), globalStrData_YM);
                }
                else if (suffixName.ToLower().Equals("bb"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + suffixName + ".csv", CommonUtility.PBOCFinInsCodeBB().ToString(), globalStrData_YM);
                }
            }
            else
            {
                if (suffixName.ToLower().Equals("ga"))
                {
                    h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000" + suffixName + ".csv", CommonUtility.PBOCFinInsCode().ToString(), globalStrData_YM);
                }
                else if (suffixName.ToLower().Equals("cb"))
                {
                    h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000" + suffixName + ".csv", CommonUtility.PBOCFinInsCodeCB().ToString(), globalStrData_YM);
                }
                else if (suffixName.ToLower().Equals("wfd"))
                {
                    h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000" + suffixName + ".csv", CommonUtility.PBOCFinInsCodeWCF().ToString(), globalStrData_YM);
                }
                else if (suffixName.ToLower().Equals("bb"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + suffixName + ".csv", CommonUtility.PBOCFinInsCodeBB().ToString(), globalStrData_YM);
                }
            }
            return h;

        }

        private bool WriteFile(byte[][] mulBytes, string[] strFileNames, ref string errMessage)
        {
            try
            {

                string strOutFile = "";//path and name 
                for (int i = 0; i < strFileNames.Length; i++)
                {
                    string strFileName = strFileNames[i];
                    byte[] bytes = mulBytes[i];
                    if (globalExportPBOCPath.Substring(globalExportPBOCPath.Length - 1, 1).Equals("\\"))
                    {
                        strOutFile = globalExportPBOCPath + strFileName;
                    }
                    else
                    {
                        strOutFile = globalExportPBOCPath + "\\" + strFileName;
                    }
                    if (File.Exists(strOutFile))
                    {
                        File.Delete(strOutFile);
                    }

                    FileStream output = null;
                    if (!File.Exists(strOutFile))
                        output = File.Create(strOutFile);

                    else
                        output = new FileStream(strOutFile, FileMode.Open);

                    string[] strArray = strFileName.Split('.');
                    if (strArray[strArray.Length - 1].ToUpper().Equals("XLS"))
                    {
                        Encoding encoding = Encoding.GetEncoding(CommonUtility.TextEncoding());
                        StreamWriter sw = new StreamWriter(output, encoding);
                        char[] charArray = System.Text.Encoding.Default.GetChars(bytes);
                        sw.Write(charArray, 0, charArray.Length);
                        sw.Flush();
                        sw.Close();
                    }
                    else
                    {
                        long offset = 0;
                        offset = output.Length;

                        if (offset > 0)
                        {
                            output.Seek(offset, SeekOrigin.Begin);

                        }
                        output.Write(bytes, 0, bytes.Length);
                        output.Close();
                    }
                    FileInfo fi = new FileInfo(strOutFile);
                    fi.LastWriteTime = dt;

                }
                return true;
            }
            catch (Exception ex)
            {
                errMessage = ex.Message;
                return false;
            }
        }

        public RefValues DownloadTXTReport(RefValues values, int bufferLength, string strData_YM)
        {
            string[] strReportName = values.ReportName;
            byte[][] bytes = values.BytesArray;
            string[] keys = values.Keys;
            string errMessage = "";
            if (DownloadTXTReport(ref strReportName, ref bytes, ref keys, bufferLength, strData_YM, ref errMessage))
            {
                values.ReportName = strReportName;
                values.BytesArray = bytes;
                values.Keys = keys;
                values.ErrMessage = errMessage;
                return values;
            }
            else
            {
                values.ErrMessage = errMessage;
                return values;
            }
        }

        public bool DownloadTXTReport(ref string[] strReportName, ref byte[][] bytes, ref string[] keys, int bufferLength, string strData_YM, ref string errMessage)
        {
            try
            {
                int i = 0;
                int fileCount = hashKeyNamePairs.Count;
                strReportName = new string[fileCount];
                bytes = new byte[fileCount][];
                keys = new string[hashKeyNamePairs.Keys.Count];
                foreach (object o in hashKeyNamePairs.Keys)
                {

                    string key = o.ToString();
                    keys[i] = key;
                    string name = hashKeyNamePairs[key].ToString();

                    string strFileName = GetExportFileName(name, strData_YM); //get the export file name by the name('GA,CB')   //here,I should get 2 or more
                    log.DebugLog(strFileName + " Method:downloadTXTReport()", MethodBase.GetCurrentMethod().Name);
                    if (!File.Exists(strFileName))
                    {
                        errMessage = "The export file does not exist";
                        return false;
                    }
                    string[] strArray = strFileName.Split('\\');
                    strReportName[i] = strArray[strArray.Length - 1];//get name
                    FileInfo fi = new FileInfo(strFileName);
                    //bytes = new byte[fi.Length]   ;
                    bytes[i] = new byte[fi.Length];
                    FileStream input = fi.Open(FileMode.Open);
                    bufferLength = input.Read(bytes[i], 0, bytes[i].Length);//get bytes
                    input.Close();
                    i++;

                }
                return true;
            }
            catch (Exception ex)
            {
                errMessage = ex.Message;
                return false;
            }
        }

        public string GetExportFileName(string suffixName, string strData_YM)
        {
            string h = "";
            log.DebugLog("suffixName is :" + suffixName, MethodBase.GetCurrentMethod().Name);
            if (!Directory.Exists(CommonUtility.PBOCExportPath()))
            {
                Directory.CreateDirectory(CommonUtility.PBOCExportPath());
            }
            if (CommonUtility.PBOCExportPath().Substring(CommonUtility.PBOCExportPath().Length - 1, 1).Equals("\\"))
            {
                if (suffixName.ToLower().Equals("ga"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + suffixName + ".txt", CommonUtility.PBOCFinInsCode().ToString(), strData_YM);//modify
                }
                else if (suffixName.ToLower().Equals("cb"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + suffixName + ".txt", CommonUtility.PBOCFinInsCodeCB().ToString(), strData_YM);//modify
                }
                else if (suffixName.ToLower().Equals("wfd"))
                {
                    //h = CNRFConfig.ExportPath + string.Format("{0}{1}0011000" + suffixName + ".txt", CNRFConfig.FinInsCodeCB.ToString(), strData_YM);//modified by liuzhihang,2010.2.15
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + suffixName + ".txt", CommonUtility.PBOCFinInsCodeWCF().ToString(), strData_YM);//modified by ZZY,2011.1.11
                }
                else if (suffixName.ToLower().Equals("bb"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + suffixName + ".txt", CommonUtility.PBOCFinInsCodeBB().ToString(), strData_YM);//modified by HB,2012.5.28
                }
            }
            else
            {
                if (suffixName.ToLower().Equals("ga"))
                {
                    h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000" + suffixName + ".txt", CommonUtility.PBOCFinInsCode().ToString(), strData_YM);//modify liu, zhihang
                }
                else if (suffixName.ToLower().Equals("cb"))
                {
                    h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000" + suffixName + ".txt", CommonUtility.PBOCFinInsCodeCB().ToString(), strData_YM);//modify liu, zhihang
                }
                else if (suffixName.ToLower().Equals("wfd"))
                {
                    //h = CNRFConfig.ExportPath + @"\" + string.Format("{0}{1}0011000" + suffixName + ".txt", CNRFConfig.FinInsCodeCB.ToString(), strData_YM);//modified by liuzhihang,2010.2.15
                    h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000" + suffixName + ".txt", CommonUtility.PBOCFinInsCodeWCF().ToString(), strData_YM);//modified by ZZY,2011.1.11
                }
                else if (suffixName.ToLower().Equals("bb"))
                {
                    //h = Config.ExportPath + @"\" + string.Format("{0}{1}0011000" + suffixName + ".txt", DbAccess.FinInsCodeCB.ToString(), strData_YM);//modified by liuzhihang,2010.2.15
                    h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000" + suffixName + ".txt", CommonUtility.PBOCFinInsCodeBB().ToString(), strData_YM);//modified by HB,2012.5.28
                }
            }
            return h;
        }

        public string GetExportFileForExcel(string strData_YM)
        {
            string h = "";
            if (!Directory.Exists(CommonUtility.PBOCExportPath()))
            {
                Directory.CreateDirectory(CommonUtility.PBOCExportPath());
            }
            if (CommonUtility.PBOCExportPath().Substring(CommonUtility.PBOCExportPath().Length - 1, 1).Equals("\\"))
            {
                h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000ForALS.xls", CommonUtility.PBOCFinInsCode().ToString(), strData_YM);
            }
            else
            {
                h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000ForALS.xls", CommonUtility.PBOCFinInsCode().ToString(), strData_YM);
            }
            return h;
        }

        public void ExecuteNonQuery(string cmdText)
        {
            PBOCDao.ExecuteNonQuery(cmdText);           
        }
    }
}
