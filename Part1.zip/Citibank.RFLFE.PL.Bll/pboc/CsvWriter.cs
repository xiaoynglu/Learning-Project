﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Mvc.Models;
using System.Reflection;
using System.Configuration;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Wordprocessing;
using Citibank.RFLFE.PL.Bll.disbursement;
using Citibank.RFLFE.PL.Bll.common;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using SystemFrameworks.Util;
using System.Collections;

namespace Citibank.RFLFE.PL.Bll.pboc
{
    public class CvsWriter : IWriter
    {
        StreamWriter swriterTxt = null;
        FileStream fstreamTxt = null;
        string cvsName = string.Empty;
        #region property
        private string path = string.Empty;
        public string Path
        {
            set
            {
                path = value;
            }
            get
            {
                return path;
            }
        }
        private string key = string.Empty;
        public string Key
        {
            set
            {
                key = value;
            }
            get
            {
                return key;
            }
        }
        private string strData_YM = string.Empty;
        public string StrData_YM
        {
            set
            {
                strData_YM = value;
            }
            get
            {
                return strData_YM;
            }
        }
        #endregion
        public CvsWriter(string _strData_YM, string CvsName)
        {
            cvsName = CvsName;
            this.StrData_YM = _strData_YM;
            getExportFileForCVS();
        }
        /// <summary>
        /// write a line of content
        /// </summary>
        /// <param name="_strLine"></param>
        public void WriteLine(string _strLine)
        {
            this.swriterTxt.WriteLine(_strLine);
            this.swriterTxt.Flush();
        }
        /// <summary>
        /// ready to work:1.generate export file for cvs, 
        /// 2.get file stream and stream writer ready
        /// </summary>
        public void Ready()
        {
            //open the export with stream objects to ready to write

            fstreamTxt = new FileStream(this.Path, FileMode.OpenOrCreate, FileAccess.Write);
            Encoding encoding = Encoding.GetEncoding(CommonUtility.TextEncoding());
            swriterTxt = new StreamWriter(fstreamTxt, encoding);
        }

        //generate export file path
        public string getExportFileForCVS()
        {
            string h = "";
            if (!Directory.Exists(CommonUtility.PBOCExportPath()))
            {
                Directory.CreateDirectory(CommonUtility.PBOCExportPath());
            }
            if (CommonUtility.PBOCExportPath().Substring(CommonUtility.PBOCExportPath().Length - 1, 1).Equals("\\"))
            {
                if (cvsName.ToLower().Equals("ga"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + cvsName + ".csv", CommonUtility.PBOCFinInsCode().ToString(), strData_YM);
                }
                else if (cvsName.ToLower().Equals("cb"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + cvsName + ".csv", CommonUtility.PBOCFinInsCodeCB().ToString(), strData_YM);
                }
                else if (cvsName.ToLower().Equals("wfd"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + cvsName + ".csv", CommonUtility.PBOCFinInsCodeWCF().ToString(), strData_YM);
                }
                else if (cvsName.ToLower().Equals("bb"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + cvsName + ".csv", CommonUtility.PBOCFinInsCodeBB().ToString(), strData_YM);
                }
            }
            else
            {
                if (cvsName.ToLower().Equals("ga"))
                {
                    h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000" + cvsName + ".csv", CommonUtility.PBOCFinInsCode().ToString(), strData_YM);
                }
                else if (cvsName.ToLower().Equals("cb"))
                {
                    h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000" + cvsName + ".csv", CommonUtility.PBOCFinInsCodeCB().ToString(), strData_YM);
                }
                else if (cvsName.ToLower().Equals("wfd"))
                {
                    h = CommonUtility.PBOCExportPath() + @"\" + string.Format("{0}{1}0011000" + cvsName + ".csv", CommonUtility.PBOCFinInsCodeWCF().ToString(), strData_YM);
                }
                else if (cvsName.ToLower().Equals("bb"))
                {
                    h = CommonUtility.PBOCExportPath() + string.Format("{0}{1}0011000" + cvsName + ".csv", CommonUtility.PBOCFinInsCodeBB().ToString(), strData_YM);
                }
            }
            this.Path = h;
            return h;
        }
        public void Close()
        {
            this.swriterTxt.Close();
            this.fstreamTxt.Close();
        }
    }
}
