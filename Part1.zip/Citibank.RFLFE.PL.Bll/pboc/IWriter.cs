﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Bll.pboc
{
    public interface IWriter// interface
    {
        string Key { get; set; }//it's used to determine which concrete objcet should be used
        string Path { get; set; }//the full file path including the path and name.
        void WriteLine(string _strLine);//write a line content to the file.
        void Ready();// get file stream and stream writer ready.
        void Close();//close file stream
    }
}
