﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Mvc.Models;
using System.Reflection;
using System.Configuration;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Wordprocessing;
using Citibank.RFLFE.PL.Bll.disbursement;
using Citibank.RFLFE.PL.Bll.common;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using SystemFrameworks.Util;
using System.Collections;

namespace Citibank.RFLFE.PL.Bll.pboc
{
    public class TempWriter : IWriter
    {
        StreamWriter swriterTxt = null;
        FileStream fstreamTxt = null;
        string tempName = string.Empty;
        #region property
        private string path = string.Empty;
        public string Path
        {
            set
            {
                path = value;
            }
            get
            {
                return path;
            }
        }
        private string key = string.Empty;
        public string Key
        {
            set
            {
                key = value;
            }
            get
            {
                return key;
            }
        }
        #endregion
        public TempWriter(string TempName)
        {
            tempName = TempName;
            getExportForTemp();
        }
        //get export file for temp
        public string getExportForTemp()
        {
            string strTempFile = AppDomain.CurrentDomain.BaseDirectory;

            if (strTempFile.Substring(strTempFile.Length - 1, 1).Equals("\\"))
            {
                strTempFile = strTempFile + System.DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            else
            {
                strTempFile = strTempFile + "\\" + System.DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            strTempFile += tempName;
            if (File.Exists(strTempFile))
            {
                File.Delete(strTempFile);
            }
            this.Path = strTempFile;
            return strTempFile;
        }
        /// <summary>
        /// wirte a line to file
        /// </summary>
        /// <param name="_strLine"></param>
        public void WriteLine(string _strLine)
        {
            this.swriterTxt.WriteLine(_strLine);
            this.swriterTxt.Flush();
        }
        /// <summary>
        /// ready to work:1.generate export file for cvs, 
        /// 2.get file stream and stream writer ready
        /// </summary>
        public void Ready()
        {
            //open the export with stream objects to ready to write
            fstreamTxt = new FileStream(this.Path, FileMode.OpenOrCreate, FileAccess.Write);
            Encoding encoding = Encoding.GetEncoding(CommonUtility.TextEncoding());
            swriterTxt = new StreamWriter(fstreamTxt, encoding);
        }
        public void Close()
        {
            this.swriterTxt.Close();
            this.fstreamTxt.Close();
        }
    }

    public class TempWriterGA : IWriter
    {
        StreamWriter swriterTxt = null;
        FileStream fstreamTxt = null;
        #region property
        private string path = string.Empty;
        public string Path
        {
            set
            {
                path = value;
            }
            get
            {
                return path;
            }
        }
        private string key = string.Empty;
        public string Key
        {
            set
            {
                key = value;
            }
            get
            {
                return key;
            }
        }
        #endregion
        public TempWriterGA()
        {
            getExportForTemp();
        }
        public string getExportForTemp()
        {
            string strTempFile = AppDomain.CurrentDomain.BaseDirectory;
            if (strTempFile.Substring(strTempFile.Length - 1, 1).Equals("\\"))
            {
                strTempFile = strTempFile + System.DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            else
            {
                strTempFile = strTempFile + "\\" + System.DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            strTempFile += "GA";
            if (File.Exists(strTempFile))
            {
                File.Delete(strTempFile);
            }
            this.Path = strTempFile;
            return strTempFile;
        }
        /// <summary>
        /// wirte a line to file
        /// </summary>
        /// <param name="_strLine"></param>
        public void WriteLine(string _strLine)
        {
            this.swriterTxt.WriteLine(_strLine);
            this.swriterTxt.Flush();
        }
        /// <summary>
        /// get file stream and stream writer ready
        /// </summary>
        public void Ready()
        {
            //open the export with stream objects to ready to write

            fstreamTxt = new FileStream(this.Path, FileMode.OpenOrCreate, FileAccess.Write);
            Encoding encoding = Encoding.GetEncoding(CommonUtility.TextEncoding());
            swriterTxt = new StreamWriter(fstreamTxt, encoding);
        }
        public void Close()
        {
            this.swriterTxt.Close();
            this.fstreamTxt.Close();
        }
    }

    public class TempWriterCB : IWriter
    {
        StreamWriter swriterTxt = null;
        FileStream fstreamTxt = null;
        #region property
        private string path = string.Empty;
        public string Path
        {
            set
            {
                path = value;
            }
            get
            {
                return path;
            }
        }
        private string key = string.Empty;
        public string Key
        {
            set
            {
                key = value;
            }
            get
            {
                return key;
            }
        }
        #endregion
        public TempWriterCB()
        {
            getExportForTemp();
        }
        //get export file for temp
        public string getExportForTemp()
        {
            string strTempFile = AppDomain.CurrentDomain.BaseDirectory;

            if (strTempFile.Substring(strTempFile.Length - 1, 1).Equals("\\"))
            {
                strTempFile = strTempFile + System.DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            else
            {
                strTempFile = strTempFile + "\\" + System.DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            strTempFile += "CB";
            if (File.Exists(strTempFile))
            {
                File.Delete(strTempFile);
            }
            this.Path = strTempFile;
            return strTempFile;
        }
        /// <summary>
        /// wirte a line to file
        /// </summary>
        /// <param name="_strLine"></param>
        public void WriteLine(string _strLine)
        {
            this.swriterTxt.WriteLine(_strLine);
            this.swriterTxt.Flush();
        }
        /// <summary>
        /// ready to work:1.generate export file for cvs, 
        /// 2.get file stream and stream writer ready
        /// </summary>
        public void Ready()
        {
            //open the export with stream objects to ready to write
            fstreamTxt = new FileStream(this.Path, FileMode.OpenOrCreate, FileAccess.Write);
            Encoding encoding = Encoding.GetEncoding(CommonUtility.TextEncoding());
            swriterTxt = new StreamWriter(fstreamTxt, encoding);
        }
        public void Close()
        {
            this.swriterTxt.Close();
            this.fstreamTxt.Close();
        }
    }

    public class TempWriterWFD : IWriter
    {
        StreamWriter swriterTxt = null;
        FileStream fstreamTxt = null;
        #region property
        private string path = string.Empty;
        public string Path
        {
            set
            {
                path = value;
            }
            get
            {
                return path;
            }
        }
        private string key = string.Empty;
        public string Key
        {
            set
            {
                key = value;
            }
            get
            {
                return key;
            }
        }
        #endregion
        public TempWriterWFD()
        {
            getExportForTemp();
        }
        //get export file for temp
        public string getExportForTemp()
        {
            string strTempFile = AppDomain.CurrentDomain.BaseDirectory;

            if (strTempFile.Substring(strTempFile.Length - 1, 1).Equals("\\"))
            {
                strTempFile = strTempFile + System.DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            else
            {
                strTempFile = strTempFile + "\\" + System.DateTime.Now.ToString("yyyyMMddHHmmss");
            }
            strTempFile += "WFD";
            if (File.Exists(strTempFile))
            {
                File.Delete(strTempFile);
            }
            this.Path = strTempFile;
            return strTempFile;
        }
        /// <summary>
        /// wirte a line to file
        /// </summary>
        /// <param name="_strLine"></param>
        public void WriteLine(string _strLine)
        {
            this.swriterTxt.WriteLine(_strLine);
            this.swriterTxt.Flush();
        }
        /// <summary>
        /// ready to work:1.generate export file for cvs, 
        /// 2.get file stream and stream writer ready
        /// </summary>
        public void Ready()
        {
            //open the export with stream objects to ready to write
            fstreamTxt = new FileStream(this.Path, FileMode.OpenOrCreate, FileAccess.Write);
            Encoding encoding = Encoding.GetEncoding(CommonUtility.TextEncoding());
            swriterTxt = new StreamWriter(fstreamTxt, encoding);
        }
        public void Close()
        {
            this.swriterTxt.Close();
            this.fstreamTxt.Close();
        }
    }
}
