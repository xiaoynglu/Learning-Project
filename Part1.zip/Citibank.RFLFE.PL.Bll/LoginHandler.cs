﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Reflection;
using Citibank.RFLFE.PL.Mvc.Models;
using System.Web;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using Citibank.RFLFE.PL.Bll.common;

namespace Citibank.RFLFE.PL.Bll
{
    public class LoginHandler : ILoginHandler
    {
        #region all Dao
        public ILoginDao LoginDao { get; set; }
        #endregion
        Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);
        public T_Sys_Users GetUserInfo(string SoeID)
        {
            T_Sys_Users user = new T_Sys_Users();
            try
            {
                user = LoginDao.GetUserInfo(SoeID);
                log.DebugLog(string.Format("GetUserInfo : invocation=[{0}]", SoeID), "GetUserInfo");
            }
            catch (Exception ex)
            {
                new Logger(MethodBase.GetCurrentMethod().DeclaringType).DebugLog(SoeID, "GetUserInfo");
            }
            return user;
        }

        public int GetUserRole(string SoeID)
        {
            return LoginDao.GetUserRole(SoeID);
        }
        public IList<MenuTree> GetMenu(int RoleType)
        {
            log.DebugLog("Begin to GetMenu", "GetMenu");
            var menuList = HttpRuntime.Cache.Get(Constants.RoleTypeCacheKeyPrefix + RoleType.ToString());
            if (menuList == null)
            {
                log.DebugLog("Get menuList from database", "GetMenu");
                if (HttpRuntime.Cache.Count == 0)
                {
                    SysParametersHandler SysParametersHandler = new SysParametersHandler();
                    SysParametersHandler.SetParametersCache();
                }
                return LoginDao.GetMenu(RoleType);
            }
            else {
                log.DebugLog("Get menuList in Cache", "GetMenu");
                return (IList<MenuTree>)menuList;
            }
        }
        public bool login(string soeid, string logonStatus, string password, string clientIPAddress, string hostName, ref string errMessage)
        {
            return LoginDao.login( soeid,  logonStatus, password, clientIPAddress,  hostName, ref  errMessage);
        }

        public UserInfo GetUserInfoByEntity(UserInfo oUserInfo)
        {
            return LoginDao.GetUserInfoByEntity(oUserInfo);
        }

       //public UserInfo getUserPoolBySoeId(string strSoeId, ref int iErrCode, ref string errMessage)
       // {
       //     try
       //     {
       //         Dictionary<string, UserInfo> data = (Dictionary<string, UserInfo>)FrameworkCaching.GetAppCache(CacheConst.CacheType.SysUserPool);

       //         if (data == null)
       //         {
       //             loadAllUserInfoToCache();

       //             data = (Dictionary<string, UserInfo>)FrameworkCaching.GetAppCache(CacheConst.CacheType.SysUserPool);

       //             if (data == null)
       //             {
       //                 errMessage = "Please contact admin to load the cache again.";
       //                 iErrCode = 1;
       //                 return null;
       //             }
       //         }
       //         if (data.ContainsKey(strSoeId.Trim().ToLower()))
       //         {
       //             return (UserInfo)data[strSoeId.Trim().ToLower()];
       //         }
       //         else
       //         {
       //             errMessage = String.Empty;
       //             loadAllUserInfoToCache();
       //             data = (Dictionary<string, UserInfo>)FrameworkCaching.GetAppCache(CacheConst.CacheType.SysUserPool);
       //             if (data.ContainsKey(strSoeId.Trim().ToLower()))
       //             {
       //                 return (UserInfo)data[strSoeId.Trim().ToLower()];
       //             }
       //             else
       //             {
       //                 errMessage = string.Format("{0} can not be found", strSoeId);
       //                 iErrCode = 1;
       //                 return null;
       //             }
       //         }
       //     }
       //     catch (Exception ex)
       //     {
       //         //log.Error(ex);
       //         errMessage = ex.Message;
       //         iErrCode = 1;
       //         return null;
       //     }
       // }
        //public bool loadAllUserInfoToCache()
        //{
        //    try
        //    {
        //        string errMessage = "";
        //        Ent_TUser ent_User = new Ent_TUser();
        //        ent_User = LoginDao.getAllUserInfo();
        //        setUserPool(ent_User.TUserInfo, ref errMessage);
        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
               
        //        return false;
        //    }
        //    //return true;
        //}


        //public static bool setUserPool(IList<UserInfo> t, ref string errMessage)
        //{
        //    FrameworkCaching.ClearAppCache(CacheConst.CacheType.SysUserPool);
        //    Dictionary<string, UserInfo> data = new Dictionary<string, UserInfo>();
        //    foreach (UserInfo User in t)
        //    {
        //        data.Add(User.SoeId.Trim().ToLower(), User);
        //    }
        //    //缓存有效期
        //    TimeSpan ts = new TimeSpan(2, 0, 0, 0, 0);
        //    FrameworkCaching.SetAppCache(CacheConst.CacheType.SysUserPool, data, ts);
        //    return true;
        //}

        public void InsertLogToDB(string soeID, string logon, string message, string ip, string hostName)
        {
            LoginDao.InsertLogToDB(soeID, logon, message, ip, hostName);
        }

    }
}
