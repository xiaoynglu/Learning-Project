﻿using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.userLevel
{
    public class CreditRatingCheckerHandler : ICreditRatingCheckerHandler
    {
        public ICreditRatingCheckerDao CreditRatingCheckerDao { get; set; }
        public CommonTResult<CreditRatingCheckerView> GetViewList(int start, int limit, CreditRatingCheckerView entity)
        {
            CommonTResult<CreditRatingCheckerView> result = null;
            CommonTResult<CreditRatingCheckerView> resultDao = CreditRatingCheckerDao.GetViewList(start, limit, entity);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<CreditRatingCheckerView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public bool CheckerApproval(int TID, int ApprovalType, string checker)
        {
            return CreditRatingCheckerDao.CheckerApproval(TID, ApprovalType, checker);
        }
    }
}
