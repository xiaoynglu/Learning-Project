﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.userLevel
{
    public class SysRolesHandler : ISysRolesHandler
    {
        public ISysRolesDao SysRolesDao { get; set; }
        public CommonTResult<T_Sys_Roles> GetSysRoles()
        {
            return SysRolesDao.GetSysRoles();
        }
        public CommonTResult<T_SysRole_UserView> QueryUser(int limit, int start)
        {
            return SysRolesDao.QueryUser(limit, start);
        }
        public bool UpdateStatus(string soeid, string newstatus)
        {
            return SysRolesDao.UpdateStatus(soeid, newstatus);
        }
        public CommonTResult<T_SysRole_UserView> QueryUserWithCondition(string soeid, string Location, string Status, int limit, int start)
        {
            CommonTResult<T_SysRole_UserView> result = SysRolesDao.QueryUserWithCondition(soeid, Location, Status, limit, start);
            return result;
        }
    }
}
