﻿using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.userLevel
{
    public class CreditRatingHandler : ICreditRatingHandler
    {
        public ICreditRatingDao CreditRatingDao { get; set; }
        public CommonTResult<CreditRatingListView> QueryCreditLevel()
        {
            return CreditRatingDao.QueryCreditLevel();
        }
        public CommonTResult<T_Sys_UsersSimple> QueryCreditOfficerUserInfo(string BranchCode, string SoeId, int limit, int start)
        {
            return CreditRatingDao.QueryCreditOfficerUserInfo(BranchCode,SoeId,limit,start);
        }
        public CommonTResult<OfficerUserLevelInfoView> QueryCreditOfficerUserLevelInfo(string soeid, int start, int limit)
        {
            return CreditRatingDao.QueryCreditOfficerUserLevelInfo(soeid,start,limit);
        }
        public bool saveContent(OfficerUserLevelInfoView entity)
        {
            return CreditRatingDao.saveContent(entity);
        }
    }
}
