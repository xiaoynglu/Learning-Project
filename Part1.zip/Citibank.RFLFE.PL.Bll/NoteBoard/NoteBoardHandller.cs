﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.NoteBoard
{
    public class NoteBoardHandller : INoteBoardHandller
    {
        #region all Dao
        public INoteBoardDao NoteBoardDao { get; set; }        
        #endregion

        public CommonTResult<T_PL_News> GetNewsList(int Start, int Limit, string keyword)
        {
            CommonTResult<T_PL_News> result = null;
            CommonTResult<T_PL_News> resultDao = NoteBoardDao.GetNewsList(Start, Limit, keyword);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_News>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public bool SaveItem(int TID, string title, string content, string soeid)
        {
            return NoteBoardDao.SaveItem(TID, title, content, soeid);
        }
        public bool DeleteItem(int TID)
        {
            return NoteBoardDao.DeleteItem(TID);
        }

        public CommonTResult<T_PL_NoteWaitConfig> GetNoteWait(int Start, int Limit,string soeid)
        {
            CommonTResult<T_PL_NoteWaitConfig> result = null;
            CommonTResult<T_PL_NoteWaitConfig> resultDao = NoteBoardDao.GetNoteWait(Start, Limit, soeid);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_NoteWaitConfig>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
        public CommonTResult<T_PL_NoteWaitConfig> GetNoteCurrent(int Start, int Limit, string soeid)
        {
            CommonTResult<T_PL_NoteWaitConfig> result = null;
            CommonTResult<T_PL_NoteWaitConfig> resultDao = NoteBoardDao.GetNoteCurrent(Start, Limit, soeid);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_NoteWaitConfig>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public bool SaveMessage(T_PL_MessageAndNotice entity, string soeid)
        {
            return NoteBoardDao.SaveMessage(entity, soeid);
        }

        public int GetMessageLastReadID(string soeid)
        {
            return NoteBoardDao.GetMessageLastReadID( soeid);
        }

        public bool SaveMessageReadLog(string soeid, string TID)
        {
            return NoteBoardDao.SaveMessageReadLog(soeid, TID);
        }

        public CommonTResult<T_Sys_Roles> GetSystemRoles()
        {
            return NoteBoardDao.GetSystemRoles();
        }

        public CommonTResult<T_PL_MessageAndNotice> GetMessageContent(int start, int limit, int typevalue, string soeid, string orgcode)
        {
            CommonTResult<T_PL_MessageAndNotice> result = null;
            CommonTResult<T_PL_MessageAndNotice> resultDao = NoteBoardDao.GetMessageContent(start, limit, typevalue, soeid, orgcode);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_MessageAndNotice>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public IList<T_Sys_Branch> GetNotePageBanks(string orgcode)
        {
            return NoteBoardDao.GetNotePageBanks(orgcode);
        }

    }
}
