﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Transactions;
using Citibank.RFLFE.PL.Mvc.Models;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;

namespace Citibank.RFLFE.PL.Bll.workflow
{
    public class WorkFlowHandler : IWorkFlowHandler
    {
        #region workflow dao
        public IWorkFlowDao WorkFlowDao { get; set; }
        #endregion

        public void SaveHandOverFWMS(Ent_Aplication entApp, string batchNO, IDictionary<string, string> fmsParameters)
        {
            WorkFlowDao.SaveHandOverFWMS(entApp,batchNO,fmsParameters);
        }
        public Dictionary<string, string> GetFMSParameters()
        {
            return WorkFlowDao.GetFMSParameters();
        }

        public int TryLock(string appid,string soeid)
        {
           return WorkFlowDao.TryLock(appid,soeid);
        }

        public string GetCurrentStatus(string appid)
        {
            return WorkFlowDao.GetCurrentStatus(appid);
        }

        public void SetVaild(string guidAppID)
        {
             WorkFlowDao.SetVaild(guidAppID);
        }

        #region Add trace information
        /// <summary>
        /// add trace information
        /// </summary>
        /// <param name="ent"></param>
        public void AddTraceInfo(T_WF_PL_INS ent)
        {
            TransactionOptions ops = new TransactionOptions();
            ops.IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted;
            bool ispengding = false;
            using (TransactionScope ts = new TransactionScope(TransactionScopeOption.Required, ops))
            {
                IList<T_WF_PL_INS> ins = WorkFlowDao.HasInstance(ent.AppID);
                if (ins.Count == 1)
                {
                    IList<T_WF_PL_INS> ins1 = WorkFlowDao.GetStageID(ent.AppID);
                    if (ins1.Count > 0)
                    {
                        int stageID = ins1[0].StageID;
                        String status = ins1[0].Status;
                        int prodID = ins1[0].ProdID;
                        string procID = ins1[0].CurrentProcessor;
                        if (status == Constants.WFStatus.PE && procID == ent.SoeID)
                        {
                            if (ent.Action == IActionTypes.Pickup)
                            {
                                ispengding = true;
                                WorkFlowDao.SetLastDate(ent.AppID, DateTime.Now);
                            }
                            if (ent.Action != IActionTypes.Pending && ent.Action != IActionTypes.Pickup)
                            {
                                ispengding = false;
                                //get last pickup time
                                IList<T_WF_PL_INS> ins2 = WorkFlowDao.GetLastDate(ent.AppID);
                                string pickupTime = ins2[0].PickupTime;

                                //
                                T_WF_PL_INS entpickup = new T_WF_PL_INS();

                                entpickup.StageID = stageID;
                                entpickup.Status = status;
                                entpickup.Action = IActionTypes.Pickup;
                                IList<T_WF_PL_STEP> steps = WorkFlowDao.GetNextStageID(entpickup);

                                entpickup.AppID = ent.AppID;
                                entpickup.SoeID = ent.SoeID;
                                entpickup.StepID = steps[0].StepID;
                                entpickup.ProcDate = pickupTime;
                                entpickup.Remarks = ent.Remarks;
                                entpickup.PendingReason = string.Empty;
                                
                                WorkFlowDao.AddTrace(entpickup);
                                //
                                entpickup.Status = Constants.WFStatus.WO;
                                WorkFlowDao.UpdateInstance(entpickup);
                                status = Constants.WFStatus.WO;
                            }
                            if (ent.Action == IActionTypes.Pending)
                            {
                                ispengding = true;
                            }
                        }
                        if (!ispengding &&
                                (status != Constants.WFStatus.WO || ent.Action != IActionTypes.Pickup)
                                && (status != Constants.WFStatus.FR || procID == string.Empty || procID == null || ent.Action != IActionTypes.Pickup)
                                && (status != Constants.WFStatus.CO || procID == string.Empty || procID == null || ent.Action != IActionTypes.Pickup)
                                )
                        {
                            ent.Status = status;
                            ent.StageID = stageID;
                            IList<T_WF_PL_STEP> steps = WorkFlowDao.GetNextStageID(ent);
                            int nStageID = steps[0].NextStageID;
                            String nStatus = steps[0].NextStageStatus;
                            int StepID = steps[0].StepID;
                            ent.StepID = StepID;
                            if (nStageID < 999 || nStageID == 1000)
                            {
                                //
                                T_WF_PL_INS entpickup = new T_WF_PL_INS();
                                entpickup.AppID = ent.AppID;
                                entpickup.StageID = nStageID;
                                entpickup.Status = nStatus;
                                entpickup.ProcDate = DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat1);
                                entpickup.Remarks = ent.Remarks;

                                if (!string.IsNullOrEmpty(ent.SoeID) && nStatus != Constants.WFStatus.IN && nStatus != Constants.WFStatus.RT
                                    && nStatus != Constants.WFStatus.UL && (nStatus != Constants.WFStatus.FR || ent.Action != IActionTypes.ReturnToBM)
                                    && (nStatus != Constants.WFStatus.FR || ent.Action != IActionTypes.ReturnToPool)
                                    && (nStatus != Constants.WFStatus.FR || ent.Action != IActionTypes.Unlocked)
                                    && (nStatus != Constants.WFStatus.CO || ent.Action != IActionTypes.Complete)
                                    && (nStatus != Constants.WFStatus.CO || ent.Action != IActionTypes.ReturnToPool)
                                    && (nStatus != Constants.WFStatus.CO || ent.Action != IActionTypes.Unlocked))
                                {
                                    entpickup.SoeID = ent.SoeID;
                                }
                                else
                                {
                                    entpickup.SoeID = string.Empty;
                                }
                                WorkFlowDao.UpdateInstance(entpickup);
                                //daAddTraceInfo.updateappRemark(ent);
                            }
                            else if (nStageID == 999)
                            {
                                //
                                T_WF_PL_INS entpickup = new T_WF_PL_INS();
                                entpickup.AppID = ent.AppID;
                                entpickup.StageID = nStageID;
                                entpickup.Status = nStatus;
                                entpickup.ProcDate = DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat1);
                                entpickup.Remarks = ent.Remarks;

                                if (!string.IsNullOrEmpty(ent.SoeID) && nStatus != Constants.WFStatus.IN && nStatus != Constants.WFStatus.RT
                                    && nStatus != Constants.WFStatus.UL && (nStatus != Constants.WFStatus.FR || ent.Action != IActionTypes.ReturnToBM)
                                    && (nStatus != Constants.WFStatus.FR || ent.Action != IActionTypes.ReturnToPool)
                                    && (nStatus != Constants.WFStatus.FR || ent.Action != IActionTypes.Unlocked)
                                    && (nStatus != Constants.WFStatus.CO || ent.Action != IActionTypes.Complete)
                                    && (nStatus != Constants.WFStatus.CO || ent.Action != IActionTypes.ReturnToPool)
                                    && (nStatus != Constants.WFStatus.CO || ent.Action != IActionTypes.Unlocked))
                                {
                                    entpickup.SoeID = ent.SoeID;
                                }
                                else
                                {
                                    entpickup.SoeID = string.Empty;
                                }
                                WorkFlowDao.UpdateInstance(entpickup);
                                WorkFlowDao.SetInsToHis(ent.AppID);
                            }
                            //
                            WorkFlowDao.AddTrace(ent);
                        }
                    }
                }
                else
                {

                    T_WF_PL_INS entpickup = new T_WF_PL_INS();
                    entpickup.AppID = ent.AppID;
                    entpickup.SoeID = ent.SoeID;
                    entpickup.StepID = 1;
                    entpickup.ProcDate = DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat1);
                    entpickup.Action = IActionTypes.Pickup;

                    entpickup.Remarks = string.Empty;
                    entpickup.PendingReason = string.Empty;

                    WorkFlowDao.AddTrace(entpickup);

                    entpickup.StageID = 1;
                    entpickup.Status =Constants.WFStatus.WO;
                    entpickup.Remarks = ent.Remarks;
                    WorkFlowDao.AddInstance(ent);
                }
                //complete the transaction
                ts.Complete();
            }
        }
        #endregion

        #region Get all working instance
        /// <summary>
        /// Get all working instance
        /// </summary>
        /// <param name="start"></param>
        /// <param name="limit"></param>
        /// <param name="orgCode"></param>
        /// <param name="roleType"></param>
        /// <param name="soeID"></param>
        /// <param name="entity"></param>
        /// <returns></returns>
        public CommonTResult<T_WF_PL_INS> GetInstances(int start, int limit, string orgCode,
            int roleType, string soeID, T_WF_PL_INS entity)
        {
            CommonTResult<T_WF_PL_INS> resultDao = WorkFlowDao.GetInstances(start, limit, orgCode, roleType, soeID, entity);
            CommonTResult<T_WF_PL_INS> result = new CommonTResult<T_WF_PL_INS>()
            {
                ResultCount = resultDao.ResultCount,
                ResultList = resultDao.ResultList,
                IsSuccess = true,
                Message = ""
            };
            return result;
        }
        #endregion

        #region Get process history by application id
        /// <summary>
        /// Get process history by application id
        /// </summary>
        /// <param name="appId"></param>
        /// <param name="limit"></param>
        /// <param name="start"></param>
        /// <returns></returns>
        public CommonTResult<ProcessHistory> GetProcHistory(Guid appId, int limit, int start)
        {
            CommonTResult<ProcessHistory> resultDao = WorkFlowDao.GetProcHistory(appId, start, limit);
            CommonTResult<ProcessHistory> result = new CommonTResult<ProcessHistory>()
            {
                ResultCount = resultDao.ResultCount,
                ResultList = resultDao.ResultList,
                IsSuccess = true,
                Message = ""
            };
            return result;
        }
        #endregion

        public CommonTResult<IDQueryView> GetIDQueryList(int start, int limit, string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string Status, string starttime, string endtime)
        {
            CommonTResult<IDQueryView> result = null; 
            CommonTResult<IDQueryView> resultDao = WorkFlowDao.GetIDQueryList(start, limit, AppNo, BorrowType, IDNo, CustName, orgcode, Status, starttime, endtime);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<IDQueryView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;            
        }
        public void AddInstance(T_WF_PL_INS instance)
        {
            WorkFlowDao.AddInstance(instance);
        }

        public CommonTResult<T_Sys_Branch> GetBranchComapny()
        {
            return WorkFlowDao.GetBranchComapny();
        }

        public void AddTrace(T_WF_PL_INS entity)
        {
            WorkFlowDao.AddTrace(entity);
        }

        public Boolean CheckHistory(Guid appID)
        {
            IList<T_WF_PL_HIS> list = WorkFlowDao.HasHistory(appID);
            if (list.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public Boolean CheckInstance(Guid appID)
        {
            IList<T_WF_PL_INS> list = WorkFlowDao.HasInstance(appID);
            if (list.Count > 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public IList<T_WF_PL_INS> GetStageID(Guid appID)
        {
            return WorkFlowDao.GetStageID(appID);
        }
        public void UpdateInstance(T_WF_PL_INS entity)
        {
            WorkFlowDao.UpdateInstance(entity);
        }
        public void UpdateTrace(T_WF_PL_INS entity)
        {
            WorkFlowDao.AddTrace(entity);
        }

        public string GetIDStatus(string CustID,string IDNo)
        {
            return WorkFlowDao.GetIDStatus(CustID,IDNo);
        }

        public bool AddNewIDChangeLog(string NewIDNo, string NewExpireDate, string NewIssueDate,string NewIssuePlace, string CustID, string soeid)
        {
            return WorkFlowDao.AddNewIDChangeLog(NewIDNo, NewExpireDate, NewIssueDate,NewIssuePlace, CustID,soeid);
        }
        public CommonTResult<T_PL_AfterLoanChangeLogView> GetAfterLoanChangeLog(int start, int limit, string CustID)
        {
            CommonTResult<T_PL_AfterLoanChangeLogView> result = null;
            CommonTResult<T_PL_AfterLoanChangeLogView> resultDao = WorkFlowDao.GetAfterLoanChangeLog(start, limit, CustID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_AfterLoanChangeLogView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<IDQueryView> GetIDChangeLogAll(string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string Status, string starttime, string endtime)
        {
            CommonTResult<IDQueryView> result = null;
            CommonTResult<IDQueryView> resultDao = WorkFlowDao.GetIDChangeLogAll(AppNo, BorrowType, IDNo, CustName, orgcode, Status, starttime, endtime);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<IDQueryView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result; 
        }
        

        public CommonTResult<IDQueryView> GetIDQueryList(string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string Status, string starttime, string endtime)
        {
            CommonTResult<IDQueryView> result = null;
            CommonTResult<IDQueryView> resultDao = WorkFlowDao.GetIDQueryList(AppNo, BorrowType, IDNo, CustName, orgcode, Status, starttime, endtime);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<IDQueryView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;   
        }

        public CommonTResult<AfterLoanMaintainView> GetAfterLoanMaintainList(int start, int limit, string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string Status, string starttime, string endtime)
        {
            CommonTResult<AfterLoanMaintainView> result = null;
            CommonTResult<AfterLoanMaintainView> resultDao = WorkFlowDao.GetAfterLoanMaintainList(start,limit,AppNo, BorrowType, IDNo, CustName, orgcode, Status, starttime, endtime);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<AfterLoanMaintainView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;   
        }

        public CommonTResult<AfterLoanMaintainView> GetAfterLoanMaintainListAll(string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string starttime, string endtime)
        {
            CommonTResult<AfterLoanMaintainView> result = null;
            CommonTResult<AfterLoanMaintainView> resultDao = WorkFlowDao.GetAfterLoanMaintainListAll(AppNo, BorrowType, IDNo, CustName, orgcode, starttime, endtime);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<AfterLoanMaintainView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;   
        }

        public CommonTResult<AfterLoanMaintainView> GetAfterLoanMaintainListWithLog(string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string starttime, string endtime)
        {
            CommonTResult<AfterLoanMaintainView> result = null;
            CommonTResult<AfterLoanMaintainView> resultDao = WorkFlowDao.GetAfterLoanMaintainListWithLog(AppNo, BorrowType, IDNo, CustName, orgcode, starttime, endtime);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<AfterLoanMaintainView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;   
        }

        public bool AddNewAfterLoanChangeLog(string CommunicationAddressAs, string NewProvince, string NewCity, string NewDistrict, string NewStreet, string NewMobileNumber, string NewTelAreaCode, string NewTelNumber, string soeid,string custID)
        {
            return WorkFlowDao.AddNewAfterLoanChangeLog(CommunicationAddressAs, NewProvince, NewCity, NewDistrict, NewStreet, NewMobileNumber, NewTelAreaCode, NewTelNumber, soeid, custID);
        }

        public CommonTResult<ComboboxEntity> GetWFStages()
        {
            CommonTResult<ComboboxEntity> result = null;
            CommonTResult<ComboboxEntity> resultDao = WorkFlowDao.GetWFStages();
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<ComboboxEntity>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }



        public CommonTResult<T_PL_IDChangeLog> GetIDChangeLog(int start, int limit, string CustID, string IDNo)
        {
            CommonTResult<T_PL_IDChangeLog> result = null;
            CommonTResult<T_PL_IDChangeLog> resultDao = WorkFlowDao.GetIDChangeLog(start, limit, CustID, IDNo);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_IDChangeLog>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;  

        }

        public List<RejectReasonsView> GetRejectReasonsView()
        {
            List<RejectReasonsView> RejectReasonsViewList = new List<RejectReasonsView>();
            List<T_PL_PendRejectReason> childrenList = new List<T_PL_PendRejectReason>();
            var result = WorkFlowDao.GetRejectReasonsView();
            if (result != null) {
                foreach (var item in result.ResultList) {
                    if (item.ParentReasonCode == "")
                    {
                        RejectReasonsView RejectReasonsView = new Mvc.Models.RejectReasonsView();
                        
                        RejectReasonsView.id = item.ID.ToString();
                        RejectReasonsView.text =item.ReasonCode+" "+item.Description;
                        RejectReasonsView.leaf =false;
               //    　   RejectReasonsView.@checked = false;

                        childrenList = result.ResultList.Where(i => i.ParentReasonCode != "" && i.ParentReasonCode == item.ReasonCode).ToList();
                        if (childrenList.Count > 0) {
                            foreach (var child in childrenList) { 
                                RejectReasonsView ChildRejectReasonsView = new Mvc.Models.RejectReasonsView();
                                ChildRejectReasonsView.id = child.ID.ToString();
                                ChildRejectReasonsView.text =child.ReasonCode+" "+child.Description;
                                ChildRejectReasonsView.leaf = true;
                            　//　ChildRejectReasonsView.@checked = false;
                                RejectReasonsView.children.Add(ChildRejectReasonsView);
                            }
                        }
                        RejectReasonsViewList.Add(RejectReasonsView);
                    }
                }
            }
            return RejectReasonsViewList;
        }

        public CommonTResult<DataEntryView> QueryHistoryDataEntry(int start, int limit, DataEntryView entity)
        {
            CommonTResult<DataEntryView> result = null;
            CommonTResult<DataEntryView> resultDao = WorkFlowDao.QueryHistoryDataEntry(start, limit, entity);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<DataEntryView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<DataEntryView> QueryWaitDataEntry(int start, int limit, DataEntryView entity)
        {
            CommonTResult<DataEntryView> result = null;
            CommonTResult<DataEntryView> resultDao = WorkFlowDao.QueryWaitDataEntry(start, limit, entity);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<DataEntryView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public string GetWFStatusByAppID(string appId)
        {
            return WorkFlowDao.GetWFStatusByAppID(appId);
        }

        public string GetCurrentStepByAppId(string appId)
        {
            return WorkFlowDao.GetCurrentStepByAppId(appId);
        }

        public bool CheckStepIDByAppIDAndStepID(string appId, string stepId)
        {
            return WorkFlowDao.CheckStepIDByAppIDAndStepID(appId,stepId);
        }
    }
}
