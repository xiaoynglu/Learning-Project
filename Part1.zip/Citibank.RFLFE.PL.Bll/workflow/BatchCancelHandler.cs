﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Transactions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.workflow
{
    public class BatchCancelHandler : IBatchCancelHandler
    {
        public IBatchCancelDao BatchCancelDao { get; set; }
        public CommonTResult<BatchCancelView> GetBatchCancelList(int start, int limit, BatchCancelQueryView entity, string orgcode)
        {
            CommonTResult<BatchCancelView> result = null;
            CommonTResult<BatchCancelView> resultDao = BatchCancelDao.GetBatchCancelList(start, limit, entity, orgcode);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<BatchCancelView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
         public bool BatchCancel(string appid, string curtime, string soeid)
        {
            return BatchCancelDao.BatchCancel(appid,curtime,soeid);
        }

    }
}
