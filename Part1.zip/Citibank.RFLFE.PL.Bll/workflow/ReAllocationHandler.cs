﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Transactions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.workflow
{
    public class ReAllocationHandler : IReAllocationHandler
    {
        public IReAllocationDao ReAllocationDao { get; set; }

        public CommonTResult<ReAllocationView> GetReAllocationList(int start, int limit, ReAllocationQueryView entity)
        {
            CommonTResult<ReAllocationView> result = null;
            CommonTResult<ReAllocationView> resultDao = ReAllocationDao.GetReAllocationList(start, limit, entity);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<ReAllocationView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;   
            
        }

        public bool ReAllocationTemp(string appid, string reallocationtype, string newexecid, string soeid)
        { 
            return ReAllocationDao.ReAllocationTemp(appid,reallocationtype,newexecid,soeid);
        }
        public bool ReAllocationForever(string appid, string reallocationtype, string newexecid, string soeid)
        {
            return ReAllocationDao.ReAllocationForever(appid,reallocationtype,newexecid,soeid);
        }

        public CommonTResult<ComboboxEntity> GetAvaliableSales(string orgcode)
        {
            CommonTResult<ComboboxEntity> result = null;
            CommonTResult<ComboboxEntity> resultDao = ReAllocationDao.GetAvaliableSales(orgcode);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<ComboboxEntity>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result; 
        }
    }
}
