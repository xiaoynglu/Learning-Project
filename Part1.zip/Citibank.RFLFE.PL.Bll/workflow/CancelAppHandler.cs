﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Transactions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.workflow
{
    public class CancelAppHandler : ICancelAppHandler
    {
        public ICancelAppDao CancelAppDao { get; set; }
        public CommonTResult<CancelAppView> GetCancelAppContentList(int start, int limit, CancelAppQueryView entity)
        {
            CommonTResult<CancelAppView> result = null;
            CommonTResult<CancelAppView> resultDao = CancelAppDao.GetCancelAppContentList(start, limit, entity);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<CancelAppView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;   
        }
        public bool RetriveApp(string AppID, string soeid)
        {
            return CancelAppDao.RetriveApp(AppID, soeid);
        }
    }
}
