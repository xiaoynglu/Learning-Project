﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Transactions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.workflow
{
    public class UnlockHandler:IUnlockHandler
    {
        #region workflow dao
        public IUnlockDao UnlockDao { get; set; }
        #endregion

        public CommonTResult<UnlockView> GetUnlock(int start, int limit, UnlockQueryView entity, string orgcode)
        {
            CommonTResult<UnlockView> result = null;
            CommonTResult<UnlockView> resultDao = UnlockDao.GetUnlock(start, limit, entity, orgcode);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<UnlockView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public bool DoUnlock(string appid,string soeid)
        {
            return UnlockDao.DoUnlock(appid,soeid);
        }
    }
}
