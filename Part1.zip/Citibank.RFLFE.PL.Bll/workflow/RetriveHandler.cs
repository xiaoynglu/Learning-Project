﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Transactions;
using Citibank.RFLFE.PL.Mvc.Models;
namespace Citibank.RFLFE.PL.Bll.workflow
{
    public class RetriveHandler : IRetriveHandler
    {
        public IRetriveDao RetriveDao { get; set; }

        public CommonTResult<RetriveView> GetRetriveList(int start, int limit, RetriveQueryView entity,string SOEID)
        {
            CommonTResult<RetriveView> result = null;
            CommonTResult<RetriveView> resultDao = RetriveDao.GetRetriveList(start, limit, entity, SOEID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<RetriveView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;   
        }

        public bool RetrieveData(string AppID,string soeid)
        {
            return RetriveDao.RetrieveData(AppID,soeid);

        }
    }
}
