﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.approval
{
    public class TopupVerificationHandler : ITopupVerificationHandler
    {
        public ITopupVerificationDao TopupVerificationDao { get; set; }

        public CommonTResult<BorrowerVerificationDetail> GetBorrowerVerification(string appID, string custId)
        {
            return TopupVerificationDao.GetBorrowerVerification(appID, custId);
        }
       
        public CommonTResult<T_PL_PhoneVerification> GetPhoneVerification(int limit, int start, Guid CustID) {

            CommonTResult<T_PL_PhoneVerification> result = null;
            CommonTResult<T_PL_PhoneVerification> resultDao = TopupVerificationDao.GetPhoneVerification(limit, start, CustID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_PhoneVerification>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
        
        public CommonTResult<T_PL_SiteVerification> GetSiteVerification(int limit, int start, Guid CustID)
        {
            CommonTResult<T_PL_SiteVerification> result = null;
            CommonTResult<T_PL_SiteVerification> resultDao = TopupVerificationDao.GetSiteVerification(limit, start, CustID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_SiteVerification>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
       
        public CommonTResult<T_PL_HouseVerification> GetHouseVerification(int limit, int start, Guid CustID)
        {
            CommonTResult<T_PL_HouseVerification> result = null;
            CommonTResult<T_PL_HouseVerification> resultDao = TopupVerificationDao.GetHouseVerification(limit, start, CustID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_HouseVerification>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
       
        public CommonTResult<T_PL_ExternalVerification> GetExternalVerification(int limit, int start, Guid CustID)
        {
            CommonTResult<T_PL_ExternalVerification> result = null;
            CommonTResult<T_PL_ExternalVerification> resultDao = TopupVerificationDao.GetExternalVerification(limit, start, CustID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_ExternalVerification>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
       
        public CommonTResult<CreditPaymentDetail> GetCreditPaymentDetail(string AppID) {
            return TopupVerificationDao.GetCreditPaymentDetail(AppID);
        }

        public bool SaveCreditPaymentDetail(CreditPaymentDetail entity){
            return TopupVerificationDao.SaveCreditPaymentDetail(entity);
        }
       
        public int SavePhoneVerification(T_PL_PhoneVerification entity)
        {
            return TopupVerificationDao.SavePhoneVerification(entity);
        }
       
        public int SaveSiteVerification(T_PL_SiteVerification entity)
        {
            return TopupVerificationDao.SaveSiteVerification(entity);
        }
      
        public int SaveHouseVerification(T_PL_HouseVerification entity)
        {
            return TopupVerificationDao.SaveHouseVerification(entity);
        }
       
        public int SaveExternalVerification(T_PL_ExternalVerification entity)
        {
            return TopupVerificationDao.SaveExternalVerification(entity);
        }
      
        public bool SaveVerificationRecord(T_PL_VerificationRecord entity)
        {
            return TopupVerificationDao.SaveVerificationRecord(entity);
        }

        public int SaveWorkingVerification(T_PL_WorkingVerification entity)
        {
            return TopupVerificationDao.SaveWorkingVerification(entity);
        }
       
        public bool DeletePhoneVerification(int tid)
        {
            return TopupVerificationDao.DeletePhoneVerification(tid);
        }
       
        public bool DeleteSiteVerification(int tid)
        {
            return TopupVerificationDao.DeleteSiteVerification(tid);
        }
       
        public bool DeleteHouseVerification(int tid)
        {
            return TopupVerificationDao.DeleteHouseVerification(tid);
        }
       
        public bool DeleteExternalVerification(int tid)
        {
            return TopupVerificationDao.DeleteExternalVerification(tid);
        }

        public bool DeleteWorkingVerification(int tid)
        {
            return TopupVerificationDao.DeleteWorkingVerification(tid);
        }
      
        public CommonTResult<T_PL_TopupUploadMaker> GetTopupUploadLoan(string AppID)
        {
            return TopupVerificationDao.GetTopupUploadLoan(AppID);
        }
      
        public CommonTResult<T_PL_LoanApproval> GetLoanApproval(string AppID, int StageID)
        {
            return TopupVerificationDao.GetLoanApproval(AppID, StageID);
        }
        
        public string GetVerificationResult(string AppID, string CustID)
        {
            string result = "-1";
            CommonTResult<T_PL_VerificationRecord> resultDao = TopupVerificationDao.GetVerificationRecord(AppID, CustID);
            if (resultDao.ResultList.Count>0)
            {
                string phoneResult = resultDao.ResultList[0].PhoneResult;
                string siteResult = resultDao.ResultList[0].SiteResult;
                string houseResult = resultDao.ResultList[0].HouseResult;
                string externalResult = resultDao.ResultList[0].ExternalResult;

                return phoneResult == "2" && siteResult == "2" && houseResult == "2" && externalResult == "2" ? "1" : "0";
            }
            return result;
        }


        public CommonTResult<T_PL_WorkingVerification> GetWorkingVerification(int limit, int start, Guid CustID)
        {
            CommonTResult<T_PL_WorkingVerification> result = null;
            CommonTResult<T_PL_WorkingVerification> resultDao = TopupVerificationDao.GetWorkingVerification(limit, start, CustID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_WorkingVerification>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
    }
}
