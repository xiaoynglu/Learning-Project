﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using CommonUtility = Citibank.RFLFE.PL.Framework.CommonUtility;
using Citibank.RFLFE.PL.Bll.common;

namespace Citibank.RFLFE.PL.Bll.approval
{
    public class PreCheckHandler : IPreCheckHandler
    {
        public IPreCheckDao PreCheckDao { get; set; }

        public CommonTResult<GuarantorPhoneVerification> GetGuarantorPhoneVerification(string appId)
        {
            return PreCheckDao.GetGuarantorPhoneVerification(appId);
        }

        public CommonTResult<BorrowerCollateralDetail> GetBorrowerCollateralDetail(string appId)
        {
            CommonTResult<BorrowerCollateralDetail> result = new CommonTResult<BorrowerCollateralDetail>();
            var borrowerCollateralDetail = PreCheckDao.GetBorrowerCollateralDetail(appId);
            //判断T_PL_MortgageCognizance表是否有数据
            var moCheck = PreCheckDao.GetMoCheck(appId);
            var pbocCheck = new T_PL_MortgageCognizance();
            if (moCheck == null)
            {
                //step1:
                //1.1get moCount from T_PL_loan by appId
                //1.2 if moCount >0 set CustDeclare =moCount-1 and set ConfirmCustDeclare =moCount
                //step2:
                //2.1 get record from T_PL_MoHouseBureau by AppId and MBCustID
                //2.2 if exists, set HouseBureau = TotalPropertyValue and set ConfirmHouseBureau = TotalPropertyValue and set HouseBureauChecked =true 
                moCheck = PreCheckDao.InitMoCheck(appId);
                moCheck.AppID = new Guid(appId);
                pbocCheck = this.GetPBOCMoCount(appId);//获取征信未结清房贷数量和征信总房贷数量
                if (pbocCheck != null)
                {
                    moCheck.PBOC = pbocCheck.PBOC;
                    moCheck.ConfirmPBOC = moCheck.PBOC;
                    moCheck.ConfirmPBOC_Unliquidated = pbocCheck.PBOC_Unliquidated;
                    moCheck.PBOC_Unliquidated = pbocCheck.PBOC_Unliquidated;
                    moCheck.PBOCChecked = true;
                }
                else
                {
                    moCheck.PBOCChecked = false;
                }
                moCheck.TotalMoCount = Math.Max(moCheck.ConfirmPBOC, Math.Max(moCheck.ConfirmCustDeclare, moCheck.ConfirmHouseBureau));
                moCheck.ConfirmTotalMoCount = moCheck.TotalMoCount;
            }
            else
            {
                if (!moCheck.PBOCChecked)
                {
                    pbocCheck = GetPBOCMoCount(appId.ToString());//获取征信未结清房贷数量和征信总房贷数量

                    if (pbocCheck != null)
                    {
                        moCheck.PBOC = pbocCheck.PBOC;
                        moCheck.ConfirmPBOC = moCheck.PBOC;
                        moCheck.ConfirmPBOC_Unliquidated = pbocCheck.PBOC_Unliquidated;
                        moCheck.PBOC_Unliquidated = pbocCheck.PBOC_Unliquidated;
                        moCheck.PBOCChecked = true;
                    }
                    else
                    {
                        moCheck.PBOCChecked = false;
                    }
                }
            }

            #region 计算现政策认定房产套数
            if (moCheck.PBOC_Unliquidated >= 2)
            {
               moCheck.TotalMoCount= 2;
            }
            else if (moCheck.PBOC_Unliquidated == 1 && moCheck.PBOC_UnliquidatedMatch == 0 && moCheck.HouseBureau >= 1)
            {
                moCheck.TotalMoCount = 2;
            }
            else if (moCheck.PBOC_Unliquidated == 1 && moCheck.PBOC_UnliquidatedMatch == 0 && moCheck.HouseBureau == 0)
            {
                moCheck.TotalMoCount = 1;
            }
            else if (moCheck.PBOC_Unliquidated == 1 && moCheck.PBOC_UnliquidatedMatch == 1 && moCheck.HouseBureau >= 2)
            {
                moCheck.TotalMoCount =2;
            }
            else if (moCheck.PBOC_Unliquidated == 1 && moCheck.PBOC_UnliquidatedMatch == 1 && moCheck.HouseBureau == 1)
            {
                moCheck.TotalMoCount = 1;
            }
            else if (moCheck.PBOC_Unliquidated == 0 && moCheck.HouseBureau >= 2)
            {
                moCheck.TotalMoCount = 1;
            }
            else if (moCheck.PBOC_Unliquidated == 0 && moCheck.HouseBureau < 2)
            {
                moCheck.TotalMoCount = 0;
            }
            else
            {
                moCheck.TotalMoCount = 0;
            }

            moCheck.TotalMoCount = Math.Max(moCheck.TotalMoCount, moCheck.CustDeclare);
            moCheck.ConfirmTotalMoCount = moCheck.ConfirmTotalMoCount;

            #endregion

            #region 计算原政策认定房产套数
            if (moCheck.HouseBureau == 0)
            {
               moCheck.TotalMoCount_Orgin = Math.Max(moCheck.HouseBureau, moCheck.PBOC);
            }
            else if (moCheck.HouseBureau == 1 && moCheck.PBOC == 0)
            {
                moCheck.TotalMoCount_Orgin = 1;
            }
            else if (moCheck.HouseBureau == 1 && moCheck.PBOC == 1 && moCheck.PBOC_Unliquidated == 0 && moCheck.PBOC_SettlementMatch == 0)
            {
                moCheck.TotalMoCount_Orgin = 2;
            }
            else if (moCheck.HouseBureau == 1 && moCheck.PBOC == 1 && moCheck.PBOC_Unliquidated == 0 && moCheck.PBOC_SettlementMatch == 1)
            {
                moCheck.TotalMoCount_Orgin = 1;
            }
            else if (moCheck.HouseBureau == 1 && moCheck.PBOC == 1 && moCheck.PBOC_Unliquidated == 1 && moCheck.PBOC_UnliquidatedMatch == 0)
            {
                moCheck.TotalMoCount_Orgin = 2;
            }
            else if (moCheck.HouseBureau == 1 && moCheck.PBOC == 1 && moCheck.PBOC_Unliquidated == 1 && moCheck.PBOC_UnliquidatedMatch == 1)
            {
                moCheck.TotalMoCount_Orgin = 1;
            }
            else if (moCheck.HouseBureau >= 2)
            {
                moCheck.TotalMoCount_Orgin = 2;
            }
            else
            {
                moCheck.TotalMoCount_Orgin = 0;
            }

            moCheck.TotalMoCount_Orgin = Math.Max(moCheck.TotalMoCount_Orgin, moCheck.CustDeclare);

            #endregion

            if (borrowerCollateralDetail.ResultList.Count > 0)
            {
                result.ResultList = new List<BorrowerCollateralDetail>();
                var borrowerCollateralDetailItem = borrowerCollateralDetail.ResultList.FirstOrDefault();
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.CustDeclare = moCheck.CustDeclare;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.ConfirmCustDeclare = moCheck.ConfirmCustDeclare;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.HouseBureau = moCheck.HouseBureau;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.ConfirmHouseBureau = moCheck.ConfirmHouseBureau;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.HouseBureauChecked = moCheck.HouseBureauChecked;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.PBOC = moCheck.PBOC;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.ConfirmPBOC = moCheck.ConfirmPBOC;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.PBOCChecked = moCheck.PBOCChecked;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.TotalMoCount = moCheck.TotalMoCount;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.ConfirmTotalMoCount = moCheck.ConfirmTotalMoCount;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.PBOC_Unliquidated = moCheck.PBOC_Unliquidated;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.ConfirmPBOC_Unliquidated = moCheck.ConfirmPBOC_Unliquidated;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.PBOC_UnliquidatedMatch = moCheck.PBOC_UnliquidatedMatch;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.ConfirmPBOC_UnliquidatedMatch = moCheck.ConfirmPBOC_UnliquidatedMatch;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.PBOC_SettlementMatch = moCheck.PBOC_SettlementMatch;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.ConfirmPBOC_SettlementMatch = moCheck.ConfirmPBOC_SettlementMatch;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.TotalMoCount_Orgin = moCheck.TotalMoCount_Orgin;
                borrowerCollateralDetailItem.T_PL_MortgageCognizance.ConfirmTotalMoCount_Orgin = moCheck.ConfirmTotalMoCount_Orgin;
                result.ResultList.Add(borrowerCollateralDetailItem);
            }
            return result;
           // return PreCheckDao.GetBorrowerCollateralDetail(appId);
        }

        /// <summary>
        /// Step1:get Customers and FamilyMembers  by AppID(the relation is 1:n  )
        /// Step2:if exists 
        /// Step2.1:foreach the records
        /// Step2.1.1:get importDate from T_PL_BureauInfoTemp by appId and customer idno , if not exist return false ,else true 
        /// Step2.2.1:set the PBOCChecked =true
        /// Step2.3.1:get total pboc value
        /// Step2.3.1.1 Get moCount of borrower as A
        /// Step2.3.1.2 Get moCount of each family members' and do sum action , as B
        /// Step2.3.1.3  sum  borrower's moCoutn and total family member's moCount  as C = A + B, add C in a List as ListC
        /// Step2.4.1:get Unclare PBOC value
        /// Step2.4.1.1:Get unclear moCount of borrower as D
        /// Step2.4.1.2:Get unclear moCount of each family members' and do sum action , as E
        /// Step2.4.1.3:sum  borrower's unclear  moCoutn and total family member's unclear moCount  as F = D + E , and add F in a List as ListF
        /// Step3.1 get the Max value as G of ListC, and set moCheck.PBOC = G (获取征信总房贷数量)
        /// Step4.1 get the Max value as H of ListF,and set moCheck.ConfirmPBOC_Unliquidated  = H(获取征信未结清房贷数量)
        /// 梗概:
        /// 循环遍历根据AppId取出的主共贷人和家庭成员，主共贷人和家庭成员的关系是1:n,将，主共贷人和家庭成员的MoCount 相加然后将总合放进List，取出最大值,征信未结清房贷数量同理
        /// </summary>
        /// <param name="appId"></param>
        /// <returns></returns>
        private T_PL_MortgageCognizance GetPBOCMoCount(string appId) {

            var result = new Dictionary<T_PL_Customers, List<T_PL_FamilyMembers>>();
            var moCheck = new T_PL_MortgageCognizance();
            var familyCount = new List<int>();
            var unClearFamilyCount = new List<int>();
            string importDate = String.Empty;
            result = PreCheckDao.GetMoCustomers(appId);
            if (result != null && result.Count > 0) {
                foreach (KeyValuePair<T_PL_Customers, List<T_PL_FamilyMembers>> Pair in result) {
                    if (!TransferPBOCData(appId, Pair.Key.IDNo, ref importDate))
                    {
                        continue;
                    }
                    moCheck.PBOCChecked = true;
                    #region get total pboc value
                    int? BorrowerValue = CalMoCount(Pair.Key.IDNo, importDate);
                    List<int> SimpleResult = new List<int>();
                    foreach (T_PL_FamilyMembers item in Pair.Value)
                    {
                        //Family member mortgage count
                        int? SimpleValue = CalMoCount(item.IDNo, importDate);
                        //Add to member value list
                        if (SimpleValue != null && SimpleValue.HasValue)
                        {
                            SimpleResult.Add(SimpleValue.Value);
                        }
                    }

                    //Get max value of members mortgage count
                    int? MemberValue = AddMoCount(SimpleResult);
                    //Compare borrower and family members mortgage value
                    if (BorrowerValue.HasValue && MemberValue.HasValue)
                    {
                        int r = BorrowerValue.Value + MemberValue.Value;
                        familyCount.Add(r);
                    }
                    else if (!BorrowerValue.HasValue && MemberValue.HasValue)
                    {
                        familyCount.Add(MemberValue.Value);
                    }
                    else if (BorrowerValue.HasValue && !MemberValue.HasValue)
                    {
                        familyCount.Add(BorrowerValue.Value);
                    }
                    #endregion

                    #region Get Unclear PBOC value
                    //Ger borrower mortgage count
                    int? UnClearCount = CalMoUnClearCount(Pair.Key.IDNo, importDate);

                    List<int> SimpleUnClearResult = new List<int>();

                    foreach (T_PL_FamilyMembers Simple in Pair.Value)
                    {
                        //Family member mortgage count
                        int? SimpleValue = CalMoUnClearCount(Simple.IDNo, importDate);
                        //Add to member value list
                        if (SimpleValue != null && SimpleValue.HasValue)
                        {
                            SimpleUnClearResult.Add(SimpleValue.Value);
                        }
                    }

                    //Get max value of members mortgage count
                    int? UnClearMemberValue = AddMoCount(SimpleUnClearResult);
                    //Compare borrower and family members mortgage value
                    if (UnClearCount.HasValue && UnClearMemberValue.HasValue)
                    {
                        int r = UnClearCount.Value + UnClearMemberValue.Value;
                        unClearFamilyCount.Add(r);
                    }
                    else if (!UnClearCount.HasValue && UnClearMemberValue.HasValue)
                    {
                        unClearFamilyCount.Add(UnClearMemberValue.Value);
                    }
                    else if (UnClearCount.HasValue && !UnClearMemberValue.HasValue)
                    {
                        unClearFamilyCount.Add(UnClearCount.Value);
                    }
                    #endregion
                }
                //Get max value of family mortgage count
                int? familyResult = CalMaxMoCount(familyCount);

                //获取征信总房贷数量
                if (familyResult.HasValue)
                {
                    moCheck.PBOC = familyResult.Value;
                }

                //获取征信未结清房贷数量
                if (CalMaxMoCount(unClearFamilyCount).HasValue)
                {
                    moCheck.ConfirmPBOC_Unliquidated = CalMaxMoCount(unClearFamilyCount).Value;
                }

                return moCheck;
            }
            return null;
        }

        private int? CalMoCount(string idNo, string importDate) {
            var ds1 = PreCheckDao.GetPBOC_Loan(idNo, importDate);
            if (ds1 != null && ds1.Tables.Count > 0 && ds1.Tables[0] != null && ds1.Tables[0].Rows.Count > 0)
            {
                DataRow[] dr1 = ds1.Tables[0].Select("LOAN_TYPE = '个人住房贷款' OR LOAN_TYPE = '个人住房公积金贷款'");
                if (dr1 != null && dr1.Length > 0)
                {
                    int j = 0;
                    List<string> History = new List<string>();

                    while (j < dr1.Length)
                    {
                        string LoanStartDate = Convert.ToString(dr1[j]["LOAN_PROVIDE_DATE"]);

                        if (!History.Contains(LoanStartDate))
                        {
                            History.Add(LoanStartDate);
                        }

                        j++;
                    }
                    return History.Count;
                }
            }
            return null;
        }

        public int? CalMoUnClearCount(string IdNum, string ImportDate)
        {
          
            DataSet ds1;

            ds1 = PreCheckDao.GetPBOC_Loan(IdNum, ImportDate);
                   

            if (ds1 != null && ds1.Tables.Count > 0 && ds1.Tables[0] != null && ds1.Tables[0].Rows.Count > 0)
            {
                DataRow[] dr1 = ds1.Tables[0].Select("LOAN_TYPE = '个人住房贷款' OR LOAN_TYPE = '个人住房公积金贷款'");

                if (dr1 != null && dr1.Length > 0)
                {
                    int j = 0;
                    int f = 0;
                    List<string> History = new List<string>();

                    while (j < dr1.Length)
                    {
                        string LoanStartDate = Convert.ToString(dr1[j]["LOAN_PROVIDE_DATE"]);

                        if (!History.Contains(LoanStartDate))
                        {
                            History.Add(LoanStartDate);
                            if (dr1[j]["ACCOUNT_STATUS"] == "结清")
                                f++;
                        }

                        j++;
                    }
                    return History.Count - f;
                }
            }

            return null;
        }

        public int? AddMoCount(List<int> Collection)
        {
            if (Collection != null && Collection.Count > 0)
            {
                int max = 0;
                //Compare max value
                foreach (int v in Collection)
                {
                    max += v;
                }

                return max;
            }

            return null;
        }

        /// <summary>
        /// 多个成员贷款取最大
        /// </summary>
        /// <param name="Collection"></param>
        /// <returns></returns>
        public int? CalMaxMoCount(List<int> Collection)
        {
            if (Collection != null && Collection.Count > 0)
            {
                int max = 0;
                //Compare max value
                foreach (int v in Collection)
                {
                    max = (max < v) ? v : max;
                }

                return max;
            }

            return null;
        }

        private bool TransferPBOCData(string appId, string idNo, ref string importDate)
        { 
            //get PBOC Local
            DataSet ds = PreCheckDao.GetPBOCLocal(appId, idNo);
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0) { 
                importDate = Convert.ToString(ds.Tables[0].Rows[0]["Importdate"]);
                return true;
            }
            return false;
        }
        
        public int SaveBorrowerCollateralDetail(BorrowerCollateralDetail entity)
        {
            return PreCheckDao.SaveBorrowerCollateralDetail(entity);
        }
       
        public CommonTResult<T_PL_OralAppraisal> GetOralAppraisal(int limit, int start, Guid appID)
        {
            CommonTResult<T_PL_OralAppraisal> result = null;
            CommonTResult<T_PL_OralAppraisal> resultDao = PreCheckDao.GetOralAppraisal(limit, start, appID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_OralAppraisal>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
       
        public int SaveOralAppraisal(T_PL_OralAppraisal entity)
        {
            return PreCheckDao.SaveOralAppraisal(entity);
        }

        public int SaveOralAppraisalPrice(T_PL_OralAppraisal entity)
        {
            return PreCheckDao.SaveOralAppraisalPrice(entity);
        }

        public bool DeleteOralAppraisal(int tid)
        {
            return PreCheckDao.DeleteOralAppraisal(tid);
        }

        public bool SavePhoneVerificationRecord(T_PL_VerificationRecord entity)
        {
            return PreCheckDao.SavePhoneVerificationRecord(entity);
        }

        public T_PL_RunResult GetRunResultByAppId(string appId)
        {
            var result = PreCheckDao.GetRunResultByAppId(appId);           
            if (result.ResultList.Count > 0)
            {
                var data = new T_PL_RunResult();
                bool needCheck =true;
                var houseCheck = true;
                var dataSet =PreCheckDao.GetCustomersAndHouseBureauByAppID(appId);
                var customerList= new  DataTable();
                var bureauCust = new  DataTable();
                int customersCount =0;
                int verifiedCust = 0;
                data = result.ResultList.FirstOrDefault();
                if(dataSet.Tables[0]!=null){
                   customerList= dataSet.Tables[0];
                }
                if(dataSet.Tables.Count>0 && dataSet.Tables[1]!=null){
                  bureauCust= dataSet.Tables[1];
                }
                if(result.ResultList.FirstOrDefault().HouseBureauCheck!=null&&result.ResultList.FirstOrDefault().HouseBureauCheck !="" ){
                   needCheck = Boolean.Parse(result.ResultList.FirstOrDefault().HouseBureauCheck) ;
                }
                if(!needCheck){
                    houseCheck = true;
                }
                if(customerList==null || customerList.Rows.Count<1||bureauCust==null || bureauCust.Rows.Count<1){
                    houseCheck = false;
                }
                if(customerList.Rows.Count!=bureauCust.Rows.Count){
                   houseCheck = false;
                }
                customersCount = customerList.Rows.Count;
                foreach(DataRow dr in customerList.Rows){
                    if (bureauCust.Select(String.Format("CustId = '{0}'", dr["CustID"])).Length > 0)
                    {
                        verifiedCust++;
                    }
                }
                if(customersCount!=verifiedCust){
                  houseCheck = false;
                }
                if(result.ResultList.FirstOrDefault().ProdID ==Constants.ProdID.MO_ID.ToString()){
                    if (result.ResultList.FirstOrDefault().HouseBureauCheck==Constants.BooleanValue_Format3.False){
                        result.ResultList.FirstOrDefault().HouseBureauCheck = Constants.Pass_Name;
                    }
                    else{
                        result.ResultList.FirstOrDefault().HouseBureauCheck = Constants.Unfinished_Name;
                    }
                    if(houseCheck&&!needCheck){
                      result.ResultList.FirstOrDefault().HouseBureauCheck =Constants.CheckFree;
                    }
                }
                #region convert value to chinese
                data.PBoC = CommonUtility.ChangeCNName(data.PBoC);
                data.ALS = CommonUtility.ChangeCNName(data.ALS);
                data.NgtvFile = CommonUtility.ChangeCNName(data.NgtvFile);
                data.DupCheck = CommonUtility.ChangeCNName(data.DupCheck);
                data.RltdPt = CommonUtility.ChangeCNName(data.RltdPt);
                data.Velocity = CommonUtility.ChangeCNName(data.Velocity);
                data.Verf = CommonUtility.ChangeCNName(data.Verf);
                data.RacStatus = CommonUtility.ChangeCNName(data.RacStatus);
                data.Devationed = CommonUtility.ChangeCNName(data.Devationed);
                data.ItnFraud = CommonUtility.ChangeCNName(data.ItnFraud);
                data.RateException = CommonUtility.ChangeCNName(data.RateException);
                #endregion
                return data;
            }
            return null;
        }

        public CommonTResult<T_PL_CRDup> GetCRDupByAppId(string appId)
        {
            return PreCheckDao.GetCRDupByAppId(appId);
        }

        public bool SavePreCheckLTVDetail(T_PL_Collateral Entity)
        {
            return PreCheckDao.SavePreCheckLTVDetail(Entity);
        }

        public CommonTResult<T_PL_Customers> GetHouseBureauObjectsListByAppId(string appId)
        {
            return PreCheckDao.GetHouseBureauObjectsListByAppId(appId);
        }

        public CommonTResult<T_PL_MoHouseBureau> GetHouseBureauListByAppId(string appId)
        {
            return PreCheckDao.GetHouseBureauListByAppId(appId);
        }

        public T_PL_Collateral GetHouseBurueauInfoByAppId(string appId)
        {
            return PreCheckDao.GetHouseBurueauInfoByAppId(appId);
        }

        public bool SaveHouseBureauObject(T_PL_MoHouseBureau Entity)
        {
            return PreCheckDao.SaveHouseBureauObject(Entity);
        }

        public bool DeleteHouseBureauObject(string tid)
        {
            return PreCheckDao.DeleteHouseBureauObject(tid);
        }

        public bool SaveHouseBureau(string appId, string needCheckHouseBureau, string houseBureauRemarks)
        {
            return PreCheckDao.SaveHouseBureau(appId, needCheckHouseBureau, houseBureauRemarks);
        }

        public CommonTResult<T_PL_CRPersonVel> GetFraudVelocity(string appId)
        {
            return PreCheckDao.GetFraudVelocity(appId);
        }

        public CommonTResult<T_PL_CRVel> GetVelocityCheck(string personId)
        {
            return PreCheckDao.GetVelocityCheck(personId);
        }

        public String GetLastRACbyApp(string appId)
        {
            return PreCheckDao.GetLastRACbyApp(appId);
        }

        public List<string> ShowVerifiedDetailsItems(string custId)
        {
            return PreCheckDao.ShowVerifiedDetailsItems(custId);
        }

        public CommonTResult<T_PL_PhoneVerification> GetAllPhoneVerificationByAppID(string appId)
        {
            return PreCheckDao.GetAllPhoneVerificationByAppID(appId);
        }

        public CommonTResult<T_PL_SiteVerification> GetAllSiteVerificationByAppID(string appId)
        {
            return PreCheckDao.GetAllSiteVerificationByAppID(appId);
        }

        public CommonTResult<T_PL_HouseVerification> GetAllHouseVerificationByAppID(string appId)
        {
            return PreCheckDao.GetAllHouseVerificationByAppID(appId);
        }

        public CommonTResult<T_PL_ExternalVerification> GetAllExternalVerificationByAppID(string appId)
        {
            return PreCheckDao.GetAllExternalVerificationByAppID(appId);
        }

        public CommonTResult<Mvc.Models.CompareBureauInfoCustInfoView> GetCompareBureauInfoCustInfoByAppID(string appId)
        {
            return PreCheckDao.GetCompareBureauInfoCustInfoByAppID(appId);
        }

        public CommonTResult<T_PL_VerificationRecord> GetVerificationDetailsListByAppID(string appId)
        {
            return PreCheckDao.GetVerificationDetailsListByAppID(appId);
        }


        public CommonTResult<T_PL_WorkingVerification> GetAllWorkingVerificationByAppID(string appId)
        {
            return PreCheckDao.GetAllWorkingVerificationByAppID(appId);
        }


        public bool SaveMortgageCognizance(T_PL_MortgageCognizance entity)
        {
            return PreCheckDao.SaveMortgageCognizance(entity);
        }
    }
}
