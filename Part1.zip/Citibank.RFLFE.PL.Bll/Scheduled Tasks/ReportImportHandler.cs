﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using System.IO;
using System.Data.SqlClient;
using Citibank.RFLFE.PL.IBll;
using log4net;

namespace Citibank.RFLFE.PL.Bll
{
    public class ReportImportHandler : IReportImportHandler
    {
        public IReportGenOrImportDao ReportGenOrImportDao { get; set; }
        public CommonTResult<T_PL_FileDefination> result = null;
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        
        public bool CheckIsImportToday(string JobName)
        {
            return ReportGenOrImportDao.CheckIsImportToday(JobName);
        }

        public Dictionary<DataTable, string> ReadSourceToDt(IList<T_PL_FileDefination> fileDefine, IList<T_Sys_PathConfiguration> PathConfig)
        {
            Dictionary<DataTable, string> result = new Dictionary<DataTable, string>();

            foreach (T_Sys_PathConfiguration config in PathConfig)
            {
                DataTable dt = new DataTable();
                string tableName = config.DataFromOrIntoTable.ToString();
                string fileName = string.Empty;
                string sourceFile = string.Empty;
                string destFile = string.Empty;
                if (config.Description == "PBOC Upload File")
                {
                    List<FileInfo> filesInfo = CommonHelper.GetFileName(config).ToList();
                    CommonHelper.BackupFile(config, DateTime.Now, filesInfo);
                    foreach (FileInfo file in filesInfo)
                    {
                        fileName = file.FullName.ToString();
                        if (config.FileNameKeyword == "CNRF*cards" && file.Name.Contains("cards"))
                        {
                            dt = CommonHelper.ConvertIListToDataTable<T_PL_PBOC_CreditCardDetail>(ReportGenOrImportDao.ReadSourceToDt<T_PL_PBOC_CreditCardDetail>(file));
                        }
                        if (config.FileNameKeyword == "CNRF*employ" && file.Name.Contains("employ"))
                        {
                            dt = CommonHelper.ConvertIListToDataTable<T_PL_PBOC_CareerInf>(ReportGenOrImportDao.ReadSourceToDt<T_PL_PBOC_CareerInf>(file));
                        }
                        if (config.FileNameKeyword == "CNRF*enquiry" && file.Name.Contains("enquiry"))
                        {
                            dt = CommonHelper.ConvertIListToDataTable<T_PL_PBOC_QueryHistory>(ReportGenOrImportDao.ReadSourceToDt<T_PL_PBOC_QueryHistory>(file));
                        }
                        if (config.FileNameKeyword == "CNRF*HouseFund" && file.Name.Contains("HouseFund"))
                        {
                            dt = CommonHelper.ConvertIListToDataTable<T_PL_PBOC_IndividualHouseFund>(ReportGenOrImportDao.ReadSourceToDt<T_PL_PBOC_IndividualHouseFund>(file));
                        }
                        if (config.FileNameKeyword == "CNRF*Insurance" && file.Name.Contains("Insurance"))
                        {
                            dt = CommonHelper.ConvertIListToDataTable<T_PL_PBOC_IndividualOldInsurance>(ReportGenOrImportDao.ReadSourceToDt<T_PL_PBOC_IndividualOldInsurance>(file));
                        }
                        if (config.FileNameKeyword == "CNRF*loan" && file.Name.Contains("loan"))
                        {
                            dt = CommonHelper.ConvertIListToDataTable<T_PL_PBOC_LoanDetail>(ReportGenOrImportDao.ReadSourceToDt<T_PL_PBOC_LoanDetail>(file));
                        }
                        if (config.FileNameKeyword == "CNRF*personal" && file.Name.Contains("personal"))
                        {
                            dt = CommonHelper.ConvertIListToDataTable<T_PL_PBOC_PersonalInfo>(ReportGenOrImportDao.ReadSourceToDt<T_PL_PBOC_PersonalInfo>(file));
                        }
                        if (config.FileNameKeyword == "CNRF*res" && file.Name.Contains("res"))
                        {
                            dt = CommonHelper.ConvertIListToDataTable<T_PL_PBOC_ResideAddress>(ReportGenOrImportDao.ReadSourceToDt<T_PL_PBOC_ResideAddress>(file));
                        }
                        if (config.FileNameKeyword == "CNRF_bresult" && file.Name.Contains("bresult"))
                        {
                            dt = CommonHelper.ConvertIListToDataTable<T_PL_PBOC_TotalInfo>(ReportGenOrImportDao.ReadSourceToDt<T_PL_PBOC_TotalInfo>(file));
                        }
                        if (config.FileNameKeyword == "htm" && file.Name.Contains("htm"))
                        {
                            //htm文件处理方法：直接拷贝，不需要导入到数据库
                            if (!Directory.Exists(config.DataFromOrIntoTable))
                            {
                                Directory.CreateDirectory(config.DataFromOrIntoTable);
                            }
                            string destFileName = CommonHelper.GetPath(config.DataFromOrIntoTable) + file.Name.ToString();
                            File.Copy(fileName, destFileName, true);
                            //拷贝完成则删除source文件夹文件
                            File.Delete(fileName);
                        }
                    }
                }
                else
                {
                    if (config.Description == "Advice" || config.Description == "Annual")
                    {
                        sourceFile = config.ImpOrGenerateFilePath + config.FileNameKeyword + config.FileFormat;
                        destFile = config.BackUpFilePath + config.FileNameKeyword + DateTime.Now.ToString("yyyyMMdd") + config.FileFormat;

                        if (File.Exists(sourceFile)) 
                        {
                            File.Copy(sourceFile, destFile, true);
                        }
                        FileInfo fileInfo = new FileInfo(destFile);
                        if (!ReportGenOrImportDao.CheckIsImportFileByWriteDate(config.FileNameKeyword, new FileInfo(destFile).LastWriteTime))
                        {
                            dt = ReportGenOrImportDao.ReadSourceToDt(fileDefine.Where(P => P.ReportType == config.Type.ToString()).ToList(), destFile);
                        }
                        else
                        {
                            log.Info(string.Format("{0} file was already imported!", config.FileNameKeyword));
                        }
                    }
                    else
                    {
                        destFile = config.ImpOrGenerateFilePath + config.FileNameKeyword + config.FileFormat;
                        dt = ReportGenOrImportDao.ReadSourceToDt(fileDefine.Where(P => P.ReportType == config.Type.ToString()).ToList(), destFile);
                    }
                    fileName = destFile;                                       
                }
                dt.TableName = tableName;
                if (dt.Rows.Count > 0)
                {
                    result.Add(dt, fileName);
                }
            }
            return result;
        }

        public void ImportGRBToDB(IList<T_PL_FileDefination> fileDefine, IList<T_Sys_PathConfiguration> PathConfig)
        {
            foreach (T_Sys_PathConfiguration config in PathConfig)
            {
                string sourceFile = CommonHelper.GetPath(config.ImpOrGenerateFilePath) + config.FileNameKeyword + config.FileFormat;
                FileInfo fileInfo = new FileInfo(sourceFile);
                bool isImportFile = ReportGenOrImportDao.CheckIsImportFileByWriteDate(fileInfo.Name.ToString(), fileInfo.LastWriteTime);
                T_PL_BatchJobLog logs = new T_PL_BatchJobLog();
                logs.JobName = "RM";
                logs.RunMachine = System.Environment.MachineName;
                if (!isImportFile)
                {
                    string destFile = CommonHelper.GetPath(config.BackUpFilePath) + config.FileNameKeyword + config.FileFormat;
                    //copy file from share folder to local path
                    if (!Directory.Exists(CommonHelper.GetPath(config.BackUpFilePath)))
                    {
                        Directory.CreateDirectory(CommonHelper.GetPath(config.BackUpFilePath));
                    }
                    File.Copy(sourceFile, destFile, true);
                    CommonResult result = ReportGenOrImportDao.ReadSourceToGRB(fileDefine.Where(P => P.ReportType == "RM").ToList(), destFile);

                    logs.FileWriteDate = new FileInfo(destFile).LastWriteTime;
                    logs.FileName = new FileInfo(destFile).Name.ToString();                    
                    logs.RunStatus = result.IsSuccess ? 1 : 0;
                    logs.Remark = result.Message;
                    File.Delete(destFile);
                }
                else
                {
                    logs.RunStatus = 0;
                    logs.Remark = "Today's GRB file was already imported in database!";
                    log.Info("Today's GRB file was already imported in database!");
                }
                InsertImportGenerateLog(logs);
            }
        }

        public CommonResult BulkCopySourceToTable(string JobName, DataTable dt, string fileName)
        {
            return ReportGenOrImportDao.BulkCopySourceToTable(JobName, dt, fileName);
        }

        public bool InsertImportGenerateLog(T_PL_BatchJobLog logs)
        {
            return ReportGenOrImportDao.InsertImportGenerateLog(logs);
        }

    }
}
