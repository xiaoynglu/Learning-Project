﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Diagnostics;
using CitiAES;
using System.IO;
using log4net;
using System.Data;
using System.Reflection;

namespace Citibank.RFLFE.PL.Bll
{
    public class CommonHelper
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public static string GetPath(string path)
        {
            if (path.LastIndexOf("\\\\") == path.Length - 2)
            {
                path = path.Substring(0, path.Length - 2) + '\\';
            }
            else if (path.LastIndexOf('\\') != path.Length - 1)
            {
                path = path + '\\';
            }
            return path;
        }

        public static string GetFileName(string ReportType)
        {
            string FileName = String.Empty;

            switch (ReportType)
            {
                case "DWHCustInfo":
                    FileName = "CITICREDIT_CUSTOMERINFO.TXT";
                    break;
                case "DWHAppInfo":
                    FileName = "CITICREDIT_APPLICATIONINFO.TXT";
                    break;
                case "DWHMortInfo":
                    FileName = "CITICREDIT_MORTGAGORINFO.TXT";
                    break;
                case "DWHAppHis":
                    FileName = "CITICREDIT_APPLICATIONHISTORY.TXT";
                    break;
                case "RiskData":
                    FileName = "CNRF_Risk_Data.TXT";
                    break;
                case "CNRFALS":
                    FileName="PBOCCNRF.TXT";
                    break;
            }

            return FileName;
        }

        public static List<FileInfo> GetFileName(T_Sys_PathConfiguration Path)
        {
            var fileInfos = new FileInfo[] { };
            List<FileInfo> returnFileInfos = new List<FileInfo>();
            try
            {
                if (Directory.Exists(Path.ImpOrGenerateFilePath))
                {
                    DirectoryInfo dirInfo = new DirectoryInfo(Path.ImpOrGenerateFilePath);
                    if (Path.FileFormat == ".txt")
                    {
                        if (!Path.DataFromOrIntoTable.Equals("T_PL_PBOC_TotalInfo"))
                        {
                            fileInfos = dirInfo.GetFiles(string.Format(@"*{0}.txt", Path.FileNameKeyword), SearchOption.AllDirectories);
                        }
                        else
                        {
                            fileInfos = dirInfo.GetFiles(string.Format(@"{0}*.txt", Path.FileNameKeyword), SearchOption.AllDirectories);
                        }
                    }
                    else if (Path.FileFormat == ".htm")
                    {
                        fileInfos = dirInfo.GetFiles("*.htm");
                    }
                    foreach (FileInfo fileInfo in fileInfos)
                    {
                        string FileName = fileInfo.FullName + ".ok";
                        if (File.Exists(FileName))
                        {
                            returnFileInfos.Add(fileInfo);
                        }
                        else
                        {
                            log.Info(string.Format("{0} - No ok file exists!", fileInfo.FullName));
                        }
                    }
                }
                else
                {
                    log.Info(string.Format("{0} - Source path does not exists!", Path.ImpOrGenerateFilePath));
                }
                if (fileInfos.Count() == 0)
                {
                    log.Info(string.Format("{0} - No source file in the source path!", Path.ImpOrGenerateFilePath));
                }
            }
            catch (Exception ex)
            {
                log.Info(string.Format("Exception occur when get file from source path {0} - {1}!", Path.ImpOrGenerateFilePath, ex.Message));
            }
            return returnFileInfos;
        }

        public static void BackupFile(T_Sys_PathConfiguration Path, DateTime date, List<FileInfo> Files)
        {
            foreach (var v in Files)
            {
                string strSourcePath = v.FullName;
                string strBackupPath = Path.BackUpFilePath;
                string strErrorBackUpFile = GetPath(strBackupPath) + v.Name + Path.Type + Path.FileFormat;
                string okFileSource = v.FullName + ".ok";
                string okFileBackup = strErrorBackUpFile + ".ok";
                if (!Directory.Exists(strBackupPath))
                {
                    Directory.CreateDirectory(strBackupPath);
                }
                File.Copy(strSourcePath, strErrorBackUpFile, true);
                if (File.Exists(okFileSource))//如果存在ok文件，则同样将ok文件备份
                {
                    File.Copy(okFileSource, okFileBackup, true);
                }
            }
        }

        public static DataTable ConvertIListToDataTable<T>(IList<T> Source)
        {
            DataTable dt = new DataTable(typeof(T).Name);
            PropertyInfo[] properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo pi in properties)
            {
                if (pi.PropertyType.IsGenericType)
                {
                    dt.Columns.Add(pi.Name, pi.PropertyType.GetGenericArguments()[0]);
                }
                else
                {
                    dt.Columns.Add(pi.Name);
                }
            }

            foreach (T item in Source)
            {
                var values = new object[properties.Length];

                for (int i = 0; i < properties.Length; i++)
                {
                    values[i] = properties[i].GetValue(item, null);
                }
                dt.Rows.Add(values);
            }
            return dt;
        }

        #region Write Methods
        /// <summary>
        /// Type: Header or Trailer, different return value base on type
        /// </summary>
        /// <param name="FileDefination"></param>
        /// <param name="WriteText"></param>
        /// <param name="Type"></param>
        /// <returns></returns>
        public static string WriteHeaderTrailerText(IList<T_PL_FileDefination> FileDefination, string WriteText, string Type)
        {
            string Value = String.Empty;
            int Length = 0;
            int RecordType = (Type == "Header") ? 0 : 2;

            foreach (var dr in FileDefination.Where(P => P.RecordType == RecordType).Where(P => P.ColumnName == "FILLER").Select(P => P.Length))
            {
                Length = Convert.ToInt32(dr);
                break;
            }
            string DatetimeNow = DateTime.Now.ToString("yyyyMMdd");
            if (Type == "Header")
            {
                Value = String.Format("{0}{1}{2}\r\n", WriteText, DatetimeNow, CommonHelper.GetEmpty(Length));
            }
            else if (Type == "Trailer")
            {
                Value = String.Format("{0}{1}{2}", WriteText, CommonHelper.SupplementLength(Convert.ToString(FileDefination.Count), 8, '0', AlignEnum.Right), CommonHelper.GetEmpty(Length));
            }
            return Value;
        }

        public static void WriteDetailText(IList<T_PL_FileDefination> FileDefination, DataTable Source, FileStream Write, bool Flag)
        {
            int Length = 0;

            StringBuilder Value = new StringBuilder();

            foreach (DataRow dr in Source.Rows)
            {
                foreach (var list in FileDefination.Where(P => P.RecordType == 1))
                {
                    string ColumnName = Convert.ToString(list.ColumnName);

                    if (Source.Columns.Contains(ColumnName))
                    {
                        Length = Convert.ToInt32(list.Length);

                        string DataType = Convert.ToString(list.DataType);

                        if (DataType.Equals("decimal", StringComparison.CurrentCultureIgnoreCase))
                        {
                            int Number = Convert.ToInt32(Convert.ToString(list.Format).Split(',')[0]);
                            int Digit = Convert.ToInt32(Convert.ToString(list.Format).Split(',')[1]);
                            string DecimalValue = CommonHelper.CheckDecimal(Convert.ToString(dr[ColumnName]), Number, Digit);
                            Value.Append(CommonHelper.SupplementLength(Encoding.GetEncoding("GB2312"), DecimalValue, Length));
                        }
                        else
                        {
                            string Body = String.Empty;

                            if (ColumnName.Contains("REMARK1"))
                            {
                                Body = Convert.ToString(dr[ColumnName]).Replace("\r\n", "");
                            }
                            else
                            {
                                Body = Convert.ToString(dr[ColumnName]);

                                if (Flag)
                                {
                                    if (ColumnName.Contains("BirthDate") || ColumnName.Contains("ID_Date"))
                                    {
                                        string[] Birth = Body.Split('-');
                                        if (Birth.Length > 1)
                                        {
                                            Body = String.Format("{0}-{1}-{2}", Birth[0], Birth[1].PadLeft(2, '0'), Birth[2].PadLeft(2, '0'));
                                        }
                                    }
                                }
                            }
                            Value.Append(CommonHelper.SupplementLength(Encoding.GetEncoding("GB2312"), Body, Length));
                        }
                    }
                    else
                    {
                        Length = Convert.ToInt32(list.Length);
                        Value.Append(CommonHelper.GetEmpty(Length));
                    }
                }
                Value.Append("\r\n");
                byte[] bvalue = Encoding.GetEncoding("GB2312").GetBytes(Value.ToString());

                Write.Write(bvalue, 0, bvalue.Length);
                Value = new StringBuilder();
            }
        }
        #endregion

        /// <summary>
        /// Get empty string
        /// </summary>
        /// <param name="Length">string length</param>
        /// <returns>string value</returns>
        internal static string GetEmpty(int Length)
        {
            if (Length <= 0)
            {
                return String.Empty;
            }
            else
            {
                return SupplementLength(String.Empty, Length);
            }
        }

        internal static int GetByteCount(char[] Source)
        {
            return GetByteCount(Encoding.GetEncoding("GB2312"), Source);
        }

        internal static int GetByteCount(Encoding Encoding, char[] Source)
        {
            if (Source == null || Source.Length <= 0)
            {
                return 0;
            }
            return Encoding.GetByteCount(Source);
        }

        internal static int GetByteCount(string Source)
        {
            return GetByteCount(Encoding.GetEncoding("GB2312"), Source);
        }

        internal static int GetByteCount(Encoding Encoding, string Source)
        {
            if (String.IsNullOrEmpty(Source))
            {
                return 0;
            }
            return Encoding.GetByteCount(Source);
        }

        internal static string SupplementLength(string Source, int MaxLength)
        {
            return SupplementLength(Encoding.GetEncoding("GB2312"), Source, MaxLength, ' ', AlignEnum.Left);
        }

        internal static string SupplementLength(string Source, int MaxLength, char SplitSymbol)
        {
            return SupplementLength(Encoding.GetEncoding("GB2312"), Source, MaxLength, SplitSymbol, AlignEnum.Left);
        }

        internal static string SupplementLength(string Source, int MaxLength, char SplitSymbol, AlignEnum AlignMode)
        {
            return SupplementLength(Encoding.GetEncoding("GB2312"), Source, MaxLength, SplitSymbol, AlignMode);
        }

        internal static string SupplementLength(Encoding Encoding, string Source, int MaxLength)
        {
            return SupplementLength(Encoding, Source, MaxLength, ' ', AlignEnum.Left);
        }

        internal static string SupplementLength(string Source, int MaxLength, AlignEnum AlignMode)
        {
            return SupplementLength(Encoding.GetEncoding("GB2312"), Source, MaxLength, ' ', AlignMode);
        }

        /// <summary>
        /// Supplement string value
        /// </summary>
        /// <param name="Encoding">Encoding value</param>
        /// <param name="Source">Original string value</param>
        /// <param name="MaxLength">Accept max byte length</param>
        /// <param name="AlignMode">Align mode</param> 
        /// <returns>Generated string value</returns>
        internal static string SupplementLength(Encoding Encoding, string Source, int MaxLength, char SplitSymbol, AlignEnum AlignMode)
        {
            int Length = GetByteCount(Encoding, Source);

            if (Length > MaxLength)
            {
                Source = SubString(Source, MaxLength, Encoding);
            }
            else
            {
                StringBuilder SB = new StringBuilder(Source);

                while (Length < MaxLength)
                {
                    if (AlignMode == AlignEnum.Left)
                    {
                        SB.Append(SplitSymbol);
                    }
                    if (AlignMode == AlignEnum.Right)
                    {
                        SB.Insert(0, SplitSymbol);
                    }
                    Length = GetByteCount(Encoding, SB.ToString());
                }

                Source = SB.ToString();
            }

            return Source;
        }

        /// <summary>
        /// Check Chinese characters
        /// </summary>
        /// <param name="Value">Value</param>
        /// <returns>True or Flase</returns>
        private static bool IsChinese(char Value)
        {
            if (String.IsNullOrEmpty(Value.ToString().Trim()))
            {
                return false;
            }
            return GetByteCount(Encoding.GetEncoding("GB2312"), new char[] { Value }) == 2;
        }

        /// <summary>
        /// Substring by byte length
        /// </summary>
        /// <param name="Source">source string</param>
        /// <param name="MaxLength">max length</param>
        /// <param name="Encoding">encoding</param>
        /// <returns>string</returns>
        private static string SubString(string Source, int MaxLength, Encoding Encoding)
        {
            if (MaxLength <= 0 || String.IsNullOrEmpty(Source))
            {
                return String.Empty;
            }
            if (Encoding == null)
            {
                Encoding = Encoding.GetEncoding("GB2312");
            }

            int Count = 0; //截取长度,串内下标

            int StringLength = Source.Length; //字符串长度

            int ByteCount = GetByteCount(Encoding, Source); //字节长度

            if (ByteCount > MaxLength) //如果字节长度大于最大长度
            {
                if (StringLength <= MaxLength) //字符串长度小于最大长度
                {
                    foreach (char c in Source.ToCharArray())
                    {
                        if (IsChinese(c)) //判断中文字符
                        {
                            MaxLength -= 2; //中文每个占2位

                            if (MaxLength >= 0)
                            {
                                Count++; //截取长度+1
                            }
                            else
                            {
                                break;
                            }
                        }
                        else //如果当前不是中文字符
                        {
                            MaxLength--;
                            Count++;
                        }
                    }
                    if (Count == 0) //如果字符串没有中文字符
                    {
                        Count = MaxLength;
                    }
                    return Source.Substring(0, Count);
                }
                else //传递的字符串长度过长
                {
                    Source = Source.Substring(0, MaxLength);//先截取长度

                    return SubString(Source, MaxLength, Encoding); //递归调用
                }
            }
            else //如果传递字符串长度适中
            {
                return Source;
            }
        }

        internal static string CheckDecimal(string value, int Number, int Digits)
        {
            decimal temp = 0m;

            if (!Decimal.TryParse(value, out temp))
            {
                return String.Empty;
            }
            else
            {
                if (value.Split('.')[0].Length > Number)
                {
                    return String.Empty;
                }
                else
                {
                    if (value.Split('.').Length > 1 && value.Split('.')[1].Length > Digits)
                    {
                        string format = "{0:F" + Digits + "}";
                        value = String.Format(format, temp);
                    }
                }
            }

            return value;
        }
    }
}
