﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.Bll
{
    internal class FieldHelper
    {
        /// <summary>
        /// Get empty string
        /// </summary>
        /// <param name="Length">string length</param>
        /// <returns>string value</returns>
        internal static string GetEmpty(int Length)
        {
            if (Length <= 0)
            {
                return String.Empty;
            }
            else
            {
                return SupplementLength(String.Empty, Length);
            }
        }

        internal static int GetByteCount(char[] Source)
        {
            return GetByteCount(Encoding.GetEncoding("GB2312"), Source);
        }

        internal static int GetByteCount(Encoding Encoding, char[] Source)
        {
            if (Source == null || Source.Length <= 0)
            {
                return 0;
            }
            return Encoding.GetByteCount(Source);
        }

        internal static int GetByteCount(string Source)
        {
            return GetByteCount(Encoding.GetEncoding("GB2312"), Source);
        }

        internal static int GetByteCount(Encoding Encoding, string Source)
        {
            if (String.IsNullOrEmpty(Source))
            {
                return 0;
            }
            return Encoding.GetByteCount(Source);
        }

        internal static string SupplementLength(string Source, int MaxLength)
        {
            return SupplementLength(Encoding.GetEncoding("GB2312"), Source, MaxLength, ' ', AlignEnum.Left);
        }

        internal static string SupplementLength(string Source, int MaxLength, char SplitSymbol)
        {
            return SupplementLength(Encoding.GetEncoding("GB2312"), Source, MaxLength, SplitSymbol, AlignEnum.Left);
        }

        internal static string SupplementLength(string Source, int MaxLength, char SplitSymbol, AlignEnum AlignMode)
        {
            return SupplementLength(Encoding.GetEncoding("GB2312"), Source, MaxLength, SplitSymbol, AlignMode);
        }

        internal static string SupplementLength(Encoding Encoding, string Source, int MaxLength)
        {
            return SupplementLength(Encoding, Source, MaxLength, ' ', AlignEnum.Left);
        }

        internal static string SupplementLength(string Source, int MaxLength, AlignEnum AlignMode)
        {
            return SupplementLength(Encoding.GetEncoding("GB2312"), Source, MaxLength, ' ', AlignMode);
        }

        /// <summary>
        /// Supplement string value
        /// </summary>
        /// <param name="Encoding">Encoding value</param>
        /// <param name="Source">Original string value</param>
        /// <param name="MaxLength">Accept max byte length</param>
        /// <param name="AlignMode">Align mode</param> 
        /// <returns>Generated string value</returns>
        internal static string SupplementLength(Encoding Encoding, string Source, int MaxLength, char SplitSymbol, AlignEnum AlignMode)
        {
            int Length = GetByteCount(Encoding, Source);

            if (Length > MaxLength)
            {
                Source = SubString(Source, MaxLength, Encoding);
            }
            else
            {
                StringBuilder SB = new StringBuilder(Source);

                while (Length < MaxLength)
                {
                    if (AlignMode == AlignEnum.Left)
                    {
                        SB.Append(SplitSymbol);
                    }
                    if (AlignMode == AlignEnum.Right)
                    {
                        SB.Insert(0, SplitSymbol);
                    }
                    Length = GetByteCount(Encoding, SB.ToString());
                }

                Source = SB.ToString();
            }

            return Source;
        }

        /// <summary>
        /// Check Chinese characters
        /// </summary>
        /// <param name="Value">Value</param>
        /// <returns>True or Flase</returns>
        private static bool IsChinese(char Value)
        {
            if (String.IsNullOrEmpty(Value.ToString().Trim()))
            {
                return false;
            }
            return GetByteCount(Encoding.GetEncoding("GB2312"), new char[] { Value }) == 2;
        }

        /// <summary>
        /// Substring by byte length
        /// </summary>
        /// <param name="Source">source string</param>
        /// <param name="MaxLength">max length</param>
        /// <param name="Encoding">encoding</param>
        /// <returns>string</returns>
        private static string SubString(string Source, int MaxLength, Encoding Encoding)
        {
            if (MaxLength <= 0 || String.IsNullOrEmpty(Source))
            {
                return String.Empty;
            }
            if (Encoding == null)
            {
                Encoding = Encoding.GetEncoding("GB2312");
            }

            int Count = 0; //截取长度,串内下标

            int StringLength = Source.Length; //字符串长度

            int ByteCount = GetByteCount(Encoding, Source); //字节长度

            if (ByteCount > MaxLength) //如果字节长度大于最大长度
            {
                if (StringLength <= MaxLength) //字符串长度小于最大长度
                {
                    foreach (char c in Source.ToCharArray())
                    {
                        if (IsChinese(c)) //判断中文字符
                        {
                            MaxLength -= 2; //中文每个占2位

                            if (MaxLength >= 0)
                            {
                                Count++; //截取长度+1
                            }
                            else
                            {
                                break;
                            }
                        }
                        else //如果当前不是中文字符
                        {
                            MaxLength--;
                            Count++;
                        }
                    }
                    if (Count == 0) //如果字符串没有中文字符
                    {
                        Count = MaxLength;
                    }
                    return Source.Substring(0, Count);
                }
                else //传递的字符串长度过长
                {
                    Source = Source.Substring(0, MaxLength);//先截取长度

                    return SubString(Source, MaxLength, Encoding); //递归调用
                }
            }
            else //如果传递字符串长度适中
            {
                return Source;
            }
        }

        internal static string CheckDecimal(string value, int Number, int Digits)
        {
            decimal temp = 0m;

            if (!Decimal.TryParse(value, out temp))
            {
                return String.Empty;
            }
            else
            {
                if (value.Split('.')[0].Length > Number)
                {
                    return String.Empty;
                }
                else
                {
                    if (value.Split('.').Length > 1 && value.Split('.')[1].Length > Digits)
                    {
                        string format = "{0:F" + Digits + "}";
                        value = String.Format(format, temp);
                    }
                }
            }

            return value;
        }


    }
}
