﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using System.IO;
using System.Reflection;
using System.Data;

namespace Citibank.RFLFE.PL.Bll
{
    public class TXTReportHelper
    {
        #region Write Methods
        public static DataTable ConvertIListToDataTable<T>(IList<T> Source)
        {
            DataTable dt = new DataTable(typeof(T).Name);
            PropertyInfo[] properties = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo pi in properties)
            {
                dt.Columns.Add(pi.Name);
            }

            foreach (T item in Source)
            {
                var values = new object[properties.Length];

                for (int i = 0; i < properties.Length; i++)
                {
                    values[i] = properties[i].GetValue(item, null);
                }
                dt.Rows.Add(values);
            }
            return dt;
        }

        /// <summary>
        /// Type: Header or Trailer, different return value base on type
        /// </summary>
        /// <param name="FileDefination"></param>
        /// <param name="WriteText"></param>
        /// <param name="Type"></param>
        /// <returns></returns>
        public static string WriteHeaderTrailerText(IList<T_PL_FileDefination> FileDefination, string WriteText, string Type)
        {
            string Value = String.Empty;
            int Length = 0;
            int RecordType = (Type == "Header") ? 0 : 2;

            foreach (var dr in FileDefination.Where(P => P.RecordType == RecordType).Where(P => P.ColumnName == "FILLER").Select(P => P.Length))
            {
                Length = Convert.ToInt32(dr);
                break;
            }
            string DatetimeNow = DateTime.Now.ToString("yyyyMMdd");
            if (Type == "Header")
            {
                Value = String.Format("{0}{1}{2}\r\n", WriteText, DatetimeNow, FieldHelper.GetEmpty(Length));
            }
            else if (Type == "Trailer")
            {
                Value = String.Format("{0}{1}{2}", WriteText, FieldHelper.SupplementLength(Convert.ToString(FileDefination.Count), 8, '0', AlignEnum.Right), FieldHelper.GetEmpty(Length));
            }
            return Value;
        }

        public static void WriteDetailText(IList<T_PL_FileDefination> FileDefination, DataTable Source, FileStream Write, bool Flag)
        {           
            int Length = 0;

            StringBuilder Value = new StringBuilder();
            
            foreach (DataRow dr in Source.Rows)
            {
                foreach (var list in FileDefination.Where(P => P.RecordType == 1))
                {
                    string ColumnName = Convert.ToString(list.ColumnName);

                    if (Source.Columns.Contains(ColumnName))
                    {
                        Length = Convert.ToInt32(list.Length);

                        string DataType = Convert.ToString(list.DataType);

                        if (DataType.Equals("decimal", StringComparison.CurrentCultureIgnoreCase))
                        {
                            int Number = Convert.ToInt32(Convert.ToString(list.Format).Split(',')[0]);
                            int Digit = Convert.ToInt32(Convert.ToString(list.Format).Split(',')[1]);
                            string DecimalValue = FieldHelper.CheckDecimal(Convert.ToString(dr[ColumnName]), Number, Digit);
                            Value.Append(FieldHelper.SupplementLength(Encoding.GetEncoding("GB2312"), DecimalValue, Length));
                        }
                        else
                        {
                            string Body = String.Empty;

                            if (ColumnName.Contains("REMARK1"))
                            {
                                Body = Convert.ToString(dr[ColumnName]).Replace("\r\n", "");
                            }
                            else
                            {
                                Body = Convert.ToString(dr[ColumnName]);

                                if (Flag)
                                {
                                    if (ColumnName.Contains("BirthDate") || ColumnName.Contains("ID_Date"))
                                    {
                                        string[] Birth = Body.Split('-');
                                        if (Birth.Length > 1)
                                        {
                                            Body = String.Format("{0}-{1}-{2}", Birth[0], Birth[1].PadLeft(2, '0'), Birth[2].PadLeft(2, '0'));
                                        }
                                    }
                                }
                            }
                            Value.Append(FieldHelper.SupplementLength(Encoding.GetEncoding("GB2312"), Body, Length));
                        }
                    }
                    else
                    {
                        Length = Convert.ToInt32(list.Length);
                        Value.Append(FieldHelper.GetEmpty(Length));
                    }
                }
                Value.Append("\r\n");
                byte[] bvalue = Encoding.GetEncoding("GB2312").GetBytes(Value.ToString());

                Write.Write(bvalue, 0, bvalue.Length);
                Value = new StringBuilder();
            }
        }

        

        #endregion

    }
}
