﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using System.Data;
using System.IO;
using log4net;

namespace Citibank.RFLFE.PL.Bll
{
    public class ReportGenerateHandler : IReportGenerateHandler
    {
        public IReportGenOrImportDao ReportGenOrImportDao { get; set; }
        public CommonTResult<T_PL_FileDefination> result = null;
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        //get run job
        public string GetRunJobType()
        {
            try
            {
                return ReportGenOrImportDao.GetRunJobType();
            }
            catch (Exception ex)
            {
                log.Error(string.Format("GetRunJobType method exception:{0}", ex.Message));
                return null;
            }
        }

        //get Other Scheduled Task File Defination
        public IList<T_PL_FileDefination> GetFileDefinationByJobType(string JobName)
        {
            try
            {
                result = ReportGenOrImportDao.GetFileDefinationByJobType(JobName);
                return result.ResultCount > 0 ? result.ResultList : null;
            }
            catch (Exception ex)
            {
                log.Error(string.Format("GetFileDefinationByJobType method exception - Job is {0}:{1}", JobName, ex.Message));
                return null;
            }
        }

        public CommonTResult<T_Sys_PathConfiguration> GetPathConfigByName(string PathName)
        {
            try
            {
                return ReportGenOrImportDao.GetPathConfigByName(PathName);
            }
            catch (Exception ex)
            {
                log.Error(string.Format("GetPathConfigByName method exception - PathName is {0}:{1}", PathName, ex.Message));
                return null;
            }
        }

        public void GenerateReport(IList<T_PL_FileDefination> fileDefine, string JobName, IList<T_Sys_PathConfiguration> PathConfig)
        {
            IList<T_PL_FileDefination> subFileDef = null;
            foreach (string fileTypes in Enum.GetNames(typeof(FileType)))
            {
                if (fileTypes.Substring(0,3) == JobName.Substring(0,3))
                {
                    //generate report
                    string outPutPath = PathConfig[0].ImpOrGenerateFilePath.ToString();
                    string FileName = CommonHelper.GetFileName(fileTypes);
                    if (!Directory.Exists(outPutPath))
                    {
                        Directory.CreateDirectory(outPutPath);
                    }

                    FileInfo file = new FileInfo(String.Format("{0}{1}", CommonHelper.GetPath(outPutPath), FileName));
                    log.Info(string.Format("GenerateReport method - Job is {0}, file name is {1}", JobName, file));
                    if (file.Exists)
                    {
                        file.Delete();
                    }

                    using (FileStream Write = new FileStream(file.FullName, FileMode.Append))
                    {
                        long OffSet = Write.Length;

                        if (OffSet > 0)
                        {
                            Write.Seek(OffSet, SeekOrigin.Begin);
                        }

                        DataTable dt = null;
                        switch (fileTypes)
                        {
                            case "DWHAppInfo":
                                dt = CommonHelper.ConvertIListToDataTable<T_PL_DWHApplicationInfo>(ReportGenOrImportDao.GetReportBodyForDB<T_PL_DWHApplicationInfo>(fileTypes).ResultList);
                                subFileDef = fileDefine.Where(P => P.ReportType == "DWHAppInfo").ToList();
                                break;
                            case "DWHCustInfo":
                                dt = CommonHelper.ConvertIListToDataTable<T_PL_DWHCustInfo>(ReportGenOrImportDao.GetReportBodyForDB<T_PL_DWHCustInfo>(fileTypes).ResultList);
                                subFileDef = fileDefine.Where(P => P.ReportType == "DWHCustInfo").ToList();
                                break;
                            case "DWHMortInfo":
                                dt = CommonHelper.ConvertIListToDataTable<T_PL_DWHMortInfo>(ReportGenOrImportDao.GetReportBodyForDB<T_PL_DWHMortInfo>(fileTypes).ResultList);
                                subFileDef = fileDefine.Where(P => P.ReportType == "DWHMortInfo").ToList();
                                break;
                            case "DWHAppHis":
                                dt = CommonHelper.ConvertIListToDataTable<T_PL_DWHApplicationHis>(ReportGenOrImportDao.GetReportBodyForDB<T_PL_DWHApplicationHis>(fileTypes).ResultList);
                                subFileDef = fileDefine.Where(P => P.ReportType == "DWHAppHis").ToList();
                                break;
                            case "RiskData":
                                dt = CommonHelper.ConvertIListToDataTable<T_PL_RiskData>(ReportGenOrImportDao.GetReportBodyForDB<T_PL_RiskData>(JobName).ResultList);
                                subFileDef = fileDefine.Where(P => P.ReportType == "RiskData").ToList();
                                break;
                            case "CNRFALS":
                                dt = CommonHelper.ConvertIListToDataTable<T_PL_PBOC_ALS>(ReportGenOrImportDao.GetReportBodyForDB<T_PL_PBOC_ALS>(JobName).ResultList);
                                subFileDef = fileDefine.Where(P => P.ReportType == "CNRFALS").ToList();
                                break;
                        }
                        if (dt == null && dt.Rows.Count <= 0)
                        {
                            log.Debug(string.Format("{0} - No data get from database!", JobName));
                        }

                        //write header text 
                        CommonHelper.WriteHeaderTrailerText(subFileDef, "HDR", "Header");
                        log.Info(string.Format("{0} - write header successfully!", JobName));
                        //write body
                        CommonHelper.WriteDetailText(subFileDef, dt, Write, false);
                        log.Info(string.Format("{0} - write body successfully!", JobName));
                        //write trailer text
                        CommonHelper.WriteHeaderTrailerText(subFileDef, "HDR", "Trailer");
                        log.Info(string.Format("{0} - write trailer successfully!", JobName));
                    }
                }
            }
        }

        
    }
}

