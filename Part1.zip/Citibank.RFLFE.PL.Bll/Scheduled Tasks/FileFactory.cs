﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using log4net;
using System.Collections;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IBll;
using System.Data;
using System.IO;

namespace Citibank.RFLFE.PL.Bll
{
    public class FileFactory
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public IReportGenerateHandler GenerateHandler = null;
        public IReportImportHandler ImportHandler = null;

        public string GetRunJobType()
        {
            return GenerateHandler.GetRunJobType();
        }

        public IList<T_PL_FileDefination> GetFileDefinationByJobType(string JobName)
        {
            IList<T_PL_FileDefination> def = GenerateHandler.GetFileDefinationByJobType(JobName);
            return def;
        }

        public CommonTResult<T_Sys_PathConfiguration> GetPathConfigByName(string PathName)
        {
            return GenerateHandler.GetPathConfigByName(PathName);
        }

        public bool GenerateImportReportByType(IList<T_PL_FileDefination> def, string JobName, IList<T_Sys_PathConfiguration> ShareFolderPath)
        {
            try
            {
                switch (JobName)
                {
                    case "DWH":
                    case "RiskData":
                    case "CNRFALS":
                        GenerateHandler.GenerateReport(def, JobName, ShareFolderPath);
                        break;
                    case "Advice":
                    case "Annual":
                    case "Bureau":
                        ImportSourceToDB(JobName, def, ShareFolderPath);
                        break;
                    case "RM":
                        ImportHandler.ImportGRBToDB(def, ShareFolderPath);
                        break;
                    case "LateFee":
                        break;
                }
                return true;
            }
            catch(Exception ex)
            {
                return false;
            }
        }

        public void ImportSourceToDB(string JobName, IList<T_PL_FileDefination> def, IList<T_Sys_PathConfiguration> sourceFile)
        {
            Dictionary<DataTable, string> dts = ImportHandler.ReadSourceToDt(def, sourceFile);
            foreach (var items in dts)
            {
                T_PL_BatchJobLog logs = new T_PL_BatchJobLog();
                CommonResult importResult = ImportHandler.BulkCopySourceToTable(JobName, items.Key, items.Value);
                if (items.Value.Length > 0)
                {
                    logs.FileWriteDate = new FileInfo(items.Value).LastWriteTime;
                    logs.FileName = new FileInfo(items.Value).Name.ToString();
                }
                logs.JobName = JobName;
                logs.RunMachine = System.Environment.MachineName;
                logs.RunStatus = importResult.IsSuccess?1:0;
                logs.Remark = importResult.Message;
                InsertImportGenerateLog(logs);
                if (JobName != "Annual")//PBOC need to delete source files & Advice need to delete backup file
                {
                    File.Delete(items.Value);
                }
            }
        }

        public bool InsertImportGenerateLog(T_PL_BatchJobLog logs)
        {
            return ImportHandler.InsertImportGenerateLog(logs);
        }
    }
}
