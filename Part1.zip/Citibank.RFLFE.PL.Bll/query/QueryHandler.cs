﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.IDal;
using System.IO;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.query
{
    public class QueryHandler : IQueryHandler
    {
        public IQueryDao QueryDao { get; set; }

        public DownloadFileResult GetDWHInfo(T_PL_DWH condition)
        {
            StringBuilder builder = new StringBuilder();
            DataTable dt = QueryDao.GetDWHInfo(condition);
            if (dt != null && dt.Rows.Count > 0)
            {
                for (int k = 0; k < dt.Columns.Count; k++)
                {
                    if (k != 0)
                    {
                        builder.Append("|");
                    }
                    builder.Append(dt.Columns[k].ColumnName);
                }

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    builder.Append(System.Environment.NewLine);
                    for (int j = 0; j < dt.Columns.Count; j++)
                    {
                        if (j != 0)
                        {
                            builder.Append("|");
                        }
                        builder.Append(dt.Rows[i][j] == DBNull.Value ? string.Empty : dt.Rows[i][j].ToString());
                    }
                }
            }
            string tempServerFileName = AppDomain.CurrentDomain.BaseDirectory + "Report\\";
            string fileName = string.Format("{0}{1}{2}.txt",condition.FileName, condition.DateBegin, condition.DateEnd).Replace("/", "");
            FileInfo file = new FileInfo(String.Format("{0}{1}", tempServerFileName, fileName));
            if (file.Exists)
            {
                file.Delete();
            }
            StringBuilder sbOut = new StringBuilder(tempServerFileName);
            FileDownloadUtility.DownloadFile(file.FullName, builder);
            DownloadFileResult fileResult = new DownloadFileResult();
            if (System.IO.File.Exists(file.FullName))
            {
                fileResult.ContentType = "text/plain";
                fileResult.FileContents = FileDownloadUtility.DownloadFile(file.FullName);
                fileResult.FileDownloadName = file.FullName;
            }
            return fileResult;
        }

        public CommonTResult<T_PL_BureauQueryResult> GetAppInfoByIDNum(string ID_NUMBER, int start, int limit)
        {
            CommonTResult<T_PL_BureauQueryResult> result = new CommonTResult<T_PL_BureauQueryResult>();
            try
            {
                result = QueryDao.GetAppInfoByIDNum(ID_NUMBER, start, limit);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_BureauQueryResult> GetCustInfoByOrgCode(string OrgCode, int start, int limit)
        {
            CommonTResult<T_PL_BureauQueryResult> result = new CommonTResult<T_PL_BureauQueryResult>();
            try
            {
                result = QueryDao.GetCustInfoByOrgCode(OrgCode, start, limit);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_WF_PL_Stage> GetAllStageNameInQuery(int QueryPage)
        {
            CommonTResult<T_WF_PL_Stage> result = new CommonTResult<T_WF_PL_Stage>();
            try
            {
                result = QueryDao.GetAllStageNameInQuery(QueryPage);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_LongOrder> GetLongApplyByDay(T_PL_Application app, int day, int start, int limit)
        {
            CommonTResult<T_PL_LongOrder> result = new CommonTResult<T_PL_LongOrder>();
            try
            {
                result = QueryDao.GetLongApplyByDay(app, day, start, limit);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_Sys_Users> GetSalesIDByOrgCode(string orgCode, string soeID, int roleType)
        {
            CommonTResult<T_Sys_Users> result = new CommonTResult<T_Sys_Users>();
            try
            {
                result = QueryDao.GetSalesIDByOrgCode(orgCode, soeID, roleType);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_WF_PL_INS> GetUserProcessInstance(T_PL_Application condition, int start, int limit)
        {
            CommonTResult<T_WF_PL_INS> result = new CommonTResult<T_WF_PL_INS>();
            try
            {
                result = QueryDao.GetUserProcessInstance(condition, start, limit);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_UserProcess> ExportUserProcessByAppID(string appids)
        {
            CommonTResult<T_PL_UserProcess> result = new CommonTResult<T_PL_UserProcess>();
            try
            {
                result = QueryDao.ExportUserProcessByAppID(appids);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_Deviation> GetDeviationList(T_PL_Application condition, int start, int limit)
        {
            CommonTResult<T_PL_Deviation> result = new CommonTResult<T_PL_Deviation>();
            try
            {
                result = QueryDao.GetDeviationList(condition, start, limit);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_DeviationTotalInfo> GetDeviationTotalInfo(T_PL_Application condition)
        {
            CommonTResult<T_PL_DeviationTotalInfo> result = new CommonTResult<T_PL_DeviationTotalInfo>();
            try
            {
                result = QueryDao.GetDeviationTotalInfo(condition);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_ApprovalInfo> GetApprovalInfoByAppId(string AppID)
        {
            CommonTResult<T_PL_ApprovalInfo> result = new CommonTResult<T_PL_ApprovalInfo>();
            try
            {
                result = QueryDao.GetApprovalInfoByAppId(AppID);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }
    }
}
