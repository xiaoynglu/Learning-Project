﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.query
{
    public class AppProgressHistoryHandler : IAppProgressHistoryHandler
    {
        public IAppProgressHistoryDao AppProgressHistoryDao { get; set; }

        public CommonTResult<AppProgressHistoryView> GetAppProgressHistory(int start, int limit, string AppID)
        {
            CommonTResult<AppProgressHistoryView> result = null;
            CommonTResult<AppProgressHistoryView> resultDao = AppProgressHistoryDao.GetAppProgressHistory(start,limit,AppID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<AppProgressHistoryView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;  
        }
    }
}
