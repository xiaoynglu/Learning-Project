﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.query
{
    public class CriticalFieldQueryHandler: ICriticalFieldQueryHandler
    {
        public ICriticalFieldQueryDao CriticalFieldQueryDao { get; set; }

        public CommonTResult<T_PL_ParameterAuditLog> QueryParameterList(int start, int limit, CriticalFieldQueryView entity)
        {
            CommonTResult<T_PL_ParameterAuditLog> result = null;
            CommonTResult<T_PL_ParameterAuditLog> resultDao = CriticalFieldQueryDao.QueryParameterList(start, limit, entity);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_ParameterAuditLog>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;  
            
        }

        public CommonTResult<T_PL_AppAuditLog> QueryList(int start, int limit, CriticalFieldQueryView entity)
        {
            CommonTResult<T_PL_AppAuditLog> result = null;
            CommonTResult<T_PL_AppAuditLog> resultDao = CriticalFieldQueryDao.QueryList(start, limit, entity);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_AppAuditLog>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;  
             
        }

        public List<string> GetCriticalField(string tablename)
        {
            return CriticalFieldQueryDao.GetCriticalField(tablename);
        }

        public string GetTableName(string rfid)
        {
            return CriticalFieldQueryDao.GetTableName(rfid);
        }

        public bool GetIsCriticalField(string tablename, string fieldname)
        {
            return CriticalFieldQueryDao.GetIsCriticalField(tablename,fieldname);
        }

        public List<string> GetParameterLogData(string rfid)
        {
            return CriticalFieldQueryDao.GetParameterLogData(rfid);
        }

        public List<string> GetLogData(string rfid)
        {
            return CriticalFieldQueryDao.GetLogData(rfid);
        }
    }
}
