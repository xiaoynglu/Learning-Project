﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
namespace Citibank.RFLFE.PL.Bll.query
{
    public class AppProgressQueryHandler : IAppProgressQueryHandler
    {
        public IAppProgressQueryDao AppProgressQueryDao { get; set; }

        public CommonTResult<appProgressDetailView> GetAppDetail(string AppID, string AppNo)
        {
            CommonTResult<appProgressDetailView> result = null;
            CommonTResult<appProgressDetailView> resultDao = AppProgressQueryDao.GetAppDetail(AppID, AppNo);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<appProgressDetailView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;  
        
        }

        public CommonTResult<appProgressView> GetappProgress(int start, int limit, string strParam, string strType, string orgCode)
        {
            CommonTResult<appProgressView> result = null;
            CommonTResult<appProgressView> resultDao = AppProgressQueryDao.GetappProgress(start, limit, strParam, strType, orgCode);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<appProgressView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;  
        }

        public bool CheckSoeIdRight(string soeId, string stageId)
        {
            var result = AppProgressQueryDao.CheckSoeIdRight(soeId, stageId);
            if (!result || Int32.Parse(stageId) < Int32.Parse(Constants.CreditApproval))
                return false;
            else return true;
        }
    }
}
