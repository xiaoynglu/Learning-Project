﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Text;
using System.Data.OleDb;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using System.Collections;


namespace Citibank.RFLFE.PL.Bll.application
{
    public class DocListHandler : IDocListHandler
    {
        #region all Dao
        public IDocListDao DocListDao { get; set; }
        public ISysParametersDao SysParametersDao { get; set; }
        public ICustomerDao CustomerDao { get; set; }
        public IApplicationDao ApplicationDao { get; set; }

        private static readonly DocListHandler instance = new DocListHandler();

        public static DocListHandler Instance
        {
            get
            {
                return instance;
            }
        }
    
        #endregion
        
        private string filePath;
        private string fileName;
        private OleDbConnection conn;
        private string connString;
        private FileType fileType;

        /// <summary>
        /// Get submitted document list
        /// </summary>
        /// <param name="appid">application id</param>
        /// <param name="stageid">stage id</param>
        /// <param name="borrowType">borrow type</param>
        /// <param name="limit">limit size for each page</param>
        /// <param name="start">start position</param>
        /// <returns>submitted document list</returns>
        public CommonTResult<T_PL_DocSubmitted> GetSubmittedDocList(string appid, int stageid, string custID)
        {
            CommonTResult<T_PL_DocSubmitted> result = null;
            CommonTResult<T_PL_DocSubmitted> resultDao = DocListDao.GetSubmittedDocList(appid, stageid, custID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_DocSubmitted>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        /// <summary>
        /// Get all required document list for specific stage id
        /// </summary>
        /// <param name="appid">application id</param>
        /// <param name="stageid">stage id</param>
        /// <param name="custID">customer id</param>
        /// <returns>T_PL_DocSumitted entity list</returns>
        public CommonTResult<T_PL_DocSubmitted> GetStageDocList(string appid, int stageid, string custID)
        {
            CommonTResult<T_PL_DocSubmitted> result = null;
            CommonTResult<T_PL_DocSubmitted> resultDao = DocListDao.GetStageDocList(appid, stageid, custID);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_DocSubmitted>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public Boolean SaveSubmittedDoc(List<T_PL_DocSubmitted> docList,string processorId)
        {
            StringBuilder insertStr = new StringBuilder();
            StringBuilder updateStr = new StringBuilder();
            foreach (var item in docList)
            {
                if (item.uploaded == true)
                {
                    item.ProcID = processorId;
                    insertStr.Append(item.AppID + ",");
                    insertStr.Append(item.CustID + ",");
                    insertStr.Append(item.DocID + ",");
                    insertStr.Append(item.StageID + ",");
                    insertStr.Append(item.ProcID + ",");
                    if (item.SubmittedTime != "")
                    {
                        DateTime dt = DateTime.Parse(item.SubmittedTime);
                        insertStr.Append(dt.ToString() + ",");
                    }
                    else {
                        insertStr.Append(item.SubmittedTime + ",");
                    }
                    insertStr.Append(item.Remarks + ";");
                }
                else
                {
                    updateStr.Append(item.TID + ",");
                }
            }
            return DocListDao.SaveSubmittedDoc(insertStr.ToString(), updateStr.ToString());
        }

        public Boolean SaveUploadedNewProposal(string filePath, string processorId,T_Sys_Users loginUser) 
        {
            var dataSet = GetExcelData(filePath);
            var mbBasicInfoRow = dataSet.Tables["主贷人基本信息"].Rows;
            var mbDetailsRow = dataSet.Tables["主贷人详细信息"].Rows;
            var mbJobInfo = dataSet.Tables["主贷人工作信息"].Rows;
            var mbFinance = dataSet.Tables["主贷人财务状况分析"].Rows;
            var cob1Row = dataSet.Tables["共贷人1"].Rows;
            var cob1DetailsRow = dataSet.Tables["共贷人1详细信息"].Rows;
            var cob2Row = dataSet.Tables["共贷人2"].Rows;
            var cob2DetailsRow = dataSet.Tables["共贷人2详细信息"].Rows;

            var result = false;

            T_PL_Application application = new T_PL_Application();

            T_PL_Customers mb = new T_PL_Customers();
            T_PL_CustomerContact mbContact = new T_PL_CustomerContact();
            T_PL_SalaryCust mbSalaryCust = new T_PL_SalaryCust();
            T_PL_SelfEmployedCust mbSelfEmployedCust = new T_PL_SelfEmployedCust();
            T_PL_SABudget mbSABudget =new Entities.T_PL_SABudget();
            T_PL_SEBudget mbSEBudget = new Entities.T_PL_SEBudget();

            T_PL_Customers cb1 = new T_PL_Customers();
            T_PL_SalaryCust cb1SalaryCust = new T_PL_SalaryCust();
            T_PL_SABudget cb1SABudget = new T_PL_SABudget();
            T_PL_CustomerContact cb1Contact = new T_PL_CustomerContact();

            T_PL_Customers cb2 = new T_PL_Customers();
            T_PL_SalaryCust cb2SalaryCust = new T_PL_SalaryCust();
            T_PL_SABudget cb2SABudget = new T_PL_SABudget();
            T_PL_CustomerContact cb2Contact = new T_PL_CustomerContact();

            #region Application

            application.AppID = System.Guid.NewGuid().ToString();
            application.CreatorID = processorId;
            application.BranchCode = loginUser.BranchCode;
            application.AgentCode = loginUser.AgentCode;
            application.OrgCode = loginUser.OrgCode;
            application.ApplicationNo = GetApplicationNo(application.BranchCode);
            application.CreateDate = DateTime.Now;
            application.IsSubmitted = "N";

            #endregion

            #region 主贷人基本信息
            mb.CustID = System.Guid.NewGuid().ToString();
            mb.AppID = application.AppID;
            mb.FirstName = mbBasicInfoRow[0][1].ToString();
            mb.LastName = mbBasicInfoRow[1][1].ToString();
            mb.PinyinName = mbBasicInfoRow[2][1].ToString();
            mb.IDNo = mbBasicInfoRow[3][1].ToString();
            mb.Gender = mbBasicInfoRow[4][1].ToString() ==Constants.Gender_Male?"1":"0";
            mb.BorrowType = Constants.BorrowType_MB;
            mb.FullName = mb.FirstName + mb.LastName;
            mb.DOB = Convert.ToDateTime(mbBasicInfoRow[5][1].ToString());
            mb.MarriageStatus = mbBasicInfoRow[6][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.MarriageStatus, mbBasicInfoRow[6][1].ToString());
            mb.SpouseName = mbBasicInfoRow[7][1].ToString() == Constants.None? string.Empty : mbBasicInfoRow[7][1].ToString();
            mb.SpouseIDNo = mbBasicInfoRow[8][1].ToString() == Constants.None ? string.Empty : mbBasicInfoRow[8][1].ToString();
            mb.HasChildren = mbBasicInfoRow[9][1].ToString() == Constants.Have ? "1" : "0";
            mb.LivedYear = Convert.ToInt32(mbBasicInfoRow[10][1].ToString());
            mb.Relation = Constants.Relation_BR;
            mb.Education = mbBasicInfoRow[11][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EducationType, mbBasicInfoRow[11][1].ToString());
            mb.ReportType = mbBasicInfoRow[12][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.ReportType, mbBasicInfoRow[12][1].ToString());
            #endregion

            #region 主贷人联系地址 
            mbContact.CustID = new Guid(mb.CustID);
            mbContact.HouseProvince =mbDetailsRow[0][1].ToString()==null?string.Empty: SysParametersDao.GetRegionCode(mbDetailsRow[0][1].ToString(),"");
            mbContact.HouseCity = mbDetailsRow[1][1].ToString()==null?string.Empty: SysParametersDao.GetRegionCode( mbDetailsRow[1][1].ToString(), mbContact.HouseProvince);
            mbContact.HouseDistrict = mbDetailsRow[2][1].ToString();
            mbContact.HouseStreet = mbDetailsRow[3][1].ToString();
            mbContact.HousePostCode = mbDetailsRow[4][1].ToString();
            mbContact.HouseStatus = mbDetailsRow[5][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.HouseStatus, mbDetailsRow[5][1].ToString());
            mbContact.HouseTelAreaCode = mbDetailsRow[6][1].ToString();
            mbContact.HouseTelNumber = mbDetailsRow[7][1].ToString() == "0" ? string.Empty : mbDetailsRow[7][1].ToString();

            mbContact.HouseSameAsResidence = mbDetailsRow[8][1].ToString() == Constants.Yes ? "1" : "0";
            mbContact.ResidenceProvince =mbDetailsRow[9][1].ToString()==null?string.Empty: SysParametersDao.GetRegionCode( mbDetailsRow[9][1].ToString(),"");
            mbContact.ResidenceCity =mbDetailsRow[10][1].ToString()==null?string.Empty:SysParametersDao.GetRegionCode( mbDetailsRow[10][1].ToString(),mbContact.ResidenceProvince);
            mbContact.ResidenceDistrict = mbDetailsRow[11][1].ToString();
            mbContact.ResidenceStreet = mbDetailsRow[12][1].ToString();
            mbContact.ResidencePostCode = mbDetailsRow[13][1].ToString();
            mbContact.ResidenceTelAreaCode = mbDetailsRow[14][1].ToString();
            mbContact.ResidenceTelNumber = mbDetailsRow[15][1].ToString() == "0" ? string.Empty : mbDetailsRow[15][1].ToString();

            mbContact.WorkingProvince =mbDetailsRow[16][1].ToString()==null?string.Empty:SysParametersDao.GetRegionCode( mbDetailsRow[16][1].ToString(),"");
            mbContact.WorkingCity =mbDetailsRow[17][1].ToString()==null?string.Empty:SysParametersDao.GetRegionCode( mbDetailsRow[17][1].ToString(),mbContact.WorkingProvince);
            mbContact.WorkingDistrict = mbDetailsRow[18][1].ToString();
            mbContact.WorkingStreet = mbDetailsRow[19][1].ToString();
            mbContact.WorkingPostCode = mbDetailsRow[20][1].ToString();
            mbContact.WorkingTelAreaCode = mbDetailsRow[21][1].ToString();
            mbContact.WorkingTelNumber = mbDetailsRow[22][1].ToString() == "0" ? string.Empty : mbDetailsRow[22][1].ToString();
            mbContact.WorkingTelExtNumber = mbDetailsRow[23][1].ToString() == "0" ? string.Empty : mbDetailsRow[23][1].ToString();

            mbContact.CommunicationAddressAs = mbDetailsRow[24][1].ToString();
            mbContact.MobileNumber = mbDetailsRow[25][1].ToString();
            mbContact.Email = mbDetailsRow[26][1].ToString() == "0" ? string.Empty : mbDetailsRow[26][1].ToString();
            mbContact.IDExpireDate = Convert.ToDateTime(mbDetailsRow[27][1].ToString());
            mbContact.RelativeName = mbDetailsRow[28][1].ToString();
            mbContact.RelativeRelation = mbDetailsRow[29][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.RelationShip, mbDetailsRow[29][1].ToString());
            mbContact.IDIssueDate = Convert.ToDateTime(mbDetailsRow[30][1].ToString());
            mbContact.IDIssuePlace = mbDetailsRow[31][1].ToString();
            mbContact.RelativeCompany = mbDetailsRow[32][1].ToString();
            mbContact.RelativeTelAreaCode = mbDetailsRow[33][1].ToString();
            mbContact.RelativeTelNumber = mbDetailsRow[34][1].ToString()=="0"?"":mbDetailsRow[34][1].ToString();
            mbContact.RelativeTelExtNumber = mbDetailsRow[35][1].ToString()=="0"?"": mbDetailsRow[35][1].ToString();
            mbContact.RelativeMobile = mbDetailsRow[36][1].ToString()=="0"?"": mbDetailsRow[36][1].ToString();

            mbContact.OtherContactName = mbDetailsRow[37][1].ToString();
            mbContact.OtherContactRelation = mbDetailsRow[38][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.RelationShip, mbDetailsRow[38][1].ToString());
            mbContact.OtherContactCompany = mbDetailsRow[39][1].ToString();
            mbContact.OtherContactTelAreaCode = mbDetailsRow[40][1].ToString();
            mbContact.OtherContactTelNumber = mbDetailsRow[41][1].ToString()=="0"?"":mbDetailsRow[41][1].ToString() ;
            mbContact.OtherContactTelExtNumber = mbDetailsRow[42][1].ToString() == "0" ? "" : mbDetailsRow[42][1].ToString();
            mbContact.OtherContactMobile = mbDetailsRow[43][1].ToString();
            #endregion

            #region  共贷人1
            if (!string.IsNullOrEmpty(cob1Row[0][1].ToString())) 
            {
                cb1.FirstName = cob1Row[0][1].ToString();
                cb1.LastName = cob1Row[1][1].ToString();
                cb1.PinyinName = cob1Row[2][1].ToString();
                cb1.IDNo = cob1Row[3][1].ToString();
                cb1.AppID = application.AppID;
                cb1.CustID = System.Guid.NewGuid().ToString();
                cb1.BorrowType = Constants.BorrowType_CB1;
                cb1.FullName = cb1.FirstName + cb1.LastName;
                cb1.Gender = cob1Row[4][1].ToString() == Constants.Gender_Male ? "1" : "0";
                cb1.DOB = cob1Row[5][1].ToString() == Constants.DateTimeFormat.DateTimeFormat2 ? DateTime.MinValue : Convert.ToDateTime(cob1Row[5][1].ToString());
                cb1.Relation = cob1Row[6][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.RelationShip, cob1Row[6][1].ToString());
                cb1.SharedFinancial = cob1Row[7][1].ToString() == Constants.Yes ? "1" : "0";
                cb1.Industry = cob1Row[8][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.G_IndustryType, cob1Row[8][1].ToString());//共贷人只能是工薪，工薪 的行业性质 是40,企业主的 是 41
                cb1.Occupation = cob1Row[9][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.OccupationType, cob1Row[9][1].ToString());

                cb1SalaryCust.CustID = new Guid(cb1.CustID);
                cb1SalaryCust.EnterpriseLevel = cob1Row[10][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EnterpriseLevel, cob1Row[10][1].ToString());
                cb1SalaryCust.Department = cob1Row[11][1].ToString();
                cb1SalaryCust.Position = cob1Row[12][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.PositionType, cob1Row[12][1].ToString());
                cb1SalaryCust.Job = cob1Row[13][1].ToString();
                cb1SalaryCust.EnterpriseName = cob1Row[14][1].ToString();
                cb1SalaryCust.EnterpriseProperty = cob1Row[15][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EnterpriseProperty, cob1Row[15][1].ToString());
                cb1SalaryCust.EnterpriseScale = cob1Row[16][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EnterpriseScale, cob1Row[16][1].ToString());
                if (!string.IsNullOrEmpty(cob1Row[17][1].ToString())) cb1SalaryCust.CurrentWorkingLife = Convert.ToInt32(cob1Row[17][1].ToString());
                if (!string.IsNullOrEmpty(cob1Row[18][1].ToString())) cb1SalaryCust.PreWorkingLife = Convert.ToInt32(cob1Row[18][1].ToString());
                if (!string.IsNullOrEmpty(cob1Row[19][1].ToString())) cb1SalaryCust.TotalWorkingLife = Convert.ToInt32(cob1Row[19][1].ToString());

                cb1SABudget.CustID = new Guid( cb1.CustID);
                if (!string.IsNullOrEmpty(cob1Row[20][1].ToString())) cb1SABudget.AfterTaxIncome = cob1Row[20][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[21][1].ToString())) cb1SABudget.RentalIncome = cob1Row[21][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[22][1].ToString())) cb1SABudget.OtherIncome = cob1Row[22][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[23][1].ToString())) cb1SABudget.OtherFamilyIncome = cob1Row[23][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[24][1].ToString())) cb1SABudget.RentalExpenses = cob1Row[24][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[25][1].ToString())) cb1SABudget.UtilitiesFee = cob1Row[25][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[26][1].ToString())) cb1SABudget.LivingExpenses = cob1Row[26][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[27][1].ToString())) cb1SABudget.EducationExpenses = cob1Row[27][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[28][1].ToString())) cb1SABudget.TransportationExpenses = cob1Row[28][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[29][1].ToString())) cb1SABudget.OtherExpenses = cob1Row[29][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[30][1].ToString())) cb1SABudget.MLRepayment = cob1Row[30][1].ToString();
                if (!string.IsNullOrEmpty(cob1Row[31][1].ToString())) cb1SABudget.ULRepayment = cob1Row[31][1].ToString();
                cb1SABudget.StageID = Convert.ToInt32(Constants.Stage.NewProposalId);
                cb1SABudget.ProcessorID = processorId;
                cb1SABudget.ProceededDate = DateTime.Now;

            }
            #endregion

            #region 共贷人1详细信息 
            if (!string.IsNullOrEmpty(cob1DetailsRow[0][1].ToString()) ) 
            {
                cb1.MarriageStatus = cob1DetailsRow[0][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.MarriageStatus, mbDetailsRow[0][1].ToString());
                cb1.SpouseName = cob1DetailsRow[1][1].ToString();
                cb1.SpouseIDNo = cob1DetailsRow[2][1].ToString();
                cb1.HasChildren = cob1DetailsRow[3][1].ToString() == Constants.Yes ? "1" : "0";
                if (!string.IsNullOrEmpty(cob1DetailsRow[4][1].ToString())) cb1.LivedYear = Convert.ToInt32(cob1DetailsRow[4][1].ToString());
                cb1.Education = cob1DetailsRow[5][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EducationType, cob1DetailsRow[5][1].ToString());

                cb1Contact.CustID = new Guid(cb1.CustID);
                cb1Contact.HouseProvince = SysParametersDao.GetRegionCode(cob1DetailsRow[6][1].ToString(), string.Empty);
                cb1Contact.HouseCity = SysParametersDao.GetRegionCode(cob1DetailsRow[7][1].ToString(), cb1Contact.HouseProvince);
                cb1Contact.HouseDistrict = cob1DetailsRow[8][1].ToString();
                cb1Contact.HouseStreet = cob1DetailsRow[9][1].ToString();
                cb1Contact.HousePostCode = cob1DetailsRow[10][1].ToString();
                cb1Contact.HouseStatus = cob1DetailsRow[11][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.HouseStatus, cob1DetailsRow[11][1].ToString());
                cb1Contact.HouseTelAreaCode = cob1DetailsRow[12][1].ToString();
                cb1Contact.HouseTelNumber = cob1DetailsRow[13][1].ToString();

                cb1Contact.HouseSameAsResidence = cob1DetailsRow[14][1].ToString() == Constants.Yes ? "1" : "0";
                cb1Contact.ResidenceProvince = cob1DetailsRow[15][1] == null ? string.Empty : SysParametersDao.GetRegionCode(cob1DetailsRow[15][1].ToString(), "");
                cb1Contact.ResidenceCity = cob1DetailsRow[16][1] == null ? string.Empty : SysParametersDao.GetRegionCode(cob1DetailsRow[16][1].ToString(), cb1Contact.ResidenceProvince);
                cb1Contact.ResidenceDistrict = cob1DetailsRow[17][1].ToString();
                cb1Contact.ResidenceStreet = cob1DetailsRow[18][1].ToString();
                cb1Contact.ResidencePostCode = cob1DetailsRow[19][1].ToString();
                cb1Contact.ResidenceTelAreaCode = cob1DetailsRow[20][1].ToString();
                cb1Contact.ResidenceTelNumber = cob1DetailsRow[21][1].ToString();

                cb1Contact.WorkingProvince = cob1DetailsRow[22][1].ToString() == null ? string.Empty : SysParametersDao.GetRegionCode(cob1DetailsRow[22][1].ToString(), "");
                cb1Contact.WorkingCity = cob1DetailsRow[23][1].ToString() == null ? string.Empty : SysParametersDao.GetRegionCode(cob1DetailsRow[23][1].ToString(), cb1Contact.WorkingProvince);
                cb1Contact.WorkingDistrict = cob1DetailsRow[24][1].ToString();
                cb1Contact.WorkingStreet = cob1DetailsRow[25][1].ToString();
                cb1Contact.WorkingPostCode = cob1DetailsRow[26][1].ToString();
                cb1Contact.WorkingTelAreaCode = cob1DetailsRow[27][1].ToString();
                cb1Contact.WorkingTelNumber = cob1DetailsRow[28][1].ToString();
                cb1Contact.WorkingTelExtNumber = cob1DetailsRow[29][1].ToString();

                cb1Contact.CommunicationAddressAs = cob1DetailsRow[30][1].ToString();
                cb1Contact.MobileNumber = cob1DetailsRow[31][1].ToString();
                cb1Contact.Email = cob1DetailsRow[32][1].ToString();
                cb1Contact.IDExpireDate = cob1DetailsRow[33][1].ToString() == Constants.DateTimeFormat.DateTimeFormat2 ? DateTime.MinValue : Convert.ToDateTime(cob1DetailsRow[33][1].ToString());
                cb1Contact.IDIssueDate = cob1DetailsRow[34][1].ToString() == Constants.DateTimeFormat.DateTimeFormat2 ? DateTime.MinValue : Convert.ToDateTime(cob1DetailsRow[34][1].ToString());
                cb1Contact.IDIssuePlace = cob1DetailsRow[35][1].ToString();

                cb1Contact.OtherContactName = cob1DetailsRow[36][1].ToString();
                cb1Contact.OtherContactRelation = cob1DetailsRow[37][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.RelationShip, cob1DetailsRow[37][1].ToString());
                cb1Contact.OtherContactTelAreaCode = cob1DetailsRow[38][1].ToString();
                cb1Contact.OtherContactTelNumber = cob1DetailsRow[39][1].ToString();
                cb1Contact.OtherContactTelExtNumber = cob1DetailsRow[40][1].ToString();
                cb1Contact.OtherContactMobile = cob1DetailsRow[41][1].ToString();
            }
            #endregion

            #region 共贷人2

            if (!string.IsNullOrEmpty(cob2Row[0][1].ToString())) 
            {
                cb2.CustID = System.Guid.NewGuid().ToString();
                cb2.FirstName = cob2Row[0][1].ToString();
                cb2.LastName = cob2Row[1][1].ToString();
                cb2.PinyinName = cob2Row[2][1].ToString();
                cb2.IDNo = cob2Row[3][1].ToString();
                cb2.FullName = cb2.FirstName + cb2.LastName;
                cb2.BorrowType = Constants.BorrowType_CB2;
                cb2.AppID = application.AppID;
                cb2.Gender = cob2Row[4][1].ToString() == Constants.Gender_Male ? "1" : "0";
                cb2.DOB = cob2Row[5][1].ToString() == Constants.DateTimeFormat.DateTimeFormat2 ? DateTime.MinValue : Convert.ToDateTime(cob2Row[5][1].ToString());
                cb2.Relation = cob2Row[6][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.RelationShip, cob2Row[6][1].ToString());
                cb2.SharedFinancial = cob2Row[7][1].ToString() == Constants.Yes ? "1" : "0";
                cb2.Industry = cob2Row[8][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.G_IndustryType, cob2Row[8][1].ToString());
                cb2.Occupation = cob2Row[9][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.OccupationType, cob2Row[9][1].ToString());

                cb2SalaryCust.CustID = new Guid(cb2.CustID);
                cb2SalaryCust.EnterpriseLevel = cob2Row[10][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EnterpriseLevel, cob2Row[10][1].ToString());
                cb2SalaryCust.Department = cob2Row[11][1].ToString();
                cb2SalaryCust.Position = cob2Row[12][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.PositionType, cob2Row[12][1].ToString());
                cb2SalaryCust.Job = cob2Row[13][1].ToString();
                cb2SalaryCust.EnterpriseName = cob2Row[14][1].ToString();
                cb2SalaryCust.EnterpriseProperty = cob2Row[15][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EnterpriseProperty, cob2Row[15][1].ToString());
                cb2SalaryCust.EnterpriseScale = cob2Row[16][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EnterpriseScale, cob2Row[16][1].ToString());
                if (!string.IsNullOrEmpty(cob1Row[17][1].ToString())) cb2SalaryCust.CurrentWorkingLife = Convert.ToInt32(cob2Row[17][1].ToString());
                if (!string.IsNullOrEmpty(cob1Row[18][1].ToString())) cb2SalaryCust.PreWorkingLife = Convert.ToInt32(cob2Row[18][1].ToString());
                if (!string.IsNullOrEmpty(cob1Row[19][1].ToString())) cb2SalaryCust.TotalWorkingLife = Convert.ToInt32(cob2Row[19][1].ToString());

                cb2SABudget.CustID = new Guid( cb2.CustID);
                if (!string.IsNullOrEmpty(cob2Row[20][1].ToString())) cb2SABudget.AfterTaxIncome = cob2Row[20][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[21][1].ToString())) cb2SABudget.RentalIncome = cob2Row[21][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[22][1].ToString())) cb2SABudget.OtherIncome = cob2Row[22][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[23][1].ToString())) cb2SABudget.OtherFamilyIncome = cob2Row[23][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[24][1].ToString())) cb2SABudget.RentalExpenses = cob2Row[24][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[25][1].ToString())) cb2SABudget.UtilitiesFee = cob2Row[25][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[26][1].ToString())) cb2SABudget.LivingExpenses = cob2Row[26][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[27][1].ToString())) cb2SABudget.EducationExpenses = cob2Row[27][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[28][1].ToString())) cb2SABudget.TransportationExpenses = cob2Row[28][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[29][1].ToString())) cb2SABudget.OtherExpenses = cob2Row[29][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[30][1].ToString())) cb2SABudget.MLRepayment = cob2Row[30][1].ToString();
                if (!string.IsNullOrEmpty(cob2Row[31][1].ToString())) cb2SABudget.ULRepayment = cob2Row[31][1].ToString();
                cb2SABudget.StageID = Convert.ToInt32(Constants.Stage.NewProposalId);
                cb2SABudget.ProcessorID = processorId;
                cb2SABudget.ProceededDate = DateTime.Now;
            }
           
            #endregion

            #region 共贷人2详细信息

            if (!string.IsNullOrEmpty(cob2DetailsRow[0][1].ToString())) 
            {
                cb2.MarriageStatus = cob2DetailsRow[0][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.MarriageStatus, cob2DetailsRow[0][1].ToString());
                cb2.SpouseName = cob2DetailsRow[1][1].ToString();
                cb2.SpouseIDNo = cob2DetailsRow[2][1].ToString();
                cb2.HasChildren = cob2DetailsRow[3][1].ToString() == Constants.Yes ? "1" : "0";
                if (!string.IsNullOrEmpty(cob2DetailsRow[4][1].ToString())) cb2.LivedYear = Convert.ToInt32(cob2DetailsRow[4][1].ToString());
                cb2.Education = mbDetailsRow[5][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EducationType, mbDetailsRow[5][1].ToString());

                cb2Contact.CustID = new Guid(cb2.CustID);
                cb2Contact.HouseProvince = cob2DetailsRow[6][1].ToString() == null ? string.Empty : SysParametersDao.GetRegionCode(cob2DetailsRow[6][1].ToString(), string.Empty);
                cb2Contact.HouseCity = cob2DetailsRow[7][1].ToString() == null ? string.Empty : SysParametersDao.GetRegionCode(cob2DetailsRow[7][1].ToString(), cb2Contact.HouseProvince);
                cb2Contact.HouseDistrict = cob2DetailsRow[8][1].ToString();
                cb2Contact.HouseStreet = cob2DetailsRow[9][1].ToString();
                cb2Contact.HousePostCode = cob2DetailsRow[10][1].ToString();
                cb2Contact.HouseStatus = cob2DetailsRow[11][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.HouseStatus, cob2DetailsRow[11][1].ToString());
                cb2Contact.HouseTelAreaCode = cob2DetailsRow[12][1].ToString();
                cb2Contact.HouseTelNumber = cob2DetailsRow[13][1].ToString();

                cb2Contact.HouseSameAsResidence = cob2DetailsRow[14][1].ToString() == Constants.Yes ? "1" : "0"; 
                cb2Contact.ResidenceProvince = cob2DetailsRow[15][1].ToString() == null ? string.Empty : SysParametersDao.GetRegionCode(cob2DetailsRow[15][1].ToString(), "");
                cb2Contact.ResidenceCity = cob2DetailsRow[16][1].ToString() == null ? string.Empty : SysParametersDao.GetRegionCode(cob2DetailsRow[16][1].ToString(), cb2Contact.ResidenceProvince);
                cb2Contact.ResidenceDistrict = cob2DetailsRow[17][1].ToString();
                cb2Contact.ResidenceStreet = cob2DetailsRow[18][1].ToString();
                cb2Contact.ResidencePostCode = cob2DetailsRow[19][1].ToString();
                cb2Contact.ResidenceTelAreaCode = cob2DetailsRow[20][1].ToString();
                cb2Contact.ResidenceTelNumber = cob2DetailsRow[21][1].ToString();

                cb2Contact.WorkingProvince = cob2DetailsRow[22][1].ToString() == null ? string.Empty : SysParametersDao.GetRegionCode(cob2DetailsRow[22][1].ToString(), "");
                cb2Contact.WorkingCity = cob2DetailsRow[23][1].ToString() == null ? string.Empty : SysParametersDao.GetRegionCode(cob2DetailsRow[23][1].ToString(), cb2Contact.WorkingProvince);
                cb2Contact.WorkingDistrict = cob2DetailsRow[24][1].ToString();
                cb2Contact.WorkingStreet = cob2DetailsRow[25][1].ToString();
                cb2Contact.WorkingPostCode = cob2DetailsRow[26][1].ToString();
                cb2Contact.WorkingTelAreaCode = cob2DetailsRow[27][1].ToString();
                cb2Contact.WorkingTelNumber = cob2DetailsRow[28][1].ToString();
                cb2Contact.WorkingTelExtNumber = cob2DetailsRow[29][1].ToString();

                cb2Contact.CommunicationAddressAs = cob2DetailsRow[30][1].ToString();
                cb2Contact.MobileNumber = cob2DetailsRow[31][1].ToString();
                cb2Contact.Email = cob2DetailsRow[32][1].ToString();
                cb2Contact.IDExpireDate = cob2DetailsRow[33][1].ToString() == Constants.DateTimeFormat.DateTimeFormat2 ? DateTime.MinValue : Convert.ToDateTime(cob2DetailsRow[33][1].ToString());
                cb2Contact.IDIssueDate = cob2DetailsRow[34][1].ToString() == Constants.DateTimeFormat.DateTimeFormat2 ? DateTime.MinValue : Convert.ToDateTime(cob2DetailsRow[34][1].ToString());
                cb2Contact.IDIssuePlace = cob2DetailsRow[35][1].ToString();

                cb2Contact.OtherContactName = cob2DetailsRow[36][1].ToString();
                cb2Contact.OtherContactRelation = cob2DetailsRow[37][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.RelationShip, cob2DetailsRow[37][1].ToString());
                cb2Contact.OtherContactTelAreaCode = cob2DetailsRow[38][1].ToString();
                cb2Contact.OtherContactTelNumber = cob2DetailsRow[39][1].ToString();
                cb2Contact.OtherContactTelExtNumber = cob2DetailsRow[40][1].ToString();
                cb2Contact.OtherContactMobile = cob2DetailsRow[41][1].ToString();
            }
            #endregion

            #region 主贷人工作信息
            if (mbJobInfo[0][1].ToString() == Constants.Q_EmploymentType_Desc)
            {
                mb.EmploymentType = Constants.Q_EmploymentType;
                mb.Industry = mbJobInfo[16][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.Q_IndustryType, mbJobInfo[16][1].ToString());
                mb.Occupation = mbJobInfo[17][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.OccupationType, mbJobInfo[17][1].ToString());
                mbSelfEmployedCust.CustID = new Guid(mb.CustID);
                if (!string.IsNullOrEmpty(mbJobInfo[18][1].ToString())) mbSelfEmployedCust.CurrentIndustryTime = Convert.ToDouble(mbJobInfo[18][1].ToString());
                mbSelfEmployedCust.ShopName = mbJobInfo[19][1].ToString();
                mbSelfEmployedCust.RegistrationNumber = mbJobInfo[20][1].ToString();
                mbSelfEmployedCust.OperatorName = mbJobInfo[21][1].ToString();
                mbSelfEmployedCust.OperationPlace = mbJobInfo[22][1].ToString();
                if (!string.IsNullOrEmpty(mbJobInfo[23][1].ToString())) mbSelfEmployedCust.EmployeeNumber = Convert.ToInt32(mbJobInfo[23][1].ToString());
                mbSelfEmployedCust.Contact = mbJobInfo[24][1].ToString();
                mbSelfEmployedCust.ContactPosition = mbJobInfo[25][1].ToString();
            }
            else 
            {
                mb.EmploymentType = Constants.G_EmploymentType;
                mb.Industry = mbJobInfo[2][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.G_IndustryType, mbJobInfo[2][1].ToString());
                mb.Occupation = mbJobInfo[3][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.OccupationType, mbJobInfo[3][1].ToString());
                mbSalaryCust.CustID = new Guid(mb.CustID);
                mbSalaryCust.EnterpriseLevel = mbJobInfo[4][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EnterpriseLevel, mbJobInfo[4][1].ToString());
                mbSalaryCust.Department = mbJobInfo[5][1].ToString();
                mbSalaryCust.Position = mbJobInfo[6][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.PositionType, mbJobInfo[6][1].ToString());
                mbSalaryCust.Job= mbJobInfo[7][1].ToString();
                mbSalaryCust.EnterpriseName = mbJobInfo[8][1].ToString();
                mbSalaryCust.EnterpriseProperty = mbJobInfo[9][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EnterpriseProperty, mbJobInfo[9][1].ToString());
                mbSalaryCust.EnterpriseScale = mbJobInfo[10][1].ToString() == null ? string.Empty : SysParametersDao.GetParamKeyByIDAndValue(Constants.SysParamID.EnterpriseScale, mbJobInfo[10][1].ToString());
                if (!string.IsNullOrEmpty(mbJobInfo[11][1].ToString())) mbSalaryCust.CurrentWorkingLife = Convert.ToInt32(mbJobInfo[11][1].ToString());
                if (!string.IsNullOrEmpty(mbJobInfo[12][1].ToString())) mbSalaryCust.PreWorkingLife = Convert.ToInt32(mbJobInfo[12][1].ToString());
                if (!string.IsNullOrEmpty(mbJobInfo[13][1].ToString())) mbSalaryCust.TotalWorkingLife = Convert.ToInt32(mbJobInfo[13][1].ToString());
                application.IsEmployeeLoan = mbJobInfo[14][1].ToString() == Constants.Yes ? "true" : "false";
            }
            #endregion

            #region 主贷人财务状况分析

            #region 工薪阶层
            if (mb.EmploymentType == Constants.G_EmploymentType)
            {
                mbSABudget.CustID = new Guid(mb.CustID);
                if (!string.IsNullOrEmpty(mbFinance[1][1].ToString())) mbSABudget.AfterTaxIncome = mbFinance[1][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[2][1].ToString())) mbSABudget.RentalIncome = mbFinance[2][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[3][1].ToString())) mbSABudget.OtherIncome = mbFinance[3][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[4][1].ToString())) mbSABudget.OtherFamilyIncome = mbFinance[4][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[5][1].ToString())) mbSABudget.RentalExpenses =mbFinance[5][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[6][1].ToString())) mbSABudget.UtilitiesFee = mbFinance[6][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[7][1].ToString())) mbSABudget.LivingExpenses = mbFinance[7][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[8][1].ToString())) mbSABudget.EducationExpenses = mbFinance[8][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[9][1].ToString())) mbSABudget.TransportationExpenses = mbFinance[9][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[10][1].ToString())) mbSABudget.OtherExpenses = mbFinance[10][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[11][1].ToString())) mbSABudget.MLRepayment = mbFinance[11][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[12][1].ToString())) mbSABudget.ULRepayment =mbFinance[12][1].ToString();
            }

            #endregion

            #region 企业主
            else
            {
                mbSEBudget.CustID = new Guid(mb.CustID);
                if (!string.IsNullOrEmpty(mbFinance[14][1].ToString())) mbSEBudget.MonthlyTurnover = mbFinance[14][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[15][1].ToString())) mbSEBudget.PurchaseCost = mbFinance[15][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[16][1].ToString())) mbSEBudget.StoreRents = mbFinance[16][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[17][1].ToString())) mbSEBudget.UtilitiesFee = mbFinance[17][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[18][1].ToString())) mbSEBudget.EmployeeSalary = mbFinance[18][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[19][1].ToString())) mbSEBudget.OtherExpenses = mbFinance[19][1].ToString();
                if (!string.IsNullOrEmpty(mbFinance[20][1].ToString())) mbSEBudget.Tax = mbFinance[20][1].ToString();
                mbSEBudget.GrossMargins = Math.Round((ConvertUtility.ConvertStringToDecimal(mbSEBudget.MonthlyTurnover) - ConvertUtility.ConvertStringToDecimal(mbSEBudget.PurchaseCost)) /  ConvertUtility.ConvertStringToDecimal(mbSEBudget.MonthlyTurnover) * 100, 2).ToString();
                mbSEBudget.StageID = Convert.ToInt32(Constants.Stage.NewProposalId);
                mbSEBudget.ProcessorID = processorId;
                mbSEBudget.ProceededDate = DateTime.Now;//todo
            } 
            #endregion

          #endregion
          
           
            result = CustomerDao.SaveCustomerInfo(mb);
            result = CustomerDao.SaveCustomerContact(mbContact);//贷款人联系信息
            result = ApplicationDao.SaveApplicationByAppId(application) > 0 ? true : false;
            if (mb.EmploymentType == Constants.Q_EmploymentType)
            {
                result = CustomerDao.SaveSelfEmployedCust(mbSelfEmployedCust);//个体户信息
                result = CustomerDao.SaveFinanceSelf(mbSEBudget);//个体户财务分析表
            } 
            else
            {
                result = CustomerDao.SaveSalaryCust(mbSalaryCust); //工薪信息
                result = CustomerDao.SaveFinanceSalary(mbSABudget);//工薪财务分析
            }
            if (!string.IsNullOrEmpty(cob1Row[0][1].ToString())) 
            {
                result = CustomerDao.SaveCustomerInfo(cb1);
                result = CustomerDao.SaveCustomerContact(cb1Contact);
                result = CustomerDao.SaveSalaryCust(cb1SalaryCust);
                result = CustomerDao.SaveFinanceSalary(cb1SABudget);
            }
            if (!string.IsNullOrEmpty(cob2Row[0][1].ToString())) 
            {
                result = CustomerDao.SaveCustomerInfo(cb2);
                result = CustomerDao.SaveCustomerContact(cb2Contact);
                result = CustomerDao.SaveSalaryCust(cb2SalaryCust);
                result = CustomerDao.SaveFinanceSalary(cb2SABudget);
            }
            return true;         
           
        }

        private DataSet GetExcelData(string path)
        {
            DataSet dsExcelData = new DataSet();
            if (System.IO.File.Exists(path))
            {
                SetFileInfo(path);
                OleDbDataAdapter adapter;
                using (conn = new OleDbConnection(connString))
                {
                    conn.Open();
                    DataTable dtSchema = conn.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

                    String[] excelSheets = new String[dtSchema.Rows.Count];
                    for (int i = 0; i < dtSchema.Rows.Count; i++)
                    {
                        excelSheets[i] = dtSchema.Rows[i]["TABLE_NAME"].ToString();
                        if (excelSheets[i].IndexOf("_") != -1)
                        {
                            continue;
                        }
                        string strSQL = "select * from [" + excelSheets[i] + "]";
                        adapter = new OleDbDataAdapter(strSQL, conn);
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dt.TableName = excelSheets[i].Replace("_", "").Replace("$", "").Replace("'", "");
                        dsExcelData.Tables.Add(dt);
                    }
                }
            }
            return dsExcelData;
        }
    
        private void SetFileInfo(string path)
        {
            filePath = path;
            fileName = filePath.Remove(0, filePath.LastIndexOf("\\") + 1);
            switch (fileName.Split('.')[fileName.Split('.').Length - 1])
            {
                case "xls": connString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties='Excel 8.0;HDR=Yes;IMEX=1;'";
                    fileType = FileType.xls; break;
                case "xlsx": connString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source =" + filePath + ";Extended Properties='Excel 12.0;HDR=Yes;IMEX=1'";
                    fileType = FileType.xlsx; break;
            }
        }

        private enum FileType
        {
            noset, xls, xlsx, csv
        }

        public string GetApplicationNo(string branchCode) 
        {
            lock (instance) {

                //获取当前日期格式
                string date = DateTime.Now.Date.ToString("yyyyMMdd");

                //获取当天的最大序列号
                string suffix = ApplicationDao.GetAppSuffix(branchCode, date);
                int nSuffix = 0;

                //当天已经申请过序列号
                if (!string.IsNullOrEmpty(suffix))
                {
                    nSuffix = int.Parse(suffix);
                    //序列号自增加1
                    nSuffix++;
                    //格式化输出
                    suffix = nSuffix.ToString().PadLeft(3, '0');
                }
                else
                {
                    //当天第一次申请序列号
                    suffix = "001";
                }

                string newAppNo = String.Empty;              

                newAppNo = branchCode + "-" + date + "-" + suffix;

                //保存申请编号
                ApplicationDao.SaveAppNo(branchCode, date, suffix,"");

                return newAppNo;
            }
        }

        public CommonTResult<T_PL_DocSubmitted> getLackDoc(string appid, string stageId)
        {
            return DocListDao.getLackDoc(appid, stageId);
        }

        public void UpdateDocListToAppChecker(string appId)
        {
            DocListDao.UpdateDocListToAppChecker(appId);
        }
    }
}
