﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Data;

namespace Citibank.RFLFE.PL.Bll.application
{
    public class AmendAppHandler : IAmendAppHandler
    {
        public IAmendAppDao AmendAppDao { get; set; }

        public Dictionary<string[], string> GetRACMapping(string collateralType)
        {
            return AmendAppDao.GetRACMapping(collateralType);
        }
    }
}
