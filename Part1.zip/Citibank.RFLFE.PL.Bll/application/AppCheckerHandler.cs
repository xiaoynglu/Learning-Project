﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.application
{
    public class AppCheckerHandler : IAppCheckerHandler
    {
        public IAppCheckerDao AppCheckerDao { get; set; }

        public CommonTResult<T_PL_Customers> GetCustDetailInfoByCustId(string CustId)
        {
            CommonTResult<T_PL_Customers> result = null;
            CommonTResult<T_PL_Customers> resultDao = AppCheckerDao.GetCustDetailInfoByCustId(CustId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_Customers>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_Customers> GetDocListRoles(string appId)
        {
            CommonTResult<T_PL_Customers> result = null;
            CommonTResult<T_PL_Customers> resultDao = AppCheckerDao.GetDocListRoles(appId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_Customers>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public Boolean SaveReviewDocList(List<T_PL_DocSubmitted> docList,string procId)
        {
            StringBuilder insertStr= new StringBuilder();
            StringBuilder updateStr = new StringBuilder();
            foreach (var item in docList) {
                if (item.uploaded == true)
                {
                    item.ProcID = procId;
                    insertStr.Append(item.AppID + ",");
                    insertStr.Append(item.CustID + ",");
                    insertStr.Append(item.DocID + ",");
                    insertStr.Append(item.StageID + ",");
                    insertStr.Append(item.ProcID + ",");
                    insertStr.Append(item.SubmittedTime + ",");
                    insertStr.Append(item.Remarks + ";");
                }
                else
                {
                    updateStr.Append(item.TID + ",");
                }
            }
            return AppCheckerDao.SaveReviewDocList(insertStr.ToString(),updateStr.ToString());
        }
    }
}
