﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.application
{
    public class CustomerHandler : ICustomerHandler
    {
        #region all Dao
        public ICustomerDao CustomerDao { get; set; }
        #endregion

        public CommonTResult<T_PL_Customers> GetCustomers(string appID, string CustId)
        {
            CommonTResult<T_PL_Customers> result = null;
            CommonTResult<T_PL_Customers> resultDao = CustomerDao.GetCustomers(appID, CustId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_Customers>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_Guarantors> GetGuarantorByAppId(string AppId)
        {
            CommonTResult<T_PL_Guarantors> result = null;
            CommonTResult<T_PL_Guarantors> resultDao = CustomerDao.GetGuarantorByAppId(AppId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_Guarantors>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_FamilyMembers> GetFamilyMembersByCustId(string CustId)
        {
            CommonTResult<T_PL_FamilyMembers> result = null;
            CommonTResult<T_PL_FamilyMembers> resultDao = CustomerDao.GetFamilyMembersByCustId(CustId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_FamilyMembers>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_Customers> GetMainAndJointCustomersListByAppId(string AppId)
        {
            CommonTResult<T_PL_Customers> result = null;
            CommonTResult<T_PL_Customers> resultDao = CustomerDao.GetMainAndJointCustomersListByAppId(AppId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_Customers>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_CustomerContact> GetBorrowerContactByCustId(string CustId)
        {
            CommonTResult<T_PL_CustomerContact> result = null;
            CommonTResult<T_PL_CustomerContact> resultDao = CustomerDao.GetBorrowerContactByCustId(CustId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_CustomerContact>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_SABudget> GetFinanceSalaryByCustId(string CustId, string stageId)
        {
            CommonTResult<T_PL_SABudget> result = null;
            CommonTResult<T_PL_SABudget> resultDao = CustomerDao.GetFinanceSalaryByCustId(CustId, stageId);
            if (resultDao.ResultList.Any())
            {
                foreach (var saBudget in resultDao.ResultList) 
                {
                    //个人家庭收入小计
                    saBudget.PersonalFamilyIncomeSubtotal = (ConvertUtility.DecimalTryParse(saBudget.AfterTaxIncome) + ConvertUtility.DecimalTryParse(saBudget.RentalIncome) + ConvertUtility.DecimalTryParse(saBudget.OtherIncome) + 
                                                             ConvertUtility.DecimalTryParse(saBudget.OtherFamilyIncome)).ToString();
                    //家庭开支小计
                    saBudget.FamilyExpenseSubtotal = (ConvertUtility.DecimalTryParse(saBudget.RentalExpenses) + ConvertUtility.DecimalTryParse(saBudget.UtilitiesFee) + ConvertUtility.DecimalTryParse(saBudget.LivingExpenses) +
                                                      ConvertUtility.DecimalTryParse(saBudget.EducationExpenses) + ConvertUtility.DecimalTryParse(saBudget.TransportationExpenses) + ConvertUtility.DecimalTryParse(saBudget.OtherExpenses)).ToString();
                    //家庭借贷每月还款小计
                    saBudget.MonthlyRepaymentSubTotal = (ConvertUtility.DecimalTryParse(saBudget.ULRepayment) + ConvertUtility.DecimalTryParse(saBudget.MLRepayment)).ToString();
                    //每月开支总计
                    saBudget.MonthlyTotalExpenses = (ConvertUtility.DecimalTryParse(saBudget.FamilyExpenseSubtotal) + ConvertUtility.DecimalTryParse(saBudget.MonthlyRepaymentSubTotal)).ToString();
                    //每月可支配收入
                    saBudget.MonthlyDisposableIncome = (ConvertUtility.DecimalTryParse(saBudget.PersonalFamilyIncomeSubtotal) - ConvertUtility.DecimalTryParse(saBudget.MonthlyTotalExpenses)).ToString();
                    //家庭开支占家庭收入比例
                    saBudget.ExpenditureAccountingForIncome = Math.Round(ConvertUtility.DecimalTryParse(saBudget.FamilyExpenseSubtotal) / ConvertUtility.DecimalTryParse(saBudget.PersonalFamilyIncomeSubtotal )* 100, 2).ToString() + "%";
                    //家庭贷款还款占家庭收入收入比例
                    saBudget.RepaymentAccountingForIncome = Math.Round(ConvertUtility.DecimalTryParse(saBudget.MonthlyRepaymentSubTotal) / ConvertUtility.DecimalTryParse(saBudget.PersonalFamilyIncomeSubtotal) * 100, 2).ToString() + "%";
                }
                result = new CommonTResult<T_PL_SABudget>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_SEBudget> GetFinanceSelfByCustId(string CustId, string stageId)
        {
            //todo  家庭财产分析,贷款 过去三年社会保险 ,与配偶商业房产拥有情况还不确定
            CommonTResult<T_PL_SEBudget> result = null;
            CommonTResult<T_PL_SEBudget> resultDao = CustomerDao.GetFinanceSelfByCustId(CustId, stageId);
            if (resultDao.ResultList.Any())
            {
                foreach (var seBudget in resultDao.ResultList) 
                {
                    //毛利
                    seBudget.GrossProfit = (ConvertUtility.ConvertStringToDecimal(seBudget.MonthlyTurnover) - ConvertUtility.ConvertStringToDecimal(seBudget.PurchaseCost)).ToString();
                    //毛利率
                    seBudget.GrossMargins = Math.Round( ConvertUtility.ConvertStringToDecimal(seBudget.GrossProfit) / ConvertUtility.ConvertStringToDecimal( seBudget.MonthlyTurnover) * 100, 2) + "%"; ;
                    //总支出
                    seBudget.TotalExpenses =(ConvertUtility.ConvertStringToDecimal(seBudget.StoreRents )+ ConvertUtility.ConvertStringToDecimal(seBudget.UtilitiesFee) +
                                            ConvertUtility.ConvertStringToDecimal( seBudget.EmployeeSalary )+ ConvertUtility.ConvertStringToDecimal(seBudget.OtherExpenses)).ToString();
                    //净收入
                    seBudget.NetIncome = (ConvertUtility.ConvertStringToDecimal(seBudget.GrossProfit) - ConvertUtility.ConvertStringToDecimal(seBudget.TotalExpenses) - ConvertUtility.ConvertStringToDecimal( seBudget.Tax)).ToString();
                    //纯利润率
                    seBudget.NetProfitMargin = Math.Round( ConvertUtility.ConvertStringToDecimal(seBudget.NetIncome )/ ConvertUtility.ConvertStringToDecimal( seBudget.MonthlyTurnover) * 100, 2).ToString() + "%";
                }
                result = new CommonTResult<T_PL_SEBudget>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_Mortgagors> GetMortgagorListByAppId(string AppId, bool isChecker)
        {
            CommonTResult<T_PL_Mortgagors> result = null;
            CommonTResult<T_PL_Mortgagors> resultDao = CustomerDao.GetMortgagorListByAppId(AppId,isChecker);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_Mortgagors>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public String GetCustIDByAppIdAndBorrowType(string appId, string borrowType) {

            return  CustomerDao.GetCustIDByAppIdAndBorrowType(appId, borrowType);
        }

        public bool SaveCustomerContact(T_PL_CustomerContact Entity)
        {
            return CustomerDao.SaveCustomerContact(Entity);
        }

        public bool SaveFinanceSalary(T_PL_SABudget Entity, string processorID)
        {
            Entity.ProceededDate = DateTime.Now;
            Entity.ProcessorID = processorID;
            return CustomerDao.SaveFinanceSalary(Entity);
        }

        public bool SaveFinanceSelf(T_PL_SEBudget Entity, string processorID)
        {
            Entity.ProceededDate = DateTime.Now;
            Entity.ProcessorID = processorID;
            return CustomerDao.SaveFinanceSelf(Entity);
        }

        public bool SaveSalaryCust(T_PL_SalaryCust Entity)
        {
            return CustomerDao.SaveSalaryCust(Entity);
        }

        public bool SaveSelfEmployedCust(T_PL_SelfEmployedCust Entity)
        {
            return CustomerDao.SaveSelfEmployedCust(Entity); 
        }

        public bool SaveCustomer(T_PL_Customers Entity)
        {
           return CustomerDao.SaveCustomerInfo(Entity);
        }

        public bool DeleteCustomerByCustId(string custId)
        {
            return CustomerDao.DeleteCustomerByCustId(custId);
        }

        public bool SaveFamilyMember(T_PL_FamilyMembers Entity)
        {
            return CustomerDao.SaveFamilyMember(Entity);
        }

        public bool SaveGuarantors(T_PL_Guarantors Entity) 
        {
            return CustomerDao.SaveGuarantors(Entity);
        }

        public bool SaveBorrowerCustomers(BorrowerBasicView entity)
        {
            return CustomerDao.SaveBorrowerCustomers(entity);
        }

        public bool DeleteFamilyMembersByMemberId(string memberId)
        {
            return CustomerDao.DeleteFamilyMembersByMemberId(memberId);
        }

        public string GetFirstPercent(string MOCount, string OrgCode, string Collateralpe)
        {
            return CustomerDao.GetFirstPercent(MOCount, OrgCode, Collateralpe);
        }

        public List<string> GetBaseAndMaxLtv(string ProdID, string MOCount, string Collateralpe, string orgCode)
        {
            return CustomerDao.GetBaseAndMaxLtv(ProdID, MOCount, Collateralpe, orgCode);
        }

        public bool SaveMortgagor(T_PL_Mortgagors Entity,bool isChecker)
        {
            return CustomerDao.SaveMortgagor(Entity,isChecker);

        }

        public bool RemoveMortgagor(string mortID, bool isChecker)
        {
            return CustomerDao.RemoveMortgagor(mortID,isChecker);
        }

        public string GetCustIDByBorrowType(string appID, string borrowType)
        {
            return CustomerDao.GetCustIDByBorrowType(appID, borrowType);
        }

        public string GetProdIDbyProdName(string prodName)
        {
            return CustomerDao.GetProdIDbyProdName(prodName);
        }

        public bool SaveCustomers(T_PL_Customers Entity)
        {
            return CustomerDao.SaveCustomers(Entity);
        }

        public CommonTResult<BorrowerBasicView> GetBorrowerCustomers(string appID, string custId)
        {
            CommonTResult<BorrowerBasicView> result = null;
            CommonTResult<BorrowerBasicView> resultDao = CustomerDao.GetBorrowerCustomers(appID, custId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<BorrowerBasicView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public bool SaveFinanceSelByCustId(T_PL_SEBudget entity,string processorId)
        {
            entity.ProcessorID = processorId;
            entity.ProceededDate = DateTime.Now;
            return CustomerDao.SaveFinanceSelByCustId(entity);
        }
        
        public bool SaveFinanceSalaryByCustId(T_PL_SABudget entity,string processorId )
        {
            entity.ProcessorID = processorId;
            entity.ProceededDate = DateTime.Now;
            return CustomerDao.SaveFinanceSalaryByCustId(entity);
        }

        public bool InitNewProposal(string AppID, string SoeID, string orgCode)
        {
            return CustomerDao.InitNewProposal(AppID, SoeID,  orgCode);
        }
        
        public bool SaveGuarantorByAppId(T_PL_Guarantors Entity)
        {
            return CustomerDao.SaveGuarantorByAppId(Entity);
        }

        public CommonTResult<FinanceSurveyView> GetFinanceSurvey(string appId)
        {
            return CustomerDao.GetFinanceSurvey(appId);
        }

        public CommonTResult<T_PL_CustIncome> GetIncomeDetails(string custId)
        {
            return CustomerDao.GetIncomeDetails(custId);
        }

        public CommonTResult<T_PL_CustDebt> GetCutDebt(string custId)
        {
            return CustomerDao.GetCutDebt(custId);
        }

        public CommonTResult<LoanInfoView> GetLoanInfo(string appId)
        {
            return CustomerDao.GetLoanInfo(appId);
        }

        public bool UpdateScoringCard(T_PL_SEBudget Entity)
        {   
            return CustomerDao.UpdateScoringCard(Entity);
        }

        public Boolean UpdateSalaryWorkInfo(T_PL_SalaryCust Entity) {
            return CustomerDao.UpdateSalaryWorkInfo(Entity);
        }

        public Boolean UpdateSelfEmploymentWorkInfo(T_PL_SelfEmployedCust Entity)
        {

            return CustomerDao.UpdateSelfEmploymentWorkInfo(Entity);
        }

        public bool SaveBorrowerDetailsInfoOfCreditApproval(T_PL_Customers Entity)
        {
            return CustomerDao.SaveBorrowerDetailsInfoOfCreditApproval(Entity);
        }

        public bool SaveFinanceSurveyOfCreditApproval(FinanceSurveyView Entity)
        {
            return CustomerDao.SaveFinanceSurveyOfCreditApproval(Entity);
        }

        public bool SaveIncomeDetailsOfCreditApproval(List<T_PL_CustIncome> List)
        {
            return CustomerDao.SaveIncomeDetailsOfCreditApproval(List);
        }

        public bool SaveCustDebtOfCreditApproval(T_PL_CustDebt Entity, string processorId)
        {
            Entity.ProcessorID = processorId;
            Entity.ProceededDate = DateTime.Now;
            return CustomerDao.SaveCustDebtOfCreditApproval(Entity);
        }

        public bool SaveLoanApprovaltOfCreditApproval(LoanInfoView Entity)
        {
            return CustomerDao.SaveLoanApprovaltOfCreditApproval(Entity);
        }

        public CommonTResult<T_PL_EntrusPay> GetEntrusPayListByAppId(string appId)
        {
            return CustomerDao.GetEntrusPayListByAppId(appId);
        }

        public bool DeleteEntrusPayById(string entrusPayId)
        {
            return CustomerDao.DeleteEntrusPayById(entrusPayId);
        }

        public bool SaveEntrusPay(T_PL_EntrusPay Entity)
        {
            return CustomerDao.SaveEntrusPay(Entity);
        }
        
        public bool UpdateCustIncome(string custId)
        {
            return CustomerDao.UpdateCustIncome(custId);
        }

        public List<string> GetCustIDListByAppID(string appId)
        {
            return CustomerDao.GetCustIDListByAppID(appId);
        }

        public CommonTResult<T_PL_BranchCompany> GetCompanyList(string companyType, string enterpriseName, string orgCode)
        {
            return CustomerDao.GetCompanyList(companyType, enterpriseName, orgCode);
        }
    }
}
