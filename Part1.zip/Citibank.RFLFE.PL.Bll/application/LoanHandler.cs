﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Data;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using StringResource = Citibank.RFLFE.PL.Framework.StringResources;

namespace Citibank.RFLFE.PL.Bll.application
{
    public class LoanHandler : ILoanHandler
    {
        public ILoanDao LoanDao { get; set; }

        /// <summary>
        /// Get loan by application id
        /// </summary>
        /// <param name="appID">appid</param>
        /// <returns>loan entity</returns>
        public T_PL_Loan GetLoanByAppId(Guid appID)
        {
            return LoanDao.GetLoanByAppId(appID);
        }

        public CommonTResult<T_PL_LTVFactors> GetLTVFactors(string appId,string prodId)
        {
            CommonTResult<T_PL_LTVFactors> result = null;
            CommonTResult<T_PL_LTVFactors> resultDao = LoanDao.GetLTVFactors(appId,prodId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_LTVFactors>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_LTVParam> GetLTVParams(int prodId, string orgCode,string appId)
        {
            CommonTResult<T_PL_LTVParam> result = null;
            CommonTResult<T_PL_LTVParam> resultDao = LoanDao.GetLTVParams(prodId, orgCode, appId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_LTVParam>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_Collateral> GetCustCollateralInfoByAppId(string AppId)
        {
            CommonTResult<T_PL_Collateral> result = null;
            CommonTResult<T_PL_Collateral> resultDao = LoanDao.GetCustCollateralInfoByAppId(AppId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_Collateral>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_SellerInfo> GetVendorListByAppId(string AppId)
        {
            CommonTResult<T_PL_SellerInfo> result = null;
            CommonTResult<T_PL_SellerInfo> resultDao = LoanDao.GetVendorListByAppId(AppId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_SellerInfo>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount
                };
            }
            return result;
        }

        public CommonTResult<T_PL_LoanIndustry> GetLoanPurposeByAppId(string AppId)
        {
            CommonTResult<T_PL_LoanIndustry> result = null;
            CommonTResult<T_PL_LoanIndustry> resultDao = LoanDao.GetLoanPurposeByAppId(AppId);
            if (resultDao.ResultList.Any())
            {
                result = new CommonTResult<T_PL_LoanIndustry>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public int SaveLoanByAppId(T_PL_Loan entity)
        {
            return LoanDao.SaveLoanByAppId(entity);
        }

        public bool SaveVendor(T_PL_SellerInfo Entity)
        {
            return LoanDao.SaveVendor(Entity);
        }

        public bool RemoveVendor(string SellerID)
        {
            return LoanDao.RemoveVendor(SellerID);
        }

        public bool SaveLTVFactors(List<T_PL_LTVFactors> EntityList)
        {
            var appId = "";
            if (EntityList.Count != 0) appId = EntityList.FirstOrDefault().AppID.ToString();
            StringBuilder str = new StringBuilder();
            foreach (var item in EntityList)
            {
                str.Append(item.TID==""?"0":item.TID);
                str.Append(",");
                str.Append(item.Factor + ",");
                str.Append(item.FactorValue + ";");
            }
            return LoanDao.SaveLTVFactors(str.ToString(),appId);
        }

        public List<string> GetHasPropertyandPropertyTypeByAppId(string appId)
        {
            return LoanDao.GetHasPropertyandPropertyTypeByAppId(appId);
        }

        public String SaveLoanPurpose(T_PL_LoanIndustry Entity)
        {
            var errorMessage = "";
            #region  check properties
            //check loan purpose info
            //Step1:第一贷款用途必填
            //Step2:贷款用途如果选择的是PERM(用于个人消费用途(买房)),第二借款用途和第三届款用途必须是空
            //Step3:贷款主要投向和次要投向不能为空
            //Step4:如果用户选择了某个贷款用途为"房屋装修及改造"则需要判断装修房屋所有人与申请人关系不能为空和装修房屋是否本套
            //Step5:来源编码，支付方式和从何处获取本行个贷业务不能为空
            //Step6:支付方式如果是"自主支付",放款银行 放款银行分行和放款帐户号必填
            //Step8:支付方式如果是"部分受托支付",放款银行 放款银行分行和放款帐户号必填，收款人用户名,收款人开户行，收款人开户分行和收款人帐号必填
            if (Entity.Purpose1 == "" || Entity.Purpose1 == null) return errorMessage = "请选择第一借款用途"; 
            if (Entity.Category == Constants.Category.PERM) {
                if ((Entity.Purpose2 != "" && Entity.Purpose2 != null) || (Entity.Purpose3 != "" && Entity.Purpose3 != null))
                        return errorMessage = "请重置第一借款用途和第二借款用途的值"; 
            }
            if (Entity.MainIndustry == "" || Entity.MainIndustry == null) return errorMessage = "请选择贷款主要投向";
            if (Entity.SubIndustry == "" || Entity.SubIndustry == null) return errorMessage = "请选择贷款次投向"; 
            if (Entity.Category == Constants.Category.PER) {
                if (Entity.Purpose1 == Constants.PER_LoanPurpose.D || Entity.Purpose2 == Constants.PER_LoanPurpose.D || Entity.Purpose2 == Constants.PER_LoanPurpose.D)
                {
                    if (Entity.DecorationRelation == "" || Entity.DecorationRelation == null) return errorMessage = "请选择装修房屋所有人与申请人关系";
                    if (Entity.IsPropertySelf == "" || Entity.IsPropertySelf==null) return errorMessage = "请选择装修房屋是否为本套"; 
                }
            }
            if (Entity.SourceCode == "" || Entity.SourceCode == null) return errorMessage = "请选择来源编号";
            if (Entity.PayType == "" || Entity.PayType == null) return errorMessage = "请选择支付方式";
            if (Entity.WhereKnow == "" || Entity.WhereKnow == null) return errorMessage = "从何处获取本行个贷业务";
            if (Entity.PayType == Constants.PayTypeValue.A || Entity.PayType == Constants.PayTypeValue.C)
            {
                if (Entity.DeditBankName == "" || Entity.DeditBankName==null) return errorMessage = "请选择放款银行";
                if (Entity.DeditSubBankName == "" || Entity.DeditSubBankName == null) return errorMessage = "请填写放款银行分行";
                if (Entity.DeditAccount == ""||Entity.DeditAccount == null) return errorMessage = "请填写放款帐户号";
            }
            if (Entity.PayType == Constants.PayTypeValue.A || Entity.PayType == Constants.PayTypeValue.B)
            {
                if (!LoanDao.IsExistEntrusPay(Entity.AppID.ToString())) return errorMessage = "请添加受托支付方式"; ;
            }
            #endregion
            if (!LoanDao.SaveLoanPurpose(Entity)) errorMessage = "保存失败";
            return errorMessage;
        }

        public bool SaveSelfPayByAppId(T_PL_LoanIndustry Entity)
        {
            return LoanDao.SaveSelfPay(Entity);
        }

        public String SaveCustCollateralInfo(T_PL_Collateral Entity)
        {
            var errorMessage = "";
            #region checke property
            if (Entity.HasProperty == Constants.HasPropertyValue.HasProperty_2) {
                if (Entity.PropertyType != "" || Entity.CollateralType != "") return errorMessage = "请重置房产拥有情况和房产抵押类型的值";
            }
            if (Entity.OwnHouse == "") return errorMessage = "请选择主贷人与配偶住宅拥有情况";
            if (Entity.ResidentialType == "") return errorMessage = "请选择房屋种类";
            if (Entity.CurrentStatus == Constants.CurrentStatus.L) {
                if (Entity.RentRemainingDate == 0) return errorMessage = "请填写租赁剩余期限"; ;
            }
            #endregion
            if (!LoanDao.SaveCustCollateralInfo(Entity)) errorMessage = "保存失败";
            return errorMessage;
        }

        public List<String> GetBeforeAndCurrentRateByAppId(string appId)
        {
            return LoanDao.GetBeforeAndCurrentRateByAppId(appId);
        }

        public bool UpdateRateException(string appId, string result)
        {
            return LoanDao.UpdateRateException(appId, result);
        }

        public bool updateRate(string appId, string rate, string soeId, string stageId)
        {
            string oldRage = LoanDao.GetSalesRate(appId);
            return LoanDao.RefreshRate(appId, rate);
            //todo 
            //insert a record into table T_CriticalField_Logging
        }

        public bool DeleteCollateralbyAppID(string appId) {

            return LoanDao.DeleteCollateralbyAppID(appId);
        }
        
        public bool DeleteMortgatarbyAppID(string appId)
        {
            return LoanDao.DeleteMortgatarbyAppID(appId);
        }

        public T_PL_Loan GetNewCurrLoanForCreditApproval(string appId)
        {
            return LoanDao.GetNewCurrLoanForCreditApproval(appId);
        }

        public T_PL_Loan getLoanParametersByAppId(string AppId)
        {

            return LoanDao.getLoanParametersByAppId(AppId);
        }

        public bool SaveLoanParameters(string appId, string requestLoan, string monthlyMaxRefund, string tenor, string rate)
        {
            return LoanDao.SaveLoanParameters(appId,requestLoan,monthlyMaxRefund,tenor,rate);
        }

        public DataTable ExportDisbursementFileByAppId(string appId)
        {
            DataSet ds = LoanDao.ExportDisbursementFileByAppId(appId);

            DataTable resultdt = new DataTable();

            resultdt.Columns.Add("支付方式");
            resultdt.Columns.Add("放款银行");
            resultdt.Columns.Add("放款账号");
            resultdt.Columns.Add("收款人");
            resultdt.Columns.Add("放款金额");
            if (ds.Tables[1].Rows.Count > 0)
            {
                //resultdt.Columns.Add("支付方式");
                //resultdt.Columns.Add("收款人开户行");
                //resultdt.Columns.Add("收款人账号");
                //resultdt.Columns.Add("收款人");
                //resultdt.Columns.Add("受托支付金额");

                foreach (DataRow dr in ds.Tables[1].Rows)
                {
                    DataRow resultdr = resultdt.NewRow();
                    resultdr["支付方式"] = "受托支付";
                    resultdr["放款银行"] = dr[4];
                    resultdr["放款账号"] = dr[2];
                    resultdr["收款人"] = dr[1];
                    resultdr["放款金额"] = dr[3];
                    resultdt.Rows.Add(resultdr);
                }
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                //if (ds.Tables[1].Rows.Count > 0)
                //{
                //    resultdt.Rows.Add(resultdt.NewRow());

                //    DataRow resultdrTitle = resultdt.NewRow();
                //    resultdrTitle["支付方式"] = "支付方式";
                //    resultdrTitle["收款人开户行"] = "放款银行";
                //    resultdrTitle["收款人账号"] = "放款帐户号";
                //    resultdrTitle["收款人"] = "自主支付金额";
                //    resultdrTitle["受托支付金额"] = "";
                //    resultdt.Rows.Add(resultdrTitle);

                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        DataRow resultdr = resultdt.NewRow();
                        resultdr["支付方式"] = "自主支付";
                        resultdr["放款银行"] = dr[3];
                        resultdr["放款账号"] = dr[1];
                        resultdr["收款人"] = "";
                        resultdr["放款金额"] = dr[2];
                        resultdt.Rows.Add(resultdr);
                    }
                //}
                //else
                //{
                //    resultdt.Columns.Add("支付方式");
                //    resultdt.Columns.Add("放款银行");
                //    resultdt.Columns.Add("放款帐户号");
                //    resultdt.Columns.Add("自主支付金额");

                //    foreach (DataRow dr in ds.Tables[0].Rows)
                //    {
                //        DataRow resultdr = resultdt.NewRow();
                //        resultdr["支付方式"] = "自主支付";
                //        resultdr["放款银行"] = dr[3];
                //        resultdr["放款帐户号"] = dr[1];
                //        resultdr["自主支付金额"] = dr[2];
                //        resultdt.Rows.Add(resultdr);
                //    }
                //}
            }

            return resultdt;
        }

        public string GetCollateralTypeByAppId(string appId)
        {
          return LoanDao.GetCollateralTypeByAppId(appId);
        }

        public string GetMortgageCountByAppId(string appId)
        {
            return LoanDao.GetMortgageCountByAppId(appId);
        }

        public bool SaveLoanApproval(T_PL_LoanApproval Entity)
        {
            return LoanDao.SaveLoanApproval(Entity);
        }

        public bool UpdateLoanInfoAndInsertRecordIntoLoanApproval(string appId,  string processorId)
        {
            return LoanDao.UpdateLoanInfoAndInsertRecordIntoLoanApproval(appId,processorId);
        }
    }
}
