﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Bll.application
{
    public class ApplicationHandler : IApplicationHandler
    {
        #region all Dao
        public IApplicationDao ApplicationDao { get; set; }
        #endregion

        public CommonTResult<ProductListView> GetNPProductList(string AppId)
        {
            CommonTResult<ProductListView> result = null;
            CommonTResult<ProductListView> resultDao =ApplicationDao.GetNPProductList(AppId);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<ProductListView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }
       
        public T_PL_Application GetApplicationByAppId(Guid appID)
        {
            return ApplicationDao.GetApplicationByAppId(appID);
        }
       
        public ApplicationDetail GetApplicationDetail(Guid appID, int stageID)
        {
            return ApplicationDao.GetApplicationDetail(appID, stageID);
        }

        public int SaveApplicationByAppId(T_PL_Application entity)
        {
            return ApplicationDao.SaveApplicationByAppId(entity);
        }

        public bool SaveOtherInfo(OtherView entity)
        {
            if (entity.PolicyReason != "" && entity.PolicyReason!=null)
            {
                entity.PolicyDeviation = "1";
            }
            else {
                entity.PolicyDeviation = "0";
            }
            if (entity.PriceReason != "" && entity.PriceReason!=null)
            {
                entity.PriceDeviation = "1";
            }
            else
            {
                entity.PriceDeviation = "0";
            }
            if (entity.ProcessReason != "" && entity.ProcessReason!=null)
            {
                entity.ProcessDeviation = "1";
            }
            else
            {
                entity.ProcessDeviation = "0";

            }
            return ApplicationDao.SaveOtherInfo(entity);
        }

        public CommonTResult<OtherView> GetOtherInfo(string appId)
        {
            return ApplicationDao.GetOtherInfo(appId);
        }

        public bool UpdateAppSubmit(string appId, string prodId, string submited, string proposalLoanSize, string proposalTenor, string productRate ,string baseRate, string avaliableLTV)
        {
            return ApplicationDao.UpdateAppSubmit(appId, prodId, submited, proposalLoanSize, proposalTenor,productRate, baseRate, avaliableLTV);
        }

        public bool UpdateDeviationed(string appId, string prodId)
        {
            return ApplicationDao.UpdateDeviationed(appId, prodId);
        }

        public bool UpdateRateDeviationed(string appId, string rateDeviationed)
        {
            return ApplicationDao.UpdateRateDeviationed(appId, rateDeviationed);
        }

        public string GetApplicationNoByAppId(string appId)
        {
            return ApplicationDao.GetApplicationNoByAppId(appId);
        }        public T_PL_Application GetApplicationByAppNo(string ApplicationNo, string OrgCode, string CreatorID)
        {
            return ApplicationDao.GetApplicationByAppNo(ApplicationNo, OrgCode, CreatorID);
        }

        public bool IsSystemDecided(string appId, string stageId)
        {
            return ApplicationDao.IsSystemDecided(appId,stageId);
        }

        public bool CheckSingleBo(string appId, string borrowType)
        {
            return ApplicationDao.CheckSingleBo(appId, borrowType);
        }

        public CommonTResult<DocumentItem> GetDocumentList(string strCustType, string strProdID, string custSegment)
        {
            return ApplicationDao.GetDocumentList(strCustType, strProdID, custSegment);
        }

        public String GetProdNameByProdId(string prodId) {

            return ApplicationDao.GetProdNameByProdId(prodId);
        }

        public string GetOrgCodeByAppId(string appId)
        {
            return ApplicationDao.GetOrgCodeByAppId(appId);
        }

        public string GetAppIdByApplicationNo(string applicationNo) {
            return ApplicationDao.GetAppIdByApplicationNo(applicationNo);
        }
    }
}
