﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.application
{
    public class TopuploadHandler : ITopuploadHandler
    {
        public ITopuploadDao TopuploadDao { get; set; }

        public CommonResult UploadBatchTopup(Stream stream, String maker)
        {
            CommonResult result = new CommonResult();
            int effectRows = 0, count = 0;
            T_PL_TopupUploadMaker topupUploadMaker = null;
            ExcelUtility ExcelUtility = new ExcelUtility();
            DataTable dt = ExcelUtility.ReadFirstSheetData(stream);

            if (dt == null || dt.Rows.Count == 0 || dt.Columns.Count == 0) {
                result.IsSuccess = false;
                result.Message = StringResources.NODATA;
                return result;
            }
            //Check if file is valid,Import data into DB.
            if (this.CheckTemplateFile(dt))
            {
                foreach (DataRow dr in dt.Rows)
                {
                    if (dr[0] == null || String.IsNullOrEmpty(Convert.ToString(dr[0])))
                    {
                        continue;
                    }
                    if (Convert.ToString(dr[0]) == "必填")
                    {
                        continue;
                    }
                    topupUploadMaker = new T_PL_TopupUploadMaker();
                    topupUploadMaker.AgentCode = Convert.ToString(dr[0]);
                    topupUploadMaker.OrgApplicationNo = Convert.ToString(dr[1]);
                    topupUploadMaker.ReportType = Convert.ToString(dr[2]);
                    topupUploadMaker.MainBorrower = Convert.ToString(dr[3]);
                    topupUploadMaker.ID_No = Convert.ToString(dr[4]);
                    topupUploadMaker.TopUpApprovedLoanSize = Convert.ToDecimal(dr[5]);
                    topupUploadMaker.TopUpRate = Convert.ToDecimal(dr[6]);
                    topupUploadMaker.TopUpApprovedTenor = Convert.ToInt32(dr[7]);
                    topupUploadMaker.TopUpSegment = Convert.ToString(dr[8]);
                    topupUploadMaker.AddressType = Convert.ToString(dr[9]);
                    topupUploadMaker.ZipCode = Convert.ToString(dr[10]);
                    topupUploadMaker.AddProvince = Convert.ToString(dr[11]);
                    topupUploadMaker.AddCity = Convert.ToString(dr[12]);
                    topupUploadMaker.AddArea = Convert.ToString(dr[13]);
                    topupUploadMaker.AddStreet = Convert.ToString(dr[14]);
                    topupUploadMaker.MainBorrowerSpouse = Convert.ToString(dr[15]);
                    topupUploadMaker.MainBorrowerSpouseID = Convert.ToString(dr[16]);
                    topupUploadMaker.LoanPrupose = Convert.ToString(dr[17]);
                    topupUploadMaker.LoanIndustry = Convert.ToString(dr[18]);
                    topupUploadMaker.Status = 1;
                    topupUploadMaker.Maker = maker;

                    effectRows += TopuploadDao.AddTopupDataOverBatch(topupUploadMaker);
                    count++;
                }
                if (effectRows == 0 && count == 0)
                {
                    result.IsSuccess = false;
                    result.Message += StringResources.NODATA;
                }
                else if (effectRows == count)
                {
                    result.IsSuccess = true;
                    result.Message = StringResources.OPERATION_UPLOAD_FILE_SUCCESS;
                }
                else
                {
                    result.IsSuccess = false;
                    result.Message += StringResources.OPERATION_UPLOAD_FILE_FAILED;
                }
            }
            else {
                result.IsSuccess = false;
                result.Message += StringResources.INCORRECTFILE;
            }
            return result;
        }

        public CommonTResult<T_PL_TopupUploadMaker> GetTopupUploadMaker(int limit, int start, T_PL_TopupUploadMaker topup)
        {
            CommonTResult<T_PL_TopupUploadMaker> result = null;
            CommonTResult<T_PL_TopupUploadMaker> resultDao = TopuploadDao.GetTopupUploadMakerList(limit, start, topup);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_TopupUploadMaker>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonResult ApproveTopupUploadMaker(string ids, string checker)
        {
            CommonResult result = new CommonResult();
            int count = 0;

            string[] tids = ids.Split(',');
            foreach (string tid in tids)
            {
                if (TopuploadDao.ApproveTopuploadMaker(new Guid(tid), checker))
                {
                    count++;
                }
            }
            if (tids.Length == count)
            {
                result.IsSuccess = true;
                result.Message = StringResources.OPERATION_APPROVE_SUCCESS;
            }
            else
            {
                result.IsSuccess = false;
                result.Message += StringResources.OPERATION_APPROVE_FAILED;
            }
            return result;
        }

        public bool RejectTopuploadMaker(string ids, string checker)
        {
            return TopuploadDao.RejectTopuploadMaker(ids, checker);
        }

        #region CheckTemlateFile
        private bool CheckTemplateFile(DataTable dt) {

            bool result = true;
            Array enumItems = Enum.GetValues(typeof(TemplateColumn));
            foreach (DataColumn dc in dt.Columns)
            {
                //System.Diagnostics.Debug.WriteLine(dc.ColumnName);
                //System.Diagnostics.Debug.WriteLine(Enum.GetName(typeof(TemplateColumn), 0));
                //Enum.GetName(typeof(TemplateColumn), 0);
                int count = 0;
                foreach (TemplateColumn ColumnCode in enumItems)
                {
                    //System.Diagnostics.Debug.WriteLine(ColumnCode);
                    if (this.GetTemplateColumn(ColumnCode) == dc.ColumnName)
                    {
                        break;
                    }
                    count++;
                }
                if (enumItems.Length == count) {
                    result = false;
                }
                if (!result) {
                    break;
                }
            }
            return result;
        }
        private enum TemplateColumn
        {
            AgentCode = 0,
            OrgApplicationNo = 1,
            ReportType = 2,
            MainBorrower = 3,
            ID_No = 4,
            TopUpApprovedLoanSize = 5,
            TopUpRate = 6,
            TopUpApprovedTenor = 7,
            TopUpSegment = 8,
            AddressType = 9,
            ZipCode = 10,
            AddProvince = 11,
            AddCity = 12,
            AddArea = 13,
            AddStreet = 14,
            MainBorrowerSpouse = 15,
            MainBorrowerSpouseID = 16,
            LoanPrupose = 17,
            LoanIndustry = 18
        }
        private string GetTemplateColumn(TemplateColumn code)
        {
            string result = string.Empty;
            switch (code)
            {
                case TemplateColumn.AgentCode:
                    result = "客户经理编号";
                    break;
                case TemplateColumn.OrgApplicationNo:
                    result = "原申请编号";
                    break;
                case TemplateColumn.ReportType:
                    result = "报表分类（编号）";
                    break;
                case TemplateColumn.MainBorrower:
                    result = "主贷人";
                    break;
                case TemplateColumn.ID_No:
                    result = "主贷人证件号码";
                    break;
                case TemplateColumn.TopUpApprovedLoanSize:
                    result = "Topup批准额度";
                    break;
                case TemplateColumn.TopUpRate:
                    result = "Topup年利率";
                    break;
                case TemplateColumn.TopUpApprovedTenor:
                    result = "Topup贷款期数（月）";
                    break;
                case TemplateColumn.TopUpSegment:
                    result = "Topup客户类别";
                    break;
                case TemplateColumn.AddressType:
                    result = "通讯地址类别";
                    break;
                case TemplateColumn.ZipCode:
                    result = "联系地址邮政编码";
                    break;
                case TemplateColumn.AddProvince:
                    result = "联系地址(省)";
                    break;
                case TemplateColumn.AddCity:
                    result = "联系地址(市)";
                    break;
                case TemplateColumn.AddArea:
                    result = "联系地址(区)";
                    break;
                case TemplateColumn.AddStreet:
                    result = "联系地址(详细街道)";
                    break;
                case TemplateColumn.MainBorrowerSpouse:
                    result = "主贷人配偶";
                    break;
                case TemplateColumn.MainBorrowerSpouseID:
                    result = "主贷人配偶证件号码";
                    break;
                case TemplateColumn.LoanPrupose:
                    result = "贷款用途";
                    break;
                case TemplateColumn.LoanIndustry:
                    result = "贷款投向";
                    break;
                default:
                    result = "未知";
                    break;
            }
            return result;
        }
        #endregion
    }
}
