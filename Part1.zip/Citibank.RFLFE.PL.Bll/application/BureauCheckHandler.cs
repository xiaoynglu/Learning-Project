﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.IO;
using System.Data;

namespace Citibank.RFLFE.PL.Bll.application
{
    public class BureauCheckHandler : IBureauCheckHandler
    {
        public IBureauCheckDao BureauCheckDao { get; set; }
        public IReportGenOrImportDao ReportGenOrImportDao { get; set; }

        public CommonTResult<T_PL_BureauInfo> QueryPersonalInfoByIdAndAppId(string AppId, string ID_NUMBER)
        {
            CommonTResult<T_PL_BureauInfo> result = new CommonTResult<T_PL_BureauInfo>();
            try
            {
                result = BureauCheckDao.QueryPersonalInfoByIdAndAppId(AppId, ID_NUMBER);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_PBOC_LoanDetail> GetBureauLoanDetails(string ID_NUMBER, string IMPORT_DATE, int start, int limit)
        {
            CommonTResult<T_PL_PBOC_LoanDetail> result = new CommonTResult<T_PL_PBOC_LoanDetail>();
            try
            {
                result = BureauCheckDao.GetBureauLoanDetails(ID_NUMBER, IMPORT_DATE, start, limit);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_PBOC_CreditCardDetail> GetBureauCardDetails(string ID_NUMBER, string IMPORT_DATE, int start, int limit)
        {
            CommonTResult<T_PL_PBOC_CreditCardDetail> result = new CommonTResult<T_PL_PBOC_CreditCardDetail>();
            try
            {
                result = BureauCheckDao.GetBureauCardDetails(ID_NUMBER, IMPORT_DATE, start, limit);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_BureauCustInfo> DownloaderBureauQueryFile(string AppID, ref string FileName)
        {
            CommonTResult<T_PL_BureauCustInfo> result = new CommonTResult<T_PL_BureauCustInfo>();
            try
            {
                result = BureauCheckDao.GetCustInfoByAppID(AppID);

                if (result.ResultList.Count > 0)//生成查询txt文件
                {
                    StringBuilder fileContect = new StringBuilder();
                    foreach (T_PL_BureauCustInfo cust in result.ResultList)
                    {
                        fileContect.AppendFormat("{0}|{1}|{2}|{3}|{4}\r\n", cust.AppID, DateTime.Now.ToString("yyyy/MM/dd").Replace("-", "/"), "0", cust.IDNo, cust.FullName);
                        if (!string.IsNullOrEmpty(cust.FormerName))//如果客户存在曾用名，则曾用名也生成一条查询记录
                        {
                            fileContect.AppendFormat("{0}|{1}|{2}|{3}|{4}\r\n", cust.AppID, DateTime.Now.ToString("yyyy/MM/dd").Replace("-", "/"), "0", cust.IDNo, cust.FormerName);
                        }
                    }
                    FileName = AppDomain.CurrentDomain.BaseDirectory + "ViewPBOCHtml\\" + "CNRF_LFE-QueryList" + DateTime.Now.ToString("hhmmsss") + ".txt";
                    
                    if (!FileDownloadUtility.DownloadFile(FileName, fileContect))
                    {
                        result.IsSuccess = false;
                        result.Message = "生成征信清单文件失败！";
                    }
                }
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public bool DownloaderQueryList(List<T_PL_QueryList> custInfos, ref string FileName)
        {
            try
            {
                StringBuilder fileContect = new StringBuilder();
                foreach (T_PL_QueryList cust in custInfos)
                {
                    fileContect.AppendFormat("{0}|{1}|{2}|{3}|{4}\r\n", cust.AppID, cust.QueryDate, cust.QueryPurpose, cust.IDNo, cust.FullName);
                }
                FileName = AppDomain.CurrentDomain.BaseDirectory + "ViewPBOCHtml\\" + "CNRF_LFE-QueryList" + DateTime.Now.ToString("hhmmsss") + ".txt";

                if (!FileDownloadUtility.DownloadFile(FileName, fileContect))
                {
                    return false;
                }

            }
            catch (Exception ex)
            {
                return false;
            }
            return true;
        }

        public CommonResult UpdateBureauQueryStatus(List<T_PL_QueryList> custInfos)
        {
            CommonResult result = new CommonResult();
            try
            {
                //DataTable table = CommonHelper.ConvertIListToDataTable(custInfos);
                result = BureauCheckDao.UpdateBureauQueryStatus(custInfos);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_BureauCustInfo> GetQueryListByAppID(string AppID)
        {
            CommonTResult<T_PL_BureauCustInfo> result = new CommonTResult<T_PL_BureauCustInfo>();
            try
            {
                result = BureauCheckDao.GetCustInfoByAppID(AppID);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_PBOC_PersonalInfo> GetBureauHTMLFileName(string AppID, string ID_NUMBER, int Flag, ref string FileName)
        {
            CommonTResult<T_PL_PBOC_PersonalInfo> result = new CommonTResult<T_PL_PBOC_PersonalInfo>();
            try
            {
                result = BureauCheckDao.GetBureauHTMLFileName(AppID, ID_NUMBER);

                if (result.ResultList.Count > 0)
                {
                    //HTML报告文件名
                    string strOutFile = AppID + "_" + result.ResultList[0].CertType + "_" + ID_NUMBER + ".htm";
　　                //copy html file from pboc folder to bureau folder

                    CommonTResult<T_Sys_PathConfiguration> pathConfig = ReportGenOrImportDao.GetPathConfigByName("PBOC");
                    if (pathConfig.ResultList.Count > 0)
                    {                        
                        string path = pathConfig.ResultList.Where(P => P.FileNameKeyword == "htm").ToList()[0].ShareFilePath;
                        string[] filedir = Directory.GetFiles(path, "*"+strOutFile, SearchOption.AllDirectories);
                        if (filedir.Length > 0)
                        {
                            if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + "ViewPBOCHtml"))
                            {
                                Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "ViewPBOCHtml");
                            }
                            string localPath = AppDomain.CurrentDomain.BaseDirectory + "ViewPBOCHtml\\" + AppID + ID_NUMBER + ".html";
                            if (Flag == 1) //强制刷新则从服务器上拿最新文件
                            {
                                File.Copy(filedir[0], localPath, false);
                            }
                            else//正常情况则先判断本地是否存在，若存在则直接从本地取；若不存在，则从服务器取
                            {
                                if (!File.Exists(localPath))
                                {
                                    File.Copy(filedir[0], localPath, false);
                                }
                            }
                            FileName = localPath;
                        }
                        else
                        {
                            result.IsSuccess = false;
                            result.Message = "HTML源文件不存在！";
                        }
                    }
                    else
                    {
                        result.IsSuccess = false;
                        result.Message = "查看HTML报告失败！";
                    }
                }
                else
                {
                    result.IsSuccess = false;
                    result.Message = "查看HTML报告失败！";
                }
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonTResult<T_PL_BureauInfo> RefreshBureauBasicInfo(string AppID, string ID_NUMBER)
        {
            CommonTResult<T_PL_BureauInfo> result = new CommonTResult<T_PL_BureauInfo>();
            CommonTResult<T_PL_PBOC_PersonalInfo> resultHTML = new CommonTResult<T_PL_PBOC_PersonalInfo>();
            try
            {
                //刷新数据
                result = BureauCheckDao.RefreshBureauBasicInfo(AppID, ID_NUMBER);                
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }

        public CommonResult SaveBureauBasicInfo(T_PL_BureauInfo info)
        {
            CommonResult result = new CommonResult();
            try
            {
                result = BureauCheckDao.SaveBureauBasicInfo(info);
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = ex.Message;
            }
            return result;
        }
    }
}
