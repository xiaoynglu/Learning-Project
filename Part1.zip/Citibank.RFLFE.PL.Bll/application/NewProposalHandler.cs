﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Mvc.Models;
using System.Reflection;
using System.Configuration;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using System.Xml.Linq;
using DocumentFormat.OpenXml.Wordprocessing;
using Citibank.RFLFE.PL.Bll.disbursement;
using Citibank.RFLFE.PL.Bll.common;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;

namespace Citibank.RFLFE.PL.Bll.application
{
    public class NewProposalHandler : INewProposalHandler
    {
        public INewProposalDao NewProposalDao { get; set; }
        public ICustomerDao CustomerDao { get; set; }
        Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);

        public CommonTResult<ProductListView> GetNPProductList(string AppId)
        {
            CommonTResult<ProductListView> result = null;
            CommonTResult<ProductListView> resultDao = NewProposalDao.GetNPProductList(AppId);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<ProductListView>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_PL_LTVFactors> GetLTVFactors(string AppId)
        {
            CommonTResult<T_PL_LTVFactors> result = null;
            CommonTResult<T_PL_LTVFactors> resultDao = NewProposalDao.GetLTVFactors(AppId);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_LTVFactors>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public bool UpdateMortgagorInfo(T_PL_Mortgagors entity)
        {
            return NewProposalDao.UpdateMortgagorInfo(entity);
        }

        public CommonTResult<T_PL_Collateral> GetCustCollateralInfoByAppId(string AppId)
        {
            CommonTResult<T_PL_Collateral> result = null;
            CommonTResult<T_PL_Collateral> resultDao = NewProposalDao.GetCustCollateralInfoByAppId(AppId);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_Collateral>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_PL_Customers> GetCustBasicInfo(string AppId)
        {
            CommonTResult<T_PL_Customers> result = null;
            CommonTResult<T_PL_Customers> resultDao = NewProposalDao.GetCustBasicInfo(AppId);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_Customers>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public CommonTResult<T_PL_Customers> GetCustInfo(string AppId)
        {
            CommonTResult<T_PL_Customers> result = null;
            CommonTResult<T_PL_Customers> resultDao = NewProposalDao.GetCustInfo(AppId);
            if (resultDao.ResultList != null)
            {
                result = new CommonTResult<T_PL_Customers>()
                {
                    ResultList = resultDao.ResultList,
                    ResultCount = resultDao.ResultCount,
                    IsSuccess = true,
                    Message = StringResources.GETDATA_SUCCESS
                };
            }
            return result;
        }

        public DownloadFileResult PrintAppFrom(string appId, string prodName, string appNo, List<String> loanParamList, string stageId)
        {
            string servicePath = CommonUtility.ProposalAppFormPath();//C:\My Files\Print\temp\
            string fileClientPath = CommonUtility.ClientPath();//C:\My Files\Print\
            string applicationEmpDocFileName = CommonUtility.ApplicationEmpAppFormDocName();
            string applicationSalDocFileName = CommonUtility.ApplicationSalAppFormDocName();
            string applicationCB2DocFileName = CommonUtility.ApplicationCB2AppFormDocName();

            string templateFile = string.Empty; //Source File
            string tempTemplateFile = "";
            string tempCB2TemplateFile ="";
            string reuseTemplate = string.Empty; // Destination File
            string reuse03Template = string.Empty; // Destination File
            
            var customerList = CustomerDao.GetCustomers(appId, "");
            var employementType = "";

            CustAndContractHandler CustAndContractHandler = new CustAndContractHandler(); 
            DataTable dataTable = NewProposalDao.GetPrintApplicationFormDataSource(appId);
            DownloadFileResult fileResult = new DownloadFileResult();
            //本地文件配置
            if (!Directory.Exists(fileClientPath)) //Create ouput folder
            {
                Directory.CreateDirectory(fileClientPath);
            }
            if (customerList != null)
            {
                employementType = customerList.ResultList.Where(i => i.BorrowType ==Constants.BorrowType_MB).FirstOrDefault().EmploymentType.ToString();
            }

            for (var i = 0; i < dataTable.Columns.Count; i++) {
                if (dataTable.Columns[i].ToString() == "LoanSize_C_MB_") {
                    if (dataTable.Rows[0][i].ToString() != "" && dataTable.Rows[0][i].ToString() != null) {
                        dataTable.Rows[0][i] = CustAndContractHandler.Arabia_to_Chinese(decimal.Parse(dataTable.Rows[0][i].ToString()));
                    }
                }
            }
                if (dataTable != null && dataTable.Rows.Count > 0)
                {
                    if (employementType ==Constants.G_EmploymentType)
                    {
                        templateFile = servicePath + applicationSalDocFileName;
                        reuseTemplate = fileClientPath + applicationSalDocFileName.Substring(0, applicationSalDocFileName.Length - 5) + "_" + DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat7) + Constants.docSuffixName;
                        tempTemplateFile = fileClientPath + applicationSalDocFileName.Substring(0, applicationSalDocFileName.Length - 5) + "_" + DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat7) + "_reuse" + Constants.docSuffixName;
                    }
                    else if (employementType ==Constants.Q_EmploymentType)
                    {
                        templateFile = servicePath + applicationEmpDocFileName;
                        reuseTemplate = fileClientPath + applicationEmpDocFileName.Substring(0, applicationEmpDocFileName.Length - 5) + "_" + DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat7) + Constants.docSuffixName;
                        tempTemplateFile = fileClientPath + applicationEmpDocFileName.Substring(0, applicationEmpDocFileName.Length - 5) + "_" + DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat7) + "_reuse" + Constants.docSuffixName;
                    }

                    File.Copy(templateFile, tempTemplateFile, true);
                    new CommonUtility(tempTemplateFile).MailMerge(dataTable, reuseTemplate, true);
                    File.Delete(tempTemplateFile);
                    if (customerList.ResultList.Count == 3)
                    {
                        templateFile = servicePath + applicationCB2DocFileName;
                        reuse03Template = fileClientPath + applicationCB2DocFileName.Substring(0, applicationCB2DocFileName.Length - 5) + "_" + DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat7) + Constants.docSuffixName;
                        tempCB2TemplateFile = fileClientPath + applicationCB2DocFileName.Substring(0, applicationCB2DocFileName.Length - 5) + "_" + DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat7) + "_reuse" + Constants.docSuffixName;
                        File.Copy(templateFile, tempCB2TemplateFile, true);
                        new CommonUtility(tempCB2TemplateFile).MailMerge(dataTable, reuse03Template, true);
                        using (WordprocessingDocument OutPutFile = WordprocessingDocument.Open(reuseTemplate, true))
                        {
                            using (WordprocessingDocument output = WordprocessingDocument.Open(reuse03Template, true))
                            {
                                XElement newBody = XElement.Parse(output.MainDocumentPart.Document.Body.OuterXml);
                                Body bo = new Body(newBody.ToString());
                                OutPutFile.MainDocumentPart.Document.Body.AppendChild<Body>(bo);
                                OutPutFile.MainDocumentPart.Document.Save();
                            }
                        }
                        File.Delete(reuse03Template);
                        File.Delete(tempCB2TemplateFile);
                    }
                    FileInfo file = new FileInfo(reuseTemplate);
                    if (System.IO.File.Exists(file.FullName))
                    {
                        fileResult.ContentType =Constants.MimeType.msWord;
                        fileResult.FileContents = FileDownloadUtility.DownloadFile(file.FullName);
                        fileResult.FileDownloadName = file.FullName;
                    }
                }
            return fileResult;
        }

        public bool CheckSingleBo(string appId, string borrowType)
        {
            return NewProposalDao.CheckSingleBo(appId, borrowType);
        }

        public bool IsSystemDecided(string appId)
        {
            return NewProposalDao.IsSystemDecided(appId);
        }

        public CommonTResult<DocumentItem> GetDocumentList(string strCustType, string strProdID, string custSegment)
        {
            return NewProposalDao.GetDocumentList(strCustType, strProdID, custSegment);
        }

        public CommonTResult<T_PL_Customers> GetPreviouseCasesByIDNo(string IdNo,string appNo)
        {
            return NewProposalDao.GetPreviouseCasesByIDNo(IdNo, ParamKeyDictionary.BorrowType_MB, appNo);
        }

        public bool CopyCoLoanerInfoByAppID(string oldAppId, string newAppId)
        {
            return NewProposalDao.CopyCoLoanerInfoByAppID(oldAppId,newAppId);
        }       

        public bool CopyFinanceInfoToNextStage(string appId, string currentStage, string nextStage)
        {
            return NewProposalDao.CopyFinanceInfoToNextStage(appId, currentStage, nextStage);
        }
    }
}
