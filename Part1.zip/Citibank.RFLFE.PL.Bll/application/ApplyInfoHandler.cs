﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Data;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Bll.application
{
    public class ApplyInfoHandler : IApplyInfoHandler
    {
        public IApplyInfoDao ApplyInfoDao { get; set; }

        public CommonTResult<ApplyInfoDetail> GetApplyInfoDetail(string appNo, string fullName, string idNo, bool isChecker, string maker)
        {
            return ApplyInfoDao.GetApplyInfoDetail(appNo, fullName, idNo, isChecker, maker);
        }

        public int SaveNosOfCollateralMaker(Guid AppID, string RightNoOfLand, string PropertyPermits, string maker) {
            return ApplyInfoDao.SaveNosOfCollateralMaker(AppID,RightNoOfLand, PropertyPermits, maker);
        }

        public int SaveLoanIndustryMaker(T_PL_LoanIndustryMaker entity) {
            return ApplyInfoDao.SaveLoanIndustryMaker(entity);
        }

        public bool ApproveNosOfCollateralMaker(Guid AppID, string RightNoOfLand, string PropertyPermits, string checker) {
            return ApplyInfoDao.ApproveNosOfCollateralMaker(AppID, RightNoOfLand, PropertyPermits, checker);
        }

        public bool RejectNosOfCollateralMaker(Guid AppID, string RightNoOfLand, string PropertyPermits, string checker)
        {
            return ApplyInfoDao.RejectNosOfCollateralMaker(AppID, RightNoOfLand, PropertyPermits, checker);
        }

        public bool ApproveLoanIndustryMaker(Guid AppID, string checker)
        {
            return ApplyInfoDao.ApproveLoanIndustryMaker(AppID, checker);
        }

        public bool RejectLoanIndustryMaker(Guid AppID, string checker)
        {
            return ApplyInfoDao.RejectLoanIndustryMaker(AppID, checker);
        }

        public bool ApproveMortgagorMaker(Guid AppID, string checker)
        {
            return ApplyInfoDao.ApproveMortgagorMaker(AppID, checker);
        }

        public bool RejectMortgagorMaker(Guid AppID, string checker)
        {
            return ApplyInfoDao.RejectMortgagorMaker(AppID, checker);
        }
    }
}
