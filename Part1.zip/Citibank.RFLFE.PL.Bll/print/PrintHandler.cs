﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework;
using System.IO;
using System.Data;
using Citibank.RFLFE.PL.IDal;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;

namespace Citibank.RFLFE.PL.Bll.print
{
    public class PrintHandler : IPrintHandler
    {
        #region Properties
        public IPrintDao PrintDao { get; set; }
        public IReportGenerateHandler GenerateHandler = null;
        IList<T_Sys_PathConfiguration> ShareFolderPath = null;
        string RootPath = AppDomain.CurrentDomain.BaseDirectory;
        string strCondition = "";
        string expression = "";
        string strServerFile = "";
        string OutputFileName = "";
        FileInfo OutputFile = null;
        string date = DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat4);
        int count = 0;
        bool isExisted = false;
        #endregion

        public CommonResult GetPrintFile(string fileType)
        {
            CommonResult result = new CommonResult();
            //本地文件配置

            string OutputPath = String.Format(@"{0}Temp\{1}", RootPath, fileType);
            if (!Directory.Exists(OutputPath)) //Create ouput folder
            {
                Directory.CreateDirectory(OutputPath);
            }

            //清空本地之前的记录

            string[] OutputFiles = Directory.GetFiles(OutputPath);
            if (OutputFiles != null && OutputFiles.Length > 0)
            {
                foreach (string item in OutputFiles)
                {
                    File.Delete(item); 
                }
            }

            try
            {
                //map
                bool flag = CommonUtility.MapPath(GenerateHandler, fileType, ref ShareFolderPath);
                if (!flag)
                {
                    result.IsSuccess = false;
                    return result;
                }

                //获取条件数据
                DataTable condition = PrintDao.GetPrintCondtion(fileType);
                if (condition == null || condition.Rows.Count < 1)
                {
                    result.IsSuccess = false;
                    return result;
                }
                Dictionary<string, Dictionary<string, string>> condtions = GetPrintCondtions(fileType);

                for (int i = 0; i < ShareFolderPath.Count; i++)
                {
                    DataTable dt = null;
                    DataRow[] drs;
                    string fileTypes = ShareFolderPath[i].Type;
                    //开始下载模板
                    CommonTResult<T_PL_MergeDefination> Def = PrintDao.GetMergeDefinationByJobType(fileTypes);
                    string TemplateName = String.Format("{0}{1}", Convert.ToString(ShareFolderPath[i].FileNameKeyword), Convert.ToString(ShareFolderPath[i].FileFormat));
                    string ServerTemplatePath = String.Format(@"{0}\{1}", Convert.ToString(ShareFolderPath[i].ImpOrGenerateFilePath), TemplateName);
                    string LocalTemplatePath = String.Format(@"{0}\{1}", OutputPath, TemplateName);
                    FileInfo SourceTemplateFile = new FileInfo(ServerTemplatePath);
                    if (SourceTemplateFile.Exists)
                    {
                        File.Copy(SourceTemplateFile.FullName, LocalTemplatePath, true);
                    }
                    else
                    {
                        result.IsSuccess = false;
                        return result;
                    }

                    //获取数据
                    dt = PrintDao.GetSourceDate(fileTypes);
                    DataTable dtNew = dt.Clone();
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        for (int j = 0; j < condition.Rows.Count; j++)
                        {
                            //满足条件的数据生成doc
                            strCondition = Convert.ToString(condition.Rows[j].ItemArray[0]);
                            if (condtions.ContainsKey(strCondition))
                            {
                                count = 1;

                                foreach (string key in condtions[strCondition].Keys)
                                {
                                    expression = string.Format("{0}='{1}' AND {2}='{3}'", ShareFolderPath[i].BackUpFilePath, strCondition, ShareFolderPath[i].ImportOrGenerateFunction, condtions[strCondition][key]);
                                    drs = dt.Select(expression);                                    

                                    if (drs.Length > 0)
                                    {
                                        dtNew = drs.CopyToDataTable();
                                        string strcondition = GetMergeFilePath(strCondition);
                                        string strServerFath = String.Format(@"{0}{1}", ShareFolderPath[i].ShareFilePath.ToString(), strcondition);
                                        if (!Directory.Exists(strServerFath)) //Create folder
                                        {
                                            Directory.CreateDirectory(strServerFath);
                                        }
                                        if (isExisted)
                                        {
                                            OutputFileName = TemplateName.Replace(".docx", string.Format("_{0}_{1}_{2}{3}", date, DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat9), count.ToString(), ShareFolderPath[i].FileFormat.ToString()));
                                        }
                                        else
                                        {
                                            if (fileTypes == "PrintAnnual" || fileTypes == "PrintInterest")
                                            {
                                                OutputFileName = TemplateName.Replace(".docx", string.Format("{0}_{1}{2}", DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat4), key, ShareFolderPath[i].FileFormat.ToString()));
                                            }
                                            else
                                            {
                                                OutputFileName = TemplateName.Replace(".docx", string.Format("{0}_{1}{2}", DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat4), count.ToString(), ShareFolderPath[i].FileFormat.ToString()));
                                            }
                                        }
                                        strServerFile = String.Format(@"{0}\{1}", strServerFath, OutputFileName);
                                        string OutputFilePath = String.Format(@"{0}\{1}{2}{3}", OutputPath, Convert.ToString(ShareFolderPath[i].FileNameKeyword), DateTime.Now.ToString(Constants.DateTimeFormat.DateTimeFormat4), Convert.ToString(ShareFolderPath[i].FileFormat));
                                        //Merge
                                        count += new CommonUtility(LocalTemplatePath).MailMerge(dtNew, OutputFilePath,true);
                                        //上传服务器
                                        OutputFile = new FileInfo(String.Format("{0}", OutputFilePath));
                                        File.Copy(OutputFile.FullName, strServerFile, true);
                                        //更新文件merge状态
                                        PrintDao.UpLoanMergeStatus(fileTypes, strCondition, condtions[strCondition][key]);
                                        
                                    }
                                }
                            }
                        }
                    }
                }
                result.IsSuccess = true;
                return result;
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                return result;
            }
        }

        public Dictionary<string, Dictionary<string, string>> GetPrintCondtions(string fileType)
        {
            Dictionary<string, Dictionary<string, string>> condtions = new Dictionary<string, Dictionary<string, string>>();

            try
            {
                DataTable dt = PrintDao.GetPrintCondtionsTable(fileType);

                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        if (condtions.ContainsKey(dr["Condition1"].ToString()))
                        {
                            if (!condtions[dr["Condition1"].ToString()].ContainsKey(dr["Condition2"].ToString()))
                            {
                                condtions[dr["Condition1"].ToString()].Add(dr["Condition2"].ToString(), dr["Condition2"].ToString());
                            }
                        }
                        else
                        {
                            Dictionary<string, string> importData = new Dictionary<string, string>();
                            importData.Add(dr["Condition2"].ToString(), dr["Condition2"].ToString());
                            condtions.Add(dr["Condition1"].ToString(), importData);
                        }
                    }
                }
                return condtions;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public string GetMergeFilePath(string strBranchCode)
        {
            switch (strBranchCode)
            {
                case "301":
                    strBranchCode =Constants.Branch.GA;
                    break;
                case "302":
                    strBranchCode = Constants.Branch.CB;
                    break;
                case "303":
                    strBranchCode = Constants.Branch.WFD;
                    break;
                case "304":
                    strBranchCode = Constants.Branch.BB;
                    break;
            }
            return strBranchCode;
        }
    }
}
