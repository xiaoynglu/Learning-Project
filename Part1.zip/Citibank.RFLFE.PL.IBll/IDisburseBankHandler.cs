﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IDisburseBankHandler
    {
        CommonTResult<T_PL_DisburseBankMaker> GetDisburseBankList(int limit, int start, string name, string alias, string status);

        int AddOrUpdateDisburseBank(string name,string alias,string id,int optype,string soeid);

        bool DeleteDisburseBank(string id);

        bool ApproveItem(string ids, string checker);

        bool RejectItem(string ids, string checker);
    }
}
