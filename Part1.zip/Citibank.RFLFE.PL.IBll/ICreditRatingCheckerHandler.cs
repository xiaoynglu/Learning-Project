﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface ICreditRatingCheckerHandler
    {
        CommonTResult<CreditRatingCheckerView> GetViewList(int start, int limit, CreditRatingCheckerView entity);

        bool CheckerApproval(int TID, int ApprovalType, string checker);
    }
}
