﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface INgtvFraudDataLoadHandler
    {
        CommonTResult<T_RP_NegativeDataMaker> GetNgtvData();
      
        CommonTResult<T_RP_FraudDataMaker> GetFraudData();
    }
}
