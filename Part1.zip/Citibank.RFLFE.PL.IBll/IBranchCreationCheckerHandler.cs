﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IBranchCreationCheckerHandler
    {
        CommonTResult<T_Sys_BranchMaker> GetBranch(int start, int limit, string BranchCode, string BranchName, string Status, string SoeID);

        CommonTResult<ComboboxEntity> GetBranchName();

        bool ApproveData(string TID, string approveresult,string SoeID);

        bool RejectData(string TID, string approveresult, string SoeID);
        
    }
}
