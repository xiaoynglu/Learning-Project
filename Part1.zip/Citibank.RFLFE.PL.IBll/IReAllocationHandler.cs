﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IReAllocationHandler
    {
        CommonTResult<ReAllocationView> GetReAllocationList(int start, int limit, ReAllocationQueryView entity);
      
        bool ReAllocationTemp(string appid, string reallocationtype, string newexecid, string soeid);
       
        bool ReAllocationForever(string appid, string reallocationtype, string newexecid, string soeid);
       
        CommonTResult<ComboboxEntity> GetAvaliableSales(string orgcode);
    }
}
