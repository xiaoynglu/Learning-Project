﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IPBOCHandler
    {
        string ImportRate();

        string ImportALS(string strData_YM);

        string ImportChargeOffAccount(string strData_YM);

        string ImportRemaingMonth();

        Dictionary<string, object>  CheckReportDataYM(string strData_YM);

        string GeneratePBOCReport(string generatePBOCReport, string exportPBOCPath);
    }
}
