﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface ISysParametersHandler
    {
        /// <summary>
        /// Get SysParameterList
        /// </summary>
        /// <returns>IList</returns>
        IList<T_Sys_Parameters> GetSysParamListByParamDesc(string paramDesc);
            
        /// <summary>
        /// Get SysParameterList
        /// </summary>
        /// <returns>IList</returns>
        IList<T_Sys_Parameters> GetSysParamListByID(string paramID);
        
        /// <summary>
        /// Get SysParameterList
        /// </summary>
        /// <returns>IList</returns>
        IList<T_Sys_Parameters> GetSysParamListByIDKey(string paramID, string key);
        
        /// <summary>
        /// Get SysProductNames
        /// </summary>
        /// <returns>String</returns>
        IList<T_Sys_Products> GetSysProdNames(int? prodID);
       
        /// <summary>
        /// Get SysBranchNames
        /// </summary>
        /// <returns>IList</returns>
        IList<T_Sys_Branch> GetSysBranchNames(string orgCode);

        IList<T_Sys_Region> GetCities(string parentCode);

        IList<T_Sys_Region> GetProvinces();

        string GetParamKeyByIDAndValue(string paramId, string paramValue);

        string GetRegionCode(string regionName, string parentCode);
       
        /// <summary>
        /// 获取贷款人
        /// </summary>
        /// <returns>IList</returns>
        IList<T_PL_Customers> GetBorrowerNames(Guid appId);

        IList<T_PL_EvaluationCompany> GetEvaluationCompanys();

        IList<T_Sys_Parameters> GetColleraterTypeByPropertyType(string propertyType);

        void SetParametersCache();

        void DayTimerStart();
    }
}
