﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IFraudDataHandler
    {
        CommonTResult<T_RP_FraudData> GetFraudDataByID(int tid);
       
        CommonTResult<T_RP_FraudDataMaker> GetFraudDataMaker(T_RP_FraudDataMaker entity, int limit, int start);
       
        CommonResult SaveFraudDataMaker(T_RP_FraudDataMaker entity);
       
        CommonResult DeleteFraudDataMaker(int tid);
       
        CommonResult ApproveFraudDataMaker(string ids, string checker);

        CommonResult RejectFraudDataMaker(string ids, string checker);
    }
}
