﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IQueryHandler
    {
        DownloadFileResult GetDWHInfo(T_PL_DWH condition);

        CommonTResult<T_PL_BureauQueryResult> GetAppInfoByIDNum(string ID_NUMBER, int start, int limit);

        CommonTResult<T_PL_BureauQueryResult> GetCustInfoByOrgCode(string OrgCode, int start, int limit);

        CommonTResult<T_WF_PL_Stage> GetAllStageNameInQuery(int QueryPage);

        CommonTResult<T_PL_LongOrder> GetLongApplyByDay(T_PL_Application app, int day, int start, int limit);

        CommonTResult<T_Sys_Users> GetSalesIDByOrgCode(string orgCode, string soeID, int roleType);

        CommonTResult<T_WF_PL_INS> GetUserProcessInstance(T_PL_Application condition, int start, int limit);

        CommonTResult<T_PL_UserProcess> ExportUserProcessByAppID(string appids);

        CommonTResult<T_PL_Deviation> GetDeviationList(T_PL_Application condition, int start, int limit);

        CommonTResult<T_PL_DeviationTotalInfo> GetDeviationTotalInfo(T_PL_Application condition);

        CommonTResult<T_PL_ApprovalInfo> GetApprovalInfoByAppId(string AppID);
    }
}
