﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface ICustAndContractHandler
    {
        IDictionary<string, string> GetApplicationAndLoanInfoByAppID(string appId);

        CommonTResult<T_PL_Customers> GetCustAndContractCustInfoByAppID(string appId);

        Boolean SaveCustAndContractContacts(T_PL_CustomerContact Entity);

        IDictionary<string, string> GetCustConfirmInfoAndFeeByAppId(string appId);

        Boolean SaveCustAndContractPayMethodCustConfirmInfoAndFee(CustAndContractPayMethodCustConfirmInfoAndFeeView Entity);

        DownloadFileResult PrintContract(string appId, string appNo, string prodId, string stageId);
    }
}
