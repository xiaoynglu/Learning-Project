﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IRPRulesHandler
    {
        CommonTResult<T_RP_RulesMaker> GetRPRulesMaker(T_RP_RulesMaker entity, int limit, int start);
       
        CommonTResult<T_RP_RulesMaker> GetRPRulesChecker(string RuleID);

        CommonTResult<T_RP_RulesMaker> GetRPRulesPendingChecker(Entities.T_RP_RulesMaker entity, int limit, int start);

        CommonResult UpdateRPRulesMaker(T_RP_RulesMaker entity);
       
        CommonResult ApproveRPRulesMaker(string ids, string checker);
       
        CommonResult RejectRPRulesMaker(string ids, string checker);

        IList<T_RP_RulesMaker> GetRuleNamesMaker();
        
        CommonTResult<T_RP_RuleResultDetail> GetRPResultDetails(string appId, int prodId);

        IList<T_RP_ADR> GetApplicationADR(Guid appId, int prodId);
       
        int SaveApplicationADR(T_RP_ADR entity);

        IList<T_RP_Params> GetRuleParamListMaker(string RuleID);

        CommonTResult<T_RP_RuleParamValuePivot> GetRuleParamValuePivotListMaker(T_RP_RuleParamValuePivot entity, int limit, int start);
       
        CommonTResult<T_RP_RuleParamValuePivot> GetRuleParamValuePivotListChecker(T_RP_RuleParamValuePivot entity, int limit, int start);
       
        bool ApplicationIsPricingDeviationed(Guid appId, int prodId);

        CommonResult SaveRPRuleParamValueMaker(string RuleIDs, string ParamIDs, string OrgCodes, string UPL_Gs, string UPL_Qs, string HE_Gs, string HE_Qs, string CRE_Gs, string CRE_Qs, string MO_Gs, string MO_Qs, string maker);

        CommonResult ApproveRPRuleParamValueMaker(string RuleIDs, string ParamIDs, string OrgCodes, string checker);

        bool RejectRPRuleParamValueMaker(string RuleIDs, string ParamIDs, string OrgCodes, string checker);
       
        CommonTResult<T_PL_AppExpireDateMaker> GetExpireDateList();
       
        bool UpdateExpireDay(string ids, string expiredays, string maker);
       
        bool ApproveExpireDay(string ids, int approveType, string checker);
       
        CommonTResult<RuleParamAlistView> GetRuleParamAlistMaker(int start, int limit, string orgcode, string Status);
        
        CommonTResult<RuleParamBlistView> GetRuleParamBlistMaker(int start, int limit, string orgcode, string Status);
       
        bool SaveLTVParamMaker(string ProdIds, string OrgCodes, string Factors, string Values, string maker);
       
        bool SaveLTVValueMaker(string ProdIds, string OrgCodes, string CollateralTypes, string BaseLTVs, string MaxDelLTVs, string maker);

        bool ApproveLTVParamMaker(string ProdIds, string OrgCodes, string Factors, string checker, int approvetype);
       
        bool ApproveLTVValueMaker(string ProdIds, string OrgCodes, string CollateralTypes, string checker, int approvetype);
    }
}
