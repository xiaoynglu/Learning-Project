﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IAmendAppHandler
    {
        Dictionary<string[], string> GetRACMapping(string collateralTyoe);
    }
}
