﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IFullRevalutionHandler
    {
        CommonTResult<FullRevalutionView> GetFullRevalutionView(int start, int limit, string appId);
       
        CommonTResult<FullRevalutionValuesView> GetValues(string appid);
       
        CommonTResult<T_PL_EvaluationCompany> GetEvaluationCompany(string appid);
       
        bool SaveEvl(T_PL_OralAppraisal entity, string itemoperator);
      
        bool DeleteEvl(string TID);
      
        bool ApplyEvl(string appid, string TID);
       
        bool IsApplied(Guid appid);
       
        int getLoanSizeByPropertyValueMO(Guid appID, decimal buySellPrice, decimal payAmount, decimal tailAmount);
       
        int getLoanSizeByPropertyValue(Guid appID);
       
        bool GetISMO(string appid);
      
        long GetCallFullValByAppId(Guid AppId);
       
        CommonTResult<FullRevalutionApproveView> GetCreditInfo_2ndAppoval(Guid guidAPPID);
       
        CommonTResult<EvlReportListView> GetEvlReportList(string APPIDs);
      
        bool updateAggreateRunResultInCallFullValuation(Guid appID, int newApprovedLoanSize);
       
        CommonTResult<T_PL_RunResult> GetEvlApprovalList(string appid);
       
        string GetFirstPercent(string appid, string OrgCode);

        Boolean UpdateFullRevalutionInfo(string appId, string completedYear, string housePrice, string firstPayment, string tailAmount);
    }
}
