﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IExceptionApproveHandler
    {
        bool UpdatePricingDeviatedAndRate(string appId, string pricingDeviated, string rate);
    }
}
