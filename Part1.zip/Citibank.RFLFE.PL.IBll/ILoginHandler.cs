﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface ILoginHandler
    {
        int GetUserRole(string SoeID);
       
        T_Sys_Users GetUserInfo(string SoeID);
       
        IList<MenuTree> GetMenu(int RoleType);
       
        bool login(string soeid, string logonStatus, string password, string clientIPAddress, string hostName, ref string errMessage);
      
        void InsertLogToDB(string soeID, string logon, string message, string ip, string hostName);
       
        UserInfo GetUserInfoByEntity(UserInfo oUserInfo);
    }
}
