﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IBranchCreationHandler
    {
        bool AddBranch(T_Sys_BranchMaker branchentity, string soeID);

        CommonTResult<ComboboxEntity> GetBranchType();
    }
}
