﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface INgtvDataHandler
    {
        CommonTResult<T_RP_NegativeDataMaker> GetNgtvData(int start, int limit, string CustName, string CompanyName, string AgentName, string IDNo, string DOB, string SalesName, string OtherCertID, string Reason, string Status);
       
        CommonTResult<T_RP_NegativeDataMaker> AddDoc(T_RP_NegativeDataMaker entity, string soeID);
       
        CommonTResult<T_RP_NegativeDataMaker> UpdateDoc(T_RP_NegativeDataMaker entity, string soeID);
      
        CommonTResult<T_RP_NegativeDataMaker> DeleteDoc(string TID, string soeID);
       
        CommonTResult<T_RP_NegativeDataCheckerView> GetNgtvDataByID(int TID);        
    }
}
