﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface ICriticalFieldQueryHandler
    {
        CommonTResult<T_PL_AppAuditLog> QueryList(int start, int limit, CriticalFieldQueryView entity);

        List<string> GetLogData(string rfid);

        string GetTableName(string rfid);

        bool GetIsCriticalField(string tablename, string fieldname);

        List<string> GetCriticalField(string tablename);

        CommonTResult<T_PL_ParameterAuditLog> QueryParameterList(int start, int limit, CriticalFieldQueryView entity);

        List<string> GetParameterLogData(string rfid);
    }
}
