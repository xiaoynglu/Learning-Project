﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IAppCheckerHandler
    {
        CommonTResult<T_PL_Customers> GetDocListRoles(string CustId);

        CommonTResult<T_PL_Customers> GetCustDetailInfoByCustId(string appId);

        Boolean SaveReviewDocList(List<T_PL_DocSubmitted> docList,string proId);
    }
}
