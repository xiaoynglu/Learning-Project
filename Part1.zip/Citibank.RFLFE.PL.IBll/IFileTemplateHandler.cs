﻿using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IFileTemplateHandler
    {
        /// <summary>
        /// 获取文件模板列表
        /// </summary>
        /// <returns>CommonTResult</returns>
        CommonTResult<T_PL_FileTemplateMaker> GetFileTemplateMakerList(int limit, int start, int? prodID, int? status);
      
        /// <summary>
        /// 获取模板条件列表
        /// </summary>
        /// <returns>CommonTResult</returns>
        CommonTResult<T_PL_ConfigConditionMaker> GetTemplateConditionMakerList(int limit, int start, int? prodID, int? status);
       
        /// <summary>
        /// 获取条件显示名ComboxList
        /// </summary>
        /// <returns>IList</returns>
        IList<T_PL_ConditionColumns> GetConditionDisplayNames(string tableName);
       
        /// <summary>
        /// 获取条件逻辑组别名ComboxList
        /// </summary>
        /// <returns>IList</returns>
        IList<T_PL_ConfigConditionMaker> GetConditionGroupNames(int tid, int parentID, int prodID);
        
        /// <summary>
        /// 获取模板文件名ComboxList
        /// </summary>
        /// <returns>IList</returns>
        IList<T_PL_FileTemplateMaker> GetTemplateFileNames(int fileType);
       
        /// <summary>
        /// 获取模板文件路径
        /// </summary>
        /// <returns>T_PL_FileTemplateMaker</returns>
        T_PL_FileTemplateMaker GetTemplateFilePathByTID(int tid);
       
        /// <summary>
        /// 更新模板文件名称
        /// </summary>
        /// <returns>int</returns>
        int ChangeTemplateName(int tid, string fileName);
       
        /// <summary>
        /// 添加模板附件条件
        /// </summary>
        /// <returns>int</returns>
        int SaveTemplateConditionMaker(T_PL_ConfigConditionMaker entity);
       
        /// <summary>
        /// 添加模板文件
        /// </summary>
        /// <returns>int</returns>
        int SaveFileTemplateMaker(T_PL_FileTemplateMaker entity);
        
        /// <summary>
        /// 删除模板文件
        /// </summary>
        /// <returns>int</returns>
        int DeleteFileTemplateMaker(int tid);
        
        /// <summary>
        /// 删除模板文件附件条件
        /// </summary>
        /// <returns>int</returns>       
        int DeleteConfigConditionMaker(int cid);
        
        /// <summary>
        /// 批准模板文件
        /// </summary>
        /// <returns>int</returns>
        bool ApproveFileTemplateMaker(string ids, string checker);
        
        /// <summary>
        /// 拒绝模板文件
        /// </summary>
        /// <returns>int</returns>
        bool RejectFileTemplateMaker(string ids, string checker);
       
        /// <summary>
        /// 批准模板文件条件
        /// </summary>
        /// <returns>int</returns>
        bool ApproveConfigConditionMaker(string ids, string checker);
       
        /// <summary>
        /// 拒绝模板文件条件
        /// </summary>
        /// <returns>int</returns>
        bool RejectConfigConditionMaker(string ids, string checker);
        
        /// <summary>
        /// 获取已经上传了的产品
        /// </summary>
        /// <returns>int</returns>
        IList<ComboxDataView> GetUploadedProd();

        Dictionary<Object, Object> GetUploadedFileNameAndAttachmentListByProdID(string prodId);
    }
}
