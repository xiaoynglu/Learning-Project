﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models.Mappers;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IAppProgressHistoryHandler
    {
        CommonTResult<AppProgressHistoryView> GetAppProgressHistory(int start, int limit, string AppID);
    }
}
