﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface INewProposalHandler
    {
        CommonTResult<T_PL_LTVFactors> GetLTVFactors(string AppId);      
       
        bool UpdateMortgagorInfo(T_PL_Mortgagors entity);
 
        CommonTResult<T_PL_Collateral> GetCustCollateralInfoByAppId(string AppId);
       
        CommonTResult<T_PL_Customers> GetCustInfo(string AppId);
       
        CommonTResult<ProductListView> GetNPProductList(string AppId);

        CommonTResult<T_PL_Customers> GetPreviouseCasesByIDNo(string IdNo, string appNo);

        Boolean CopyCoLoanerInfoByAppID(string oldAppId, string newAppId);

        DownloadFileResult PrintAppFrom(string appId, string prodName, string appNo, List<String> LoanParaList, string stageId);

        Boolean CheckSingleBo(string appId, string borrowType);

        Boolean IsSystemDecided(string appId);

        Boolean CopyFinanceInfoToNextStage(string appId,string currentStage,string nextStage);

        CommonTResult<T_PL_Customers> GetCustBasicInfo(string AppId);
      
        CommonTResult<DocumentItem> GetDocumentList(string strCustType, string strProdID, string custSegment);       
    }
}
