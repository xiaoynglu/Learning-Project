﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IDisburseRegistHandler
    {
        Dictionary<string, string> GetDetails(string appid);

        bool DoProcess(string islock,string appid,string soeid,string appno,string stageid);
       
        CommonTResult<T_PL_EclipseHandover> GetEclipse(string AppId);
      
        DataTable GetParamForCLMS(string appid);
      
        decimal GetCallFullValByAppId(string appId);
      
        string GetOwnerByAppID(string appId);
      
        DataTable GetCollateral(string appid);
       
        string GetProvinceByCode(string procode);
      
        string GetCityByCode(string procode, string citycode);
       
        string GetNewLoanSize(string AppID);
      
        bool SaveCLMS(T_PL_CLMSHandover entity);
       
        void SetCLMSDate(string appid);
      
        CommonTResult<T_PL_CLMSHandover> GetCLMS(string appid);
      
        string GetSecondApproveOPDate(string appId);
       
        CommonTResult<T_PL_ALSView> GetALS(string appid, bool istopup, string productname);
       
        bool IsTopupBatch(string appid);
       
        CommonTResult<ApplicationInofView> GetApplicationInof(string appid);
       
        DataTable GetALsShowInfo(string appid);
      
        Dictionary<string, string> GetCountPackage(string appid);
       
        CommonTResult<T_PL_EclipseHandover> ExportReport(string IDType, string appid);
       
        void GenerateALS(string appId, string accOpenDate);
       
        bool SaveNumber(string appId, string customerNumber,string custID, string co1CustNumber,string cust1ID, string co2CustNumber,string cust2ID, string GuaNo,string GuaID, string relationshipNumber, string Mo1No,string Mo1ID, string Mo2No,string Mo2ID, string Mo3No,string Mo3ID);
       
        void SaveRemarks(string appId, string remarks);
       
        void SaveCLMSInfor(string appId, string accOpenDate, string CLMSLineID, string CLMSCollateralID);
       
        string GetProdName(string appid);
       
        string GetAppNoByAppId(string appId);
      
        CustNOForDisburseView GetCustNOs(string appid);
      
        string GetExpireDay(string appid);
     
        Dictionary<string, string> GetCLMSInfor(string appId);
      
        void SaveDetails(string appid, string remarks, string accopendate, string paymethods);
      
        CommonTResult<DisburseItemDetail> GetItemDetailInfo(string appid, string itemtype, string itemid);
       
        DataTable GetFeeCode(string appid);
       
        CommonTResult<T_PL_ALSCOLView> GetALSCOL(string appid, bool istopup, string productname);
       
        Dictionary<string, string> GetFeeData(string appid);
       
        T_PL_SelfPay GetSelfPayInfo(string AppID);
    }
}
