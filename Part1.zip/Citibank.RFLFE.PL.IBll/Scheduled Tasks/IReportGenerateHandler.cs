﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IReportGenerateHandler
    {
        string GetRunJobType();

        IList<T_PL_FileDefination> GetFileDefinationByJobType(string JobName);

        void GenerateReport(IList<T_PL_FileDefination> fileDefine, string JobName, IList<T_Sys_PathConfiguration> OutPutPath);

        CommonTResult<T_Sys_PathConfiguration> GetPathConfigByName(string PathName);
    }
}
