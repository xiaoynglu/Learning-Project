﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IReportImportHandler
    {
        bool CheckIsImportToday(string JobName);

        Dictionary<DataTable, string> ReadSourceToDt(IList<T_PL_FileDefination> fileDefine, IList<T_Sys_PathConfiguration> PathConfig);

        void ImportGRBToDB(IList<T_PL_FileDefination> fileDefine, IList<T_Sys_PathConfiguration> PathConfig);

        CommonResult BulkCopySourceToTable(string JobName, DataTable dt, string tableName);

        bool InsertImportGenerateLog(T_PL_BatchJobLog logs);
    }
}
