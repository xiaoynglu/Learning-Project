﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IRelatedPersonHandler
    {
        CommonTResult<T_RP_RelatedPerson> GetRelatedPersonByID(int tid);
       
        CommonTResult<T_RP_RelatedPersonMaker> GetRelatedPersonMaker(T_RP_RelatedPersonMaker entity, int limit, int start);
       
        CommonResult SaveRelatedPersonMaker(T_RP_RelatedPersonMaker entity);
       
        CommonResult DeleteRelatedPersonMaker(int tid);
       
        CommonResult ApproveRelatedPersonMaker(string ids, string checker);
       
        CommonResult RejectRelatedPersonMaker(string ids, string checker);        
    }
}
