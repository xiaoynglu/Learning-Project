﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface ICustomerHandler
    {
        CommonTResult<T_PL_Customers> GetCustomers(string appID, string custId);

        CommonTResult<T_PL_Guarantors> GetGuarantorByAppId(string appId);

        CommonTResult<T_PL_FamilyMembers> GetFamilyMembersByCustId(string custId);

        CommonTResult<T_PL_Customers> GetMainAndJointCustomersListByAppId(string appId);

        CommonTResult<T_PL_CustomerContact> GetBorrowerContactByCustId(string custId);

        String GetCustIDByAppIdAndBorrowType(string appId, string borrowType);

        CommonTResult<T_PL_SABudget> GetFinanceSalaryByCustId(string custId, string stageId);

        CommonTResult<T_PL_SEBudget> GetFinanceSelfByCustId(string custId,string stageId);

        CommonTResult<T_PL_Mortgagors> GetMortgagorListByAppId(string appId, bool isChecker);

        Boolean SaveCustomerContact(T_PL_CustomerContact Entity);

        Boolean SaveFinanceSalary(T_PL_SABudget Entity, string processorID);

        Boolean SaveFinanceSelf(T_PL_SEBudget Entity, string processorID);

        Boolean SaveSalaryCust(T_PL_SalaryCust Entity);

        Boolean SaveSelfEmployedCust(T_PL_SelfEmployedCust Entity);

        Boolean SaveCustomer(T_PL_Customers Entity);

        Boolean DeleteCustomerByCustId(string custId);

        Boolean SaveFamilyMember(T_PL_FamilyMembers Entity);

        Boolean SaveGuarantors(T_PL_Guarantors Entity);

        Boolean SaveBorrowerCustomers(BorrowerBasicView entity);

        Boolean DeleteFamilyMembersByMemberId(string memberId);

        String GetFirstPercent(string moCount, string orgCode, string collateralpe);

        List<string> GetBaseAndMaxLtv(string prodID, string moCount, string collateralpe, string orgCode);

        Boolean SaveMortgagor(T_PL_Mortgagors Entity,bool isChecker);

        Boolean RemoveMortgagor(string mortID, bool isChecker);

        String GetCustIDByBorrowType(string appID, string borrowType);

        String GetProdIDbyProdName(string prodName);

        Boolean SaveCustomers(T_PL_Customers Entity);

        CommonTResult<BorrowerBasicView> GetBorrowerCustomers(string appID, string custId);

        Boolean SaveFinanceSalaryByCustId(T_PL_SABudget Entity, string processorId);

        Boolean SaveFinanceSelByCustId(T_PL_SEBudget Entity, string processorId);

        Boolean InitNewProposal(string appID, string soeID, string orgCode);

        Boolean SaveGuarantorByAppId(T_PL_Guarantors Entity);

        CommonTResult<FinanceSurveyView> GetFinanceSurvey(string appId);

        CommonTResult<T_PL_CustIncome> GetIncomeDetails(string custId);

        CommonTResult<T_PL_CustDebt> GetCutDebt(string custId);

        CommonTResult<LoanInfoView> GetLoanInfo(string appId);

        Boolean UpdateScoringCard(T_PL_SEBudget Entity);

        Boolean UpdateSalaryWorkInfo(T_PL_SalaryCust Entity);

        Boolean UpdateSelfEmploymentWorkInfo(T_PL_SelfEmployedCust Entity);

        Boolean SaveBorrowerDetailsInfoOfCreditApproval(T_PL_Customers Entity);

        Boolean SaveFinanceSurveyOfCreditApproval(FinanceSurveyView Entity);

        Boolean SaveIncomeDetailsOfCreditApproval(List<T_PL_CustIncome> List);

        Boolean SaveCustDebtOfCreditApproval(T_PL_CustDebt Entity,string processorId);

        Boolean SaveLoanApprovaltOfCreditApproval(LoanInfoView Entity);

        CommonTResult<T_PL_EntrusPay> GetEntrusPayListByAppId(string appId);

        Boolean DeleteEntrusPayById(string entrusPayId);

        Boolean SaveEntrusPay(T_PL_EntrusPay Entity);

        Boolean UpdateCustIncome(string custId);

        List<string> GetCustIDListByAppID(string appId);

        CommonTResult<T_PL_BranchCompany> GetCompanyList(string companyType, string enterpriseName, string orgCode);
    }
}
