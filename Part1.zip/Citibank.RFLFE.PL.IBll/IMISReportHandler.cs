﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using System.Data;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IMISReportHandler
    {
        CommonTResult<T_Sys_Branch> GetBranchByOrg(T_Sys_Branch brs);

        Boolean UploadHoliday(string filePath, string uploadType, T_Sys_Users loginUser);

        Boolean DeleteHoliday();

        CommonTResult<T_PL_TempDefination> GetMISReportTempDefination(int role, int gird, string userID, string repName);

        CommonTResult<T_PL_MISReportTemplate> GetTemplateByUserId(string userID);

        bool SaveTemplateSetting(string templateName, string ColumnIds, string userID);

        bool DeleteTemplateSetting(string templateName, string userID);

        DataSet ExportTimeQueryByStages(string Stages, string BeginDate, string EndDate, string ProdIDs, string UserID);

        DataTable ExportProcessHistoryReport(string Stages, string StartDate, string EndDate);

        CommonTResult<T_PL_MISReport_TempColumns> GetMSIReportByCondition(string OrgCode, string RepNo, string SoeId, string ProdID, string BeginDate, string EndDate, string TimeFlag, int RepFlag, int Start, int Limit);

        DataTable ExportMSIReportByCondition(string OrgCode, string RepNo, string SoeId, string ProdID, string BeginDate, string EndDate, string TimeFlag, int RepFlag);
    }
}
