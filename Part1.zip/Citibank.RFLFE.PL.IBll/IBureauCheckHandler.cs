﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IBureauCheckHandler
    {
        CommonTResult<T_PL_BureauInfo> QueryPersonalInfoByIdAndAppId(string AppId, string ID_NUMBER);

        CommonTResult<T_PL_PBOC_LoanDetail> GetBureauLoanDetails(string ID_NUMBER, string IMPORT_DATE, int start, int limit);

        CommonTResult<T_PL_PBOC_CreditCardDetail> GetBureauCardDetails(string ID_NUMBER, string IMPORT_DATE, int start, int limit);

        CommonTResult<T_PL_BureauCustInfo> DownloaderBureauQueryFile(string AppID, ref string FileName);

        bool DownloaderQueryList(List<T_PL_QueryList> custInfos, ref string FileName);

        CommonResult UpdateBureauQueryStatus(List<T_PL_QueryList> custInfos);

        CommonTResult<T_PL_PBOC_PersonalInfo> GetBureauHTMLFileName(string AppID, string ID_NUMBER, int Flag, ref string FileName);

        CommonTResult<T_PL_BureauInfo> RefreshBureauBasicInfo(string AppID, string ID_NUMBER);

        CommonResult SaveBureauBasicInfo(T_PL_BureauInfo info);

        CommonTResult<T_PL_BureauCustInfo> GetQueryListByAppID(string AppID);
    }
}
