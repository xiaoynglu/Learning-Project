﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface INgtvDataCheckerHandler
    {
        CommonTResult<T_RP_NegativeDataCheckerView> GetNgtvData(int start, int limit, string CustName, string CompanyName, string AgentName, string IDNo, string DOB, string SalesName, string OtherCertID, string Reason, string Status, string Maker, string Checker, string ModifiedTime);
       
        bool ApproveNgtvData(string TID, string approveresult, string soeID);
       
        bool RejectData(string TID, string approveresult, string soeID);
       
        CommonTResult<T_RP_NegativeDataCheckerView> GetNgtvDataByID(int TID);
    }
}
