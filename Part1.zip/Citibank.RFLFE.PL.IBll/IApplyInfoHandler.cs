﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IApplyInfoHandler
    {
        CommonTResult<ApplyInfoDetail> GetApplyInfoDetail(string appNo, string fullName, string idNo,bool isChecker, string maker);
       
        int SaveNosOfCollateralMaker(Guid AppID, string RightNoOfLand, string PropertyPermits, string maker);
        
        int SaveLoanIndustryMaker(T_PL_LoanIndustryMaker entity);
       
        bool ApproveNosOfCollateralMaker(Guid AppID, string RightNoOfLand, string PropertyPermits, string checker);
       
        bool RejectNosOfCollateralMaker(Guid AppID, string RightNoOfLand, string PropertyPermits, string checker);
       
        bool ApproveLoanIndustryMaker(Guid AppID, string checker);
       
        bool RejectLoanIndustryMaker(Guid AppID, string checker);
      
        bool ApproveMortgagorMaker(Guid AppID, string checker);
       
        bool RejectMortgagorMaker(Guid AppID, string checker);
    }
}
