﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IDocListHandler
    {
        CommonTResult<T_PL_DocSubmitted> GetSubmittedDocList(string appid, int stageid, string custID);
       
        CommonTResult<T_PL_DocSubmitted> GetStageDocList(string appid, int stageid, string custID);
        
        Boolean SaveSubmittedDoc(List<T_PL_DocSubmitted> docList, string processorId);
        
        Boolean SaveUploadedNewProposal(string filePath, string processorId,T_Sys_Users loginUser);

        CommonTResult<T_PL_DocSubmitted> getLackDoc(string appid, string stageId);

        string GetApplicationNo(string branchCode);

        void UpdateDocListToAppChecker(string appId);
    }
}
