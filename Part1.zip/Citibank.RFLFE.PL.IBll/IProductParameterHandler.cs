﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IProductParameterHandler
    {
        /// <summary>
        /// 获取产品的基础利率
        /// </summary>
        /// <returns>CommonTResult</returns>
        CommonTResult<T_PL_BaseRateMaker> GetBaseRateByProdID(int? prodID);
      
        /// <summary>
        /// 获取MO产品的基础利率
        /// </summary>
        /// <returns>CommonTResult</returns>
        CommonTResult<T_PL_BaseRateMaker> GetBaseRateMOByOrgCode(string orgCode);
       
        /// <summary>
        /// 修改产品的基础利率
        /// </summary>
        /// <returns>int</returns>
        int MakeProdBaseRate(string[] baseRates,string maker);
       
        /// <summary>
        /// 修改产品的利率与费用
        /// </summary>
        /// <returns>int</returns>
        int MakeRateAndFee(string[] critis, string maker);
        
        /// <summary>
        /// 获取费用
        /// </summary>
        /// <returns>CommonTResult</returns>
        CommonTResult<T_PL_FeeMaker> GetFees(T_PL_FeeMaker fee);
       
        /// <summary>
        /// 获取利率
        /// </summary>
        /// <returns>CommonTResult</returns>
        CommonTResult<T_PL_RateMaker> GetRates(T_PL_RateMaker rate);
        
        /// <summary>
        /// 批量上传Rate
        /// </summary>
        /// <returns>CommonResult</returns>
        CommonResult UploadRateData(Stream stream, string maker);
       
        /// <summary>
        /// 根据就业类型动态加载对应企业类别-combox list
        /// </summary>
        /// <returns>IList</returns>
        IList<T_Sys_Parameters> GetCustSegments(string employType);
        
        /// <summary>
        /// 获取文档列表数据-grid list
        /// </summary>
        /// <returns>CommonTResult</returns>
        CommonTResult<T_PL_DocListMaker> GetDocListMaker(int limit, int start, T_PL_DocListMaker docList);
        
        /// <summary>
        /// 新增产品文档列表Maker
        /// </summary>
        /// <returns>int</returns>
        int AddDocListMaker(T_PL_DocListMaker entity);
        
        /// <summary>
        /// 更新产品文档列表Maker
        /// </summary>
        /// <returns>int</returns>
        int SaveDocListMaker(T_PL_DocListMaker entity);
       
        /// <summary>
        /// 删除产品文档列表Maker
        /// </summary>
        /// <returns>bool</returns>
        bool DelDocListMaker(string ids, string maker);
       
        /// <summary>
        /// 解析Template批量加载产品文档数据Maker
        /// </summary>
        /// <returns>bool</returns>
        bool UploadDocList(Stream stream, T_PL_DocListMaker docListMaker);
       
        /// <summary>
        /// 批准基础利率
        /// </summary>
        /// <returns>bool</returns>
        bool ApproveBaseRateMaker(string ids, string checker);
       
        /// <summary>
        /// 拒绝基础利率
        /// </summary>
        /// <returns>bool</returns>
        bool RejectBaseRateMaker(string ids, string checker);
       
        /// <summary>
        /// 批准利率和费用
        /// </summary>
        /// <returns>bool</returns>
        bool ApproveRateAndFeeMaker(string ids, string channel, string checker);
       
        /// <summary>
        /// 拒绝利率和费用
        /// </summary>
        /// <returns>bool</returns>
        bool RejectRateAndFeeMaker(string ids, string channel, string checker);
       
        /// <summary>
        /// 批准文档信息
        /// </summary>
        /// <returns>bool</returns>
        bool ApproveDocListMaker(string ids, string checker);
        
        /// <summary>
        /// 拒绝文档信息
        /// </summary>
        /// <returns>bool</returns>
        bool RejectDocListMaker(string ids, string checker);
    }
}
