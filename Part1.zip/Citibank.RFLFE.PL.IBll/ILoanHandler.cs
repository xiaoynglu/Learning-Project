﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using System.Data;

namespace Citibank.RFLFE.PL.IBll
{
    public interface ILoanHandler
    {
        T_PL_Loan GetLoanByAppId(Guid appID);

        CommonTResult<T_PL_LTVFactors> GetLTVFactors(string appId,string prodId);

        CommonTResult<T_PL_LTVParam> GetLTVParams(int prodId, string orgCode, string appId);

        CommonTResult<T_PL_Collateral> GetCustCollateralInfoByAppId(string AppId);

        CommonTResult<T_PL_SellerInfo> GetVendorListByAppId(string AppId);

        CommonTResult<T_PL_LoanIndustry> GetLoanPurposeByAppId(string AppId);

        int SaveLoanByAppId(T_PL_Loan entity);

        bool SaveSelfPayByAppId(T_PL_LoanIndustry Entity);
        
        Boolean SaveVendor(T_PL_SellerInfo Entity);

        Boolean RemoveVendor(string sellerID);

        Boolean SaveLTVFactors(List<T_PL_LTVFactors> EntityList);

        List<string> GetHasPropertyandPropertyTypeByAppId(string appId);

        String SaveLoanPurpose(T_PL_LoanIndustry Entity);

        String SaveCustCollateralInfo(T_PL_Collateral Entity);

        List<String> GetBeforeAndCurrentRateByAppId(string appId);

        Boolean UpdateRateException(string appId, string result);

        Boolean updateRate(string appId, string rate, string soeId, string stageId);

        Boolean DeleteCollateralbyAppID(string appId);

        Boolean DeleteMortgatarbyAppID(string appId);

        T_PL_Loan GetNewCurrLoanForCreditApproval(string appId);

        T_PL_Loan getLoanParametersByAppId(string AppId);

        Boolean SaveLoanParameters(string appId, string requestLoan, string monthlyMaxRefund, string tenor, string rate);

        DataTable ExportDisbursementFileByAppId(string appId);

        string GetCollateralTypeByAppId(string appId);

        string GetMortgageCountByAppId(string appId);

        Boolean SaveLoanApproval(T_PL_LoanApproval Entity);

        Boolean UpdateLoanInfoAndInsertRecordIntoLoanApproval(string appId,string processorId);
    }
}
