﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models.Mappers;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IAppProgressQueryHandler
    {
        CommonTResult<appProgressView> GetappProgress(int start, int limit, string strParam, string strType, string orgCode);

        CommonTResult<appProgressDetailView> GetAppDetail(string AppID, string AppNo);

        bool CheckSoeIdRight(string soeId, string stageId);
    }
}
