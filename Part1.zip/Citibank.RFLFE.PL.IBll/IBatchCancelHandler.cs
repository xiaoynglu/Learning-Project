﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models.Mappers;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IBatchCancelHandler
    {
        CommonTResult<BatchCancelView> GetBatchCancelList(int start, int limit, BatchCancelQueryView entity, string orgcode);

        bool BatchCancel(string appid,string curtime,string soeid);
    }
}
