﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;


namespace Citibank.RFLFE.PL.IBll
{
    public interface ICreditRatingHandler
    {
        CommonTResult<CreditRatingListView> QueryCreditLevel();

        CommonTResult<T_Sys_UsersSimple> QueryCreditOfficerUserInfo(string BranchCode, string SoeId, int limit, int start);

        CommonTResult<OfficerUserLevelInfoView> QueryCreditOfficerUserLevelInfo(string soeid, int start, int limit);

        bool saveContent(OfficerUserLevelInfoView entity);
    }
}
