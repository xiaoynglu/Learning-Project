﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IBranchDataHandler
    {
        CommonTResult<T_Sys_BranchMaker> GetBranchDataMaker(T_Sys_BranchMaker entity, int limit, int start);
       
        CommonTResult<T_Sys_BranchMaker> GetSysBranchPendingChecker(Entities.T_Sys_BranchMaker entity, int limit, int start);

        CommonResult UpdateBranchDataMaker(T_Sys_BranchMaker entity);
        
        CommonResult ApproveBranchDataMaker(string ids, string checker);
       
        CommonResult RejectBranchDataMaker(string ids, string checker);

        CommonTResult<T_PL_BranchCompanyMaker> GetBranchCompanyMaker(Entities.T_PL_BranchCompanyMaker entity, int limit, int start);

        CommonResult MergeBranchCompanyMaker(T_PL_BranchCompanyMaker view);
       
        CommonResult ApproveBranchCompanyMaker(string ids, string checker);
       
        CommonResult RejectBranchCompanyMaker(string ids, string checker);

        CommonResult DeleteBranchCompanyMaker(string ids, string checker);

        CommonTResult<T_PL_EvaluationCompanyMaker> GetEvaluationCompanyMaker(T_PL_EvaluationCompanyMaker entity, int limit, int start);

        CommonResult MergeBranchEvaluationCompanyMaker(T_PL_EvaluationCompanyMaker view);
       
        CommonResult ApproveBranchEvaluationCompanyMaker(string ids, string checker);
       
        CommonResult RejectBranchEvaluationCompanyMaker(string ids, string checker);

        CommonResult DeleteBranchEvaluationCompanyMaker(string ids, string checker);

        IList<T_Sys_Branch> GetBranchNamesMaker();
    }
}
