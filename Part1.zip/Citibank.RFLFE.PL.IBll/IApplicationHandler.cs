﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IApplicationHandler
    {
        T_PL_Application GetApplicationByAppId(Guid appID);

        ApplicationDetail GetApplicationDetail(Guid appID, int stageID);

        int SaveApplicationByAppId(T_PL_Application entity);

        Boolean SaveOtherInfo(OtherView entity);

        CommonTResult<OtherView> GetOtherInfo(string appId);

        Boolean UpdateAppSubmit(string appId, string prodId, string submited, string proposalLoanSize, string proposalTenor,string productRate, string baseRate, string avaliableLTV);

        Boolean UpdateDeviationed(string appId,string prodId);

        Boolean UpdateRateDeviationed(string appId, string rateDeviationed);

        String GetApplicationNoByAppId(string appId);

        T_PL_Application GetApplicationByAppNo(string ApplicationNo, string OrgCode, string CreatorID);

        CommonTResult<ProductListView> GetNPProductList(string AppId);

        Boolean IsSystemDecided(string appId,string stageId );

        Boolean CheckSingleBo(string appId, string borrowType);

        CommonTResult<DocumentItem> GetDocumentList(string strCustType, string strProdID, string custSegment);

        String GetProdNameByProdId(string prodId);

        string GetOrgCodeByAppId(string appId);

        string GetAppIdByApplicationNo(string applicationNo);
    }
}
