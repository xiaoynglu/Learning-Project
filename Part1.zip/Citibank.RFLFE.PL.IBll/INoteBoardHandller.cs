﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.IBll
{
    public interface INoteBoardHandller
    {
        CommonTResult<T_PL_News> GetNewsList(int Start, int Limit, string keyword);
       
        CommonTResult<T_PL_NoteWaitConfig> GetNoteWait(int Start, int Limit, string SOEID);
       
        CommonTResult<T_PL_NoteWaitConfig> GetNoteCurrent(int Start, int Limit, string SOEID);
       
        bool SaveItem(int TID, string title, string content, string soeid);
      
        bool DeleteItem(int TID);
       
        IList<T_Sys_Branch> GetNotePageBanks(string orgcode);
       
        CommonTResult<T_PL_MessageAndNotice> GetMessageContent(int start, int limit, int typevalue, string soeid, string orgcode);
       
        bool SaveMessage(T_PL_MessageAndNotice entity, string soeid);
       
        int GetMessageLastReadID(string soeid);
       
        bool SaveMessageReadLog(string soeid, string TID);
       
        CommonTResult<T_Sys_Roles> GetSystemRoles();
    }
}
