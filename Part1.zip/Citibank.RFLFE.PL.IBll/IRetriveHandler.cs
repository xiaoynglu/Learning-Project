﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IRetriveHandler
    {
        CommonTResult<RetriveView> GetRetriveList(int start, int limit, RetriveQueryView entity, string orgcode);
       
        bool RetrieveData(string AppID, string soeid);
    }
}
