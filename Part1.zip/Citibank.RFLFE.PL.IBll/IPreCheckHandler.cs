﻿using System;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.IBll
{
    public interface IPreCheckHandler
    {
        CommonTResult<GuarantorPhoneVerification> GetGuarantorPhoneVerification(string appId);

        CommonTResult<BorrowerCollateralDetail> GetBorrowerCollateralDetail(string appId);
        
        int SaveBorrowerCollateralDetail(BorrowerCollateralDetail bcd);
        
        CommonTResult<T_PL_OralAppraisal> GetOralAppraisal(int limit, int start, Guid appID);
        
        int SaveOralAppraisal(T_PL_OralAppraisal entity);
        
        int SaveOralAppraisalPrice(T_PL_OralAppraisal entity);
        
        bool DeleteOralAppraisal(int tid);
        
        bool SavePhoneVerificationRecord(T_PL_VerificationRecord entity);

        T_PL_RunResult GetRunResultByAppId(string appId);

        CommonTResult<T_PL_CRDup> GetCRDupByAppId(string appId);

        Boolean SavePreCheckLTVDetail(T_PL_Collateral Entity);

         CommonTResult<T_PL_Customers> GetHouseBureauObjectsListByAppId(string appId) ;

         CommonTResult<T_PL_MoHouseBureau> GetHouseBureauListByAppId(string appId);

         T_PL_Collateral GetHouseBurueauInfoByAppId(string appId);

         Boolean SaveHouseBureauObject(T_PL_MoHouseBureau Entity);

         Boolean DeleteHouseBureauObject(string tid);

         Boolean SaveHouseBureau(string appId, string needCheckHouseBureau, string houseBureauRemarks);

         CommonTResult<T_PL_CRPersonVel> GetFraudVelocity(string appId);

         CommonTResult<T_PL_CRVel> GetVelocityCheck(string personId);

         String GetLastRACbyApp(string appId);

         List<string> ShowVerifiedDetailsItems(string custId);

         CommonTResult<T_PL_PhoneVerification> GetAllPhoneVerificationByAppID(string appId);

         CommonTResult<T_PL_SiteVerification> GetAllSiteVerificationByAppID(string appId);
        
        CommonTResult<T_PL_HouseVerification> GetAllHouseVerificationByAppID(string appId);
        
        CommonTResult<T_PL_ExternalVerification> GetAllExternalVerificationByAppID(string appId);

        CommonTResult<CompareBureauInfoCustInfoView> GetCompareBureauInfoCustInfoByAppID(string appId);

        CommonTResult<T_PL_VerificationRecord> GetVerificationDetailsListByAppID(string appId);

        CommonTResult<T_PL_WorkingVerification> GetAllWorkingVerificationByAppID(string appId);

        Boolean SaveMortgageCognizance(T_PL_MortgageCognizance entity);
    }
}
