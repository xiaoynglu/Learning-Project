﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Bll;
using System.Configuration;
using CitiAES;
using Spring.Context;
using Spring.Context.Support;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Framework;
using System.Reflection;
using Citibank.RFLFE.PL.IBll;
using System.IO;
using Citibank.RFLFE.PL.Framework;
using log4net;

namespace Citibank.RELFE.PL.JobMainService
{
    class Program
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        static void Main(string[] args)
        {
            T_PL_BatchJobLog dbLog = new T_PL_BatchJobLog();

            string dalContextPath = @"assembly://Citibank.RFLFE.PL.Framework/Citibank.RFLFE.PL.Framework/Configuration.dal-objects.xml";
            string csContextPath = @"assembly://Citibank.RFLFE.PL.Framework/Citibank.RFLFE.PL.Framework/Configuration.bll-objects.xml";
            ContextRegistry.Clear();
            string[] configurationLocations = new string[] { dalContextPath, csContextPath };
            IApplicationContext ctx = new XmlApplicationContext(configurationLocations);

            UserCredentialsDbProvider ucdp = (UserCredentialsDbProvider)ctx.GetObject("dbProvider");
            string connectionString = ConfigurationManager.ConnectionStrings["LFE"].ConnectionString;
            CitiAES.clsAES AES = new CitiAES.clsAES();
            string password = AES.Decrypt(ConfigurationManager.AppSettings["LFEDB1"]) + AES.Decrypt(ConfigurationManager.AppSettings["LFEDB2"]);
            ucdp.ConnectionString = string.Format(connectionString, password);      
                
            FileFactory Factory = ctx.GetObject("FileFactory") as FileFactory ;

            log.Info("Job run start!");

            //CheckTime and Get JobName
            string jobs = Factory.GetRunJobType();
            jobs = "Bureau";
            if (jobs.Length > 0)
            {
                foreach (string JobName in jobs.Split(','))
                {
                    dbLog.JobName = JobName;
                    dbLog.RunMachine = System.Environment.MachineName;

                    //GetFileDefination: DWH, RiskDate, RM, Advice,Annual
                    IList<T_PL_FileDefination> Def = Factory.GetFileDefinationByJobType(JobName);
                    if (JobName != "Bureau" && (Def == null || Def.Count == 0))
                    {
                        //log
                        dbLog.RunStatus = 0;
                        dbLog.Remark = "No file defination!";
                        Factory.InsertImportGenerateLog(dbLog);
                        log.Info(string.Format("{0} - No file defination!", JobName));
                        return;
                    }

                    //MapDriver
                    IList<T_Sys_PathConfiguration> ShareFolderPath = null;
                    bool flag = MapPath(Factory, JobName, ref ShareFolderPath);
                    if (!flag)
                    {
                        //add log
                        dbLog.RunStatus = 0;
                        dbLog.Remark = "Map source path failed!";
                        Factory.InsertImportGenerateLog(dbLog);
                        log.Info(string.Format("{0} - Map path failed!", JobName));
                        return;
                    }
                    //Generate or Import Report by job type
                    bool result = Factory.GenerateImportReportByType(Def, JobName, ShareFolderPath);
                    log.Info(string.Format("batch job run {0} today!", result?"successfully": "failed"));
                    // Insert generate or import log                    
                    if (JobName == "CNRFALS" || JobName == "DWH" || JobName == "RiskData")
                    {
                        dbLog.RunStatus = result ? 1 : 0;
                        dbLog.Remark = result ? "successfully" : "failed";
                        Factory.InsertImportGenerateLog(dbLog);
                    }

                    //Send to NDM (optional)  --DWH, RiskData
                    if (JobName == "DWH" || JobName == "RiskData")
                    {
                        FileInfo[] files = new DirectoryInfo(ShareFolderPath[0].ImpOrGenerateFilePath).GetFiles();
                        string destFile = string.Empty;
                        foreach (var fileInfo in files)
                        {
                            string fileName = fileInfo.Name.Substring(0, fileInfo.Name.IndexOf(".") - 1);
                            destFile = CommonHelper.GetPath(ShareFolderPath[0].BackUpFilePath) + fileName + DateTime.Now.ToString("yyyyMMddhhmmss") + fileInfo.Name.Substring(fileInfo.Name.IndexOf("."), fileInfo.Name.Length);
                            File.Copy(fileInfo.FullName.ToString(), destFile, true);
                        }
                    }
                    //Notification
                    string env = ConfigurationManager.AppSettings["Env"];
                    if (env != null && env != "" && env.Substring(0, 1) == "S")
                        env = "[SIT]";
                    else if (env != null && env != "" && env.Substring(0, 1) == "U")
                        env = "[UAT]";
                    else if (env != null && env != "" && env.Substring(0, 1) == "C")
                        env = "[COB]";
                    else if (env != null && env != "" && env.Substring(0, 1) == "P")
                        env = "[PROD]";
                    else
                        env = "";
                    string subject = string.Format("{0} - CNRF LFE Batch Job Notification", JobName);
                    string emailTo = ShareFolderPath[0].EmailTo.ToString();
                    string content = string.Format("[{0}]{1} batch job run {2} today!",env, JobName, result?"successfully": "failed");
                    MailSend.SendByAddress(content, subject, emailTo);
                }
            }
            log.Info("Job run end!");
        }

        public static bool MapPath(FileFactory Factory, string JobName, ref IList<T_Sys_PathConfiguration> ShareFolderPath)
        {
            CommonTResult<T_Sys_PathConfiguration> PathConfig = null;
            string FileName = string.Empty;
            PathConfig = Factory.GetPathConfigByName(JobName);
            if (PathConfig.ResultCount == 0 || PathConfig == null)
            {
                log.Info(string.Format("{0} - Map path failed! No path configuration get from database.", JobName));
                return false;
            }
            clsAES AES = new clsAES();
            MapPath.MapPath map = new MapPath.MapPath();

            string strShareFolder = PathConfig.ResultList[0].ShareFilePath.ToString();
            string strDomainUser = PathConfig.ResultList[0].FileAccessFunctionID.ToString();
            string password = AES.Decrypt(PathConfig.ResultList[0].FileAccessFunctionPWD.ToString());
            var msg = string.Empty;
            if (!map.IsMapPath(strDomainUser, password, strShareFolder, ref msg))
            {
                log.Info(string.Format("{0} - Map path failed! Path - {1}, DomainUser - {2}, Password - {3}", JobName, strShareFolder, strDomainUser, password));
                return false;
            }
            ShareFolderPath = PathConfig.ResultList;
            return true;
         }
    }
}
