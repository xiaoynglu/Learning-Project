﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.Rule
{
    public class RuleResultDao : AdoDaoSupport, IRuleResultDao
    {
        /// <summary>
        /// get RP detail results 
        /// </summary>
        /// <param name="appId">application id</param>
        /// <param name="prodId">prod id</param>
        /// <returns></returns>
        public CommonTResult<T_RP_RuleResultDetail> GetRPResultDetails(string appId, int prodId)
        {
            CommonTResult<T_RP_RuleResultDetail> result = new CommonTResult<T_RP_RuleResultDetail>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", new Guid(appId));
            parameters.AddWithValue("ProdID", prodId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_RuleResultDetail>(
                CommandType.StoredProcedure, SPNames.PL_GetRPResultDetails, new T_RP_RuleResultDetailMapper<T_RP_RuleResultDetail>(), parameters);
            return result;
        }

        /// <summary>
        /// Get application ADR
        /// </summary>
        /// <param name="appId">application id</param>
        /// <param name="prodId">product id</param>
        /// <returns></returns>
        public IList<T_RP_ADR> GetApplicationADR(Guid appId, int prodId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddWithValue("ProdID", prodId);
            IList<T_RP_ADR> list = AdoTemplate.QueryWithRowMapper<T_RP_ADR>(CommandType.StoredProcedure, SPNames.PL_GetApplicationADR, new T_RP_ADRMapper<T_RP_ADR>(), parameters);
            return list;
        }

        public int SaveApplicationADR(T_RP_ADR entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();            
            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("ProdID", entity.ProdID);
            parameters.AddWithValue("Result", entity.Result);
            parameters.AddWithValue("AvaliableLTV", entity.AvaliableLTV);
            parameters.AddWithValue("BaseRate", entity.BaseRate);
            parameters.AddWithValue("BMDeviated", entity.BMDeviated);
            parameters.AddWithValue("CurrDBR", entity.CurrDBR);
            parameters.AddWithValue("CustSegment", entity.CustSegment);
            parameters.AddWithValue("Deviated", entity.Deviated);
            parameters.AddWithValue("DeviationLevel", entity.DeviationLevel);
            parameters.AddWithValue("DeviationRemarks", entity.DeviationRemarks);
            parameters.AddWithValue("DSCR", entity.DSCR);
            parameters.AddWithValue("Installment", entity.Installment);
            parameters.AddWithValue("InterestRate", entity.InterestRate);
            parameters.AddWithValue("LoanAmount", entity.LoanAmount);
            parameters.AddWithValue("LoanTenor", entity.LoanTenor);
            parameters.AddWithValue("MaxLTV", entity.MaxLTV);
            parameters.AddWithValue("PolicyDeviated", entity.PolicyDeviated);
            parameters.AddWithValue("PolicyDeviationReason", entity.PolicyDeviationReason);
            parameters.AddWithValue("PriceDeviated", entity.PriceDeviated);
            parameters.AddWithValue("PriceDeviationReason", entity.PriceDeviationReason);
            parameters.AddWithValue("ProcessDeviated", entity.ProcessDeviated);
            parameters.AddWithValue("ProcessDeviationReason", entity.ProcessDeviationReason);
            parameters.AddWithValue("ProcID", entity.ProcID);
            parameters.AddWithValue("ProposalDeviated", entity.ProposalDeviated);
            parameters.AddWithValue("RateException", entity.RateException);
            parameters.AddWithValue("RefreshDate", entity.RefreshDate);
            parameters.AddWithValue("RiskSegment", entity.RiskSegment);
            parameters.AddWithValue("TotalDBR", entity.TotalDBR);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure,
                SPNames.PL_SaveApplicationADR, parameters);
            return result;
        }
    }
}
