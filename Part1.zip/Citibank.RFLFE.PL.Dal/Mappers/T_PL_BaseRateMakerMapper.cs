﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_BaseRateMakerMapper<T> : IRowMapper<T> where T : T_PL_BaseRateMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<int>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<string>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Value"))
                view.Value = dataReader.GetValueOrDefault<decimal>("Value");
            if (DataReaderRowFilter.RowFilter(dataReader, "ValueOverFive"))
                view.ValueOverFive = dataReader.GetValueOrDefault<decimal>("ValueOverFive");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstPayRate"))
                view.FirstPayRate = dataReader.GetValueOrDefault<decimal>("FirstPayRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "SecondPayRate"))
                view.SecondPayRate = dataReader.GetValueOrDefault<decimal>("SecondPayRate");

            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<int>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");

            if (DataReaderRowFilter.RowFilter(dataReader, "StatusDesc"))
                view.StatusDesc = dataReader.GetValueOrDefault<string>("StatusDesc");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchName"))
                view.BranchName = dataReader.GetValueOrDefault<string>("BranchName");
            return view;
        }
    }
}
