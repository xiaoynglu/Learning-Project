﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_Sys_RolesMapper<T> : IRowMapper<T> where T : T_Sys_Roles, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "RoleID"))
                view.RoleID = dataReader.GetValueOrDefault<int>("RoleID");
            if (DataReaderRowFilter.RowFilter(dataReader, "RoleName"))
                view.RoleName = dataReader.GetValueOrDefault<String>("RoleName");
            
            return view;
        }
    }
}
