﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_SellerInfoMapper<T> : IRowMapper<T> where T : T_PL_SellerInfo, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "SellerID"))
                view.SellerID = dataReader.GetValueOrDefault<Guid>("SellerID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Gender"))
                view.Gender = dataReader.GetValueOrDefault<String>("Gender")=="1"?"男":"女";
            if (DataReaderRowFilter.RowFilter(dataReader, "Name"))
                view.Name = dataReader.GetValueOrDefault<String>("Name");
            if (DataReaderRowFilter.RowFilter(dataReader, "PinyinName"))
                view.PinyinName = dataReader.GetValueOrDefault<String>("PinyinName");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<String>("IDNo");
            
            return view;
        }
    }
}
