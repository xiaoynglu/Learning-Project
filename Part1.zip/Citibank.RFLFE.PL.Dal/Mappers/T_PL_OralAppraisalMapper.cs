﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_OralAppraisalMapper<T> : IRowMapper<T> where T : T_PL_OralAppraisal, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyID"))
                view.CompanyID = dataReader.GetValueOrDefault<int>("CompanyID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyName"))
                view.CompanyName = dataReader.GetValueOrDefault<string>("CompanyName");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestDate"))
                view.RequestDate = dataReader.GetValueOrDefault<string>("RequestDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "AcceptDate"))
                view.AcceptDate = dataReader.GetValueOrDefault<string>("AcceptDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Price"))
                view.Price = dataReader.GetValueOrDefault<decimal>("Price");
            if (DataReaderRowFilter.RowFilter(dataReader, "Fee"))
                view.Fee = dataReader.GetValueOrDefault<decimal>("Fee");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<string>("Remarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateID"))
                view.CreateID = dataReader.GetValueOrDefault<string>("CreateID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateDate"))
                view.CreateDate = dataReader.GetValueOrDefault<string>("CreateDate");

            return view;
        }
    }
}
