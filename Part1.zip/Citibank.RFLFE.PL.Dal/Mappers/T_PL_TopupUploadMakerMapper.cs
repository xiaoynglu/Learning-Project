﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_TopupUploadMakerMapper<T> : IRowMapper<T> where T : T_PL_TopupUploadMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TopupID"))
                view.TopupID = dataReader.GetValueOrDefault<Guid>("TopupID");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgApplicationNo"))
                view.OrgApplicationNo = dataReader.GetValueOrDefault<string>("OrgApplicationNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "TopUpSegment"))
                view.TopUpSegment = dataReader.GetValueOrDefault<string>("TopUpSegment");
            if (DataReaderRowFilter.RowFilter(dataReader, "ID_No"))
                view.ID_No = dataReader.GetValueOrDefault<string>("ID_No");
            if (DataReaderRowFilter.RowFilter(dataReader, "MainBorrower"))
                view.MainBorrower = dataReader.GetValueOrDefault<string>("MainBorrower");
            if (DataReaderRowFilter.RowFilter(dataReader, "AgentCode"))
                view.AgentCode = dataReader.GetValueOrDefault<string>("AgentCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgLoanSize"))
                view.OrgLoanSize = dataReader.GetValueOrDefault<decimal>("OrgLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "TopUpApprovedTenor"))
                view.TopUpApprovedTenor = dataReader.GetValueOrDefault<int>("TopUpApprovedTenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "TopUpApprovedLoanSize"))
                view.TopUpApprovedLoanSize = dataReader.GetValueOrDefault<decimal>("TopUpApprovedLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "TopUpRate"))
                view.TopUpRate = dataReader.GetValueOrDefault<decimal>("TopUpRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<int>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "StatusDesc"))
                view.StatusDesc = dataReader.GetValueOrDefault<string>("StatusDesc");

            return view;
        }
    }
}
