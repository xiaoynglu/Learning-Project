﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class FinanceSurveyViewMapper<T> : IRowMapper<T> where T : FinanceSurveyView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "MBCustId"))
                view.MBCustId = dataReader.GetValueOrDefault<String>("MBCustId");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB1CustId"))
                view.CB1CustId = dataReader.GetValueOrDefault<String>("CB1CustId");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB2CustId"))
                view.CB2CustId = dataReader.GetValueOrDefault<String>("CB2CustId");
            if (DataReaderRowFilter.RowFilter(dataReader, "MB_PaySlip"))
                view.MB_PaySlip = dataReader.GetValueOrDefault<Decimal>("MB_PaySlip");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB1_PaySlip"))
                view.CB1_PaySlip = dataReader.GetValueOrDefault<Decimal>("CB1_PaySlip");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB2_PaySlip"))
                view.CB2_PaySlip = dataReader.GetValueOrDefault<Decimal>("CB2_PaySlip");
            if (DataReaderRowFilter.RowFilter(dataReader, "FamilyOtherDebt"))
                view.FamilyOtherDebt = dataReader.GetValueOrDefault<Decimal>("FamilyOtherDebt");
            if (DataReaderRowFilter.RowFilter(dataReader, "MB_CompanyLetter"))
                view.MB_CompanyLetter = dataReader.GetValueOrDefault<Decimal>("MB_CompanyLetter");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB1_CompanyLetter"))
                view.CB1_CompanyLetter = dataReader.GetValueOrDefault<Decimal>("CB1_CompanyLetter");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB2_CompanyLetter"))
                view.CB2_CompanyLetter = dataReader.GetValueOrDefault<Decimal>("CB2_CompanyLetter");
            if (DataReaderRowFilter.RowFilter(dataReader, "MB_MonthlyIncome"))
                view.MB_MonthlyIncome = dataReader.GetValueOrDefault<Decimal>("MB_MonthlyIncome");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB1_MonthlyIncome"))
                view.CB1_MonthlyIncome = dataReader.GetValueOrDefault<Decimal>("CB1_MonthlyIncome");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB2_MonthlyIncome"))
                view.CB2_MonthlyIncome = dataReader.GetValueOrDefault<Decimal>("CB2_MonthlyIncome");
            if (DataReaderRowFilter.RowFilter(dataReader, "MBMonthlyDebt"))
                view.MBMonthlyDebt = dataReader.GetValueOrDefault<Decimal>("MBMonthlyDebt");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB1MonthlyDebt"))
                view.CB1MonthlyDebt = dataReader.GetValueOrDefault<Decimal>("CB1MonthlyDebt");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB2MonthlyDebt"))
                view.CB2MonthlyDebt = dataReader.GetValueOrDefault<Decimal>("CB2MonthlyDebt");

            if (DataReaderRowFilter.RowFilter(dataReader, "FamilyOtherMonthlyIncome"))
                view.FamilyOtherMonthlyIncome = dataReader.GetValueOrDefault<Decimal>("FamilyOtherMonthlyIncome");
            if (DataReaderRowFilter.RowFilter(dataReader, "FamilyMonthlyExpense"))
                view.FamilyMonthlyExpense = dataReader.GetValueOrDefault<Decimal>("FamilyMonthlyExpense");
            if (DataReaderRowFilter.RowFilter(dataReader, "MonthlyTotalIncome"))
                view.MonthlyTotalIncome = dataReader.GetValueOrDefault<Decimal>("MonthlyTotalIncome");
            if (DataReaderRowFilter.RowFilter(dataReader, "MonthlyTotalDebt"))
                view.MonthlyTotalDebt = dataReader.GetValueOrDefault<Decimal>("MonthlyTotalDebt");
            if (DataReaderRowFilter.RowFilter(dataReader, "MonthlyDisposableIncome"))
                view.MonthlyDisposableIncome = dataReader.GetValueOrDefault<Decimal>("MonthlyDisposableIncome");
            if (DataReaderRowFilter.RowFilter(dataReader, "MBEmployementType"))
                view.MBEmployementType = dataReader.GetValueOrDefault<string>("MBEmployementType");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerCount"))
                view.CustomerCount = dataReader.GetValueOrDefault<int>("CustomerCount");
            

            return view;
        }
    }
}
