﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_RateMakerMapper<T> : IRowMapper<T> where T : T_PL_RateMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T entity = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                entity.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                entity.ProdID = dataReader.GetValueOrDefault<int>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                entity.OrgCode = dataReader.GetValueOrDefault<string>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralType"))
                entity.CollateralType = dataReader.GetValueOrDefault<string>("CollateralType");
            if (DataReaderRowFilter.RowFilter(dataReader, "EmploymentType"))
                entity.EmploymentType = dataReader.GetValueOrDefault<string>("EmploymentType");
            if (DataReaderRowFilter.RowFilter(dataReader, "Segment"))
                entity.Segment = dataReader.GetValueOrDefault<string>("Segment");
            if (DataReaderRowFilter.RowFilter(dataReader, "Value"))
                entity.Value = dataReader.GetValueOrDefault<decimal>("Value");
            if (DataReaderRowFilter.RowFilter(dataReader, "BaseValue"))
                entity.BaseValue = dataReader.GetValueOrDefault<decimal>("BaseValue");
            if (DataReaderRowFilter.RowFilter(dataReader, "Spread"))
                entity.Spread = dataReader.GetValueOrDefault<decimal>("Spread");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsSecond"))
                entity.IsSecond = dataReader.GetValueOrDefault<bool>("IsSecond");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsOverFive"))
                entity.IsOverFive = dataReader.GetValueOrDefault<bool>("IsOverFive");

            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                entity.Status = dataReader.GetValueOrDefault<int>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                entity.Maker = dataReader.GetValueOrDefault<string>("Maker");

            if (DataReaderRowFilter.RowFilter(dataReader, "StatusDesc"))
                entity.StatusDesc = dataReader.GetValueOrDefault<string>("StatusDesc");
            return entity;
        }
    }
}
