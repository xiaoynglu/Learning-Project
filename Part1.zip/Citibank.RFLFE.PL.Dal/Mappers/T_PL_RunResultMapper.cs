﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_RunResultMapper<T> : IRowMapper<T> where T : T_PL_RunResult, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T entity = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                entity.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                entity.ProdID = dataReader.GetValueOrDefault<string>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageID"))
                entity.StageID = dataReader.GetValueOrDefault<string>("StageID");
            if (DataReaderRowFilter.RowFilter(dataReader, "MUE"))
                entity.MUE = dataReader.GetValueOrDefault<string>("MUE");
            if (DataReaderRowFilter.RowFilter(dataReader, "SDBR"))
                entity.SDBR = dataReader.GetValueOrDefault<string>("SDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "UDBR"))
                entity.UDBR = dataReader.GetValueOrDefault<string>("UDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "CDBR"))
                entity.CDBR = dataReader.GetValueOrDefault<string>("CDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "TDBR"))
                entity.TDBR = dataReader.GetValueOrDefault<string>("TDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "LTV"))
                entity.LTV = dataReader.GetValueOrDefault<string>("LTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "MonthlyInstallment"))
                entity.MonthlyInstallment = dataReader.GetValueOrDefault<string>("MonthlyInstallment");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBoC"))
                entity.PBoC = dataReader.GetValueOrDefault<string>("PBoC");
            if (DataReaderRowFilter.RowFilter(dataReader, "ALS"))
                entity.ALS = dataReader.GetValueOrDefault<string>("ALS");
            if (DataReaderRowFilter.RowFilter(dataReader, "NgtvFile"))
                entity.NgtvFile = dataReader.GetValueOrDefault<string>("NgtvFile");
            if (DataReaderRowFilter.RowFilter(dataReader, "DupCheck"))
                entity.DupCheck = dataReader.GetValueOrDefault<string>("DupCheck");
            if (DataReaderRowFilter.RowFilter(dataReader, "RltdPt"))
                entity.RltdPt = dataReader.GetValueOrDefault<string>("RltdPt");
            if (DataReaderRowFilter.RowFilter(dataReader, "ItnFraud"))
                entity.ItnFraud = dataReader.GetValueOrDefault<string>("ItnFraud");
            if (DataReaderRowFilter.RowFilter(dataReader, "Velocity"))
                entity.Velocity = dataReader.GetValueOrDefault<string>("Velocity");
            if (DataReaderRowFilter.RowFilter(dataReader, "Verf"))
                entity.Verf = dataReader.GetValueOrDefault<string>("Verf");
            if (DataReaderRowFilter.RowFilter(dataReader, "RacStatus"))
                entity.RacStatus = dataReader.GetValueOrDefault<string>("RacStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "Devationed"))
                entity.Devationed = dataReader.GetValueOrDefault<string>("Devationed");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaxLoanSize"))
                entity.MaxLoanSize = dataReader.GetValueOrDefault<string>("MaxLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "CStage"))
                entity.CStage = dataReader.GetValueOrDefault<string>("CStage");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOCIqrDate"))
                entity.PBOCIqrDate = dataReader.GetValueOrDefault<string>("PBOCIqrDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Prescreener"))
                entity.Prescreener = dataReader.GetValueOrDefault<string>("Prescreener");
            if (DataReaderRowFilter.RowFilter(dataReader, "Verifier"))
                entity.Verifier = dataReader.GetValueOrDefault<string>("Verifier");
            if (DataReaderRowFilter.RowFilter(dataReader, "CrdtSn"))
                entity.CrdtSn = dataReader.GetValueOrDefault<string>("CrdtSn");
            if (DataReaderRowFilter.RowFilter(dataReader, "FApprover"))
                entity.FApprover = dataReader.GetValueOrDefault<string>("FApprover");
            if (DataReaderRowFilter.RowFilter(dataReader, "SApprover"))
                entity.SApprover = dataReader.GetValueOrDefault<string>("SApprover");
            if (DataReaderRowFilter.RowFilter(dataReader, "MDBR"))
                entity.MDBR = dataReader.GetValueOrDefault<string>("MDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "RateException"))
                entity.RateException = dataReader.GetValueOrDefault<string>("RateException") == "False" ? "false" : "true";
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseBureauCheck"))
                entity.HouseBureauCheck = dataReader.GetValueOrDefault<string>("HouseBureauCheck");
            return entity;
        }
    }
}
