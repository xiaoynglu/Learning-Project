﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_LoanApprovalMapper<T> : IRowMapper<T> where T : T_PL_LoanApproval, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageID"))
                view.StageID = dataReader.GetValueOrDefault<int>("StageID");
            if (DataReaderRowFilter.RowFilter(dataReader, "InterestRate"))
                view.InterestRate = dataReader.GetValueOrDefault<decimal>("InterestRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApprovedLoanSize"))
                view.ApprovedLoanSize = dataReader.GetValueOrDefault<decimal>("ApprovedLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApprovedLoanTenor"))
                view.ApprovedLoanTenor = dataReader.GetValueOrDefault<string>("ApprovedLoanTenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "RefreshedRate"))
                view.RefreshedRate = dataReader.GetValueOrDefault<string>("RefreshedRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "HomeOtherIncome"))
                view.HomeOtherIncome = dataReader.GetValueOrDefault<decimal>("HomeOtherIncome");
            if (DataReaderRowFilter.RowFilter(dataReader, "HomeOtherDebt"))
                view.HomeOtherDebt = dataReader.GetValueOrDefault<decimal>("HomeOtherDebt");
            if (DataReaderRowFilter.RowFilter(dataReader, "HomeMonthly"))
                view.HomeMonthly = dataReader.GetValueOrDefault<decimal>("HomeMonthly");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcessorID"))
                view.ProcessorID = dataReader.GetValueOrDefault<string>("ProcessorID");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedHouse"))
                view.ProceededDate = dataReader.GetValueOrDefault<DateTime>("VerifiedHouse");
            return view;
        }
    }
}
