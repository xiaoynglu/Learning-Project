﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class CreditRatingCheckerViewMapper<T> : IRowMapper<T> where T : CreditRatingCheckerView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<String>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgTID"))
                view.OrgTID = dataReader.GetValueOrDefault<String>("OrgTID");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestType"))
                view.RequestTypeShow = dataReader.GetValueOrDefault<String>("RequestType")=="1"? "新增":"修改";
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchCode"))
                view.BranchCode = dataReader.GetValueOrDefault<String>("BranchCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "SoeID"))
                view.SoeID = dataReader.GetValueOrDefault<String>("SoeID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProductName"))
                view.ProductName = dataReader.GetValueOrDefault<String>("ProductName");
            if (DataReaderRowFilter.RowFilter(dataReader, "LoanSize"))
                view.LoanSizeChange = dataReader.GetValueOrDefault<String>("RequestType") == "1" ? dataReader.GetValueOrDefault<String>("LoanSize") : dataReader.GetValueOrDefault<String>("OrgLoanSize") + " => " + dataReader.GetValueOrDefault<String>("LoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "levelCode"))
                view.levelCodeChange = dataReader.GetValueOrDefault<String>("RequestType") == "1" ? dataReader.GetValueOrDefault<String>("levelCode") : dataReader.GetValueOrDefault<String>("OrglevelCode") + " => " + dataReader.GetValueOrDefault<String>("LevelCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<String>("Maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "StatusValue"))
                view.Status = dataReader.GetValueOrDefault<String>("StatusValue");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateTime"))
                view.CreateTime = dataReader.GetValueOrDefault<String>("CreateTime");
            return view;
        }
    }
}
