﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class FullRevalutionViewMapper<T> : IRowMapper<T> where T : FullRevalutionView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<Int32>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsApplied"))
                view.IsApplied = dataReader.GetValueOrDefault<String>("IsApplied");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsApplied"))
                view.IsAppliedDes = dataReader.GetValueOrDefault<String>("IsApplied")=="True"?"是":"否";
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyName"))
                view.CompanyName = dataReader.GetValueOrDefault<String>("CompanyName");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyID"))
                view.CompanyID = dataReader.GetValueOrDefault<String>("CompanyID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestDate"))
                view.RequestDate = Convert.ToDateTime(dataReader.GetValueOrDefault<String>("RequestDate")).ToString("yyyy-MM-dd");
            if (DataReaderRowFilter.RowFilter(dataReader, "AcceptDate"))
                view.AcceptDate = Convert.ToDateTime(dataReader.GetValueOrDefault<String>("AcceptDate")).ToString("yyyy-MM-dd");
            if (DataReaderRowFilter.RowFilter(dataReader, "Price"))
                view.Price = dataReader.GetValueOrDefault<String>("Price");
            if (DataReaderRowFilter.RowFilter(dataReader, "Fee"))
                view.Fee = dataReader.GetValueOrDefault<String>("Fee");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<String>("Remarks");

            return view;
        }
    }
}
