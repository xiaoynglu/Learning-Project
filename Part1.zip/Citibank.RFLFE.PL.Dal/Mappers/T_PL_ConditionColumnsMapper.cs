﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_ConditionColumnsMapper<T> : IRowMapper<T> where T : T_PL_ConditionColumns, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ID"))
                view.ID = dataReader.GetValueOrDefault<int>("ID");
            if (DataReaderRowFilter.RowFilter(dataReader, "DisplayName"))
                view.DisplayName = dataReader.GetValueOrDefault<string>("DisplayName");
            return view;
        }
    }
}
