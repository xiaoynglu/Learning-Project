﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class EvlReportListViewMapper<T> : IRowMapper<T> where T : EvlReportListView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "appNo"))
                view.appNo = dataReader.GetValueOrDefault<String>("appNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "cnName"))
                view.cnName = dataReader.GetValueOrDefault<String>("cnName");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustName"))
                view.CustName = dataReader.GetValueOrDefault<String>("CustName");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseType"))
                view.HouseType = dataReader.GetValueOrDefault<String>("HouseType");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseAge"))
                view.HouseAge = dataReader.GetValueOrDefault<String>("HouseAge");
            if (DataReaderRowFilter.RowFilter(dataReader, "Coll"))
                view.Coll = dataReader.GetValueOrDefault<String>("Coll");
            if (DataReaderRowFilter.RowFilter(dataReader, "Area"))
                view.Area = dataReader.GetValueOrDefault<String>("Area");
            
            return view;
        }
    }
}
