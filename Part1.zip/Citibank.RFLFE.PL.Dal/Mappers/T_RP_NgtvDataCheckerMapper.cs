﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_RP_NgtvDataCheckerMapper<T> : IRowMapper<T> where T : T_RP_NegativeDataCheckerView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustName"))
                view.CustName = dataReader.GetValueOrDefault<string>("CustName");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<string>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyName"))
                view.CompanyName = dataReader.GetValueOrDefault<string>("CompanyName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DOB"))
                view.DOB = dataReader.GetValueOrDefault<string>("DOB");
            if (DataReaderRowFilter.RowFilter(dataReader, "AgentName"))
                view.AgentName = dataReader.GetValueOrDefault<string>("AgentName");
            if (DataReaderRowFilter.RowFilter(dataReader, "SalesName"))
                view.SalesName = dataReader.GetValueOrDefault<string>("SalesName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Reason"))
                view.Reason = dataReader.GetValueOrDefault<string>("Reason");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherCertID"))
                view.OtherCertID = dataReader.GetValueOrDefault<string>("OtherCertID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<string>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "OpType"))
                view.OpType = dataReader.GetValueOrDefault<string>("OpType");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateDate"))
                view.CreateDate = dataReader.GetValueOrDefault<string>("CreateDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedTime"))
                view.ModifiedTime = dataReader.GetValueOrDefault<string>("ModifiedTime"); 
            
            return view;
        }
    }
}
