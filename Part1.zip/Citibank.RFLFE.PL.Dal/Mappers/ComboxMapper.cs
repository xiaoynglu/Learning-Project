﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class ComboxMapper<T> : IRowMapper<T> where T : ComboboxEntity, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "Description"))
                view.Description = dataReader.GetValueOrDefault<string>("Description");
            if (DataReaderRowFilter.RowFilter(dataReader, "Code"))
                view.Code = dataReader.GetValueOrDefault<string>("Code");
            return view;
        }   
    }
}
