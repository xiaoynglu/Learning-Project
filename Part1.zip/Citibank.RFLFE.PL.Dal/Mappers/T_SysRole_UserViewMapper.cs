﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_SysRole_UserViewMapper<T> : IRowMapper<T> where T : T_SysRole_UserView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<String>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "SoeID"))
                view.SoeID = dataReader.GetValueOrDefault<String>("SoeID");
            if (DataReaderRowFilter.RowFilter(dataReader, "GEID"))
                view.GEID = dataReader.GetValueOrDefault<String>("GEID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AgentCode"))
                view.AgentCode = dataReader.GetValueOrDefault<String>("AgentCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "CNName"))
                view.CNName = dataReader.GetValueOrDefault<String>("CNName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ENName"))
                view.ENName = dataReader.GetValueOrDefault<String>("ENName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<String>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchCode"))
                view.BranchCode = dataReader.GetValueOrDefault<String>("BranchCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Location"))
                view.Location = dataReader.GetValueOrDefault<String>("Location");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<String>("Status")=="0"?"已禁用":"已启用";
            if (DataReaderRowFilter.RowFilter(dataReader, "RoleType"))
                view.RoleType = dataReader.GetValueOrDefault<String>("RoleType");
            if (DataReaderRowFilter.RowFilter(dataReader, "LocationDesc"))
                view.LocationDesc = dataReader.GetValueOrDefault<String>("LocationDesc");
            if (DataReaderRowFilter.RowFilter(dataReader, "RoleName"))
                view.RoleName = dataReader.GetValueOrDefault<String>("RoleName");
            if (DataReaderRowFilter.RowFilter(dataReader, "LastLoginTime"))
                view.LastLoginTime = dataReader.GetValueOrDefault<String>("LastLoginTime");
            
            return view;
        }
    }
}
