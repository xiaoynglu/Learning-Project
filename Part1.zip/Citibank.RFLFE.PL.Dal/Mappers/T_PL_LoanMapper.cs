﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using System.Reflection;
namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_LoanMapper<T> : IRowMapper<T> where T : T_PL_Loan, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();

            PropertyInfo[] properties = typeof(T).GetProperties();

            if (DataReaderRowFilter.RowFilter(dataReader, "CustSegment"))
                view.CustSegment = dataReader.GetValueOrDefault<String>("CustSegment");
            if (DataReaderRowFilter.RowFilter(dataReader, "AccOpenDate"))
                view.AccOpenDate = dataReader.GetValueOrDefault<DateTime>("AccOpenDate").ToString("yyyy-MM-dd HH:mm:ss");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNO"))
                view.AppNO = dataReader.GetValueOrDefault<String>("AppNO");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApprovedLoanSize"))
                view.ApprovedLoanSize = dataReader.GetValueOrDefault<Decimal>("ApprovedLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaxLoanSize"))
                view.MaxLoanSize = dataReader.GetValueOrDefault<Decimal>("MaxLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "AvailableUnsecuredSize"))
                view.AvailableUnsecuredSize = dataReader.GetValueOrDefault<Decimal>("AvailableUnsecuredSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApprovedTenor"))
                view.ApprovedTenor = dataReader.GetValueOrDefault<String>("ApprovedTenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "BaseLTV"))
                view.BaseLTV = dataReader.GetValueOrDefault<Decimal>("BaseLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "BaseRate"))
                view.BaseRate = dataReader.GetValueOrDefault<Decimal>("BaseRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "DisbursedDate"))
                view.DisbursedDate = dataReader.GetValueOrDefault<DateTime>("DisbursedDate").ToString("yyyy-MM-dd HH:mm:ss");
            if (DataReaderRowFilter.RowFilter(dataReader, "Fee"))
                view.Fee = dataReader.GetValueOrDefault<Decimal>("Fee");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstHouseArea"))
                view.FirstHouseArea = dataReader.GetValueOrDefault<Decimal>("FirstHouseArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstHouseOp"))
                view.FirstHouseOp = dataReader.GetValueOrDefault<String>("FirstHouseOp");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstPayAmount"))
                view.FirstPayAmount = dataReader.GetValueOrDefault<Decimal>("FirstPayAmount");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstPayPercent"))
                view.FirstPayPercent = dataReader.GetValueOrDefault<Decimal>("FirstPayPercent");
            if (DataReaderRowFilter.RowFilter(dataReader, "HasProperty"))
                view.HasProperty = dataReader.GetValueOrDefault<String>("HasProperty");
            if (DataReaderRowFilter.RowFilter(dataReader, "Installment"))
                view.Installment = dataReader.GetValueOrDefault<Decimal>("Installment");
            if (DataReaderRowFilter.RowFilter(dataReader, "InsuranceFee"))
                view.InsuranceFee = dataReader.GetValueOrDefault<Decimal>("InsuranceFee");
            if (DataReaderRowFilter.RowFilter(dataReader, "InterestRate"))
                view.InterestRate = dataReader.GetValueOrDefault<Decimal>("InterestRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsImprovedHouse"))
                view.IsImprovedHouse = dataReader.GetValueOrDefault<String>("IsImprovedHouse");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsPartialMortgage"))
                view.IsPartialMortgage = dataReader.GetValueOrDefault<String>("IsPartialMortgage");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaxAllowedLTV"))
                view.MaxAllowedLTV = dataReader.GetValueOrDefault<Decimal>("MaxAllowedLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "MorgageCount"))
                view.MorgageCount = dataReader.GetValueOrDefault<Int32>("MorgageCount");
            if (DataReaderRowFilter.RowFilter(dataReader, "OwnHouse"))
                view.OwnHouse = dataReader.GetValueOrDefault<String>("OwnHouse") == "True" ? "1" : "0";
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<Int32>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<String>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProposalLoanSize"))
                view.ProposalLoanSize = dataReader.GetValueOrDefault<Decimal>("ProposalLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProposalTenor"))
                view.ProposalTenor = dataReader.GetValueOrDefault<String>("ProposalTenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReducedLTV"))
                view.ReducedLTV = dataReader.GetValueOrDefault<Decimal>("ReducedLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestLoanSize"))
                view.RequestLoanSize = dataReader.GetValueOrDefault<Decimal>("RequestLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestTenor"))
                view.RequestTenor = dataReader.GetValueOrDefault<String>("RequestTenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "TailAmount"))
                view.TailAmount = dataReader.GetValueOrDefault<Decimal>("TailAmount");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<String>("Remarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "Deviated"))
                view.Deviated = dataReader.GetValueOrDefault<Boolean>("Deviated");
            return view;
        }
    }
}
