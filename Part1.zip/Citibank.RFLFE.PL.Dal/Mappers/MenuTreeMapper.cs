﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class MenuTreeMapper<T> : IRowMapper<T> where T : MenuTree, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ID"))
                view.ID = dataReader.GetValueOrDefault<Int32>("ID");
            if (DataReaderRowFilter.RowFilter(dataReader, "EleText"))
                view.EleText = dataReader.GetValueOrDefault<string>("EleText");
            if (DataReaderRowFilter.RowFilter(dataReader, "EleId"))
                view.EleId = dataReader.GetValueOrDefault<string>("EleId");
            if (DataReaderRowFilter.RowFilter(dataReader, "ParentId"))
                view.ParentId = dataReader.GetValueOrDefault<Int32>("ParentId");
            if (DataReaderRowFilter.RowFilter(dataReader, "SortBy"))
                view.SortBy = dataReader.GetValueOrDefault<Int32>("SortBy");
            if (DataReaderRowFilter.RowFilter(dataReader, "Url"))
                view.Url = dataReader.GetValueOrDefault<string>("Url");
            if (DataReaderRowFilter.RowFilter(dataReader, "disabled"))
                view.disabled = dataReader.GetValueOrDefault<bool>("disabled");
            return view;
        }
    }
}
