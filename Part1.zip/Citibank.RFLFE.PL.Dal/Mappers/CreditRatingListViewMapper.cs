﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class CreditRatingListViewMapper<T> : IRowMapper<T> where T : CreditRatingListView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ReasonCode"))
                view.ReasonCode = dataReader.GetValueOrDefault<String>("ReasonCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "LevelCode"))
                view.LevelCode = dataReader.GetValueOrDefault<String>("LevelCode");
           

            return view;
        }
    }
}
