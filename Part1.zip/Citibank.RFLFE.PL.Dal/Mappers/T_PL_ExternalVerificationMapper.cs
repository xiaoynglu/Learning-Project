﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_ExternalVerificationMapper<T> : IRowMapper<T> where T : T_PL_ExternalVerification, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreditStatus"))
                view.CreditStatus = dataReader.GetValueOrDefault<int>("CreditStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "HasSocialSecurity"))
                view.HasSocialSecurity = dataReader.GetValueOrDefault<bool>("HasSocialSecurity") == true ? 1 : 0;
            if (DataReaderRowFilter.RowFilter(dataReader, "PensionAmount"))
                view.PensionAmount = dataReader.GetValueOrDefault<decimal>("PensionAmount");
            if (DataReaderRowFilter.RowFilter(dataReader, "PensionNumber"))
                view.PensionNumber = dataReader.GetValueOrDefault<string>("PensionNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "PensionStatus"))
                view.PensionStatus = dataReader.GetValueOrDefault<int>("PensionStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "TaxesStatus"))
                view.TaxesStatus = dataReader.GetValueOrDefault<int>("TaxesStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<string>("Remarks");

            if (DataReaderRowFilter.RowFilter(dataReader, "CheckerID"))
                view.CheckerID = dataReader.GetValueOrDefault<string>("CheckerID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CheckDate"))
                view.CheckDate = dataReader.GetValueOrDefault<string>("CheckDate");

            return view;
        }
    }
}
