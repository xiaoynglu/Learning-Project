﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_HouseVerificationMapper<T> : IRowMapper<T> where T : T_PL_HouseVerification, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseAddress"))
                view.HouseAddress = dataReader.GetValueOrDefault<string>("HouseAddress");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<string>("Remarks");

            if (DataReaderRowFilter.RowFilter(dataReader, "CheckerID"))
                view.CheckerID = dataReader.GetValueOrDefault<string>("CheckerID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CheckDate"))
                view.CheckDate = dataReader.GetValueOrDefault<string>("CheckDate");

            return view;
        }
    }
}
