﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_EntrusPayMapper<T> : IRowMapper<T> where T : T_PL_EntrusPay, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "EntrusPayID"))
                view.EntrusPayID = dataReader.GetValueOrDefault<String>("EntrusPayID");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeName"))
                view.PayeeName = dataReader.GetValueOrDefault<String>("PayeeName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeBankName"))
                view.PayeeBankName = dataReader.GetValueOrDefault<String>("PayeeBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeBankNameDesc"))
                view.PayeeBankNameDesc = dataReader.GetValueOrDefault<String>("PayeeBankNameDesc");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeSubBankName"))
                view.PayeeSubBankName = dataReader.GetValueOrDefault<String>("PayeeSubBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeAccount"))
                view.PayeeAccount = dataReader.GetValueOrDefault<String>("PayeeAccount");
            if (DataReaderRowFilter.RowFilter(dataReader, "PaymentAmount"))
                view.PaymentAmount = dataReader.GetValueOrDefault<String>("PaymentAmount");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeBankFullName"))
                view.PayeeBankFullName = dataReader.GetValueOrDefault<String>("PayeeBankFullName");
            
            return view;
        }
    }
}
