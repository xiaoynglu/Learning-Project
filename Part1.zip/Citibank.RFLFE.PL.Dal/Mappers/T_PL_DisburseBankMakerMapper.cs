﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_DisburseBankMakerMapper<T> : IRowMapper<T> where T : T_PL_DisburseBankMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "Id"))
                view.Id = dataReader.GetValueOrDefault<string>("Id");
            if (DataReaderRowFilter.RowFilter(dataReader, "FullName"))
                view.FullName = dataReader.GetValueOrDefault<string>("FullName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Alias"))
                view.Alias = dataReader.GetValueOrDefault<string>("Alias");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "MakeDate"))
                view.MakeDate = dataReader.GetValueOrDefault<string>("MakeDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            if (DataReaderRowFilter.RowFilter(dataReader, "CheckDate"))
                view.CheckDate = dataReader.GetValueOrDefault<string>("CheckDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Operation"))
                view.Operation = dataReader.GetValueOrDefault<string>("Operation");
            if (DataReaderRowFilter.RowFilter(dataReader, "Operation"))
            {
                if (dataReader.GetValueOrDefault<string>("Operation") == "1")
                {
                    view.OpName = "新增";
                }
                if (dataReader.GetValueOrDefault<string>("Operation") == "2")
                {
                    view.OpName = "修改";
                }
                if (dataReader.GetValueOrDefault<string>("Operation") == "3")
                {
                    view.OpName = "删除";
                }
            }                        
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<string>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "statusname"))
                view.statusname = dataReader.GetValueOrDefault<string>("statusname"); 

            return view;
        }
    }
}
