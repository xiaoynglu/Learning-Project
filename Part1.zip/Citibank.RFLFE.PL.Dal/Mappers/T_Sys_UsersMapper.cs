﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_Sys_UsersMapper<T> : IRowMapper<T> where T : T_Sys_Users, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AgentCode"))
                view.AgentCode = dataReader.GetValueOrDefault<string>("AgentCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchCode"))
                view.BranchCode = dataReader.GetValueOrDefault<string>("BranchCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            if (DataReaderRowFilter.RowFilter(dataReader, "CNName"))
                view.CNName = dataReader.GetValueOrDefault<string>("CNName");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateTime"))
                view.CreateTime = dataReader.GetValueOrDefault<DateTime>("CreateTime").ToString("yyyy-MM-dd");
            if (DataReaderRowFilter.RowFilter(dataReader, "ENName"))
                view.ENName = dataReader.GetValueOrDefault<string>("ENName");
            if (DataReaderRowFilter.RowFilter(dataReader, "GEID"))
                view.GEID = dataReader.GetValueOrDefault<string>("GEID");
            if (DataReaderRowFilter.RowFilter(dataReader, "GOCCode"))
                view.GOCCode = dataReader.GetValueOrDefault<string>("GOCCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Location"))
                view.Location = dataReader.GetValueOrDefault<string>("Location");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedTime"))
                view.ModifiedTime = dataReader.GetValueOrDefault<DateTime>("ModifiedTime").ToString("yyyy-MM-dd");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<string>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Phone"))
                view.Phone = dataReader.GetValueOrDefault<string>("Phone");
            if (DataReaderRowFilter.RowFilter(dataReader, "RoleType"))
                view.RoleType = dataReader.GetValueOrDefault<int>("RoleType");
            if (DataReaderRowFilter.RowFilter(dataReader, "RoleName"))
                view.RoleName = dataReader.GetValueOrDefault<string>("RoleName");
            if (DataReaderRowFilter.RowFilter(dataReader, "SoeID"))
                view.SoeID = dataReader.GetValueOrDefault<string>("SoeID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<int>("Status");
            return view;
        }
    }
}
