﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_RP_ADRMapper<T> : IRowMapper<T> where T : T_RP_ADR, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AvaliableLTV"))
                view.AvaliableLTV = dataReader.GetValueOrDefault<Decimal>("AvaliableLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "BaseRate"))
                view.BaseRate = dataReader.GetValueOrDefault<Decimal>("BaseRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "BMDeviated"))
                view.BMDeviated = dataReader.GetValueOrDefault<String>("BMDeviated");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrDBR"))
                view.CurrDBR = dataReader.GetValueOrDefault<Decimal>("CurrDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustSegment"))
                view.CustSegment = dataReader.GetValueOrDefault<String>("CustSegment");
            if (DataReaderRowFilter.RowFilter(dataReader, "Deviated"))
                view.Deviated = dataReader.GetValueOrDefault<String>("Deviated");
            if (DataReaderRowFilter.RowFilter(dataReader, "DeviationLevel"))
                view.DeviationLevel = dataReader.GetValueOrDefault<String>("DeviationLevel");
            if (DataReaderRowFilter.RowFilter(dataReader, "DeviationRemarks"))
                view.DeviationRemarks = dataReader.GetValueOrDefault<String>("DeviationRemarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "DSCR"))
                view.DSCR = dataReader.GetValueOrDefault<Decimal>("DSCR");
            if (DataReaderRowFilter.RowFilter(dataReader, "Installment"))
                view.Installment = dataReader.GetValueOrDefault<Decimal>("Installment");
            if (DataReaderRowFilter.RowFilter(dataReader, "InterestRate"))
                view.InterestRate = dataReader.GetValueOrDefault<Decimal>("InterestRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "LoanAmount"))
                view.LoanAmount = dataReader.GetValueOrDefault<Decimal>("LoanAmount");
            if (DataReaderRowFilter.RowFilter(dataReader, "LoanTenor"))
                view.LoanTenor = dataReader.GetValueOrDefault<String>("LoanTenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaxLTV"))
                view.MaxLTV = dataReader.GetValueOrDefault<Int32>("MaxLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "PolicyDeviated"))
                view.PolicyDeviated = dataReader.GetValueOrDefault<String>("PolicyDeviated");
            if (DataReaderRowFilter.RowFilter(dataReader, "PolicyDeviationReason"))
                view.PolicyDeviationReason = dataReader.GetValueOrDefault<String>("PolicyDeviationReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "PriceDeviated"))
                view.PriceDeviated = dataReader.GetValueOrDefault<String>("PriceDeviated");
            if (DataReaderRowFilter.RowFilter(dataReader, "PriceDeviationReason"))
                view.PriceDeviationReason = dataReader.GetValueOrDefault<String>("PriceDeviationReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcessDeviated"))
                view.ProcessDeviated = dataReader.GetValueOrDefault<String>("ProcessDeviated");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcessDeviationReason"))
                view.ProcessDeviationReason = dataReader.GetValueOrDefault<String>("ProcessDeviationReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcID"))
                view.ProcID = dataReader.GetValueOrDefault<String>("ProcID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<Int32>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProposalDeviated"))
                view.ProposalDeviated = dataReader.GetValueOrDefault<String>("ProposalDeviated");
            if (DataReaderRowFilter.RowFilter(dataReader, "RateException"))
                view.RateException = dataReader.GetValueOrDefault<String>("RateException");
            if (DataReaderRowFilter.RowFilter(dataReader, "RefreshDate"))
                view.RefreshDate = dataReader.GetValueOrDefault<DateTime>("RefreshDate").ToString("yyyy-MM-dd HH:mm:ss");
            if (DataReaderRowFilter.RowFilter(dataReader, "Result"))
                view.Result = dataReader.GetValueOrDefault<String>("Result");
            if (DataReaderRowFilter.RowFilter(dataReader, "RiskSegment"))
                view.RiskSegment = dataReader.GetValueOrDefault<String>("RiskSegment");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalDBR"))
                view.TotalDBR = dataReader.GetValueOrDefault<Decimal>("TotalDBR");
            return view;
        }
    }
}
