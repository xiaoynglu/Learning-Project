﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_MortgagorsMapper<T> : IRowMapper<T> where T : T_PL_Mortgagors, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "MortID"))
                view.MortID = dataReader.GetValueOrDefault<Guid>("MortID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustNO"))
                view.CustNO = dataReader.GetValueOrDefault<String>("CustNO");
            if (DataReaderRowFilter.RowFilter(dataReader, "Name"))
                view.Name = dataReader.GetValueOrDefault<string>("Name");
            if (DataReaderRowFilter.RowFilter(dataReader, "PinyinName"))
                view.PinyinName = dataReader.GetValueOrDefault<string>("PinyinName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Relation"))
                view.Relation = dataReader.GetValueOrDefault<string>("Relation");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelationDesc"))
                view.RelationDesc = dataReader.GetValueOrDefault<string>("RelationDesc");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<string>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "Telephone"))
                view.Telephone = dataReader.GetValueOrDefault<string>("Telephone");
            if (DataReaderRowFilter.RowFilter(dataReader, "MobileNumber"))
                view.MobileNumber = dataReader.GetValueOrDefault<string>("MobileNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "MarriageStatus"))
                view.MarriageStatus = dataReader.GetValueOrDefault<string>("MarriageStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "SpouseName"))
                view.SpouseName = dataReader.GetValueOrDefault<string>("SpouseName");
            if (DataReaderRowFilter.RowFilter(dataReader, "SpousePinyinName"))
                view.SpousePinyinName = dataReader.GetValueOrDefault<string>("SpousePinyinName");
            if (DataReaderRowFilter.RowFilter(dataReader, "SpouseIDNo"))
                view.SpouseIDNo = dataReader.GetValueOrDefault<string>("SpouseIDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "SpouseTelephone"))
                view.SpouseTelephone = dataReader.GetValueOrDefault<string>("SpouseTelephone");
            if (DataReaderRowFilter.RowFilter(dataReader, "SpouseMobile"))
                view.SpouseMobile = dataReader.GetValueOrDefault<string>("SpouseMobile");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseProvince"))
                view.HouseProvince = dataReader.GetValueOrDefault<string>("HouseProvince");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseCity"))
                view.HouseCity = dataReader.GetValueOrDefault<string>("HouseCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseDistrict"))
                view.HouseDistrict = dataReader.GetValueOrDefault<string>("HouseDistrict");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseStreet"))
                view.HouseStreet = dataReader.GetValueOrDefault<string>("HouseStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "HousePostCode"))
                view.HousePostCode = dataReader.GetValueOrDefault<string>("HousePostCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelatedCustomersCount"))
                view.RelatedCustomersCount = dataReader.GetValueOrDefault<int>("RelatedCustomersCount");
            if (DataReaderRowFilter.RowFilter(dataReader, "MBCustID"))
                view.MBCustID = dataReader.GetValueOrDefault<string>("MBCustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB1CustID"))
                view.CB1CustID = dataReader.GetValueOrDefault<string>("CB1CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CB2CustID"))
                view.CB2CustID = dataReader.GetValueOrDefault<string>("CB2CustID");

            return view;
        }
    }
}
