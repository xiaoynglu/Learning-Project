﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_DocSubmittedMapper<T> : IRowMapper<T> where T : T_PL_DocSubmitted, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "DocID"))
                view.DocID = dataReader.GetValueOrDefault<Int32>("DocID");
            if (DataReaderRowFilter.RowFilter(dataReader, "DocName"))
                view.DocName = dataReader.GetValueOrDefault<String>("DocName");
            if (DataReaderRowFilter.RowFilter(dataReader, "GroupNo"))
                view.GroupNo = dataReader.GetValueOrDefault<String>("GroupNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcID"))
                view.ProcID = dataReader.GetValueOrDefault<String>("ProcID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<String>("Remarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageID"))
                view.StageID = dataReader.GetValueOrDefault<Int32>("StageID");
            if (DataReaderRowFilter.RowFilter(dataReader, "SubmittedTime"))
            {
                if (dataReader["SubmittedTime"] == null || string.IsNullOrEmpty(dataReader["SubmittedTime"].ToString()))
                {
                    view.SubmittedTime = string.Empty;
                }
                else
                {
                    view.SubmittedTime = dataReader.GetValueOrDefault<DateTime>("SubmittedTime").ToString("yyyy-MM-dd HH:mm:ss");
                }
            }
            if (DataReaderRowFilter.RowFilter(dataReader, "Submitted"))
                view.Submitted = dataReader.GetValueOrDefault<String>("Submitted");

            if (DataReaderRowFilter.RowFilter(dataReader, "IsRequired"))
                view.IsRequired = dataReader.GetValueOrDefault<String>("IsRequired");
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<long>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelationShip"))
                view.RelationShip = dataReader.GetValueOrDefault<string>("RelationShip");

            return view;
        }
    }
}
