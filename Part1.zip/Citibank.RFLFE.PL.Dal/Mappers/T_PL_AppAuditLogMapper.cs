﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_AppAuditLogMapper<T> : IRowMapper<T> where T : T_PL_AppAuditLog, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ID"))
                view.TID = dataReader.GetValueOrDefault<int>("ID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNO"))
                view.AppNO = dataReader.GetValueOrDefault<string>("AppNO").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "StageID"))
                view.StageID = dataReader.GetValueOrDefault<string>("StageID");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestType"))
                view.RequestType = dataReader.GetValueOrDefault<string>("RequestType");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestType"))
                view.RequestTypeShow = dataReader.GetValueOrDefault<string>("RequestType") == "1" ? "新增" : "修改";
            if (DataReaderRowFilter.RowFilter(dataReader, "LogType"))
                view.LogType = dataReader.GetValueOrDefault<string>("LogType");
            if (DataReaderRowFilter.RowFilter(dataReader, "TableName"))
                view.TableName = dataReader.GetValueOrDefault<string>("TableName");
            if (DataReaderRowFilter.RowFilter(dataReader, "GroupNumber"))
                view.GroupNumber = dataReader.GetValueOrDefault<Guid>("GroupNumber").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "LogContent"))
                view.LogContent = dataReader.GetValueOrDefault<string>("LogContent");
            if (DataReaderRowFilter.RowFilter(dataReader, "OperationLog"))
                view.OperationLog = dataReader.GetValueOrDefault<string>("OperationLog");
            if (DataReaderRowFilter.RowFilter(dataReader, "Operator"))
                view.Operator = dataReader.GetValueOrDefault<string>("Operator");
            if (DataReaderRowFilter.RowFilter(dataReader, "OperateTime"))
                view.OperateTime = dataReader.GetValueOrDefault<string>("OperateTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageName"))
                view.StageName = dataReader.GetValueOrDefault<string>("StageName");

            return view;
        }
    }
}
