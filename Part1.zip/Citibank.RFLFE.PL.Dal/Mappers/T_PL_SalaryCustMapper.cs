﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_SalaryCustMapper<T> : IRowMapper<T> where T : T_PL_SalaryCust, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseLevel"))
                view.EnterpriseLevel = dataReader.GetValueOrDefault<string>("EnterpriseLevel");
            if (DataReaderRowFilter.RowFilter(dataReader, "Department"))
                view.Department = dataReader.GetValueOrDefault<String>("Department");
            if (DataReaderRowFilter.RowFilter(dataReader, "Position"))
                view.Position = dataReader.GetValueOrDefault<String>("Position");
            if (DataReaderRowFilter.RowFilter(dataReader, "Job"))
                view.Job = dataReader.GetValueOrDefault<String>("Job");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseName"))
                view.EnterpriseName = dataReader.GetValueOrDefault<String>("EnterpriseName");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseProperty"))
                view.EnterpriseProperty = dataReader.GetValueOrDefault<String>("EnterpriseProperty");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseScale"))
                view.EnterpriseScale = dataReader.GetValueOrDefault<String>("EnterpriseScale");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentWorkingLife"))
                view.CurrentWorkingLife = dataReader.GetValueOrDefault<Int32>("CurrentWorkingLife");

            if (DataReaderRowFilter.RowFilter(dataReader, "PreWorkingLife"))
                view.PreWorkingLife = dataReader.GetValueOrDefault<Int32>("PreWorkingLife");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalWorkingLife"))
                view.TotalWorkingLife = dataReader.GetValueOrDefault<Int32>("TotalWorkingLife");
          
            return view;
        }
    }
}
