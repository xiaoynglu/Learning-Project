﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_SelfEmployedCustMapper<T> : IRowMapper<T> where T : T_PL_SelfEmployedCust, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentIndustryTime"))
                view.CurrentIndustryTime = dataReader.GetValueOrDefault<Int32>("CurrentIndustryTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "ShopName"))
                view.ShopName = dataReader.GetValueOrDefault<String>("ShopName");
            if (DataReaderRowFilter.RowFilter(dataReader, "RegistrationNumber"))
                view.RegistrationNumber = dataReader.GetValueOrDefault<String>("RegistrationNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "OperatorName"))
                view.OperatorName = dataReader.GetValueOrDefault<String>("OperatorName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OperationPlace"))
                view.OperationPlace = dataReader.GetValueOrDefault<String>("OperationPlace");
            if (DataReaderRowFilter.RowFilter(dataReader, "EmployeeNumber"))
                view.EmployeeNumber = dataReader.GetValueOrDefault<Int32>("EmployeeNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Contact"))
                view.Contact = dataReader.GetValueOrDefault<String>("Contact");
            if (DataReaderRowFilter.RowFilter(dataReader, "ContactPosition"))
                view.ContactPosition = dataReader.GetValueOrDefault<String>("ContactPosition");

            return view;
        }
    }
}
