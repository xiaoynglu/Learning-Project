﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_Sys_ProductsMapper<T> : IRowMapper<T> where T : T_Sys_Products, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<int>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdType"))
                view.ProdType = dataReader.GetValueOrDefault<string>("ProdType");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdCode"))
                view.ProdCode = dataReader.GetValueOrDefault<string>("ProdCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdRCCode"))
                view.ProdRCCode = dataReader.GetValueOrDefault<string>("ProdRCCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreditAcc"))
                view.CreditAcc = dataReader.GetValueOrDefault<string>("CreditAcc");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitAcc"))
                view.DebitAcc = dataReader.GetValueOrDefault<string>("DebitAcc");
            if (DataReaderRowFilter.RowFilter(dataReader, "Descriptions"))
                view.Descriptions = dataReader.GetValueOrDefault<string>("Descriptions");
            return view;
        }
    }
}
