﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_Sys_RegionMapper<T> : IRowMapper<T> where T : T_Sys_Region, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "RegionCode"))
                view.RegionCode = dataReader.GetValueOrDefault<String>("RegionCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "RegionName"))
                view.RegionName = dataReader.GetValueOrDefault<String>("RegionName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ParentCode"))
                view.ParentCode = dataReader.GetValueOrDefault<String>("ParentCode");
           

            return view;
        }
    }
}
