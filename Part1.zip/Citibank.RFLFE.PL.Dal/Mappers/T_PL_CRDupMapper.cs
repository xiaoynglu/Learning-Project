﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_CRDupMapper<T> : IRowMapper<T> where T : T_PL_CRDup, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "DupCRID"))
                view.DupCRID = dataReader.GetValueOrDefault<int>("DupCRID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();

            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "Name"))
                view.Name = dataReader.GetValueOrDefault<String>("Name");
            if (DataReaderRowFilter.RowFilter(dataReader, "MatchResult"))
                view.MatchResult = dataReader.GetValueOrDefault<String>("MatchResult");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNo"))
                view.AppNo = dataReader.GetValueOrDefault<String>("AppNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "MatchName"))
                view.MatchName = dataReader.GetValueOrDefault<String>("MatchName");
            if (DataReaderRowFilter.RowFilter(dataReader, "MatchIDNo"))
                view.MatchIDNo = dataReader.GetValueOrDefault<String>("MatchIDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppDate"))
                view.AppDate = dataReader.GetValueOrDefault<DateTime>("AppDate").ToString("yyyy/MM/dd"); ;
            if (DataReaderRowFilter.RowFilter(dataReader, "AppCurrStage"))
                view.AppCurrStage = dataReader.GetValueOrDefault<String>("AppCurrStage");    

            return view;
        }
    }
}
