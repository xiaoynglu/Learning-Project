﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class EvlApprovalListViewMapper<T> : IRowMapper<T> where T : EvlApprovalListView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "MUE"))
                view.MUE = dataReader.GetValueOrDefault<String>("MUE");
            if (DataReaderRowFilter.RowFilter(dataReader, "SDBR"))
                view.SDBR = dataReader.GetValueOrDefault<String>("SDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "UDBR"))
                view.UDBR = dataReader.GetValueOrDefault<String>("UDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "CDBR"))
                view.CDBR = dataReader.GetValueOrDefault<String>("CDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "TDBR"))
                view.TDBR = dataReader.GetValueOrDefault<String>("TDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "LTV"))
                view.LTV = dataReader.GetValueOrDefault<String>("LTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "MonthlyInstallment"))
                view.MonthlyInstallment = dataReader.GetValueOrDefault<String>("MonthlyInstallment");

            return view;
        }
    }
}
