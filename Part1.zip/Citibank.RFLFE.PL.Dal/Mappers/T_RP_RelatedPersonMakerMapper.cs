﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_RP_RelatedPersonMakerMapper<T> : IRowMapper<T> where T : T_RP_RelatedPersonMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CertID"))
                view.CertID = dataReader.GetValueOrDefault<string>("CertID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative1"))
                view.CloseRelative1 = dataReader.GetValueOrDefault<string>("CloseRelative1");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative10"))
                view.CloseRelative10 = dataReader.GetValueOrDefault<string>("CloseRelative10");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative11"))
                view.CloseRelative11 = dataReader.GetValueOrDefault<string>("CloseRelative11");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative12"))
                view.CloseRelative12 = dataReader.GetValueOrDefault<string>("CloseRelative12");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative13"))
                view.CloseRelative13 = dataReader.GetValueOrDefault<string>("CloseRelative13");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative14"))
                view.CloseRelative14 = dataReader.GetValueOrDefault<string>("CloseRelative14");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative15"))
                view.CloseRelative15 = dataReader.GetValueOrDefault<string>("CloseRelative15");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative16"))
                view.CloseRelative16 = dataReader.GetValueOrDefault<string>("CloseRelative16");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative17"))
                view.CloseRelative17 = dataReader.GetValueOrDefault<string>("CloseRelative17");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative18"))
                view.CloseRelative18 = dataReader.GetValueOrDefault<string>("CloseRelative18");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative19"))
                view.CloseRelative19 = dataReader.GetValueOrDefault<string>("CloseRelative19");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative20"))
                view.CloseRelative20 = dataReader.GetValueOrDefault<string>("CloseRelative20");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative2"))
                view.CloseRelative2 = dataReader.GetValueOrDefault<string>("CloseRelative2");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative3"))
                view.CloseRelative3 = dataReader.GetValueOrDefault<string>("CloseRelative3");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative4"))
                view.CloseRelative4 = dataReader.GetValueOrDefault<string>("CloseRelative4");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative5"))
                view.CloseRelative5 = dataReader.GetValueOrDefault<string>("CloseRelative5");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative6"))
                view.CloseRelative6 = dataReader.GetValueOrDefault<string>("CloseRelative6");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative7"))
                view.CloseRelative7 = dataReader.GetValueOrDefault<string>("CloseRelative7");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative8"))
                view.CloseRelative8 = dataReader.GetValueOrDefault<string>("CloseRelative8");
            if (DataReaderRowFilter.RowFilter(dataReader, "CloseRelative9"))
                view.CloseRelative9 = dataReader.GetValueOrDefault<string>("CloseRelative9");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateDate"))
                view.CreateDate = dataReader.GetValueOrDefault<DateTime>("CreateDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "InsideName"))
                view.InsideName = dataReader.GetValueOrDefault<string>("InsideName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedTime"))
                view.ModifiedTime = dataReader.GetValueOrDefault<DateTime>("ModifiedTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<int>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "StatusDesc"))
                view.StatusDesc = dataReader.GetValueOrDefault<string>("StatusDesc");
            if (DataReaderRowFilter.RowFilter(dataReader, "OpType"))
                view.OpType = dataReader.GetValueOrDefault<int>("OpType");
            if (DataReaderRowFilter.RowFilter(dataReader, "OpTypeDesc"))
                view.OpTypeDesc = dataReader.GetValueOrDefault<string>("OpTypeDesc");
            return view;
        }
    }
}
