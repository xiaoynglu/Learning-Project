﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_ReportDefinationDetailMapper<T> : IRowMapper<T> where T : T_PL_ReportDefinationDetail, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            
            if (DataReaderRowFilter.RowFilter(dataReader, "PreFilename"))
                view.PreFilename = dataReader.GetValueOrDefault<String>("PreFilename");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "ColNo"))
                view.ColNo = dataReader.GetValueOrDefault<Int32>("ColNo");

            if (DataReaderRowFilter.RowFilter(dataReader, "Required"))
                view.Required = dataReader.GetValueOrDefault<Int32>("Required");

            if (DataReaderRowFilter.RowFilter(dataReader, "StartPostion"))
                view.StartPostion = dataReader.GetValueOrDefault<Int32>("StartPostion");

            if (DataReaderRowFilter.RowFilter(dataReader, "EndPostion"))
                view.EndPostion = dataReader.GetValueOrDefault<Int32>("EndPostion");

            if (DataReaderRowFilter.RowFilter(dataReader, "MinLength"))
                view.MinLength = dataReader.GetValueOrDefault<Int32>("MinLength");

            if (DataReaderRowFilter.RowFilter(dataReader, "MaxLength"))
                view.MaxLength = dataReader.GetValueOrDefault<Int32>("MaxLength");

            if (DataReaderRowFilter.RowFilter(dataReader, "DataType"))
                view.DataType = dataReader.GetValueOrDefault<Int32>("DataType");

            if (DataReaderRowFilter.RowFilter(dataReader, "DataFormat"))
                view.DataFormat = dataReader.GetValueOrDefault<String>("DataFormat");


            if (DataReaderRowFilter.RowFilter(dataReader, "ColName"))
                view.ColName = dataReader.GetValueOrDefault<String>("ColName");

            if (DataReaderRowFilter.RowFilter(dataReader, "DataSource"))
                view.DataSource = dataReader.GetValueOrDefault<Int32>("DataSource");

            if (DataReaderRowFilter.RowFilter(dataReader, "RowNo"))
                view.RowNo = dataReader.GetValueOrDefault<Int32>("RowNo");

         

            return view;
        }
    
    }
}
