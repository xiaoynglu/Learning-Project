﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_CollateralMapper<T> : IRowMapper<T> where T : T_PL_Collateral, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "HasProperty"))
                view.HasProperty = dataReader.GetValueOrDefault<string>("HasProperty");
            if (DataReaderRowFilter.RowFilter(dataReader, "OwnHouse"))
                view.OwnHouse = dataReader.GetValueOrDefault<Boolean>("OwnHouse")==true?"1":"0";
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralType"))
                view.CollateralType = dataReader.GetValueOrDefault<string>("CollateralType");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseValue"))
                view.HouseValue = dataReader.GetValueOrDefault<decimal>("HouseValue");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseAge"))
                view.HouseAge = dataReader.GetValueOrDefault<int>("HouseAge");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseArea"))
                view.HouseArea = dataReader.GetValueOrDefault<decimal>("HouseArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "CarArea"))
                view.CarArea = dataReader.GetValueOrDefault<decimal>("CarArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "GarageArea"))
                view.GarageArea = dataReader.GetValueOrDefault<decimal>("GarageArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyType"))
                view.PropertyType = dataReader.GetValueOrDefault<string>("PropertyType");
            if (DataReaderRowFilter.RowFilter(dataReader, "Province"))
                view.Province = dataReader.GetValueOrDefault<string>("Province");
            if (DataReaderRowFilter.RowFilter(dataReader, "City"))
                view.City = dataReader.GetValueOrDefault<string>("City");
            if (DataReaderRowFilter.RowFilter(dataReader, "Region"))
                view.Region = dataReader.GetValueOrDefault<string>("Region");
            if (DataReaderRowFilter.RowFilter(dataReader, "Address"))
                view.Address = dataReader.GetValueOrDefault<string>("Address");
            if (DataReaderRowFilter.RowFilter(dataReader, "ResidentialType"))
                view.ResidentialType = dataReader.GetValueOrDefault<string>("ResidentialType");
            if (DataReaderRowFilter.RowFilter(dataReader, "CommunityName"))
                view.CommunityName = dataReader.GetValueOrDefault<string>("CommunityName");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentStatus"))
                view.CurrentStatus = dataReader.GetValueOrDefault<string>("CurrentStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyPermits"))
                view.PropertyPermits = dataReader.GetValueOrDefault<string>("PropertyPermits");
            if (DataReaderRowFilter.RowFilter(dataReader, "LandArea"))
                view.LandArea = dataReader.GetValueOrDefault<decimal>("LandArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "RightNoOfLand"))
                view.RightNoOfLand = dataReader.GetValueOrDefault<string>("RightNoOfLand");
            if (DataReaderRowFilter.RowFilter(dataReader, "RightTypeOfLand"))
                view.RightTypeOfLand = dataReader.GetValueOrDefault<string>("RightTypeOfLand");
            if (DataReaderRowFilter.RowFilter(dataReader, "FloorSpace"))
                view.FloorSpace = dataReader.GetValueOrDefault<decimal>("FloorSpace");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalPrice"))
                view.TotalPrice = dataReader.GetValueOrDefault<decimal>("TotalPrice");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompletedDate"))
                view.CompletedDate = dataReader.GetValueOrDefault<String>("CompletedDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "LandUsingYear"))
                view.LandUsingYear = dataReader.GetValueOrDefault<int>("LandUsingYear");
            if (DataReaderRowFilter.RowFilter(dataReader, "RentRemainingDate"))
                view.RentRemainingDate = dataReader.GetValueOrDefault<int>("RentRemainingDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "BaseLTV"))
                view.BaseLTV = dataReader.GetValueOrDefault<Decimal>("BaseLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaxAllowedLTV"))
                view.MaxAllowedLTV = dataReader.GetValueOrDefault<Decimal>("MaxAllowedLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReducedLTV"))
                view.ReducedLTV = dataReader.GetValueOrDefault<Decimal>("ReducedLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "MorgageCount"))
                view.MorgageCount = dataReader.GetValueOrDefault<String>("MorgageCount");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsImprovedHouse"))
                view.IsImprovedHouse = dataReader.GetValueOrDefault<String>("IsImprovedHouse");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsPartialMortgage"))
                view.IsPartialMortgage = dataReader.GetValueOrDefault<String>("IsPartialMortgage");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstHouseArea"))
              view.FirstHouseArea = dataReader.GetValueOrDefault<String>("FirstHouseArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstHouseOp"))
                view.FirstHouseOp = dataReader.GetValueOrDefault<String>("FirstHouseOp");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstPayPercent"))
                view.FirstPayPercent = dataReader.GetValueOrDefault<String>("FirstPayPercent");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstPayAmount"))
                view.FirstPayAmount = dataReader.GetValueOrDefault<String>("FirstPayAmount");

            if (DataReaderRowFilter.RowFilter(dataReader, "HighPropertyFactorActualValue"))
                view.HighPropertyFactorActualValue = dataReader.GetValueOrDefault<Decimal>("HighPropertyFactorActualValue");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsSelectHighProperty"))
                view.IsSelectHighProperty = dataReader.GetValueOrDefault<Boolean>("IsSelectHighProperty");
            return view;
        }
    }
}
