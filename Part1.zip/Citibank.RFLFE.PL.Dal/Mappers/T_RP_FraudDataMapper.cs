﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_RP_FraudDataMapper<T> : IRowMapper<T> where T : T_RP_FraudData, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CertID"))
                view.CertID = dataReader.GetValueOrDefault<string>("CertID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyAddress"))
                view.CompanyAddress = dataReader.GetValueOrDefault<string>("CompanyAddress");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyName"))
                view.CompanyName = dataReader.GetValueOrDefault<string>("CompanyName");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyPhone"))
                view.CompanyPhone = dataReader.GetValueOrDefault<string>("CompanyPhone");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyPhoneAreaCode"))
                view.CompanyPhoneAreaCode = dataReader.GetValueOrDefault<string>("CompanyPhoneAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyPhoneExt"))
                view.CompanyPhoneExt = dataReader.GetValueOrDefault<string>("CompanyPhoneExt");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustName"))
                view.CustName = dataReader.GetValueOrDefault<string>("CustName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ExpireDate"))
                view.ExpireDate = dataReader.GetValueOrDefault<string>("ExpireDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "HomeAddress"))
                view.HomeAddress = dataReader.GetValueOrDefault<string>("HomeAddress");
            if (DataReaderRowFilter.RowFilter(dataReader, "HomePhone"))
                view.HomePhone = dataReader.GetValueOrDefault<string>("HomePhone");
            if (DataReaderRowFilter.RowFilter(dataReader, "HomePhoneAreaCode"))
                view.HomePhoneAreaCode = dataReader.GetValueOrDefault<string>("HomePhoneAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "InfoSource"))
                view.InfoSource = dataReader.GetValueOrDefault<string>("InfoSource");
            if (DataReaderRowFilter.RowFilter(dataReader, "MobilePhone"))
                view.MobilePhone = dataReader.GetValueOrDefault<string>("MobilePhone");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReferrerName"))
                view.ReferrerName = dataReader.GetValueOrDefault<string>("ReferrerName");
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            return view;
        }
    }
}
