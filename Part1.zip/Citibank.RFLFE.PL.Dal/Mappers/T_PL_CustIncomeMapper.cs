﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_CustIncomeMapper<T> : IRowMapper<T> where T : T_PL_CustIncome, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "IncomeType"))
                view.IncomeType = dataReader.GetValueOrDefault<String>("IncomeType");
            if (DataReaderRowFilter.RowFilter(dataReader, "DeclareAmount"))
                view.DeclareAmount = dataReader.GetValueOrDefault<Decimal>("DeclareAmount");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedAmount"))
                view.VerifiedAmount = dataReader.GetValueOrDefault<Decimal>("VerifiedAmount");
            if (DataReaderRowFilter.RowFilter(dataReader, "isSelected"))
                view.isSelected = dataReader.GetValueOrDefault<int>("isSelected")==1?"true":"false";
            if (DataReaderRowFilter.RowFilter(dataReader, "ProvenIncome"))
                view.ProvenIncome = dataReader.GetValueOrDefault<Decimal>("ProvenIncome");
         
            return view;
        }
    }
}
