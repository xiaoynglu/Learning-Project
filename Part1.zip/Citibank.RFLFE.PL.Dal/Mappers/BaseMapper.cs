﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Data;
using System.Reflection;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class BaseMapper<T> : IRowMapper<T> 
    {
        protected T entity;

        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            entity = (T)Activator.CreateInstance(typeof(T));

            PropertyInfo[] properties = typeof(T).GetProperties();

            foreach (PropertyInfo pi in properties)
            {
                if (dataReader[pi.Name] == null)
                {
                    pi.SetValue(entity, null, null);
                }
                else
                {
                    if (pi.PropertyType == typeof(String))
                    {
                        pi.SetValue(entity, dataReader[pi.Name].ToString(), null);
                    }
                    else if (pi.PropertyType == typeof(Guid) || pi.PropertyType == typeof(Guid?))
                    {
                        pi.SetValue(entity, Guid.Parse(dataReader[pi.Name].ToString()), null);
                    }
                    else if (pi.PropertyType == typeof(DateTime) || pi.PropertyType == typeof(DateTime?))
                    {
                        pi.SetValue(entity, Convert.ToDateTime(dataReader[pi.Name]), null);
                    }
                    else if (pi.PropertyType == typeof(Int32?) || pi.PropertyType == typeof(Int32))
                    {
                        pi.SetValue(entity, int.Parse(dataReader[pi.Name].ToString()), null);
                    }
                    else if (pi.PropertyType == typeof(Boolean?) || pi.PropertyType == typeof(Boolean))
                    {
                        pi.SetValue(entity, Boolean.Parse(dataReader[pi.Name].ToString()), null);
                    }
                }
            }
            return entity;
        }
    }
}
