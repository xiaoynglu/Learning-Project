﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class appProgressDetailViewMapper<T> : IRowMapper<T> where T : appProgressDetailView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNo"))
                view.AppNo = dataReader.GetValueOrDefault<String>("AppNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "Product"))
                view.Product = dataReader.GetValueOrDefault<String>("Product");
            if (DataReaderRowFilter.RowFilter(dataReader, "Risk"))
                view.Risk = dataReader.GetValueOrDefault<String>("Risk");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApplySize"))
                view.ApplySize = dataReader.GetValueOrDefault<String>("ApplySize");
            if (DataReaderRowFilter.RowFilter(dataReader, "LoanPeriod"))
                view.LoanPeriod = dataReader.GetValueOrDefault<String>("LoanPeriod").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "Profit"))
                view.Profit = dataReader.GetValueOrDefault<String>("Profit").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ApprovalResult"))
                view.ApprovalResult = dataReader.GetValueOrDefault<String>("ApprovalResult").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "RefuseReason"))
                view.RefuseReason = dataReader.GetValueOrDefault<String>("RefuseReason").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ApprovalSize"))
                view.ApprovalSize = dataReader.GetValueOrDefault<String>("ApprovalSize").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ApprovalTime"))
                view.ApprovalTime = dataReader.GetValueOrDefault<String>("ApprovalTime").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "MonthPay"))
                view.MonthPay = dataReader.GetValueOrDefault<String>("MonthPay").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmResult"))
                view.ConfirmResult = dataReader.GetValueOrDefault<String>("ConfirmResult").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmTime"))
                view.ConfirmTime = dataReader.GetValueOrDefault<String>("ConfirmTime").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "SignTime"))
                view.SignTime = dataReader.GetValueOrDefault<String>("SignTime").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<String>("CustID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "RelationID"))
                view.RelationID = dataReader.GetValueOrDefault<String>("RelationID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "Bank"))
                view.Bank = dataReader.GetValueOrDefault<String>("Bank").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "Account"))
                view.Account = dataReader.GetValueOrDefault<String>("Account").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustName"))
                view.CustName = dataReader.GetValueOrDefault<String>("CustName").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "StartTime"))
                view.StartTime = dataReader.GetValueOrDefault<String>("StartTime").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "FMS"))
                view.FMS = dataReader.GetValueOrDefault<String>("FMS").ToString();

            return view;
        }
    }
}
