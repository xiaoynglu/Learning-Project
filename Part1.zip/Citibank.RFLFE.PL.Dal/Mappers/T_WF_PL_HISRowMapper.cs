﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_WF_PL_HISRowMapper<T> : IRowMapper<T> where T : T_WF_PL_HIS, new()
    {
       T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
       {
           T view = new T();
           if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
               view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
           if (DataReaderRowFilter.RowFilter(dataReader, "CreateDate"))
               view.CreateDate = dataReader.GetValueOrDefault<DateTime>("CreateDate").ToString("yyyy-MM-dd HH:mm:ss");
           if (DataReaderRowFilter.RowFilter(dataReader, "ExecID"))
               view.ExecID = dataReader.GetValueOrDefault<string>("ExecID");
           if (DataReaderRowFilter.RowFilter(dataReader, "PickupTime"))
               view.PickupTime = dataReader.GetValueOrDefault<DateTime>("PickupTime").ToString("yyyy-MM-dd HH:mm:ss");
           if (DataReaderRowFilter.RowFilter(dataReader, "PickupTime"))
               view.PickupTime = dataReader.GetValueOrDefault<DateTime>("PickupTime").ToString("yyyy-MM-dd HH:mm:ss");
           if (DataReaderRowFilter.RowFilter(dataReader, "ProcDate"))
               view.ProcDate = dataReader.GetValueOrDefault<DateTime>("ProcDate").ToString("yyyy-MM-dd HH:mm:ss");
           if (DataReaderRowFilter.RowFilter(dataReader, "ProcID"))
               view.ProcID = dataReader.GetValueOrDefault<string>("ProcID");
           if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
               view.Remarks = dataReader.GetValueOrDefault<string>("Remarks");
           if (DataReaderRowFilter.RowFilter(dataReader, "SalesID"))
               view.SalesID = dataReader.GetValueOrDefault<string>("SalesID");
           if (DataReaderRowFilter.RowFilter(dataReader, "StageID"))
               view.StageID = dataReader.GetValueOrDefault<int>("StageID");
           if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
               view.Status = dataReader.GetValueOrDefault<string>("Status");
           return view;

       }

    }
}
