﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class ConditionGroupNamesMapper<T> : IRowMapper<T> where T : T_PL_ConfigConditionMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            //if (DataReaderRowFilter.RowFilter(dataReader, "TemplateID"))
            //    view.TemplateID = dataReader.GetValueOrDefault<int>("TemplateID");
            if (DataReaderRowFilter.RowFilter(dataReader, "GroupName"))
                view.GroupName = dataReader.GetValueOrDefault<string>("GroupName");
            return view;
        }
    }
}
