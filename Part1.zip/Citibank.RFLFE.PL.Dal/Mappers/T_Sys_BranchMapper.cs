﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_Sys_BranchMapper<T> : IRowMapper<T> where T : T_Sys_Branch, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<string>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Location"))
                view.Location = dataReader.GetValueOrDefault<string>("Location");
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchCode"))
                view.BranchCode = dataReader.GetValueOrDefault<string>("BranchCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchName"))
                view.BranchName = dataReader.GetValueOrDefault<string>("BranchName");
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchAddress"))
                view.BranchAddress = dataReader.GetValueOrDefault<string>("BranchAddress");
            if (DataReaderRowFilter.RowFilter(dataReader, "PostCode"))
                view.PostCode = dataReader.GetValueOrDefault<string>("PostCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Fax"))
                view.Fax = dataReader.GetValueOrDefault<string>("Fax");
            if (DataReaderRowFilter.RowFilter(dataReader, "Phone"))
                view.Phone = dataReader.GetValueOrDefault<string>("Phone");
            if (DataReaderRowFilter.RowFilter(dataReader, "RCCode"))
                view.RCCode = dataReader.GetValueOrDefault<string>("RCCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "CityCode"))
                view.CityCode = dataReader.GetValueOrDefault<string>("CityCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "ALSCode"))
                view.ALSCode = dataReader.GetValueOrDefault<string>("ALSCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "BM"))
                view.BM = dataReader.GetValueOrDefault<string>("BM");
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchType"))
                view.BranchType = dataReader.GetValueOrDefault<int>("BranchType");
            



            return view;
        }
    }
}
