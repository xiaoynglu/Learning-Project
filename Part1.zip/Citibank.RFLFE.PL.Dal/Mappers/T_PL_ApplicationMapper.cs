﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_ApplicationMapper<T> : IRowMapper<T> where T : T_PL_Application, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AgentCode"))
                view.AgentCode = dataReader.GetValueOrDefault<String>("AgentCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ApplicationNo"))
                view.ApplicationNo = dataReader.GetValueOrDefault<String>("ApplicationNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateDate"))
                view.CreateDate = dataReader.GetValueOrDefault<DateTime>("CreateDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreatorID"))
                view.CreatorID = dataReader.GetValueOrDefault<String>("CreatorID");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsALSChecked"))
                view.IsALSChecked = dataReader.GetValueOrDefault<String>("IsALSChecked");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsEmployeeLoan"))
                view.IsEmployeeLoan = dataReader.GetValueOrDefault<String>("IsEmployeeLoan");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsLackDoc"))
                view.IsLackDoc = dataReader.GetValueOrDefault<String>("IsLackDoc");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsPBOCChecked"))
                view.IsPBOCChecked = dataReader.GetValueOrDefault<String>("IsPBOCChecked");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsSamePlace"))
                view.IsSamePlace = dataReader.GetValueOrDefault<String>("IsSamePlace");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsSubmitted"))
                view.IsSubmitted = dataReader.GetValueOrDefault<String>("IsSubmitted");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsTown"))
                view.IsTown = dataReader.GetValueOrDefault<String>("IsTown");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<String>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayType"))
                view.PayType = dataReader.GetValueOrDefault<String>("PayType");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<Int32>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelationNumber"))
                view.RelationNumber = dataReader.GetValueOrDefault<String>("RelationNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<String>("Remarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "SourceCode"))
                view.SourceCode = dataReader.GetValueOrDefault<String>("SourceCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "UserDefined1"))
                view.UserDefined1 = dataReader.GetValueOrDefault<String>("UserDefined1");
            if (DataReaderRowFilter.RowFilter(dataReader, "UserDefined2"))
                view.UserDefined2 = dataReader.GetValueOrDefault<String>("UserDefined2");
            if (DataReaderRowFilter.RowFilter(dataReader, "UserDefined3"))
                view.UserDefined3 = dataReader.GetValueOrDefault<String>("UserDefined3");
            if (DataReaderRowFilter.RowFilter(dataReader, "UserDefined4"))
                view.UserDefined4 = dataReader.GetValueOrDefault<String>("UserDefined4");
            if (DataReaderRowFilter.RowFilter(dataReader, "UserDefined5"))
                view.UserDefined5 = dataReader.GetValueOrDefault<String>("UserDefined5");
            if (DataReaderRowFilter.RowFilter(dataReader, "WhereKnow"))
                view.WhereKnow = dataReader.GetValueOrDefault<String>("WhereKnow");
            return view;
        }
    }
}
