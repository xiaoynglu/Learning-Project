﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_LTVValueMapper<T> : IRowMapper<T> where T : T_PL_LTVValue, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdId"))
                view.ProdId = dataReader.GetValueOrDefault<int>("ProdId");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<Guid>("OrgCode").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralType"))
                view.CollateralType = dataReader.GetValueOrDefault<String>("CollateralType");
            if (DataReaderRowFilter.RowFilter(dataReader, "BaseLTV"))
                view.BaseLTV = dataReader.GetValueOrDefault<Decimal>("BaseLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaxDelLTV"))
                view.MaxDelLTV = dataReader.GetValueOrDefault<Decimal>("MaxDelLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "MoCount"))
                view.MoCount = dataReader.GetValueOrDefault<int>("MoCount");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreatorId"))
                view.CreatorId = dataReader.GetValueOrDefault<String>("CreatorId");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreatedDate"))
                view.CreatedDate = dataReader.GetValueOrDefault<DateTime>("CreatedDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "UpdatorId"))
                view.UpdatorId = dataReader.GetValueOrDefault<String>("UpdatorId");
            if (DataReaderRowFilter.RowFilter(dataReader, "UpdatedDate"))
                view.UpdatedDate = dataReader.GetValueOrDefault<DateTime>("UpdatedDate");
          
            return view;
        }
    }
}
