﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_EvaluationCompanyMakerMapper<T> : IRowMapper<T> where T : T_PL_EvaluationCompanyMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<string>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyName"))
                view.CompanyName = dataReader.GetValueOrDefault<string>("CompanyName");

            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyType"))
                view.CompanyType = dataReader.GetValueOrDefault<string>("CompanyType");

            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyTypeName"))
                view.CompanyTypeName = dataReader.GetValueOrDefault<string>("CompanyTypeName");

            if (DataReaderRowFilter.RowFilter(dataReader, "Phone"))
                view.Phone = dataReader.GetValueOrDefault<string>("Phone");

            if (DataReaderRowFilter.RowFilter(dataReader, "ContactName"))
                view.ContactName = dataReader.GetValueOrDefault<string>("ContactName");
            

            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<int>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "StatusName"))
                view.StatusName = dataReader.GetValueOrDefault<string>("StatusName");


            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");

            if (DataReaderRowFilter.RowFilter(dataReader, "CreateTime"))
                view.CreateTime = dataReader.GetValueOrDefault<DateTime>("CreateTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifyedTime"))
                view.ModifiedTime = dataReader.GetValueOrDefault<DateTime>("ModifyedTime");

            if (DataReaderRowFilter.RowFilter(dataReader, "OpType"))
                view.OpType = dataReader.GetValueOrDefault<int>("OpType");
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");

            if (DataReaderRowFilter.RowFilter(dataReader, "OpTypeName"))
                view.OpTypeName = dataReader.GetValueOrDefault<string>("OpTypeName");





            return view;
        }
    }
}
