﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_CustDebtMapper<T> : IRowMapper<T> where T : T_PL_CustDebt, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<String>("CustID");

            if (DataReaderRowFilter.RowFilter(dataReader, "CurrDebt"))
                view.CurrDebt = dataReader.GetValueOrDefault<Decimal>("CurrDebt");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrCollateralLoan"))
                view.CurrCollateralLoan = dataReader.GetValueOrDefault<Decimal>("CurrCollateralLoan");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrUnsecuredLoan"))
                view.CurrUnsecuredLoan = dataReader.GetValueOrDefault<Decimal>("CurrUnsecuredLoan");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrCreditCard"))
                view.CurrCreditCard = dataReader.GetValueOrDefault<Decimal>("CurrCreditCard");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrPropertyFee"))
                view.CurrPropertyFee = dataReader.GetValueOrDefault<Decimal>("CurrPropertyFee");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrTotalDebt"))
                view.CurrTotalDebt = dataReader.GetValueOrDefault<Decimal>("CurrTotalDebt");

            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedDebt"))
                view.ModifiedDebt = dataReader.GetValueOrDefault<Decimal>("ModifiedDebt");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedCollateralLoan"))
                view.ModifiedCollateralLoan = dataReader.GetValueOrDefault<Decimal>("ModifiedCollateralLoan");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedUnsecuredLoan"))
                view.ModifiedUnsecuredLoan = dataReader.GetValueOrDefault<Decimal>("ModifiedUnsecuredLoan");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedPropertyFee"))
                view.ModifiedPropertyFee = dataReader.GetValueOrDefault<Decimal>("ModifiedPropertyFee");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedCreditCard"))
                view.ModifiedCreditCard = dataReader.GetValueOrDefault<Decimal>("ModifiedCreditCard");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedTotalDebt"))
                view.ModifiedTotalDebt = dataReader.GetValueOrDefault<Decimal>("ModifiedTotalDebt");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcessorID"))
                view.ProcessorID = dataReader.GetValueOrDefault<String>("ProcessorID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProceededDate"))
                view.ProceededDate = dataReader.GetValueOrDefault<DateTime>("ProceededDate");
           
            return view;
        }
    }
}
