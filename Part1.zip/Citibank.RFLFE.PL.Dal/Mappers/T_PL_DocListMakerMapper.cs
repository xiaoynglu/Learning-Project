﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_DocListMakerMapper<T> : IRowMapper<T> where T : T_PL_DocListMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "DocID"))
                view.DocID = dataReader.GetValueOrDefault<int>("DocID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<int>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "DocName"))
                view.DocName = dataReader.GetValueOrDefault<string>("DocName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DocType"))
                view.DocType = dataReader.GetValueOrDefault<int>("DocType");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustType"))
                view.CustType = dataReader.GetValueOrDefault<string>("CustType");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustSegment"))
                view.CustSegment = dataReader.GetValueOrDefault<string>("CustSegment");
            if (DataReaderRowFilter.RowFilter(dataReader, "GroupNo"))
                view.GroupNo = dataReader.GetValueOrDefault<string>("GroupNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsRequired"))
                view.IsRequired = dataReader.GetValueOrDefault<string>("IsRequired");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<string>("Remarks");

            if (DataReaderRowFilter.RowFilter(dataReader, "OpType"))
                view.OpType = dataReader.GetValueOrDefault<int>("OpType");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<int>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateTime"))
                view.CreateTime = dataReader.GetValueOrDefault<DateTime>("CreateTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedTime"))
                view.ModifiedTime = dataReader.GetValueOrDefault<DateTime>("ModifiedTime");

            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustType"))
                view.CustTypeDesc = dataReader.GetValueOrDefault<string>("CustType")=="ML"?"主贷人":"共贷人";
            if (DataReaderRowFilter.RowFilter(dataReader, "CustSegmentDesc"))
                view.CustSegmentDesc = dataReader.GetValueOrDefault<string>("CustSegmentDesc");
            if (DataReaderRowFilter.RowFilter(dataReader, "OpTypeDesc"))
                view.OpTypeDesc = dataReader.GetValueOrDefault<string>("OpTypeDesc");
            if (DataReaderRowFilter.RowFilter(dataReader, "StatusDesc"))
                view.StatusDesc = dataReader.GetValueOrDefault<string>("StatusDesc");

            return view;
        }
    }
}
