﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_EclipseHandoverMapper<T> : IRowMapper<T> where T : T_PL_EclipseHandover, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");

            if (DataReaderRowFilter.RowFilter(dataReader, "Surname"))
                view.SurName = dataReader.GetValueOrDefault<String>("Surname");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstName"))
                view.FirstName = dataReader.GetValueOrDefault<String>("FirstName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DOB"))
                view.DOB = dataReader.GetValueOrDefault<String>("DOB");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNum"))
                view.IDNum = dataReader.GetValueOrDefault<String>("IDNum");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustSubType"))
                view.CustSubType = dataReader.GetValueOrDefault<String>("CustSubType");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaritalStatus"))
                view.MaritalStatus = dataReader.GetValueOrDefault<String>("MaritalStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "Gender"))
                view.Gender = dataReader.GetValueOrDefault<String>("Gender");

            if (DataReaderRowFilter.RowFilter(dataReader, "Prefix")) view.Prefix = dataReader.GetValueOrDefault<String>("Prefix");
            if (DataReaderRowFilter.RowFilter(dataReader, "MomMaidenName")) view.MomMaidenName = dataReader.GetValueOrDefault<String>("MomMaidenName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PPName")) view.PPName = dataReader.GetValueOrDefault<String>("PPName");
            if (DataReaderRowFilter.RowFilter(dataReader, "MailingInstruction")) view.MailingInstruction = dataReader.GetValueOrDefault<String>("MailingInstruction");
            if (DataReaderRowFilter.RowFilter(dataReader, "HoldInstruction")) view.HoldInstruction = dataReader.GetValueOrDefault<String>("HoldInstruction");
            if (DataReaderRowFilter.RowFilter(dataReader, "CorrespondenceLanguage")) view.CorrespondenceLanguage = dataReader.GetValueOrDefault<String>("CorrespondenceLanguage");
            if (DataReaderRowFilter.RowFilter(dataReader, "SpokenLanguage")) view.SpokenLanguage = dataReader.GetValueOrDefault<String>("SpokenLanguage");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDExpiryDate")) view.IDExpiryDate = dataReader.GetValueOrDefault<String>("IDExpiryDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDExpiryYear")) view.IDExpiryYear = dataReader.GetValueOrDefault<String>("IDExpiryYear");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDExpiryMonth")) view.IDExpiryMonth = dataReader.GetValueOrDefault<String>("IDExpiryMonth");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDExpiryDay")) view.IDExpiryDay = dataReader.GetValueOrDefault<String>("IDExpiryDay");
            if (DataReaderRowFilter.RowFilter(dataReader, "Nationality")) view.Nationality = dataReader.GetValueOrDefault<String>("Nationality");
            if (DataReaderRowFilter.RowFilter(dataReader, "PremanentResident")) view.PremanentResident = dataReader.GetValueOrDefault<String>("PremanentResident");
            if (DataReaderRowFilter.RowFilter(dataReader, "Domicile")) view.Domicile = dataReader.GetValueOrDefault<String>("Domicile");
            if (DataReaderRowFilter.RowFilter(dataReader, "WHTax")) view.WHTax = dataReader.GetValueOrDefault<String>("WHTax");
            if (DataReaderRowFilter.RowFilter(dataReader, "TaxDomicile")) view.TaxDomicile = dataReader.GetValueOrDefault<String>("TaxDomicile");
            if (DataReaderRowFilter.RowFilter(dataReader, "VIPType")) view.VIPType = dataReader.GetValueOrDefault<String>("VIPType");
            if (DataReaderRowFilter.RowFilter(dataReader, "Staff")) view.Staff = dataReader.GetValueOrDefault<String>("Staff");
            if (DataReaderRowFilter.RowFilter(dataReader, "FaxIndemnity")) view.FaxIndemnity = dataReader.GetValueOrDefault<String>("FaxIndemnity");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerDeceased")) view.CustomerDeceased = dataReader.GetValueOrDefault<String>("CustomerDeceased");
            if (DataReaderRowFilter.RowFilter(dataReader, "PCBankingIndicator")) view.PCBankingIndicator = dataReader.GetValueOrDefault<String>("PCBankingIndicator");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerDisabled")) view.CustomerDisabled = dataReader.GetValueOrDefault<String>("CustomerDisabled");
            if (DataReaderRowFilter.RowFilter(dataReader, "SafeBox")) view.SafeBox = dataReader.GetValueOrDefault<String>("SafeBox");
            if (DataReaderRowFilter.RowFilter(dataReader, "RCCode")) view.RCCode = dataReader.GetValueOrDefault<String>("RCCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "AOCode")) view.AOCode = dataReader.GetValueOrDefault<String>("AOCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "BankAtWork")) view.BankAtWork = dataReader.GetValueOrDefault<String>("BankAtWork");
            if (DataReaderRowFilter.RowFilter(dataReader, "Email1")) view.Email1 = dataReader.GetValueOrDefault<String>("Email1");
            if (DataReaderRowFilter.RowFilter(dataReader, "OKtoMail1")) view.OKtoMail1 = dataReader.GetValueOrDefault<String>("OKtoMail1");
            if (DataReaderRowFilter.RowFilter(dataReader, "MobilePhone")) view.MobilePhone = dataReader.GetValueOrDefault<String>("MobilePhone");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneTypeH")) view.PhoneTypeH = dataReader.GetValueOrDefault<String>("PhoneTypeH");
            if (DataReaderRowFilter.RowFilter(dataReader, "CountryCodeH")) view.CountryCodeH = dataReader.GetValueOrDefault<String>("CountryCodeH");
            if (DataReaderRowFilter.RowFilter(dataReader, "AreaCodeH")) view.AreaCodeH = dataReader.GetValueOrDefault<String>("AreaCodeH");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneH")) view.PhoneH = dataReader.GetValueOrDefault<String>("PhoneH");
            if (DataReaderRowFilter.RowFilter(dataReader, "ExtnH")) view.ExtnH = dataReader.GetValueOrDefault<String>("ExtnH");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneTypeO")) view.PhoneTypeO = dataReader.GetValueOrDefault<String>("PhoneTypeO");
            if (DataReaderRowFilter.RowFilter(dataReader, "CountryCodeO")) view.CountryCodeO = dataReader.GetValueOrDefault<String>("CountryCodeO");
            if (DataReaderRowFilter.RowFilter(dataReader, "AreaCodeO")) view.AreaCodeO = dataReader.GetValueOrDefault<String>("AreaCodeO");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneO")) view.PhoneO = dataReader.GetValueOrDefault<String>("PhoneO");
            if (DataReaderRowFilter.RowFilter(dataReader, "ExtnO")) view.ExtnO = dataReader.GetValueOrDefault<String>("ExtnO");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneTypeC")) view.PhoneTypeC = dataReader.GetValueOrDefault<String>("PhoneTypeC");
            if (DataReaderRowFilter.RowFilter(dataReader, "CountryCodeC")) view.CountryCodeC = dataReader.GetValueOrDefault<String>("CountryCodeC");
            if (DataReaderRowFilter.RowFilter(dataReader, "AreaCodeC")) view.AreaCodeC = dataReader.GetValueOrDefault<String>("AreaCodeC");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneC")) view.PhoneC = dataReader.GetValueOrDefault<String>("PhoneC");
            if (DataReaderRowFilter.RowFilter(dataReader, "ExtnC")) view.ExtnC = dataReader.GetValueOrDefault<String>("ExtnC");
            if (DataReaderRowFilter.RowFilter(dataReader, "MailAddInd")) view.MailAddInd = dataReader.GetValueOrDefault<String>("MailAddInd");
            if (DataReaderRowFilter.RowFilter(dataReader, "AddressTypeH")) view.AddressTypeH = dataReader.GetValueOrDefault<String>("AddressTypeH");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add1H")) view.Add1H = dataReader.GetValueOrDefault<String>("Add1H");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add2H")) view.Add2H = dataReader.GetValueOrDefault<String>("Add2H");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add3H")) view.Add3H = dataReader.GetValueOrDefault<String>("Add3H");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add4H")) view.Add4H = dataReader.GetValueOrDefault<String>("Add4H");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProvinceH")) view.ProvinceH = dataReader.GetValueOrDefault<String>("ProvinceH");
            if (DataReaderRowFilter.RowFilter(dataReader, "CityDistrictH")) view.CityDistrictH = dataReader.GetValueOrDefault<String>("CityDistrictH");
            if (DataReaderRowFilter.RowFilter(dataReader, "PostCodeH")) view.PostCodeH = dataReader.GetValueOrDefault<String>("PostCodeH");
            if (DataReaderRowFilter.RowFilter(dataReader, "CountryH")) view.CountryH = dataReader.GetValueOrDefault<String>("CountryH");
            if (DataReaderRowFilter.RowFilter(dataReader, "OKtoMailH")) view.OKtoMailH = dataReader.GetValueOrDefault<String>("OKtoMailH");
            if (DataReaderRowFilter.RowFilter(dataReader, "AddressTypeO")) view.AddressTypeO = dataReader.GetValueOrDefault<String>("AddressTypeO");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add1O")) view.Add1O = dataReader.GetValueOrDefault<String>("Add1O");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add2O")) view.Add2O = dataReader.GetValueOrDefault<String>("Add2O");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add3O")) view.Add3O = dataReader.GetValueOrDefault<String>("Add3O");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add4O")) view.Add4O = dataReader.GetValueOrDefault<String>("Add4O");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProvinceO")) view.ProvinceO = dataReader.GetValueOrDefault<String>("ProvinceO");
            if (DataReaderRowFilter.RowFilter(dataReader, "CityDistrictO")) view.CityDistrictO = dataReader.GetValueOrDefault<String>("CityDistrictO");
            if (DataReaderRowFilter.RowFilter(dataReader, "PostCodeO")) view.PostCodeO = dataReader.GetValueOrDefault<String>("PostCodeO");
            if (DataReaderRowFilter.RowFilter(dataReader, "CountryO")) view.CountryO = dataReader.GetValueOrDefault<String>("CountryO");
            if (DataReaderRowFilter.RowFilter(dataReader, "OKtoMailO")) view.OKtoMailO = dataReader.GetValueOrDefault<String>("OKtoMailO");
            if (DataReaderRowFilter.RowFilter(dataReader, "AddressTypeL")) view.AddressTypeL = dataReader.GetValueOrDefault<String>("AddressTypeL");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add1L")) view.Add1L = dataReader.GetValueOrDefault<String>("Add1L");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add2L")) view.Add2L = dataReader.GetValueOrDefault<String>("Add2L");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add3L")) view.Add3L = dataReader.GetValueOrDefault<String>("Add3L");
            if (DataReaderRowFilter.RowFilter(dataReader, "Add4L")) view.Add4L = dataReader.GetValueOrDefault<String>("Add4L");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProvinceL")) view.ProvinceL = dataReader.GetValueOrDefault<String>("ProvinceL");
            if (DataReaderRowFilter.RowFilter(dataReader, "CityDistrictL")) view.CityDistrictL = dataReader.GetValueOrDefault<String>("CityDistrictL");
            if (DataReaderRowFilter.RowFilter(dataReader, "PostCodeL")) view.PostCodeL = dataReader.GetValueOrDefault<String>("PostCodeL");
            if (DataReaderRowFilter.RowFilter(dataReader, "CountryL")) view.CountryL = dataReader.GetValueOrDefault<String>("CountryL");
            if (DataReaderRowFilter.RowFilter(dataReader, "OKtoMailL")) view.OKtoMailL = dataReader.GetValueOrDefault<String>("OKtoMailL");
            if (DataReaderRowFilter.RowFilter(dataReader, "EqualtoMAdd")) view.EqualtoMAdd = dataReader.GetValueOrDefault<String>("EqualtoMAdd");
            if (DataReaderRowFilter.RowFilter(dataReader, "SourceOfWealth")) view.SourceOfWealth = dataReader.GetValueOrDefault<String>("SourceOfWealth");
            if (DataReaderRowFilter.RowFilter(dataReader, "OccupationCodeKYC")) view.OccupationCodeKYC = dataReader.GetValueOrDefault<String>("OccupationCodeKYC");
            if (DataReaderRowFilter.RowFilter(dataReader, "OccupationCodeEmployment")) view.OccupationCodeEmployment = dataReader.GetValueOrDefault<String>("OccupationCodeEmployment");
            if (DataReaderRowFilter.RowFilter(dataReader, "AnnualFundingRange")) view.AnnualFundingRange = dataReader.GetValueOrDefault<String>("AnnualFundingRange");
            if (DataReaderRowFilter.RowFilter(dataReader, "EmployerName")) view.EmployerName = dataReader.GetValueOrDefault<String>("EmployerName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApplicationNo")) view.ApplicationNo = dataReader.GetValueOrDefault<String>("ApplicationNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "IndustryCode")) view.IndustryCode = dataReader.GetValueOrDefault<String>("IndustryCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "SellerChineseName")) view.SellerChineseName = dataReader.GetValueOrDefault<String>("SellerChineseName");
            if (DataReaderRowFilter.RowFilter(dataReader, "SellerEngName")) view.SellerEngName = dataReader.GetValueOrDefault<String>("SellerEngName");
            if (DataReaderRowFilter.RowFilter(dataReader, "SellerGender")) view.SellerGender = dataReader.GetValueOrDefault<String>("SellerGender");
            if (DataReaderRowFilter.RowFilter(dataReader, "SellerIDNum")) view.SellerIDNum = dataReader.GetValueOrDefault<String>("SellerIDNum");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDIssueDate")) view.IDIssueDate = dataReader.GetValueOrDefault<String>("IDIssueDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDIssuePlace")) view.IDIssuePlace = dataReader.GetValueOrDefault<String>("IDIssuePlace");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProvinceHName")) view.ProvinceHName = dataReader.GetValueOrDefault<String>("ProvinceHName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProvinceOName")) view.ProvinceOName = dataReader.GetValueOrDefault<String>("ProvinceOName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProvinceLName")) view.ProvinceLName = dataReader.GetValueOrDefault<String>("ProvinceLName");
            
            return view;
        }
    }
}
