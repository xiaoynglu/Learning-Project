﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    class T_PL_NoteWaitConfigMapper<T> : IRowMapper<T> where T : T_PL_NoteWaitConfig, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageID"))
                view.StageID = dataReader.GetValueOrDefault<int>("StageID");
            if (DataReaderRowFilter.RowFilter(dataReader, "PanelID"))
                view.PanelID = dataReader.GetValueOrDefault<string>("PanelID");
            if (DataReaderRowFilter.RowFilter(dataReader, "PanelType"))
                view.PanelType = dataReader.GetValueOrDefault<string>("PanelType");
            if (DataReaderRowFilter.RowFilter(dataReader, "PanelTitle"))
                view.PanelTitle = dataReader.GetValueOrDefault<string>("PanelTitle");
            if (DataReaderRowFilter.RowFilter(dataReader, "appid"))
                view.appid = dataReader.GetValueOrDefault<Guid>("appid").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "StageName"))
                view.StageName = dataReader.GetValueOrDefault<string>("StageName");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNo"))
                view.AppNo = dataReader.GetValueOrDefault<string>("AppNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "Controller"))
                view.Controller = dataReader.GetValueOrDefault<string>("Controller");
            if (DataReaderRowFilter.RowFilter(dataReader, "EleName"))
                view.EleName = dataReader.GetValueOrDefault<string>("EleName");
            if (DataReaderRowFilter.RowFilter(dataReader, "status"))
                view.status = dataReader.GetValueOrDefault<string>("status");
            if (DataReaderRowFilter.RowFilter(dataReader, "procdate"))
                view.procdate = dataReader.GetValueOrDefault<string>("procdate");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerName"))
                view.CustomerName = dataReader.GetValueOrDefault<string>("CustomerName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            
            return view;
        }
    }
}
