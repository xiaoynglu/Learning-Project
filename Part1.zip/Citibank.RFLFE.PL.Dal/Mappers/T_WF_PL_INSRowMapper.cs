﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_WF_PL_INSRowMapper<T> : IRowMapper<T> where T : T_WF_PL_INS, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "Action"))
                view.Action = dataReader.GetValueOrDefault<string>("Action");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNo"))
                view.AppNo = dataReader.GetValueOrDefault<string>("AppNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateDate"))
                view.CreateDate = dataReader.GetValueOrDefault<DateTime>("CreateDate").ToString("yyyy-MM-dd HH:mm:ss");

            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentProcessor"))
                view.CurrentProcessor = dataReader.GetValueOrDefault<string>("CurrentProcessor");

            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<string>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerName"))
                view.CustomerName = dataReader.GetValueOrDefault<string>("CustomerName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DateBegin"))
                view.DateBegin = dataReader.GetValueOrDefault<DateTime>("DateBegin").ToString("yyyy-MM-dd HH:mm:ss");
            if (DataReaderRowFilter.RowFilter(dataReader, "DateEnd"))
                view.DateEnd = dataReader.GetValueOrDefault<DateTime>("DateEnd").ToString("yyyy-MM-dd HH:mm:ss");
            if (DataReaderRowFilter.RowFilter(dataReader, "ExecID"))
                view.ExecID = dataReader.GetValueOrDefault<string>("ExecID");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstName"))
                view.FirstName = dataReader.GetValueOrDefault<string>("FirstName");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsLocked"))
                view.IsLocked = dataReader.GetValueOrDefault<int>("IsLocked")==1?true:false;
            if (DataReaderRowFilter.RowFilter(dataReader, "LastName"))
                view.LastName = dataReader.GetValueOrDefault<string>("LastName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PendingReason"))
                view.PendingReason = dataReader.GetValueOrDefault<string>("PendingReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "PickupTime"))
                view.PickupTime = dataReader.GetValueOrDefault<DateTime>("PickupTime").ToString("yyyy-MM-dd HH:mm:ss");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcDate"))
                view.ProcDate = dataReader.GetValueOrDefault<DateTime>("ProcDate").ToString("yyyy-MM-dd HH:mm:ss");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<int>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<string>("Remarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "SalesID"))
                view.SalesID = dataReader.GetValueOrDefault<string>("SalesID");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageID"))
                view.StageID = dataReader.GetValueOrDefault<int>("StageID");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageName"))
                view.StageName = dataReader.GetValueOrDefault<string>("StageName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<string>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "StatusDesc"))
                view.StatusDesc = dataReader.GetValueOrDefault<string>("StatusDesc");
            if (DataReaderRowFilter.RowFilter(dataReader, "StepID"))
                view.StepID = dataReader.GetValueOrDefault<int>("StepID");
            if (DataReaderRowFilter.RowFilter(dataReader, "StepName"))
                view.StepName = dataReader.GetValueOrDefault<string>("StepName");
            return view;
        }
    }
}
