﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_LoanIndustryMapper<T> : IRowMapper<T> where T : T_PL_LoanIndustry, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose1"))
                view.Purpose1 = dataReader.GetValueOrDefault<String>("Purpose1");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose2"))
                view.Purpose2 = dataReader.GetValueOrDefault<String>("Purpose2");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose3"))
                view.Purpose3 = dataReader.GetValueOrDefault<String>("Purpose3");
            if (DataReaderRowFilter.RowFilter(dataReader, "AgentCode"))
                view.AgentCode = dataReader.GetValueOrDefault<String>("AgentCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Education"))
                view.OtherPurpose = dataReader.GetValueOrDefault<String>("OtherPurpose");
            if (DataReaderRowFilter.RowFilter(dataReader, "Category"))
                view.Category = dataReader.GetValueOrDefault<String>("Category");
            if (DataReaderRowFilter.RowFilter(dataReader, "CommericialFiment"))
                view.CommericialFitment = dataReader.GetValueOrDefault<String>("CommericialFiment");
            if (DataReaderRowFilter.RowFilter(dataReader, "MainIndustry"))
                view.MainIndustry = dataReader.GetValueOrDefault<String>("MainIndustry");
            if (DataReaderRowFilter.RowFilter(dataReader, "SubIndustry"))
                view.SubIndustry = dataReader.GetValueOrDefault<String>("SubIndustry");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationProvince"))
                view.DecorationProvince = dataReader.GetValueOrDefault<String>("DecorationProvince");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationCity"))
                view.DecorationCity = dataReader.GetValueOrDefault<String>("DecorationCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationRegion"))
                view.DecorationRegion = dataReader.GetValueOrDefault<String>("DecorationRegion");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationAddress"))
                view.DecorationAddress = dataReader.GetValueOrDefault<String>("DecorationAddress");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsPropertySelf"))
                //view.IsPropertySelf = dataReader.GetValueOrDefault<Boolean>("IsPropertySelf") == true?"是":"否";
                view.IsPropertySelf = dataReader.GetValueOrDefault<String>("IsPropertySelf") == "True" ? "1" : "0"; ;
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationRelation"))
                view.DecorationRelation = dataReader.GetValueOrDefault<String>("DecorationRelation");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationPropertyValue1"))
                view.DecorationPropertyValue1 = dataReader.GetValueOrDefault<Decimal>("DecorationPropertyValue1");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationPropertyValue2"))
                view.DecorationPropertyValue2 = dataReader.GetValueOrDefault<Decimal>("DecorationPropertyValue2");
            //T_PL_SelfPay
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitAccount"))
                view.DeditAccount = dataReader.GetValueOrDefault<String>("DebitAccount");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitBankName"))
                view.DeditBankName = dataReader.GetValueOrDefault<String>("DebitBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitReason"))
                view.DeditReason = dataReader.GetValueOrDefault<String>("DebitReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitRemarks"))
                view.DeditRemarks = dataReader.GetValueOrDefault<String>("DebitRemarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitSubBankName"))
                view.DeditSubBankName = dataReader.GetValueOrDefault<String>("DebitSubBankName");
            //T_PL_Application
            if (DataReaderRowFilter.RowFilter(dataReader, "SourceCode"))
                view.SourceCode = dataReader.GetValueOrDefault<String>("SourceCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "AgentCode"))
                view.AgentCode = dataReader.GetValueOrDefault<String>("AgentCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "WhereKnow"))
                view.WhereKnow = dataReader.GetValueOrDefault<String>("WhereKnow");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayType"))
                view.PayType = dataReader.GetValueOrDefault<String>("PayType");
            //T_PL_AcceptService
            if (DataReaderRowFilter.RowFilter(dataReader, "ServiceID"))
                view.ServiceID = dataReader.GetValueOrDefault<String>("ServiceID");
            //T_PL_EntrusPay
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeName"))
                view.PayeeName = dataReader.GetValueOrDefault<String>("PayeeName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeBankName"))
                view.PayeeBankName = dataReader.GetValueOrDefault<String>("PayeeBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeSubBankName"))
                view.PayeeSubBankName = dataReader.GetValueOrDefault<String>("PayeeSubBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeAccount"))
                view.PayeeAccount = dataReader.GetValueOrDefault<String>("PayeeAccount");
            if (DataReaderRowFilter.RowFilter(dataReader, "PaymentAmount"))
                view.PaymentAmount = dataReader.GetValueOrDefault<String>("PaymentAmount");
            return view;
        }
    }
}
