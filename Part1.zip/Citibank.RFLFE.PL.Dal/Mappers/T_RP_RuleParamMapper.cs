﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_RP_RuleParamMapper<T> : IRowMapper<T> where T : T_RP_Params, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ParamID"))
                view.ParamID = dataReader.GetValueOrDefault<int>("ParamID");
            if (DataReaderRowFilter.RowFilter(dataReader, "RuleID"))
                view.RuleID = dataReader.GetValueOrDefault<int>("RuleID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ParamName"))
                view.ParamName = dataReader.GetValueOrDefault<string>("ParamName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<string>("Remarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrderBy"))
                view.OrderBy = dataReader.GetValueOrDefault<int>("OrderBy");

            if (DataReaderRowFilter.RowFilter(dataReader, "IsValid"))
                view.IsValid = dataReader.GetValueOrDefault<int>("IsValid");



            return view;
        }
    }
}
