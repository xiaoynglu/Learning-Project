﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class ProductListViewMapper<T> : IRowMapper<T> where T : ProductListView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "Code"))
                view.ProdID = dataReader.GetValueOrDefault<string>("Code");
            if (DataReaderRowFilter.RowFilter(dataReader, "Prod"))
                view.ProdName = dataReader.GetValueOrDefault<string>("Prod");
            if (DataReaderRowFilter.RowFilter(dataReader, "result"))
                view.Result = dataReader.GetValueOrDefault<string>("result");
            if (DataReaderRowFilter.RowFilter(dataReader, "LoanSize"))
                view.LoanAmount = dataReader.GetValueOrDefault<string>("LoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "Tenor"))
                view.LoanTenor = dataReader.GetValueOrDefault<string>("Tenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "installment"))
                view.Installment = dataReader.GetValueOrDefault<string>("installment");
            if (DataReaderRowFilter.RowFilter(dataReader, "baseInterest"))
                view.BaseRate = dataReader.GetValueOrDefault<string>("baseInterest");
            if (DataReaderRowFilter.RowFilter(dataReader, "Interest"))
                view.InterestRate = dataReader.GetValueOrDefault<string>("Interest");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrDBR"))
                view.CurrDBR = dataReader.GetValueOrDefault<string>("CurrDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalDBR"))
                view.TotalDBR = dataReader.GetValueOrDefault<string>("TotalDBR");
            if (DataReaderRowFilter.RowFilter(dataReader, "LTV"))
                view.AvaliableLTV = dataReader.GetValueOrDefault<string>("LTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "maxLTV"))
                view.MaxLTV = dataReader.GetValueOrDefault<string>("maxLTV");
            return view;
        }
    }
}
