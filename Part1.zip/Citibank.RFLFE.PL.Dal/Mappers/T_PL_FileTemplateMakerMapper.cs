﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_FileTemplateMakerMapper<T> : IRowMapper<T> where T : T_PL_FileTemplateMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<int>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "FilePath"))
                view.FilePath = dataReader.GetValueOrDefault<string>("FilePath");
            if (DataReaderRowFilter.RowFilter(dataReader, "FileName"))
                view.FileName = dataReader.GetValueOrDefault<string>("FileName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgFileName"))
                view.OrgFileName = dataReader.GetValueOrDefault<string>("OrgFileName");            
            if (DataReaderRowFilter.RowFilter(dataReader, "FileType"))
                view.FileType = dataReader.GetValueOrDefault<int>("FileType");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<int>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "MakeDate"))
                view.MakeDate = dataReader.GetValueOrDefault<DateTime>("MakeDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            if (DataReaderRowFilter.RowFilter(dataReader, "CheckDate"))
                view.CheckDate = dataReader.GetValueOrDefault<DateTime>("CheckDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "OpType"))
                view.OpType = dataReader.GetValueOrDefault<int>("OpType");
            if (DataReaderRowFilter.RowFilter(dataReader, "FileTypeName"))
                view.FileTypeName = dataReader.GetValueOrDefault<string>("FileTypeName");
            if (DataReaderRowFilter.RowFilter(dataReader, "SubFileName"))
                view.SubFileName = dataReader.GetValueOrDefault<string>("SubFileName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "StatusName"))
                view.StatusName = dataReader.GetValueOrDefault<string>("StatusName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OpTypeName"))
                view.OpTypeName = dataReader.GetValueOrDefault<string>("OpTypeName");
            return view;
        }
    }
}
