﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    class T_PL_MoHouseBureauMapper<T> : IRowMapper<T> where T : T_PL_MoHouseBureau, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();

            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<Int32>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "FullName"))
                view.FullName = dataReader.GetValueOrDefault<String>("FullName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyValue"))
                view.PropertyValue = dataReader.GetValueOrDefault<String>("PropertyValue");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalPropertyValue"))
                view.TotalPropertyValue = dataReader.GetValueOrDefault<String>("TotalPropertyValue");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<String>("Remarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateID"))
                view.CreateID = dataReader.GetValueOrDefault<String>("CreateID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreatedTime"))
                view.CreatedTime = dataReader.GetValueOrDefault<String>("CreatedTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "UpdateID"))
                view.UpdateID = dataReader.GetValueOrDefault<String>("UpdateID");
            if (DataReaderRowFilter.RowFilter(dataReader, "UpdatedTime"))
                view.UpdatedTime = dataReader.GetValueOrDefault<String>("UpdatedTime");
            return view;
        }
    }
}
