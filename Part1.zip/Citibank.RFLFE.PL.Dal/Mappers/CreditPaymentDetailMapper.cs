﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class CreditPaymentDetailMapper<T> : IRowMapper<T> where T : CreditPaymentDetail, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T entity = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                entity.T_PL_Application.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "PayType"))
                entity.T_PL_Application.PayType = dataReader.GetValueOrDefault<string>("PayType");
            //"T_PL_SelfPay"
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitName"))
                entity.T_PL_SelfPay.DebitName = dataReader.GetValueOrDefault<string>("DebitName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitBankName"))
                entity.T_PL_SelfPay.DebitBankName = dataReader.GetValueOrDefault<string>("DebitBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitSubBankName"))
                entity.T_PL_SelfPay.DebitSubBankName = dataReader.GetValueOrDefault<string>("DebitSubBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitAccount"))
                entity.T_PL_SelfPay.DebitAccount = dataReader.GetValueOrDefault<string>("DebitAccount");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitReason"))
                entity.T_PL_SelfPay.DebitReason = dataReader.GetValueOrDefault<string>("DebitReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitRemarks"))
                entity.T_PL_SelfPay.DebitRemarks = dataReader.GetValueOrDefault<string>("DebitRemarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "SelfPaymentAmount"))
                entity.T_PL_SelfPay.PaymentAmount = dataReader.GetValueOrDefault<decimal>("SelfPaymentAmount");
            //"T_PL_EntrusPay"
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeName"))
                entity.T_PL_EntrusPay.PayeeName = dataReader.GetValueOrDefault<string>("PayeeName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeBankName"))
                entity.T_PL_EntrusPay.PayeeBankName = dataReader.GetValueOrDefault<string>("PayeeBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeSubBankName"))
                entity.T_PL_EntrusPay.PayeeSubBankName = dataReader.GetValueOrDefault<string>("PayeeSubBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeAccount"))
                entity.T_PL_EntrusPay.PayeeAccount = dataReader.GetValueOrDefault<string>("PayeeAccount");
            if (DataReaderRowFilter.RowFilter(dataReader, "EntrusPaymentAmount"))
                entity.T_PL_EntrusPay.PaymentAmount = dataReader.GetValueOrDefault<string>("EntrusPaymentAmount");
            return entity;
        }   
    }
}
