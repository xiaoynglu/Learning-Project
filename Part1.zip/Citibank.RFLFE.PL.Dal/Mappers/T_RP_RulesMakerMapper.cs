﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_RP_RulesMakerMapper<T> : IRowMapper<T> where T : T_RP_RulesMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "RuleName"))
                view.RuleName = dataReader.GetValueOrDefault<string>("RuleName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ClassName"))
                view.ClassName = dataReader.GetValueOrDefault<string>("ClassName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReasonID"))
                view.ReasonID = dataReader.GetValueOrDefault<string>("ReasonID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReferMessage"))
                view.ReferMessage = dataReader.GetValueOrDefault<string>("ReferMessage");
            if (DataReaderRowFilter.RowFilter(dataReader, "ActualMessage"))
                view.ActualMessage = dataReader.GetValueOrDefault<string>("ActualMessage");

            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<string>("Remarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "HitType"))
                view.HitType = dataReader.GetValueOrDefault<string>("HitType");
            if (DataReaderRowFilter.RowFilter(dataReader, "DeviationLvl"))
                view.DeviationLvl = dataReader.GetValueOrDefault<string>("DeviationLvl");
 

            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");

            if (DataReaderRowFilter.RowFilter(dataReader, "CreateTime"))
                view.CreateTime = dataReader.GetValueOrDefault<DateTime>("CreateTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifyedTime"))
                view.ModifiedTime = dataReader.GetValueOrDefault<DateTime>("ModifyedTime");
 
            if (DataReaderRowFilter.RowFilter(dataReader, "RuleID"))
                view.RuleID = dataReader.GetValueOrDefault<int>("RuleID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<int>("Status");
 
            if (DataReaderRowFilter.RowFilter(dataReader, "StatusName"))
                view.StatusName = dataReader.GetValueOrDefault<string>("StatusName");




            return view;
        }
    }
}
