﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class ApplyInfoDetailMapper<T> : IRowMapper<T> where T : ApplyInfoDetail, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            //"T_PL_Application"
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.T_PL_Application.ProdID = dataReader.GetValueOrDefault<int>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApplicationNo"))
                view.T_PL_Application.ApplicationNo = dataReader.GetValueOrDefault<string>("ApplicationNo");
            //"T_PL_LoanIndustryMaker"
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.T_PL_LoanIndustryMaker.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Category"))
                view.T_PL_LoanIndustryMaker.Category = dataReader.GetValueOrDefault<string>("Category");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose1"))
                view.T_PL_LoanIndustryMaker.Purpose1 = dataReader.GetValueOrDefault<string>("Purpose1");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose2"))
                view.T_PL_LoanIndustryMaker.Purpose2 = dataReader.GetValueOrDefault<string>("Purpose2");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose3"))
                view.T_PL_LoanIndustryMaker.Purpose3 = dataReader.GetValueOrDefault<string>("Purpose3");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherPurpose"))
                view.T_PL_LoanIndustryMaker.OtherPurpose = dataReader.GetValueOrDefault<string>("OtherPurpose");
            if (DataReaderRowFilter.RowFilter(dataReader, "CommericialFitment"))
                view.T_PL_LoanIndustryMaker.CommericialFitment = dataReader.GetValueOrDefault<string>("CommericialFitment");
            if (DataReaderRowFilter.RowFilter(dataReader, "MainIndustry"))
                view.T_PL_LoanIndustryMaker.MainIndustry = dataReader.GetValueOrDefault<string>("MainIndustry");
            if (DataReaderRowFilter.RowFilter(dataReader, "SubIndustry"))
                view.T_PL_LoanIndustryMaker.SubIndustry = dataReader.GetValueOrDefault<string>("SubIndustry");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationProvince"))
                view.T_PL_LoanIndustryMaker.DecorationProvince = dataReader.GetValueOrDefault<string>("DecorationProvince");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationCity"))
                view.T_PL_LoanIndustryMaker.DecorationCity = dataReader.GetValueOrDefault<string>("DecorationCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationRegion"))
                view.T_PL_LoanIndustryMaker.DecorationRegion = dataReader.GetValueOrDefault<string>("DecorationRegion");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationAddress"))
                view.T_PL_LoanIndustryMaker.DecorationAddress = dataReader.GetValueOrDefault<string>("DecorationAddress");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsPropertySelf"))
                view.T_PL_LoanIndustryMaker.IsPropertySelf = dataReader.GetValueOrDefault<bool>("IsPropertySelf");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationRelation"))
                view.T_PL_LoanIndustryMaker.DecorationRelation = dataReader.GetValueOrDefault<string>("DecorationRelation");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationPropertyValue1"))
                view.T_PL_LoanIndustryMaker.DecorationPropertyValue1 = dataReader.GetValueOrDefault<decimal>("DecorationPropertyValue1");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationPropertyValue2"))
                view.T_PL_LoanIndustryMaker.DecorationPropertyValue2 = dataReader.GetValueOrDefault<decimal>("DecorationPropertyValue2");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.T_PL_LoanIndustryMaker.Status = dataReader.GetValueOrDefault<int>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.T_PL_LoanIndustryMaker.Maker = dataReader.GetValueOrDefault<string>("Maker");
            //"T_PL_CollateralMaker"
            if (DataReaderRowFilter.RowFilter(dataReader, "RightNoOfLand"))
                view.T_PL_CollateralMaker.RightNoOfLand = dataReader.GetValueOrDefault<string>("RightNoOfLand");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyPermits"))
                view.T_PL_CollateralMaker.PropertyPermits = dataReader.GetValueOrDefault<string>("PropertyPermits");
            ///////////////////Get Data from checker table
            if (DataReaderRowFilter.RowFilter(dataReader, "Category_CK"))
                view.T_PL_LoanIndustry.Category = dataReader.GetValueOrDefault<string>("Category_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose1_CK"))
                view.T_PL_LoanIndustry.Purpose1 = dataReader.GetValueOrDefault<string>("Purpose1_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose2_CK"))
                view.T_PL_LoanIndustry.Purpose2 = dataReader.GetValueOrDefault<string>("Purpose2_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose3_CK"))
                view.T_PL_LoanIndustry.Purpose3 = dataReader.GetValueOrDefault<string>("Purpose3_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherPurpose_CK"))
                view.T_PL_LoanIndustry.OtherPurpose = dataReader.GetValueOrDefault<string>("OtherPurpose_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "CommericialFitment_CK"))
                view.T_PL_LoanIndustry.CommericialFitment = dataReader.GetValueOrDefault<string>("CommericialFitment_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "MainIndustry_CK"))
                view.T_PL_LoanIndustry.MainIndustry = dataReader.GetValueOrDefault<string>("MainIndustry_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "SubIndustry_CK"))
                view.T_PL_LoanIndustry.SubIndustry = dataReader.GetValueOrDefault<string>("SubIndustry_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationProvince_CK"))
                view.T_PL_LoanIndustry.DecorationProvince = dataReader.GetValueOrDefault<string>("DecorationProvince_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationCity_CK"))
                view.T_PL_LoanIndustry.DecorationCity = dataReader.GetValueOrDefault<string>("DecorationCity_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationRegion_CK"))
                view.T_PL_LoanIndustry.DecorationRegion = dataReader.GetValueOrDefault<string>("DecorationRegion_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationAddress_CK"))
                view.T_PL_LoanIndustry.DecorationAddress = dataReader.GetValueOrDefault<string>("DecorationAddress_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsPropertySelf_CK"))
                view.T_PL_LoanIndustry.IsPropertySelf = dataReader.GetValueOrDefault<String>("IsPropertySelf_CK") == "True" ? "1" : "0";
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationRelation_CK"))
                view.T_PL_LoanIndustry.DecorationRelation = dataReader.GetValueOrDefault<string>("DecorationRelation_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationPropertyValue1_CK"))
                view.T_PL_LoanIndustry.DecorationPropertyValue1 = dataReader.GetValueOrDefault<decimal>("DecorationPropertyValue1_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "DecorationPropertyValue2_CK"))
                view.T_PL_LoanIndustry.DecorationPropertyValue2 = dataReader.GetValueOrDefault<decimal>("DecorationPropertyValue2_CK");
            //"T_PL_CollateralMaker"
            if (DataReaderRowFilter.RowFilter(dataReader, "RightNoOfLand_CK"))
                view.T_PL_Collateral.RightNoOfLand = dataReader.GetValueOrDefault<string>("RightNoOfLand_CK");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyPermits_CK"))
                view.T_PL_Collateral.PropertyPermits = dataReader.GetValueOrDefault<string>("PropertyPermits_CK");
            return view;
        }   
    }
}
