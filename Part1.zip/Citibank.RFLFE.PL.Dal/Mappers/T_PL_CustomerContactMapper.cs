﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_CustomerContactMapper<T> : IRowMapper<T> where T : T_PL_CustomerContact, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseProvince"))
                view.HouseProvince = dataReader.GetValueOrDefault<String>("HouseProvince");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseCity"))
                view.HouseCity = dataReader.GetValueOrDefault<string>("HouseCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseDistrict"))
                view.HouseDistrict = dataReader.GetValueOrDefault<string>("HouseDistrict");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseStreet"))
                view.HouseStreet = dataReader.GetValueOrDefault<String>("HouseStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "HousePostCode"))
                view.HousePostCode = dataReader.GetValueOrDefault<String>("HousePostCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseStatus"))
                view.HouseStatus = dataReader.GetValueOrDefault<String>("HouseStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseTelAreaCode"))
                view.HouseTelAreaCode = dataReader.GetValueOrDefault<String>("HouseTelAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseTelNumber"))
                view.HouseTelNumber = dataReader.GetValueOrDefault<String>("HouseTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseSameAsResidence"))
                view.HouseSameAsResidence = dataReader.GetValueOrDefault<String>("HouseSameAsResidence")=="True"?"1":"0";
            if (DataReaderRowFilter.RowFilter(dataReader, "ResidenceProvince"))
                view.ResidenceProvince = dataReader.GetValueOrDefault<String>("ResidenceProvince");

            if (DataReaderRowFilter.RowFilter(dataReader, "ResidenceCity"))
                view.ResidenceCity = dataReader.GetValueOrDefault<String>("ResidenceCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "ResidenceDistrict"))
                view.ResidenceDistrict = dataReader.GetValueOrDefault<String>("ResidenceDistrict");
            if (DataReaderRowFilter.RowFilter(dataReader, "ResidenceStreet"))
                view.ResidenceStreet = dataReader.GetValueOrDefault<String>("ResidenceStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "ResidencePostCode"))
                view.ResidencePostCode = dataReader.GetValueOrDefault<String>("ResidencePostCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "ResidenceTelAreaCode"))
                view.ResidenceTelAreaCode = dataReader.GetValueOrDefault<String>("ResidenceTelAreaCode");

            if (DataReaderRowFilter.RowFilter(dataReader, "ResidenceTelNumber"))
                view.ResidenceTelNumber = dataReader.GetValueOrDefault<String>("ResidenceTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingProvince"))
                view.WorkingProvince = dataReader.GetValueOrDefault<String>("WorkingProvince");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingCity"))
                view.WorkingCity = dataReader.GetValueOrDefault<String>("WorkingCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingDistrict"))
                view.WorkingDistrict = dataReader.GetValueOrDefault<String>("WorkingDistrict");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingStreet"))
                view.WorkingStreet = dataReader.GetValueOrDefault<String>("WorkingStreet");

            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingPostCode"))
                view.WorkingPostCode = dataReader.GetValueOrDefault<String>("WorkingPostCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingTelAreaCode"))
                view.WorkingTelAreaCode = dataReader.GetValueOrDefault<String>("WorkingTelAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingTelNumber"))
                view.WorkingTelNumber = dataReader.GetValueOrDefault<String>("WorkingTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingTelExtNumber"))
                view.WorkingTelExtNumber = dataReader.GetValueOrDefault<String>("WorkingTelExtNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "CommunicationAddressAs"))
                view.CommunicationAddressAs = dataReader.GetValueOrDefault<String>("CommunicationAddressAs");
            if (DataReaderRowFilter.RowFilter(dataReader, "MobileNumber"))
                view.MobileNumber = dataReader.GetValueOrDefault<String>("MobileNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Email"))
                view.Email = dataReader.GetValueOrDefault<String>("Email");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDIssueDate"))
                view.IDIssueDate = dataReader.GetValueOrDefault<DateTime>("IDIssueDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDExpireDate"))
                view.IDExpireDate = dataReader.GetValueOrDefault<DateTime>("IDExpireDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDIssuePlace"))
                view.IDIssuePlace = dataReader.GetValueOrDefault<String>("IDIssuePlace");

            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactName"))
                view.OtherContactName = dataReader.GetValueOrDefault<String>("OtherContactName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactRelation"))
                view.OtherContactRelation = dataReader.GetValueOrDefault<String>("OtherContactRelation");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactTelAreaCode"))
                view.OtherContactTelAreaCode = dataReader.GetValueOrDefault<String>("OtherContactTelAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactTelNumber"))
                view.OtherContactTelNumber = dataReader.GetValueOrDefault<String>("OtherContactTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactTelExtNumber"))
                view.OtherContactTelExtNumber = dataReader.GetValueOrDefault<String>("OtherContactTelExtNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactMobile"))
                view.OtherContactMobile = dataReader.GetValueOrDefault<String>("OtherContactMobile");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactCompany"))
                view.OtherContactCompany = dataReader.GetValueOrDefault<String>("OtherContactCompany");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeName"))
                view.RelativeName = dataReader.GetValueOrDefault<String>("RelativeName");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeRelation"))
                view.RelativeRelation = dataReader.GetValueOrDefault<String>("RelativeRelation");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeCompany"))
                view.RelativeCompany = dataReader.GetValueOrDefault<String>("RelativeCompany");

            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeTelAreaCode"))
                view.RelativeTelAreaCode = dataReader.GetValueOrDefault<String>("RelativeTelAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeTelNumber"))
                view.RelativeTelNumber = dataReader.GetValueOrDefault<String>("RelativeTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeTelExtNumber"))
                view.RelativeTelExtNumber = dataReader.GetValueOrDefault<String>("RelativeTelExtNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeMobile"))
                view.RelativeMobile = dataReader.GetValueOrDefault<String>("RelativeMobile");
           
            return view;
        }
    }
}
