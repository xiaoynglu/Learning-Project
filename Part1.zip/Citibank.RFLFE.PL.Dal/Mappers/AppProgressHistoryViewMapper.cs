﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class AppProgressHistoryViewMapper<T> : IRowMapper<T> where T : AppProgressHistoryView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "PRO_ID"))
                view.PRO_ID = dataReader.GetValueOrDefault<String>("PRO_ID");
            if (DataReaderRowFilter.RowFilter(dataReader, "BEGINDATE"))
                view.BeginDate = dataReader.GetValueOrDefault<DateTime>("BEGINDATE").ToString("yyyy-MM-dd HH:mm:ss");
            if (DataReaderRowFilter.RowFilter(dataReader, "BEGINSTAGE"))
                view.BeginStage = dataReader.GetValueOrDefault<String>("BEGINSTAGE");
            if (DataReaderRowFilter.RowFilter(dataReader, "ENDDATE"))
                view.EndDate = dataReader.GetValueOrDefault<DateTime>("ENDDATE").ToString("yyyy-MM-dd HH:mm:ss");
            if (DataReaderRowFilter.RowFilter(dataReader, "ENDSTAGE"))
                view.EndStage = dataReader.GetValueOrDefault<String>("ENDSTAGE");
            if (DataReaderRowFilter.RowFilter(dataReader, "ACTION"))
                view.Action = dataReader.GetValueOrDefault<String>("ACTION");
            if (DataReaderRowFilter.RowFilter(dataReader, "REMARKS"))
                view.Remarks = dataReader.GetValueOrDefault<String>("REMARKS");
            
            return view;
        }
    }
}
