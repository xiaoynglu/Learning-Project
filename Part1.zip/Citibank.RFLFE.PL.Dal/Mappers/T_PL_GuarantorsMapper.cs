﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_GuarantorsMapper<T> : IRowMapper<T> where T : T_PL_Guarantors, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "GuarantorID"))
                view.GuarantorID = dataReader.GetValueOrDefault<Guid>("GuarantorID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustNO"))
                view.CustNO = dataReader.GetValueOrDefault<String>("CustNO");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "Name"))
                view.Name = dataReader.GetValueOrDefault<String>("Name");
            if (DataReaderRowFilter.RowFilter(dataReader, "PinyinName"))
                view.PinyinName = dataReader.GetValueOrDefault<String>("PinyinName");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<String>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "Telephone"))
                view.Telephone = dataReader.GetValueOrDefault<String>("Telephone");
            if (DataReaderRowFilter.RowFilter(dataReader, "MobileNumber"))
                view.MobileNumber = dataReader.GetValueOrDefault<String>("MobileNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Relation"))
                view.Relation = dataReader.GetValueOrDefault<String>("Relation");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseProvince"))
                view.HouseProvince = dataReader.GetValueOrDefault<String>("HouseProvince");

            if (DataReaderRowFilter.RowFilter(dataReader, "HouseCity"))
                view.HouseCity = dataReader.GetValueOrDefault<String>("HouseCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseDistrict"))
                view.HouseDistrict = dataReader.GetValueOrDefault<String>("HouseDistrict");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseStreet"))
                view.HouseStreet = dataReader.GetValueOrDefault<String>("HouseStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "HousePostCode"))
                view.HousePostCode = dataReader.GetValueOrDefault<String>("HousePostCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingProvince"))
                view.WorkingProvince = dataReader.GetValueOrDefault<String>("WorkingProvince");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingCity"))
                view.WorkingCity = dataReader.GetValueOrDefault<String>("WorkingCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingDistrict"))
                view.WorkingDistrict = dataReader.GetValueOrDefault<String>("WorkingDistrict");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingStreet"))
                view.WorkingStreet = dataReader.GetValueOrDefault<String>("WorkingStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingPostCode"))
                view.WorkingPostCode = dataReader.GetValueOrDefault<String>("WorkingPostCode");

            return view;
        }
    }
}
