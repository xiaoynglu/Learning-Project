﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class ReAllocationViewMapper<T> : IRowMapper<T> where T : ReAllocationView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNo"))
                view.AppNo = dataReader.GetValueOrDefault<String>("AppNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerID"))
                view.CustomerID = dataReader.GetValueOrDefault<String>("CustomerID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerName"))
                view.CustomerName = dataReader.GetValueOrDefault<String>("CustomerName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProductName"))
                view.ProductName = dataReader.GetValueOrDefault<String>("ProductName");
            if (DataReaderRowFilter.RowFilter(dataReader, "sales"))
                view.sales = dataReader.GetValueOrDefault<String>("sales");           
            if (DataReaderRowFilter.RowFilter(dataReader, "DateOfApplication"))
                view.DateOfApplication = dataReader.GetValueOrDefault<String>("DateOfApplication");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentStage"))
                view.CurrentStage = dataReader.GetValueOrDefault<String>("CurrentStage");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentProcessor"))
                view.CurrentProcessor = dataReader.GetValueOrDefault<String>("CurrentProcessor");
            if (DataReaderRowFilter.RowFilter(dataReader, "status"))
                view.status = dataReader.GetValueOrDefault<String>("status");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppCreate"))
                view.AppCreate = dataReader.GetValueOrDefault<String>("AppCreate");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentExec"))
                view.CurrentExec = dataReader.GetValueOrDefault<String>("CurrentExec");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<String>("OrgCode");

            return view;
        }
    }
}
