﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class OtherViewMapper<T> : IRowMapper<T> where T : OtherView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppId"))
                view.AppId = dataReader.GetValueOrDefault<Guid>("AppId").ToString();

            if (DataReaderRowFilter.RowFilter(dataReader, "PolicyDeviationReason"))
                view.PolicyReason = dataReader.GetValueOrDefault<String>("PolicyDeviationReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "PriceDeviationReason"))
                view.PriceReason = dataReader.GetValueOrDefault<String>("PriceDeviationReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcessDeviationReason"))
                view.ProcessReason = dataReader.GetValueOrDefault<String>("ProcessDeviationReason");

            if (DataReaderRowFilter.RowFilter(dataReader, "PolicyDeviated"))
                view.PolicyDeviation = dataReader.GetValueOrDefault<String>("PolicyDeviated")=="True"?"true":"false";
            if (DataReaderRowFilter.RowFilter(dataReader, "PriceDeviated"))
                view.PriceDeviation = dataReader.GetValueOrDefault<String>("PriceDeviated") == "True" ? "true" : "false"; ;
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcessDeviated"))
                view.ProcessDeviation = dataReader.GetValueOrDefault<String>("ProcessDeviated") == "True" ? "true" : "false"; ;

            if (DataReaderRowFilter.RowFilter(dataReader, "DeviationRemarks"))
                view.Remarks = dataReader.GetValueOrDefault<String>("DeviationRemarks");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "UserDefined1"))
                view.UserDefined1 = dataReader.GetValueOrDefault<String>("UserDefined1");
            if (DataReaderRowFilter.RowFilter(dataReader, "UserDefined2"))
                view.UserDefined2 = dataReader.GetValueOrDefault<String>("UserDefined2");
            if (DataReaderRowFilter.RowFilter(dataReader, "UserDefined3"))
                view.UserDefined3 = dataReader.GetValueOrDefault<String>("UserDefined3");
            if (DataReaderRowFilter.RowFilter(dataReader, "UserDefined4"))
                view.UserDefined4 = dataReader.GetValueOrDefault<String>("UserDefined4");
            if (DataReaderRowFilter.RowFilter(dataReader, "UserDefined5"))
                view.UserDefined5 = dataReader.GetValueOrDefault<String>("UserDefined5");
          
            
            return view;
        }
    }
}
