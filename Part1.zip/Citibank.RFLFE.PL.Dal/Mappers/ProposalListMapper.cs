﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class ProposalListMapper<T> : IRowMapper<T> where T : ProposalListEntity, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "App_ID"))
                view.App_ID = dataReader.GetValueOrDefault<string>("App_ID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNo"))
                view.AppNo = dataReader.GetValueOrDefault<string>("AppNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerID"))
                view.CustomerID = dataReader.GetValueOrDefault<string>("CustomerID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerName"))
                view.CustomerName = dataReader.GetValueOrDefault<string>("CustomerName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Product"))
                view.Product = dataReader.GetValueOrDefault<string>("Product");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProductName"))
                view.ProductName = dataReader.GetValueOrDefault<string>("ProductName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DateOfApplication"))
                view.DateOfApplication = dataReader.GetValueOrDefault<string>("DateOfApplication");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentStage"))
                view.CurrentStage = dataReader.GetValueOrDefault<string>("CurrentStage");
            if (DataReaderRowFilter.RowFilter(dataReader, "status"))
                view.status = dataReader.GetValueOrDefault<string>("status");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentProcessor"))
                view.CurrentProcessor = dataReader.GetValueOrDefault<string>("CurrentProcessor");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsLocked"))
                view.IsLocked = dataReader.GetValueOrDefault<string>("IsLocked");            
            return view;
        }   
    }
}
