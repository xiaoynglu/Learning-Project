﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_AfterLoanChangeLogMapper<T> : IRowMapper<T> where T : T_PL_AfterLoanChangeLogView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();           
            if (DataReaderRowFilter.RowFilter(dataReader, "CustName"))
                view.CustName = dataReader.GetValueOrDefault<String>("CustName");
            if (DataReaderRowFilter.RowFilter(dataReader, "BorrowType"))
                view.BorrowType = dataReader.GetValueOrDefault<String>("BorrowType");

            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<String>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "phone"))
                view.phone = dataReader.GetValueOrDefault<String>("phone");
            if (DataReaderRowFilter.RowFilter(dataReader, "MobileNumber"))
                view.MobileNumber = dataReader.GetValueOrDefault<String>("MobileNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Address"))
                view.Address = dataReader.GetValueOrDefault<String>("Address");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModiID"))
                view.ModiID = dataReader.GetValueOrDefault<String>("ModiID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModiDate"))
                view.ModiDate = dataReader.GetValueOrDefault<String>("ModiDate");            

            return view;
        }
    }
}
