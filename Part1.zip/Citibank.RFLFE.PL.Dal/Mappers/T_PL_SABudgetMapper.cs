﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_SABudgetMapper<T> : IRowMapper<T> where T : T_PL_SABudget, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageID"))
                view.StageID = dataReader.GetValueOrDefault<Int32>("StageID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AfterTaxIncome"))
                view.AfterTaxIncome = dataReader.GetValueOrDefault<Decimal>("AfterTaxIncome").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "RentalIncome"))
                view.RentalIncome = dataReader.GetValueOrDefault<Decimal>("RentalIncome").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherIncome"))
                view.OtherIncome = dataReader.GetValueOrDefault<Decimal>("OtherIncome").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherFamilyIncome"))
                view.OtherFamilyIncome = dataReader.GetValueOrDefault<Decimal>("OtherFamilyIncome").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "RentalExpenses"))
                view.RentalExpenses = dataReader.GetValueOrDefault<Decimal>("RentalExpenses").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "UtilitiesFee"))
                view.UtilitiesFee = dataReader.GetValueOrDefault<Decimal>("UtilitiesFee").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "LivingExpenses"))
                view.LivingExpenses = dataReader.GetValueOrDefault<Decimal>("LivingExpenses").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "EducationExpenses"))
                view.EducationExpenses = dataReader.GetValueOrDefault<Decimal>("EducationExpenses").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "TransportationExpenses"))
                view.TransportationExpenses = dataReader.GetValueOrDefault<Decimal>("TransportationExpenses").ToString();

            if (DataReaderRowFilter.RowFilter(dataReader, "OtherExpenses"))
                view.OtherExpenses = dataReader.GetValueOrDefault<Decimal>("OtherExpenses").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "MLRepayment"))
                view.MLRepayment = dataReader.GetValueOrDefault<Decimal>("MLRepayment").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ULRepayment"))
                view.ULRepayment = dataReader.GetValueOrDefault<Decimal>("ULRepayment").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "MonthlyDebt"))
                view.MonthlyDebt = dataReader.GetValueOrDefault<Decimal>("MonthlyDebt").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcessorID"))
                view.ProcessorID = dataReader.GetValueOrDefault<String>("ProcessorID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProceededDate"))
                view.ProceededDate = dataReader.GetValueOrDefault<DateTime>("ProceededDate");
          
            return view;
        }
    }
}
