﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_SEBudgetMapper<T> : IRowMapper<T> where T : T_PL_SEBudget, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageID"))
                view.StageID = dataReader.GetValueOrDefault<Int32>("StageID");
            if (DataReaderRowFilter.RowFilter(dataReader, "MonthlyTurnover"))
                view.MonthlyTurnover = dataReader.GetValueOrDefault<Decimal>("MonthlyTurnover").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "PurchaseCost"))
                view.PurchaseCost = dataReader.GetValueOrDefault<Decimal>("PurchaseCost").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "GrossMargins"))
                view.GrossMargins = dataReader.GetValueOrDefault<String>("GrossMargins");
            if (DataReaderRowFilter.RowFilter(dataReader, "StoreRents"))
                view.StoreRents = dataReader.GetValueOrDefault<Decimal>("StoreRents").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "UtilitiesFee"))
                view.UtilitiesFee = dataReader.GetValueOrDefault<Decimal>("UtilitiesFee").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "EmployeeSalary"))
                view.EmployeeSalary = dataReader.GetValueOrDefault<Decimal>("EmployeeSalary").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherExpenses"))
                view.OtherExpenses = dataReader.GetValueOrDefault<Decimal>("OtherExpenses").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "MLRepayment"))
                view.MLRepayment = dataReader.GetValueOrDefault<Decimal>("MLRepayment").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ULRepayment"))
                view.ULRepayment = dataReader.GetValueOrDefault<Decimal>("ULRepayment").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "RentalIncome"))
                view.RentalIncome = dataReader.GetValueOrDefault<Decimal>("RentalIncome").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "Tax"))
                view.Tax = dataReader.GetValueOrDefault<Decimal>("Tax").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "MonthlyIncome"))
                view.MonthlyIncome = dataReader.GetValueOrDefault<Decimal>("MonthlyIncome").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "MonthlyDebt"))
                view.MonthlyDebt = dataReader.GetValueOrDefault<Decimal>("MonthlyDebt").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "OwnedEstate"))
                view.OwnedEstate = dataReader.GetValueOrDefault<String>("OwnedEstate") == "True" ? "1" : "0";
            if (DataReaderRowFilter.RowFilter(dataReader, "OwnedResidence"))
                view.OwnedResidence = dataReader.GetValueOrDefault<String>("OwnedResidence")=="True"?"1":"0";
            if (DataReaderRowFilter.RowFilter(dataReader, "PaidInsurance"))
                view.PaidInsurance = dataReader.GetValueOrDefault<String>("PaidInsurance") == "True" ? "1" : "0";
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcessorID"))
                view.ProcessorID = dataReader.GetValueOrDefault<String>("ProcessorID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProceededDate"))
                view.ProceededDate = dataReader.GetValueOrDefault<DateTime>("ProceededDate");

            return view;
        }
    }
}
