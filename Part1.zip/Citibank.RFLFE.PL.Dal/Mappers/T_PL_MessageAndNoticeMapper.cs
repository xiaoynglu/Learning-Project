﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_MessageAndNoticeMapper<T> : IRowMapper<T> where T : T_PL_MessageAndNotice, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "typevalue"))
                view.typevalue = dataReader.GetValueOrDefault<int>("typevalue");
            if (DataReaderRowFilter.RowFilter(dataReader, "contentvalue"))
                view.contentvalue = dataReader.GetValueOrDefault<String>("contentvalue");
            if (DataReaderRowFilter.RowFilter(dataReader, "starttime"))
                view.starttime = dataReader.GetValueOrDefault<DateTime>("starttime").ToString("yyyy-MM-dd hh:mm");
            if (DataReaderRowFilter.RowFilter(dataReader, "endtime"))
                view.endtime = dataReader.GetValueOrDefault<DateTime>("endtime").ToString("yyyy-MM-dd hh:mm"); ;
            if (DataReaderRowFilter.RowFilter(dataReader, "orgcode"))
                view.orgcode = dataReader.GetValueOrDefault<String>("orgcode");
            if (DataReaderRowFilter.RowFilter(dataReader, "roletype"))
                view.roletype = dataReader.GetValueOrDefault<String>("roletype");
            
            return view;
        }
    }
}
