﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_LTVFactorsMapper<T> : IRowMapper<T> where T : T_PL_LTVFactors, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<String>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Factor"))
                view.Factor = dataReader.GetValueOrDefault<String>("Factor");
            if (DataReaderRowFilter.RowFilter(dataReader, "FactorValue"))
                view.FactorValue = dataReader.GetValueOrDefault<String>("FactorValue");
           
            return view;
        }
    }
}
