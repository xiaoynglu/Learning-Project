﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_AppExpireDateMakerMapper<T> : IRowMapper<T> where T : T_PL_AppExpireDateMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<string>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");            
            if (DataReaderRowFilter.RowFilter(dataReader, "ExpireDate"))
                view.ExpireDate = dataReader.GetValueOrDefault<string>("ExpireDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<string>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
            {
                if (dataReader.GetValueOrDefault<string>("Status") == "1")
                {
                    view.statusname = "待审批";
                }
                if (dataReader.GetValueOrDefault<string>("Status") == "2")
                {
                    view.statusname = "已审批";
                }
                if (dataReader.GetValueOrDefault<string>("Status") == "3")
                {
                    view.statusname = "已拒绝";
                }
            }
                view.Status = dataReader.GetValueOrDefault<string>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "CreateDate"))
                view.CreateDate = dataReader.GetValueOrDefault<string>("CreateDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModifiedTime"))
                view.ModifiedTime = dataReader.GetValueOrDefault<string>("ModifiedTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "OpType"))
                view.OpType = dataReader.GetValueOrDefault<string>("OpType");
            if (DataReaderRowFilter.RowFilter(dataReader, "OpType"))
            {
                if (dataReader.GetValueOrDefault<string>("OpType") == "1")
                {
                    view.OpName = "新增";
                }
                if (dataReader.GetValueOrDefault<string>("OpType") == "2")
                {
                    view.OpName = "修改";
                }
                if (dataReader.GetValueOrDefault<string>("OpType") == "3")
                {
                    view.OpName = "删除";
                }
            }
                
            
            return view;
        }
    }
}
