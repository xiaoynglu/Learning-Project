﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_MortgageCognizanceMapper<T> : IRowMapper<T> where T : T_PL_MortgageCognizance, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<Int64>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustDeclare"))
                view.CustDeclare = dataReader.GetValueOrDefault<Int32>("CustDeclare");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmCustDeclare"))
                view.ConfirmCustDeclare = dataReader.GetValueOrDefault<Int32>("ConfirmCustDeclare");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseBureau"))
                view.HouseBureau = dataReader.GetValueOrDefault<Int32>("HouseBureau");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmHouseBureau"))
                view.ConfirmHouseBureau = dataReader.GetValueOrDefault<Int32>("ConfirmHouseBureau");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseBureauChecked"))
                view.HouseBureauChecked = dataReader.GetValueOrDefault<Boolean>("HouseBureauChecked");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC"))
                view.PBOC = dataReader.GetValueOrDefault<Int32>("PBOC");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmPBOC"))
                view.ConfirmPBOC = dataReader.GetValueOrDefault<Int32>("ConfirmPBOC");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOCChecked"))
                view.PBOCChecked = dataReader.GetValueOrDefault<Boolean>("PBOCChecked");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalMoCount"))
                view.TotalMoCount = dataReader.GetValueOrDefault<Int32>("TotalMoCount");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmTotalMoCount"))
                view.ConfirmTotalMoCount = dataReader.GetValueOrDefault<Int32>("ConfirmTotalMoCount");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_Unliquidated"))
                view.PBOC_Unliquidated = dataReader.GetValueOrDefault<Int32>("PBOC_Unliquidated");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmPBOC_Unliquidated"))
                view.ConfirmPBOC_Unliquidated = dataReader.GetValueOrDefault<Int32>("ConfirmPBOC_Unliquidated");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_UnliquidatedMatch"))
                view.PBOC_UnliquidatedMatch = dataReader.GetValueOrDefault<Int32>("PBOC_UnliquidatedMatch");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmPBOC_UnliquidatedMatch"))
                view.ConfirmPBOC_UnliquidatedMatch = dataReader.GetValueOrDefault<Int32>("ConfirmPBOC_UnliquidatedMatch");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_SettlementMatch"))
                view.PBOC_SettlementMatch = dataReader.GetValueOrDefault<Int32>("PBOC_SettlementMatch");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmPBOC_SettlementMatch"))
                view.ConfirmPBOC_SettlementMatch = dataReader.GetValueOrDefault<Int32>("ConfirmPBOC_SettlementMatch");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalMoCount_Orgin"))
                view.TotalMoCount_Orgin = dataReader.GetValueOrDefault<Int32>("TotalMoCount_Orgin");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmTotalMoCount_Orgin"))
                view.ConfirmTotalMoCount_Orgin = dataReader.GetValueOrDefault<Int32>("ConfirmTotalMoCount_Orgin");
            return view;
        }
    }
}
