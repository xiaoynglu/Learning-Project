﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
   public  class T_PL_IDChangeLogMapper<T> : IRowMapper<T> where T : T_PL_IDChangeLog, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<string>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDIssueDate"))
                view.IDIssueDate = dataReader.GetValueOrDefault<string>("IDIssueDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDExpireDate"))
                view.IDExpireDate = dataReader.GetValueOrDefault<string>("IDExpireDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDIssuePlace"))
                view.IDIssuePlace = dataReader.GetValueOrDefault<string>("IDIssuePlace");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModiID"))
                view.ModiID = dataReader.GetValueOrDefault<string>("ModiID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModiDate"))
                view.ModiDate = dataReader.GetValueOrDefault<string>("ModiDate");
            
            return view;
        }
    }
}
