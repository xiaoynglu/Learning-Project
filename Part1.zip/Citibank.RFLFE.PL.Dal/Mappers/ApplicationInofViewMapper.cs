﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    class ApplicationInofViewMapper<T> : IRowMapper<T> where T : ApplicationInofView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "prodid"))
                view.ProdID = dataReader.GetValueOrDefault<String>("prodid").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustNo"))
                view.CustNo = dataReader.GetValueOrDefault<String>("CustNo").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "RelationshipNumber"))
                view.RelnNo = dataReader.GetValueOrDefault<String>("RelationshipNumber").ToString();
            return view;
        }
    }
}
