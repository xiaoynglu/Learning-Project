﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class ProcessHistoryRowMapper<T> : IRowMapper<T> where T : ProcessHistory, new()
    {
         T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "Action"))
                view.Action = dataReader.GetValueOrDefault<String>("Action");
            if (DataReaderRowFilter.RowFilter(dataReader, "BeginDate"))
                view.BeginDate = dataReader.GetValueOrDefault<String>("BeginDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "BeginStage"))
                view.BeginStage = dataReader.GetValueOrDefault<String>("BeginStage");
            if (DataReaderRowFilter.RowFilter(dataReader, "EndDate"))
                view.EndDate = dataReader.GetValueOrDefault<String>("EndDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "EndStage"))
                view.EndStage = dataReader.GetValueOrDefault<String>("EndStage");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcID"))
                view.ProcID = dataReader.GetValueOrDefault<String>("ProcID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<String>("Remarks");
            return view;
        }
    }
}
