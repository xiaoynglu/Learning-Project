﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class OfficerUserLevelInfoViewMapper<T> : IRowMapper<T> where T : OfficerUserLevelInfoView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<String>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "PRODID"))
                view.PRODID = dataReader.GetValueOrDefault<String>("PRODID");
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchCode"))
                view.BranchCode = dataReader.GetValueOrDefault<String>("BranchCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "PRODNAME"))
                view.PRODNAME = dataReader.GetValueOrDefault<String>("PRODNAME");
            if (DataReaderRowFilter.RowFilter(dataReader, "LEVELCODE"))
                view.LEVELCODE = dataReader.GetValueOrDefault<String>("LEVELCODE");
            if (DataReaderRowFilter.RowFilter(dataReader, "MAXLOANSIZE"))
                view.MAXLOANSIZE = dataReader.GetValueOrDefault<String>("MAXLOANSIZE");

            return view;
        }
    }
}
