﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class TemplateFilePathMapper<T> : IRowMapper<T> where T : T_PL_FileTemplateMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "FilePath"))
                view.FilePath = dataReader.GetValueOrDefault<string>("FilePath");
            if (DataReaderRowFilter.RowFilter(dataReader, "FileName"))
                view.FileName = dataReader.GetValueOrDefault<string>("FileName");
            return view;
        }
    }
}
