﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class FullRevalutionValuesViewMapper<T> : IRowMapper<T> where T : FullRevalutionValuesView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "homeFee"))
                view.homeFee = dataReader.GetValueOrDefault<String>("homeFee");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompletedDate"))
                view.CompletedDate = dataReader.GetValueOrDefault<String>("CompletedDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Address"))
                view.Address = dataReader.GetValueOrDefault<String>("Address");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseArea"))
                view.HouseArea = dataReader.GetValueOrDefault<String>("HouseArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "RightTypeOfLand"))
                view.RightTypeOfLand = dataReader.GetValueOrDefault<String>("RightTypeOfLand");
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralTypeDescription"))
                view.CollateralTypeDescription = dataReader.GetValueOrDefault<String>("CollateralTypeDescription");            

            return view;
        }
    }
}
