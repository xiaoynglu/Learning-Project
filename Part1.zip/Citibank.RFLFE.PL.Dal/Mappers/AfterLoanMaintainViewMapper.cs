﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    class AfterLoanMaintainViewMapper<T> : IRowMapper<T> where T : AfterLoanMaintainView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNo"))
                view.AppNo = dataReader.GetValueOrDefault<String>("AppNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<String>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustName"))
                view.CustName = dataReader.GetValueOrDefault<String>("CustName");
            if (DataReaderRowFilter.RowFilter(dataReader, "BorrowType"))
                view.BorrowType = dataReader.GetValueOrDefault<String>("BorrowType");
            if (dataReader.GetValueOrDefault<String>("BorrowType") == "MB")
            {
                view.BorrowTypeString = "主贷人";
            }
            if (dataReader.GetValueOrDefault<String>("BorrowType") == "CB1")
            {
                view.BorrowTypeString = "共贷人1";
            }
            if (dataReader.GetValueOrDefault<String>("BorrowType") == "CB2")
            {
                view.BorrowTypeString = "共贷人2";
            }
            if (DataReaderRowFilter.RowFilter(dataReader, "MobileNumber"))
                view.MobileNumber = dataReader.GetValueOrDefault<String>("MobileNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Address"))
                view.Address = dataReader.GetValueOrDefault<String>("Address");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ModiID"))
                view.ModiID = dataReader.GetValueOrDefault<String>("ModiID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ModiDate"))
                view.ModiDate = dataReader.GetValueOrDefault<String>("ModiDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseTelNumber"))
                view.HouseTelNumber = dataReader.GetValueOrDefault<String>("HouseTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Province"))
                view.Province = dataReader.GetValueOrDefault<String>("Province");
            if (DataReaderRowFilter.RowFilter(dataReader, "City"))
                view.City = dataReader.GetValueOrDefault<String>("City");
            if (DataReaderRowFilter.RowFilter(dataReader, "District"))
                view.District = dataReader.GetValueOrDefault<String>("District");
            if (DataReaderRowFilter.RowFilter(dataReader, "Street"))
                view.Street = dataReader.GetValueOrDefault<String>("Street");
            if (DataReaderRowFilter.RowFilter(dataReader, "TelAreaCode"))
                view.TelAreaCode = dataReader.GetValueOrDefault<String>("TelAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "TelNumber"))
                view.TelNumber = dataReader.GetValueOrDefault<String>("TelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "CommunicationAddressAs"))
                view.CommunicationAddressAs = dataReader.GetValueOrDefault<String>("CommunicationAddressAs").ToString();
            
            return view;
        }
    }
}
