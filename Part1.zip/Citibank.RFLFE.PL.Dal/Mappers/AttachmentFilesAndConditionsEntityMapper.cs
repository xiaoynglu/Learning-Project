﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class AttachmentFilesAndConditionsEntityMapper<T> : IRowMapper<T> where T : AttachmentFilesAndConditionsEntity, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<String>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<String>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "FilePath"))
                view.FilePath = dataReader.GetValueOrDefault<String>("FilePath");
            if (DataReaderRowFilter.RowFilter(dataReader, "FileType"))
                view.FileType = dataReader.GetValueOrDefault<String>("FileType");
            if (DataReaderRowFilter.RowFilter(dataReader, "FileName"))
                view.FileName = dataReader.GetValueOrDefault<String>("FileName");
            if (DataReaderRowFilter.RowFilter(dataReader, "TemplateID"))
                view.TemplateID = dataReader.GetValueOrDefault<String>("TemplateID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfigID"))
                view.ConfigID = dataReader.GetValueOrDefault<Guid>("ConfigID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ParentID"))
                view.ParentID = dataReader.GetValueOrDefault<String>("ParentID");
            if (DataReaderRowFilter.RowFilter(dataReader, "BorrowerType"))
                view.BorrowerType = dataReader.GetValueOrDefault<String>("BorrowerType");
            if (DataReaderRowFilter.RowFilter(dataReader, "QueryBy"))
                view.QueryBy = dataReader.GetValueOrDefault<String>("QueryBy");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrderBy"))
                view.OrderBy = dataReader.GetValueOrDefault<String>("OrderBy");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConditionID"))
                view.ConditionID = dataReader.GetValueOrDefault<String>("ConditionID");
            if (DataReaderRowFilter.RowFilter(dataReader, "TabID"))
                view.TabID = dataReader.GetValueOrDefault<String>("TabID");
            if (DataReaderRowFilter.RowFilter(dataReader, "GroupID"))
                view.GroupID = dataReader.GetValueOrDefault<Guid>("GroupID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "GroupName"))
                view.GroupName = dataReader.GetValueOrDefault<String>("GroupName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OP"))
                view.OP = dataReader.GetValueOrDefault<String>("OP");
            if (DataReaderRowFilter.RowFilter(dataReader, "Value"))
                view.Value = dataReader.GetValueOrDefault<String>("Value");
           
            return view;
        }
    }
}
