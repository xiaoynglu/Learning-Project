﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_SelfPayMapper<T> : IRowMapper<T> where T : T_PL_SelfPay, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitName"))
                view.DebitName = dataReader.GetValueOrDefault<string>("DebitName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitBankName"))
                view.DebitBankName = dataReader.GetValueOrDefault<string>("DebitBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitSubBankName"))
                view.DebitSubBankName = dataReader.GetValueOrDefault<string>("DebitSubBankName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitAccount"))
                view.DebitAccount = dataReader.GetValueOrDefault<string>("DebitAccount");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitReason"))
                view.DebitReason = dataReader.GetValueOrDefault<string>("DebitReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "DebitRemarks"))
                view.DebitRemarks = dataReader.GetValueOrDefault<string>("DebitRemarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "PaymentAmount"))
                view.PaymentAmount = dataReader.GetValueOrDefault<Decimal>("PaymentAmount");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayeeBankFullName"))
                view.PayeeBankFullName = dataReader.GetValueOrDefault<string>("PayeeBankFullName");            
            
            return view;
        }
    }
}
