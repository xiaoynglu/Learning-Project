﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_Sys_ParametersMapper<T> : IRowMapper<T> where T : T_Sys_Parameters, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ParamID"))
                view.ParamID = dataReader.GetValueOrDefault<string>("ParamID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ParentID"))
                view.ParentID = dataReader.GetValueOrDefault<string>("ParentID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Key"))
                view.Key = dataReader.GetValueOrDefault<string>("Key");
            if (DataReaderRowFilter.RowFilter(dataReader, "Value"))
                view.Value = dataReader.GetValueOrDefault<string>("Value");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrderBy"))
                view.OrderBy = dataReader.GetValueOrDefault<int>("OrderBy");
            return view;
        }
    }
}
