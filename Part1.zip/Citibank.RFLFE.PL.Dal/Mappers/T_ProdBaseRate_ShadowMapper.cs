﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_ProdBaseRate_ShadowMapper<T> : IRowMapper<T> where T : T_ProdBaseRate_Shadow, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<int>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<string>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "BaseRate"))
                view.BaseRate = dataReader.GetValueOrDefault<decimal>("BaseRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstPayRate"))
                view.FirstPayRate = dataReader.GetValueOrDefault<decimal>("FirstPayRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "SecondPayRate"))
                view.SecondPayRate = dataReader.GetValueOrDefault<decimal>("SecondPayRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "BaseRateOver5"))
                view.BaseRateOver5 = dataReader.GetValueOrDefault<decimal>("BaseRateOver5");

            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchName"))
                view.BranchName = dataReader.GetValueOrDefault<string>("BranchName");
            return view;
        }
    }
}
