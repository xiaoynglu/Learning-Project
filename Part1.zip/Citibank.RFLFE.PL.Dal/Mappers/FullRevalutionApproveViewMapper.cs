﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class FullRevalutionApproveViewMapper<T> : IRowMapper<T> where T : FullRevalutionApproveView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "HousePrice"))
                view.HousePrice = dataReader.GetValueOrDefault<String>("HousePrice");
            if (DataReaderRowFilter.RowFilter(dataReader, "TailSize"))
                view.TailSize = dataReader.GetValueOrDefault<String>("TailSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "PaySize"))
                view.PaySize = dataReader.GetValueOrDefault<String>("PaySize");
            if (DataReaderRowFilter.RowFilter(dataReader, "PayPercent"))
                view.PayPercent = dataReader.GetValueOrDefault<String>("PayPercent");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaxLTV"))
                view.MaxLTV = dataReader.GetValueOrDefault<String>("MaxLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "OldMaxLoanSize"))
                view.OldMaxLoanSize = dataReader.GetValueOrDefault<String>("OldMaxLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "NowMaxLoanSize"))
                view.NowMaxLoanSize = dataReader.GetValueOrDefault<String>("NowMaxLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "ActualLTV"))
                view.ActualLTV = dataReader.GetValueOrDefault<String>("ActualLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "ALoanSize"))
                view.ALoanSize = dataReader.GetValueOrDefault<String>("ALoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "NewALoanSize"))
                view.NewALoanSize = dataReader.GetValueOrDefault<String>("NewALoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "ATenor"))
                view.ATenor = dataReader.GetValueOrDefault<String>("ATenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "RateForYear"))
                view.RateForYear = dataReader.GetValueOrDefault<String>("RateForYear");           

            return view;
        }
    }
}
