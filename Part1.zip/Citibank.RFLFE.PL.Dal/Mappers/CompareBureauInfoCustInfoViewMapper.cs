﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class CompareBureauInfoCustInfoViewMapper<T> : IRowMapper<T> where T : CompareBureauInfoCustInfoView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "BorrowType"))
                view.BorrowType = dataReader.GetValueOrDefault<String>("BorrowType");
            if (DataReaderRowFilter.RowFilter(dataReader, "FullName"))
                view.FullName = dataReader.GetValueOrDefault<String>("FullName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Gender"))
                view.Gender = dataReader.GetValueOrDefault<String>("Gender");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseStreet"))
                view.HouseStreet = dataReader.GetValueOrDefault<String>("HouseStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "ShopName"))
                view.ShopName = dataReader.GetValueOrDefault<String>("ShopName");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingYear"))
                view.WorkingYear = dataReader.GetValueOrDefault<String>("WorkingYear");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingStreet"))
                view.WorkingStreet = dataReader.GetValueOrDefault<String>("WorkingStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "MobileNumber"))
                view.MobileNumber = dataReader.GetValueOrDefault<String>("MobileNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseTelNumber"))
                view.HouseTelNumber = dataReader.GetValueOrDefault<String>("HouseTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingTelNumber"))
                view.WorkingTelNumber = dataReader.GetValueOrDefault<String>("WorkingTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeName"))
                view.RelativeName = dataReader.GetValueOrDefault<String>("RelativeName");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeRelation"))
                view.RelativeRelation = dataReader.GetValueOrDefault<String>("RelativeRelation");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeTelAreaCode"))
                view.RelativeTelAreaCode = dataReader.GetValueOrDefault<String>("RelativeTelAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeTelNumber"))
                view.RelativeTelNumber = dataReader.GetValueOrDefault<String>("RelativeTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeTelExtNumber"))
                view.RelativeTelExtNumber = dataReader.GetValueOrDefault<String>("RelativeTelExtNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelativeMobile"))
                view.RelativeMobile = dataReader.GetValueOrDefault<String>("RelativeMobile");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactName"))
                view.OtherContactName = dataReader.GetValueOrDefault<String>("OtherContactName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactRelation"))
                view.OtherContactRelation = dataReader.GetValueOrDefault<String>("OtherContactRelation");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactTelAreaCode"))
                view.OtherContactTelAreaCode = dataReader.GetValueOrDefault<String>("OtherContactTelAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactTelNumber"))
                view.OtherContactTelNumber = dataReader.GetValueOrDefault<String>("OtherContactTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactTelExtNumber"))
                view.OtherContactTelExtNumber = dataReader.GetValueOrDefault<String>("OtherContactTelExtNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactMobile"))
                view.OtherContactMobile = dataReader.GetValueOrDefault<String>("OtherContactMobile");

            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_FullName"))
                view.PBOC_FullName = dataReader.GetValueOrDefault<String>("PBOC_FullName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_Gender"))
                view.PBOC_Gender = dataReader.GetValueOrDefault<String>("PBOC_Gender");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_HouseStreet"))
                view.PBOC_HouseStreet = dataReader.GetValueOrDefault<String>("PBOC_HouseStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_ShopName"))
                view.PBOC_ShopName = dataReader.GetValueOrDefault<String>("PBOC_ShopName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_WorkingYear"))
                view.PBOC_WorkingYear = dataReader.GetValueOrDefault<String>("PBOC_WorkingYear");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_WorkingStreet"))
                view.PBOC_WorkingStreet = dataReader.GetValueOrDefault<String>("PBOC_WorkingStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_MobileNumber"))
                view.PBOC_MobileNumber = dataReader.GetValueOrDefault<String>("PBOC_MobileNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_HouseTelNumber"))
                view.PBOC_HouseTelNumber = dataReader.GetValueOrDefault<String>("PBOC_HouseTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_WorkingTelNumber"))
                view.PBOC_WorkingTelNumber = dataReader.GetValueOrDefault<String>("PBOC_WorkingTelNumber");
            
            return view;
        }
    }
}
