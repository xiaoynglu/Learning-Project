﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_RP_RuleParamValuePivotMaper<T> : IRowMapper<T> where T : T_RP_RuleParamValuePivot, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "RuleID"))
                view.RuleID = dataReader.GetValueOrDefault<int>("RuleID");

            if (DataReaderRowFilter.RowFilter(dataReader, "ParamID"))
                view.ParamID = dataReader.GetValueOrDefault<int>("ParamID");

            if (DataReaderRowFilter.RowFilter(dataReader, "ParamName"))
                view.ParamName = dataReader.GetValueOrDefault<string>("ParamName");
           //if (DataReaderRowFilter.RowFilter(dataReader, "CustType"))
           //    view.CustType = dataReader.GetValueOrDefault<string>("CustType");
            if (DataReaderRowFilter.RowFilter(dataReader, "UPL_Q"))
                view.UPL_Q = dataReader.GetValueOrDefault<string>("UPL_Q");
            if (DataReaderRowFilter.RowFilter(dataReader, "UPL_G"))
                view.UPL_G = dataReader.GetValueOrDefault<string>("UPL_G");
            if (DataReaderRowFilter.RowFilter(dataReader, "HE_Q"))
                view.HE_Q = dataReader.GetValueOrDefault<string>("HE_Q");

            if (DataReaderRowFilter.RowFilter(dataReader, "HE_G"))
                view.HE_G = dataReader.GetValueOrDefault<string>("HE_G");

            if (DataReaderRowFilter.RowFilter(dataReader, "CRE_Q"))
                view.CRE_Q = dataReader.GetValueOrDefault<string>("CRE_Q");
            if (DataReaderRowFilter.RowFilter(dataReader, "CRE_G"))
                view.CRE_G = dataReader.GetValueOrDefault<string>("CRE_G");
            if (DataReaderRowFilter.RowFilter(dataReader, "MO_Q"))
                view.MO_Q = dataReader.GetValueOrDefault<string>("MO_Q");
            if (DataReaderRowFilter.RowFilter(dataReader, "MO_G"))
                view.MO_G = dataReader.GetValueOrDefault<string>("MO_G");
            if (DataReaderRowFilter.RowFilter(dataReader, "Rownumber"))
                view.Rownumber = dataReader.GetValueOrDefault<string>("Rownumber");

            if (DataReaderRowFilter.RowFilter(dataReader, "BranchName"))
                view.BranchName = dataReader.GetValueOrDefault<string>("BranchName");

            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<string>("OrgCode");



            
            return view;
        }
    }
}
