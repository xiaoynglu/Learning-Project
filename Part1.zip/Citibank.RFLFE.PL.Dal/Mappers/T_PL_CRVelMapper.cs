﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_CRVelMapper<T> : IRowMapper<T> where T : T_PL_CRVel, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "T_VelCR"))
                view.T_VelCR = dataReader.GetValueOrDefault<String>("T_VelCR");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "MatchCode"))
                view.MatchCode = dataReader.GetValueOrDefault<String>("MatchCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNo"))
                view.AppNo = dataReader.GetValueOrDefault<String>("AppNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustName"))
                view.CustName = dataReader.GetValueOrDefault<String>("CustName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReferName"))
                view.ReferName = dataReader.GetValueOrDefault<String>("ReferName");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyName"))
                view.CompanyName = dataReader.GetValueOrDefault<String>("CompanyName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Hphone"))
                view.Hphone = dataReader.GetValueOrDefault<String>("Hphone");
            if (DataReaderRowFilter.RowFilter(dataReader, "Mphone"))
                view.Mphone = dataReader.GetValueOrDefault<String>("Mphone");
            if (DataReaderRowFilter.RowFilter(dataReader, "Ophone"))
                view.Ophone = dataReader.GetValueOrDefault<String>("Ophone");
            if (DataReaderRowFilter.RowFilter(dataReader, "Haddr"))
                view.Haddr = dataReader.GetValueOrDefault<String>("Haddr");
            if (DataReaderRowFilter.RowFilter(dataReader, "Oaddr"))
                view.Oaddr = dataReader.GetValueOrDefault<String>("Oaddr");
            if (DataReaderRowFilter.RowFilter(dataReader, "Vel_PersonID"))
                view.Vel_PersonID = dataReader.GetValueOrDefault<String>("Vel_PersonID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ParaName"))
                view.ParaName = dataReader.GetValueOrDefault<String>("ParaName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ParaPhone"))
                view.ParaPhone = dataReader.GetValueOrDefault<String>("ParaPhone");
            if (DataReaderRowFilter.RowFilter(dataReader, "ParaMbile"))
                view.ParaMbile = dataReader.GetValueOrDefault<String>("ParaMbile");
            if (DataReaderRowFilter.RowFilter(dataReader, "OthName"))
                view.OthName = dataReader.GetValueOrDefault<String>("OthName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OthPhone"))
                view.OthPhone = dataReader.GetValueOrDefault<String>("OthPhone");
            if (DataReaderRowFilter.RowFilter(dataReader, "OthMBile"))
                view.OthMBile = dataReader.GetValueOrDefault<String>("OthMBile");
            if (DataReaderRowFilter.RowFilter(dataReader, "SpouseName"))
                view.SpouseName = dataReader.GetValueOrDefault<String>("SpouseName");
            return view;
        }
    }
}
