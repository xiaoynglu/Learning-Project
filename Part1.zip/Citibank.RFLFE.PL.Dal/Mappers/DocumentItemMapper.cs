﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class DocumentItemMapper<T> : IRowMapper<T> where T : DocumentItem, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();

            if (DataReaderRowFilter.RowFilter(dataReader, "DocID"))
                view.DocID = dataReader.GetValueOrDefault<string>("DocID");
            if (DataReaderRowFilter.RowFilter(dataReader, "DocName"))
                view.DocName = dataReader.GetValueOrDefault<string>("DocName");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsRequired"))
                view.IsRequired = dataReader.GetValueOrDefault<string>("IsRequired")=="1"?"是":"否";
           
            return view;
        }   
    }
}
