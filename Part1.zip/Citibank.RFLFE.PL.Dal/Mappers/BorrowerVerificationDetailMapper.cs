﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class BorrowerVerificationDetailMapper<T> : IRowMapper<T> where T : BorrowerVerificationDetail, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            //贷款人
            if (DataReaderRowFilter.RowFilter(dataReader, "FullName"))
                view.T_PL_Customers.FullName = dataReader.GetValueOrDefault<string>("FullName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Gender"))
                view.T_PL_Customers.Gender = dataReader.GetValueOrDefault<string>("Gender");
            if (DataReaderRowFilter.RowFilter(dataReader, "LivedYear"))
                view.T_PL_Customers.LivedYear = dataReader.GetValueOrDefault<int>("LivedYear");
            if (DataReaderRowFilter.RowFilter(dataReader, "EmploymentType"))
                view.T_PL_Customers.EmploymentType = dataReader.GetValueOrDefault<string>("EmploymentType");
            //贷款联系人
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingTelNumber"))
                view.T_PL_CustomerContact.WorkingTelNumber = dataReader.GetValueOrDefault<string>("WorkingTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseStreet"))
                view.T_PL_CustomerContact.HouseStreet = dataReader.GetValueOrDefault<string>("HouseStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseTelNumber"))
                view.T_PL_CustomerContact.HouseTelNumber = dataReader.GetValueOrDefault<string>("HouseTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "MobileNumber"))
                view.T_PL_CustomerContact.MobileNumber = dataReader.GetValueOrDefault<string>("MobileNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingStreet"))
                view.T_PL_CustomerContact.WorkingStreet = dataReader.GetValueOrDefault<string>("WorkingStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactName"))
                view.T_PL_CustomerContact.OtherContactName = dataReader.GetValueOrDefault<string>("OtherContactName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactRelation"))
                view.T_PL_CustomerContact.OtherContactRelation = dataReader.GetValueOrDefault<string>("OtherContactRelation");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactTelNumber"))
                view.T_PL_CustomerContact.OtherContactTelNumber = dataReader.GetValueOrDefault<string>("OtherContactTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactTelExtNumber"))
                view.T_PL_CustomerContact.OtherContactTelExtNumber = dataReader.GetValueOrDefault<string>("OtherContactTelExtNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactMobile"))
                view.T_PL_CustomerContact.OtherContactMobile = dataReader.GetValueOrDefault<string>("OtherContactMobile");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherContactTelAreaCode"))
                view.T_PL_CustomerContact.OtherContactTelAreaCode = dataReader.GetValueOrDefault<string>("OtherContactTelAreaCode");
            //工薪
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentWorkingLife"))
                view.T_PL_Customers.T_PL_SalaryCust.CurrentWorkingLife = dataReader.GetValueOrDefault<int>("CurrentWorkingLife");
            //个体户
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentIndustryTime"))
                view.T_PL_Customers.T_PL_SelfEmployedCust.CurrentIndustryTime = dataReader.GetValueOrDefault<int>("CurrentIndustryTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "ContactPosition"))
                view.T_PL_Customers.T_PL_SelfEmployedCust.ContactPosition = dataReader.GetValueOrDefault<string>("ContactPosition");
            if (DataReaderRowFilter.RowFilter(dataReader, "ShopName"))
                view.T_PL_Customers.T_PL_SelfEmployedCust.ShopName = dataReader.GetValueOrDefault<string>("ShopName");
            //核实记录
            if (DataReaderRowFilter.RowFilter(dataReader, "CustType"))
                view.T_PL_VerificationRecord.CustType = dataReader.GetValueOrDefault<string>("CustType");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedPhone"))
                view.T_PL_VerificationRecord.VerifiedPhone = dataReader.GetValueOrDefault<bool>("VerifiedPhone");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedInternet"))
                view.T_PL_VerificationRecord.VerifiedInternet = dataReader.GetValueOrDefault<bool>("VerifiedInternet");
            if (DataReaderRowFilter.RowFilter(dataReader, "Verified114"))
                view.T_PL_VerificationRecord.Verified114 = dataReader.GetValueOrDefault<bool>("Verified114");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedOther"))
                view.T_PL_VerificationRecord.VerifiedOther = dataReader.GetValueOrDefault<bool>("VerifiedOther");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedOtherRemark"))
                view.T_PL_VerificationRecord.VerifiedOtherRemark = dataReader.GetValueOrDefault<string>("VerifiedOtherRemark");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneReason"))
                view.T_PL_VerificationRecord.PhoneReason = dataReader.GetValueOrDefault<string>("PhoneReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneResult"))
                view.T_PL_VerificationRecord.PhoneResult = dataReader.GetValueOrDefault<string>("PhoneResult");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedSite"))
                view.T_PL_VerificationRecord.VerifiedSite = dataReader.GetValueOrDefault<bool>("VerifiedSite");
            if (DataReaderRowFilter.RowFilter(dataReader, "SiteReason"))
                view.T_PL_VerificationRecord.SiteReason = dataReader.GetValueOrDefault<string>("SiteReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "SiteResult"))
                view.T_PL_VerificationRecord.SiteResult = dataReader.GetValueOrDefault<string>("SiteResult");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedHouse"))
                view.T_PL_VerificationRecord.VerifiedHouse = dataReader.GetValueOrDefault<bool>("VerifiedHouse");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseReason"))
                view.T_PL_VerificationRecord.HouseReason = dataReader.GetValueOrDefault<string>("HouseReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseResult"))
                view.T_PL_VerificationRecord.HouseResult = dataReader.GetValueOrDefault<string>("HouseResult");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedExternal"))
                view.T_PL_VerificationRecord.VerifiedExternal = dataReader.GetValueOrDefault<bool>("VerifiedExternal");
            if (DataReaderRowFilter.RowFilter(dataReader, "ExternalReason"))
                view.T_PL_VerificationRecord.ExternalReason = dataReader.GetValueOrDefault<string>("ExternalReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "ExternalResult"))
                view.T_PL_VerificationRecord.ExternalResult = dataReader.GetValueOrDefault<string>("ExternalResult");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingReason"))
                view.T_PL_VerificationRecord.WorkingReason = dataReader.GetValueOrDefault<string>("WorkingReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingResult"))
                view.T_PL_VerificationRecord.WorkingResult = dataReader.GetValueOrDefault<string>("WorkingResult");
            return view;
        }   
    }
}
