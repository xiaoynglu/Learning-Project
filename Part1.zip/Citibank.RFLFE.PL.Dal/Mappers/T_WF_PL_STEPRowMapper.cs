﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;


namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_WF_PL_STEPRowMapper<T> : IRowMapper<T> where T : T_WF_PL_STEP, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "IsValid"))
                view.IsValid = dataReader.GetValueOrDefault<Int32>("IsValid");
            if (DataReaderRowFilter.RowFilter(dataReader, "NextStageID"))
                view.NextStageID = dataReader.GetValueOrDefault<Int32>("NextStageID");
            if (DataReaderRowFilter.RowFilter(dataReader, "NextStageStatus"))
                view.NextStageStatus = dataReader.GetValueOrDefault<string>("NextStageStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<string>("Remarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageID"))
                view.StageID = dataReader.GetValueOrDefault<Int32>("StageID");
            if (DataReaderRowFilter.RowFilter(dataReader, "StageStatus"))
                view.StageStatus = dataReader.GetValueOrDefault<string>("StageStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "StepID"))
                view.StepID = dataReader.GetValueOrDefault<Int32>("StepID");
            if (DataReaderRowFilter.RowFilter(dataReader, "StepName"))
                view.StepName = dataReader.GetValueOrDefault<string>("StepName");
           
            return view;
        }
    }
}
