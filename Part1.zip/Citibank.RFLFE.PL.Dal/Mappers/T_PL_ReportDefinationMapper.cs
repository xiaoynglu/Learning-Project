﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_ReportDefinationMapper<T> : IRowMapper<T> where T : T_PL_ReportDefination, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "UID"))
                view.UID = dataReader.GetValueOrDefault<Int32>("UID");
          
            if (DataReaderRowFilter.RowFilter(dataReader, "PreFilename"))
                view.PreFilename = dataReader.GetValueOrDefault<String>("PreFilename");
           
            if (DataReaderRowFilter.RowFilter(dataReader, "ReportHDStartTag"))
                view.ReportHDStartTag = dataReader.GetValueOrDefault<String>("ReportHDStartTag");
           
            if (DataReaderRowFilter.RowFilter(dataReader, "ReportHDTagStartPos"))
                view.ReportHDTagStartPos = dataReader.GetValueOrDefault<Int32>("ReportHDTagStartPos");
         
            if (DataReaderRowFilter.RowFilter(dataReader, "ReportHDTagEndTPos"))
                view.ReportHDTagEndTPos = dataReader.GetValueOrDefault<Int32>("ReportHDTagEndTPos");
          
            if (DataReaderRowFilter.RowFilter(dataReader, "ReportHDRows"))
                view.ReportHDRows = dataReader.GetValueOrDefault<Int32>("ReportHDRows");
          
            if (DataReaderRowFilter.RowFilter(dataReader, "AvailbleDataRows"))
                view.AvailbleDataRows = dataReader.GetValueOrDefault<Int32>("AvailbleDataRows");
          
            if (DataReaderRowFilter.RowFilter(dataReader, "FooterTag"))
                view.FooterTag = dataReader.GetValueOrDefault<String>("FooterTag").ToString();
            
            if (DataReaderRowFilter.RowFilter(dataReader, "FooterTagStartPos"))
                view.FooterTagStartPos = dataReader.GetValueOrDefault<Int32>("FooterTagStartPos");
           
            if (DataReaderRowFilter.RowFilter(dataReader, "FooterTagEndPos"))
                view.FooterTagEndPos = dataReader.GetValueOrDefault<Int32>("FooterTagEndPos");
          
            if (DataReaderRowFilter.RowFilter(dataReader, "FooterRows"))
                view.FooterRows = dataReader.GetValueOrDefault<Int32>("FooterRows");
         
            if (DataReaderRowFilter.RowFilter(dataReader, "SourcePath"))
                view.SourcePath = dataReader.GetValueOrDefault<String>("SourcePath");
           
            if (DataReaderRowFilter.RowFilter(dataReader, "DestPath"))
                view.DestPath = dataReader.GetValueOrDefault<String>("DestPath");
          
            if (DataReaderRowFilter.RowFilter(dataReader, "SaveFileName"))
                view.SaveFileName = dataReader.GetValueOrDefault<String>("SaveFileName");
           
            if (DataReaderRowFilter.RowFilter(dataReader, "DTSName"))
                view.DTSName = dataReader.GetValueOrDefault<String>("DTSName");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "BackUpPath"))
                view.BackUpPath = dataReader.GetValueOrDefault<String>("BackUpPath");
           
            if (DataReaderRowFilter.RowFilter(dataReader, "Description"))
                view.Description = dataReader.GetValueOrDefault<String>("Description");
           
            if (DataReaderRowFilter.RowFilter(dataReader, "FileType"))
                view.FileType = dataReader.GetValueOrDefault<Int32>("FileType");
           
            if (DataReaderRowFilter.RowFilter(dataReader, "SaveDays"))
                view.SaveDays = dataReader.GetValueOrDefault<Int32>("SaveDays");
          
            if (DataReaderRowFilter.RowFilter(dataReader, "ReportType"))
                view.ReportType = dataReader.GetValueOrDefault<Int32>("ReportType");
          
            if (DataReaderRowFilter.RowFilter(dataReader, "TableName"))
                view.TableName = dataReader.GetValueOrDefault<String>("TableName");
           
            if (DataReaderRowFilter.RowFilter(dataReader, "DeleteFlag"))
                view.DeleteFlag = dataReader.GetValueOrDefault<Int32>("DeleteFlag");
           
            if (DataReaderRowFilter.RowFilter(dataReader, "HistoryTable"))
                view.HistoryTable = dataReader.GetValueOrDefault<String>("HistoryTable");
          
            return view;
        }
    
    }
}
