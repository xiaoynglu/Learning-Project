﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    class appProgressViewMapper<T> : IRowMapper<T> where T : appProgressView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<String>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestNo"))
                view.RequestNo = dataReader.GetValueOrDefault<String>("RequestNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustId"))
                view.CustId = dataReader.GetValueOrDefault<String>("CustId");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustName"))
                view.CustName = dataReader.GetValueOrDefault<String>("CustName");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustRole"))
                view.CustRole = dataReader.GetValueOrDefault<String>("CustRole");
            if (DataReaderRowFilter.RowFilter(dataReader, "Product"))
                view.Product = dataReader.GetValueOrDefault<String>("Product");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProductName"))
                view.ProductName = dataReader.GetValueOrDefault<String>("ProductName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Saler"))
                view.Saler = dataReader.GetValueOrDefault<String>("Saler");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestDate"))
                view.RequestDate = dataReader.GetValueOrDefault<String>("RequestDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProcessStatus"))
                view.ProcessStatus = dataReader.GetValueOrDefault<String>("ProcessStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<String>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "Processor"))
                view.Processor = dataReader.GetValueOrDefault<String>("Processor");
            return view;
        }
    }
}
