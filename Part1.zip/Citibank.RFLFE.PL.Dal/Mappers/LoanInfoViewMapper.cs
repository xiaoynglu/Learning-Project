﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class LoanInfoViewMapper<T> : IRowMapper<T> where T : LoanInfoView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdId"))
                view.ProdId = dataReader.GetValueOrDefault<String>("ProdId");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestLoanSize"))
                view.RequestLoanSize = dataReader.GetValueOrDefault<Decimal>("RequestLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "SalesName"))
                view.SalesName = dataReader.GetValueOrDefault<String>("SalesName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProposalLoanSize"))
                view.ProposalLoanSize = dataReader.GetValueOrDefault<Decimal>("ProposalLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestTenor"))
                view.RequestTenor = dataReader.GetValueOrDefault<String>("RequestTenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "LoanCategory"))
                view.LoanCategory = dataReader.GetValueOrDefault<String>("LoanCategory");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose1"))
                view.Purpose1 = dataReader.GetValueOrDefault<String>("Purpose1");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose2"))
                view.Purpose2 = dataReader.GetValueOrDefault<String>("Purpose2");
            if (DataReaderRowFilter.RowFilter(dataReader, "Purpose3"))
                view.Purpose3 = dataReader.GetValueOrDefault<String>("Purpose3");
            if (DataReaderRowFilter.RowFilter(dataReader, "OtherPurpose"))
                view.OtherPurpose = dataReader.GetValueOrDefault<String>("OtherPurpose");
            if (DataReaderRowFilter.RowFilter(dataReader, "LoanDirection"))
                view.LoanDirection = dataReader.GetValueOrDefault<String>("LoanDirection");
            if (DataReaderRowFilter.RowFilter(dataReader, "SubLoanDirection"))
                view.SubLoanDirection = dataReader.GetValueOrDefault<String>("SubLoanDirection");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaxLoanSize"))
                view.MaxLoanSize = dataReader.GetValueOrDefault<Decimal>("MaxLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApprovedTenor"))
                view.ApprovedTenor = dataReader.GetValueOrDefault<String>("ApprovedTenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "AvailableUnsecuredSize"))
                view.AvailableUnsecuredSize = dataReader.GetValueOrDefault<Decimal>("AvailableUnsecuredSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "InterestRate"))
                view.InterestRate = dataReader.GetValueOrDefault<Decimal>("InterestRate");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApprovedLoanSize"))
                view.ApprovedLoanSize = dataReader.GetValueOrDefault<Decimal>("ApprovedLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "ActualLTV"))
                view.ActualLTV = dataReader.GetValueOrDefault<Decimal>("ActualLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "Installment"))
                view.Installment = dataReader.GetValueOrDefault<Decimal>("Installment");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyType"))
                view.PropertyType = dataReader.GetValueOrDefault<String>("PropertyType");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsPropertySelf"))
                view.IsPropertySelf = dataReader.GetValueOrDefault<String>("IsPropertySelf") == "True" ? "1" : "0"; ;
            return view;
        }
    }
}
