﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_LTVParamMapper<T> : IRowMapper<T> where T : T_PL_LTVParam, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "Factor"))
                view.Factor = dataReader.GetValueOrDefault<string>("Factor");
            if (DataReaderRowFilter.RowFilter(dataReader, "FactorName"))
                view.FactorName = dataReader.GetValueOrDefault<string>("FactorName");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsValid"))
                view.IsValid = dataReader.GetValueOrDefault<string>("IsValid");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<string>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<Int32>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<Int32>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Value"))
                view.Value = dataReader.GetValueOrDefault<Int32>("Value");
            return view;
        }
    }
}
