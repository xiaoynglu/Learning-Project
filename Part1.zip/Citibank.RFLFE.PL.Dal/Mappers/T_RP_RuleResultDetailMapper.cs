﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_RP_RuleResultDetailMapper<T> : IRowMapper<T> where T : T_RP_RuleResultDetail, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ActualMessage"))
                view.ActualMessage = dataReader.GetValueOrDefault<String>("ActualMessage");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Descriptions"))
                view.Descriptions = dataReader.GetValueOrDefault<String>("Descriptions");
            if (DataReaderRowFilter.RowFilter(dataReader, "DetailID"))
                view.DetailID = dataReader.GetValueOrDefault<int>("DetailID");
            if (DataReaderRowFilter.RowFilter(dataReader, "DeviationLvl"))
                view.DeviationLvl = dataReader.GetValueOrDefault<string>("DeviationLvl");

            if (DataReaderRowFilter.RowFilter(dataReader, "HitType"))
                view.HitType = dataReader.GetValueOrDefault<string>("HitType");

            if (DataReaderRowFilter.RowFilter(dataReader, "MajorReasonDesc"))
                view.MajorReasonDesc = dataReader.GetValueOrDefault<string>("MajorReasonDesc");
            if (DataReaderRowFilter.RowFilter(dataReader, "MajorReasonID"))
                view.MajorReasonID = dataReader.GetValueOrDefault<int>("MajorReasonID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<int>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReasonCode"))
                view.ReasonCode = dataReader.GetValueOrDefault<string>("ReasonCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReasonID"))
                view.ReasonID = dataReader.GetValueOrDefault<int>("ReasonID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReferMessage"))
                view.ReferMessage = dataReader.GetValueOrDefault<string>("ReferMessage");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.Remarks = dataReader.GetValueOrDefault<string>("Remarks");
            if (DataReaderRowFilter.RowFilter(dataReader, "Result"))
                view.Result = dataReader.GetValueOrDefault<String>("Result");
            if (DataReaderRowFilter.RowFilter(dataReader, "ResultID"))
                view.ResultID = dataReader.GetValueOrDefault<int>("ResultID");
            if (DataReaderRowFilter.RowFilter(dataReader, "RuleID"))
                view.RuleID = dataReader.GetValueOrDefault<int>("RuleID");
            if (DataReaderRowFilter.RowFilter(dataReader, "RuleName"))
                view.RuleName = dataReader.GetValueOrDefault<string>("RuleName");
           
            return view;

        }
    }
}
