﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class RuleParamAlistViewMapper<T> : IRowMapper<T> where T : RuleParamAlistView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralName"))
                view.CollateralName = dataReader.GetValueOrDefault<String>("CollateralName");
            if (DataReaderRowFilter.RowFilter(dataReader, "MoCountDisplay"))
                view.MoCountDisplay = dataReader.GetValueOrDefault<String>("MoCountDisplay");
            if (DataReaderRowFilter.RowFilter(dataReader, "BaseLTV"))
                view.BaseLTV = dataReader.GetValueOrDefault<String>("BaseLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaxDelLTV"))
                view.MaxDelLTV = dataReader.GetValueOrDefault<String>("MaxDelLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralType"))
                view.CollateralType = dataReader.GetValueOrDefault<String>("CollateralType");
            if (DataReaderRowFilter.RowFilter(dataReader, "MoCount"))
                view.MoCount = dataReader.GetValueOrDefault<String>("MoCount");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<String>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<String>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdId"))
                view.ProdId = dataReader.GetValueOrDefault<String>("ProdId");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<String>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "Rownumber"))
                view.Rownumber = dataReader.GetValueOrDefault<string>("Rownumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
            {
                if (dataReader.GetValueOrDefault<String>("Status") == "1")
                {
                    view.statusname = "待审批";
                }
                if (dataReader.GetValueOrDefault<String>("Status") == "2")
                {
                    view.statusname = "已审批";
                }
                if (dataReader.GetValueOrDefault<String>("Status") == "3")
                {
                    view.statusname = "已拒绝";
                }
            }
                
            return view;
        }
    }
}
