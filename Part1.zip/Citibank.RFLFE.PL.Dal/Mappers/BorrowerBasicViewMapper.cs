﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class BorrowerBasicViewMapper<T> : IRowMapper<T> where T : BorrowerBasicView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();

            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "LastName"))
                view.LastName = dataReader.GetValueOrDefault<string>("LastName");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstName"))
                view.FirstName = dataReader.GetValueOrDefault<string>("FirstName");
            if (DataReaderRowFilter.RowFilter(dataReader, "FullName"))
                view.FullName = dataReader.GetValueOrDefault<string>("FullName");
            if (DataReaderRowFilter.RowFilter(dataReader, "PinyinName"))
                view.PinyinName = dataReader.GetValueOrDefault<string>("PinyinName");
            if (DataReaderRowFilter.RowFilter(dataReader, "FormerName"))
                view.FormerName = dataReader.GetValueOrDefault<string>("FormerName");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<string>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "Gender"))
                view.Gender = dataReader.GetValueOrDefault<string>("Gender");
            if (DataReaderRowFilter.RowFilter(dataReader, "DOB"))
                view.DOB = dataReader.GetValueOrDefault<string>("DOB");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReportType"))
                view.ReportType = dataReader.GetValueOrDefault<string>("ReportType");
            if (DataReaderRowFilter.RowFilter(dataReader, "Education"))
                view.Education = dataReader.GetValueOrDefault<string>("Education");
            if (DataReaderRowFilter.RowFilter(dataReader, "BorrowType"))
                view.BorrowType = dataReader.GetValueOrDefault<string>("BorrowType");
            if (DataReaderRowFilter.RowFilter(dataReader, "LivedYear"))
                view.LivedYear = dataReader.GetValueOrDefault<string>("LivedYear");
            if (DataReaderRowFilter.RowFilter(dataReader, "MarriageStatus"))
                view.MarriageStatus = dataReader.GetValueOrDefault<string>("MarriageStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "SpouseName"))
                view.SpouseName = dataReader.GetValueOrDefault<string>("SpouseName");
            if (DataReaderRowFilter.RowFilter(dataReader, "SpouseIDNo"))
                view.SpouseIDNo = dataReader.GetValueOrDefault<string>("SpouseIDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "HasChildren"))
                view.HasChildren = dataReader.GetValueOrDefault<String>("HasChildren") == "True" ? "1" : "0";
            if (DataReaderRowFilter.RowFilter(dataReader, "Relation"))
                view.RelationShip = dataReader.GetValueOrDefault<string>("Relation");
            if (DataReaderRowFilter.RowFilter(dataReader, "SharedFinancial"))
                view.SharedFinancial = dataReader.GetValueOrDefault<String>("SharedFinancial") == "True" ? "1" : "0";
            if (DataReaderRowFilter.RowFilter(dataReader, "Occupation"))
                view.Occupation = dataReader.GetValueOrDefault<string>("Occupation");
            if (DataReaderRowFilter.RowFilter(dataReader, "EmploymentType"))
                view.EmploymentType = dataReader.GetValueOrDefault<string>("EmploymentType");
            if (DataReaderRowFilter.RowFilter(dataReader, "Industry"))
                view.Industry = dataReader.GetValueOrDefault<string>("Industry");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsTown"))
                view.IsTown = (dataReader.GetValueOrDefault<string>("IsTown")=="True"?"true":"false");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsSamePlace"))
                view.IsSamePlace = (dataReader.GetValueOrDefault<string>("IsSamePlace")=="True"?"true":"false");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsEmployeeLoan"))
                view.IsEmployeeLoan = (dataReader.GetValueOrDefault<string>("IsEmployeeLoan")=="True"?"true":"false");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseLevel"))
                view.EnterpriseLevel = dataReader.GetValueOrDefault<string>("EnterpriseLevel");
            if (DataReaderRowFilter.RowFilter(dataReader, "Department"))
                view.Department = dataReader.GetValueOrDefault<string>("Department");
            if (DataReaderRowFilter.RowFilter(dataReader, "Position"))
                view.Position = dataReader.GetValueOrDefault<string>("Position");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseName"))
                view.EnterpriseName = dataReader.GetValueOrDefault<string>("EnterpriseName");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseScale"))
                view.EnterpriseScale = dataReader.GetValueOrDefault<string>("EnterpriseScale");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentWorkingLife"))
                view.CurrentWorkingLife = dataReader.GetValueOrDefault<string>("CurrentWorkingLife");
            if (DataReaderRowFilter.RowFilter(dataReader, "PreWorkingLife"))
                view.PreWorkingLife = dataReader.GetValueOrDefault<string>("PreWorkingLife");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalWorkingLife"))
                view.TotalWorkingLife = dataReader.GetValueOrDefault<string>("TotalWorkingLife");
            if (DataReaderRowFilter.RowFilter(dataReader, "OperatorName"))
                view.OperatorName = dataReader.GetValueOrDefault<string>("OperatorName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ShopName"))
                view.ShopName = dataReader.GetValueOrDefault<string>("ShopName");
            if (DataReaderRowFilter.RowFilter(dataReader, "RegistrationNumber"))
                view.RegistrationNumber = dataReader.GetValueOrDefault<string>("RegistrationNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "OperationPlace"))
                view.OperationPlace = dataReader.GetValueOrDefault<string>("OperationPlace");
            if (DataReaderRowFilter.RowFilter(dataReader, "EmployeeNumber"))
                view.EmployeeNumber = dataReader.GetValueOrDefault<string>("EmployeeNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentIndustryTime"))
                view.CurrentIndustryTime = dataReader.GetValueOrDefault<string>("CurrentIndustryTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "Contact"))
                view.Contact = dataReader.GetValueOrDefault<string>("Contact");
            if (DataReaderRowFilter.RowFilter(dataReader, "ContactPosition"))
                view.ContactPosition = dataReader.GetValueOrDefault<string>("ContactPosition");
            if (DataReaderRowFilter.RowFilter(dataReader, "Job"))
                view.Job = dataReader.GetValueOrDefault<string>("Job");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseProperty"))
                view.EnterpriseProperty = dataReader.GetValueOrDefault<string>("EnterpriseProperty");
            
            return view;
        }   
    }
}
