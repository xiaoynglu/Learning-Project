﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_ALSViewMapper<T> : IRowMapper<T> where T : T_PL_ALSView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "APPID"))
                view.APPID = dataReader.GetValueOrDefault<Guid>("APPID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AccountNumber"))
                view.AccountNumber = dataReader.GetValueOrDefault<String>("AccountNumber");

            if (DataReaderRowFilter.RowFilter(dataReader, "PRODUCTCODE"))
                view.PRODUCTCODE = dataReader.GetValueOrDefault<String>("PRODUCTCODE");
            if (DataReaderRowFilter.RowFilter(dataReader, "LOANAMOUNT"))
                view.LOANAMOUNT = dataReader.GetValueOrDefault<String>("LOANAMOUNT");
            if (DataReaderRowFilter.RowFilter(dataReader, "LOANPROCEEDS"))
                view.LOANPROCEEDS = dataReader.GetValueOrDefault<String>("LOANPROCEEDS");
            if (DataReaderRowFilter.RowFilter(dataReader, "BASERATE"))
                view.BASERATE = dataReader.GetValueOrDefault<String>("BASERATE");
            if (DataReaderRowFilter.RowFilter(dataReader, "INTERESTRATE"))
                view.INTERESTRATE = dataReader.GetValueOrDefault<String>("INTERESTRATE");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerNumber"))
                view.CustomerNumber = dataReader.GetValueOrDefault<String>("CustomerNumber").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "RelationshipNumber"))
                view.RelationshipNumber = dataReader.GetValueOrDefault<String>("RelationshipNumber").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "RCNumber"))
                view.RCNumber = dataReader.GetValueOrDefault<String>("RCNumber").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CONTRACTDATE"))
                view.CONTRACTDATE = dataReader.GetValueOrDefault<String>("CONTRACTDATE").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "FIRSTDUEDATE"))
                view.FIRSTDUEDATE = dataReader.GetValueOrDefault<String>("FIRSTDUEDATE").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "TERM"))
                view.TERM = dataReader.GetValueOrDefault<String>("TERM").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "MATURITYDATE"))
                view.MATURITYDATE = dataReader.GetValueOrDefault<String>("MATURITYDATE").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "PrimBranch"))
                view.PrimBranch = dataReader.GetValueOrDefault<String>("PrimBranch").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "IndustryCode"))
                view.IndustryCode = dataReader.GetValueOrDefault<String>("IndustryCode").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CACSCity"))
                view.CACSCity = dataReader.GetValueOrDefault<String>("CACSCity").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CACSLoc"))
                view.CACSLoc = dataReader.GetValueOrDefault<String>("CACSLoc").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CityCode"))
                view.CityCode = dataReader.GetValueOrDefault<String>("CityCode").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ACF"))
                view.ACF = dataReader.GetValueOrDefault<String>("ACF").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "FS"))
                view.FS = Convert.ToString( dataReader.GetValueOrDefault<String>("FS"));
            if (DataReaderRowFilter.RowFilter(dataReader, "FU"))
                view.FU = Convert.ToString(dataReader.GetValueOrDefault<String>("FU"));
            if (DataReaderRowFilter.RowFilter(dataReader, "FL1"))
                view.FL1 = Convert.ToString(dataReader.GetValueOrDefault<String>("FL1"));
            if (DataReaderRowFilter.RowFilter(dataReader, "PURPOSE"))
                view.PURPOSE = dataReader.GetValueOrDefault<String>("PURPOSE").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "AgentCode"))
                view.AgentCode = dataReader.GetValueOrDefault<String>("AgentCode").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "SourceCode"))
                view.SourceCode = dataReader.GetValueOrDefault<String>("SourceCode").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "INCOMETYPE"))
                view.INCOMETYPE = dataReader.GetValueOrDefault<String>("INCOMETYPE").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "EMPLOYERCD"))
                view.EMPLOYERCD = dataReader.GetValueOrDefault<String>("EMPLOYERCD").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "SEGMENTID"))
                view.SEGMENTID = dataReader.GetValueOrDefault<String>("SEGMENTID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "OriginalAccNo"))
                view.OriginalAccNo = dataReader.GetValueOrDefault<String>("OriginalAccNo").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "OriginalSegmentId"))
                view.OriginalSegmentId = dataReader.GetValueOrDefault<String>("OriginalSegmentId").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "LOANDIRECTION"))
                view.LOANDIRECTION = dataReader.GetValueOrDefault<String>("LOANDIRECTION").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "DisbursementMethod"))
                view.DisbursementMethod = dataReader.GetValueOrDefault<String>("DisbursementMethod").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "LineID"))
                view.LineID = dataReader.GetValueOrDefault<String>("LineID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralID"))
                view.CollateralID = dataReader.GetValueOrDefault<String>("CollateralID").ToString();
            return view;
        }
    
    }
}
