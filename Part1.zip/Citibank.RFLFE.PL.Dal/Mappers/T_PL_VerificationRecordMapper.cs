﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_VerificationRecordMapper<T> : IRowMapper<T> where T : T_PL_VerificationRecord, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "BorrowType"))
                view.BorrowType = dataReader.GetValueOrDefault<string>("BorrowType");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustType"))
                view.CustType = dataReader.GetValueOrDefault<string>("CustType");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedPhone"))
                view.VerifiedPhone = dataReader.GetValueOrDefault<bool>("VerifiedPhone");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedInternet"))
                view.VerifiedInternet = dataReader.GetValueOrDefault<bool>("VerifiedInternet");
            if (DataReaderRowFilter.RowFilter(dataReader, "Verified114"))
                view.Verified114 = dataReader.GetValueOrDefault<bool>("Verified114");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedOther"))
                view.VerifiedOther = dataReader.GetValueOrDefault<bool>("VerifiedOther");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedOtherRemark"))
                view.VerifiedOtherRemark = dataReader.GetValueOrDefault<string>("VerifiedOtherRemark");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneReason"))
                view.PhoneReason = dataReader.GetValueOrDefault<string>("PhoneReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneResult"))
                view.PhoneResult = dataReader.GetValueOrDefault<string>("PhoneResult");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedSite"))
                view.VerifiedSite = dataReader.GetValueOrDefault<bool>("VerifiedSite");
            if (DataReaderRowFilter.RowFilter(dataReader, "SiteReason"))
                view.SiteReason = dataReader.GetValueOrDefault<string>("SiteReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "SiteResult"))
                view.SiteResult = dataReader.GetValueOrDefault<string>("SiteResult");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedHouse"))
                view.VerifiedHouse = dataReader.GetValueOrDefault<bool>("VerifiedHouse");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseReason"))
                view.HouseReason = dataReader.GetValueOrDefault<string>("HouseReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseResult"))
                view.HouseResult = dataReader.GetValueOrDefault<string>("HouseResult");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedExternal"))
                view.VerifiedExternal = dataReader.GetValueOrDefault<bool>("VerifiedExternal");
            if (DataReaderRowFilter.RowFilter(dataReader, "ExternalReason"))
                view.ExternalReason = dataReader.GetValueOrDefault<string>("ExternalReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "ExternalResult"))
                view.ExternalResult = dataReader.GetValueOrDefault<string>("ExternalResult");
            return view;
        }
    }
}
