﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class BorrowerCollateralDetailMapper<T> : IRowMapper<T> where T : BorrowerCollateralDetail, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            //抵押房产基本信息
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.T_PL_Collateral.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralType"))
                view.T_PL_Collateral.CollateralType = dataReader.GetValueOrDefault<string>("CollateralType");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyType"))
                view.T_PL_Collateral.PropertyType = dataReader.GetValueOrDefault<string>("PropertyType");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseValue"))
                view.T_PL_Collateral.HouseValue = dataReader.GetValueOrDefault<decimal>("HouseValue");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseAge"))
                view.T_PL_Collateral.HouseAge = dataReader.GetValueOrDefault<int>("HouseAge");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseArea"))
                view.T_PL_Collateral.HouseArea = dataReader.GetValueOrDefault<decimal>("HouseArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "CarArea"))
                view.T_PL_Collateral.CarArea = dataReader.GetValueOrDefault<decimal>("CarArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "GarageArea"))
                view.T_PL_Collateral.GarageArea = dataReader.GetValueOrDefault<decimal>("GarageArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyType"))
                view.T_PL_Collateral.PropertyType = dataReader.GetValueOrDefault<string>("PropertyType");
            if (DataReaderRowFilter.RowFilter(dataReader, "Province"))
                view.T_PL_Collateral.Province = dataReader.GetValueOrDefault<string>("Province");
            if (DataReaderRowFilter.RowFilter(dataReader, "City"))
                view.T_PL_Collateral.City = dataReader.GetValueOrDefault<string>("City");
            if (DataReaderRowFilter.RowFilter(dataReader, "Region"))
                view.T_PL_Collateral.Region = dataReader.GetValueOrDefault<string>("Region");
            if (DataReaderRowFilter.RowFilter(dataReader, "Address"))
                view.T_PL_Collateral.Address = dataReader.GetValueOrDefault<string>("Address");
            if (DataReaderRowFilter.RowFilter(dataReader, "PostCode"))
                view.T_PL_Collateral.PostCode = dataReader.GetValueOrDefault<string>("PostCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "ResidentialType"))
                view.T_PL_Collateral.ResidentialType = dataReader.GetValueOrDefault<string>("ResidentialType");
            if (DataReaderRowFilter.RowFilter(dataReader, "CommunityName"))
                view.T_PL_Collateral.CommunityName = dataReader.GetValueOrDefault<string>("CommunityName");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentStatus"))
                view.T_PL_Collateral.CurrentStatus = dataReader.GetValueOrDefault<string>("CurrentStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyPermits"))
                view.T_PL_Collateral.PropertyPermits = dataReader.GetValueOrDefault<string>("PropertyPermits");
            if (DataReaderRowFilter.RowFilter(dataReader, "LandArea"))
                view.T_PL_Collateral.LandArea = dataReader.GetValueOrDefault<decimal>("LandArea");
            if (DataReaderRowFilter.RowFilter(dataReader, "RightNoOfLand"))
                view.T_PL_Collateral.RightNoOfLand = dataReader.GetValueOrDefault<string>("RightNoOfLand");
            if (DataReaderRowFilter.RowFilter(dataReader, "RightTypeOfLand"))
                view.T_PL_Collateral.RightTypeOfLand = dataReader.GetValueOrDefault<string>("RightTypeOfLand");
            if (DataReaderRowFilter.RowFilter(dataReader, "FloorSpace"))
                view.T_PL_Collateral.FloorSpace = dataReader.GetValueOrDefault<decimal>("FloorSpace");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalPrice"))
                view.T_PL_Collateral.TotalPrice = dataReader.GetValueOrDefault<decimal>("TotalPrice");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompletedDate"))
                view.T_PL_Collateral.CompletedDate = dataReader.GetValueOrDefault<String>("CompletedDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "SoilUsingYear"))
                view.T_PL_Collateral.SoilUsingYear = dataReader.GetValueOrDefault<int>("SoilUsingYear");
            if (DataReaderRowFilter.RowFilter(dataReader, "LandUsingYear"))
                view.T_PL_Collateral.LandUsingYear = dataReader.GetValueOrDefault<int>("LandUsingYear");
            if (DataReaderRowFilter.RowFilter(dataReader, "RentRemainingDate"))
                view.T_PL_Collateral.RentRemainingDate = dataReader.GetValueOrDefault<int>("RentRemainingDate");
            //贷款信息
            if (DataReaderRowFilter.RowFilter(dataReader, "IsPartialMortgage"))
                view.T_PL_Loan.IsPartialMortgage = dataReader.GetValueOrDefault<string>("IsPartialMortgage");
            if (DataReaderRowFilter.RowFilter(dataReader, "HasProperty"))
                view.T_PL_Loan.HasProperty = dataReader.GetValueOrDefault<string>("HasProperty");
            if (DataReaderRowFilter.RowFilter(dataReader, "OwnHouse"))
                view.T_PL_Loan.OwnHouse = dataReader.GetValueOrDefault<Boolean>("OwnHouse") == true ? "1" : "0";
            if (DataReaderRowFilter.RowFilter(dataReader, "BaseLTV"))
                view.T_PL_Loan.BaseLTV = dataReader.GetValueOrDefault<Decimal>("BaseLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaxAllowedLTV"))
                view.T_PL_Loan.MaxAllowedLTV = dataReader.GetValueOrDefault<Decimal>("MaxAllowedLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReducedLTV"))
                view.T_PL_Loan.ReducedLTV = dataReader.GetValueOrDefault<Decimal>("ReducedLTV");
            if (DataReaderRowFilter.RowFilter(dataReader, "MorgageCount"))
                view.T_PL_Loan.MorgageCount = dataReader.GetValueOrDefault<int>("MorgageCount");
            //抵押房产认定表
            if (DataReaderRowFilter.RowFilter(dataReader, "CustDeclare"))
                view.T_PL_MortgageCognizance.CustDeclare = dataReader.GetValueOrDefault<int>("CustDeclare");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmCustDeclare"))
                view.T_PL_MortgageCognizance.ConfirmCustDeclare = dataReader.GetValueOrDefault<int>("ConfirmCustDeclare");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseBureau"))
                view.T_PL_MortgageCognizance.HouseBureau = dataReader.GetValueOrDefault<int>("HouseBureau");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmHouseBureau"))
                view.T_PL_MortgageCognizance.ConfirmHouseBureau = dataReader.GetValueOrDefault<int>("ConfirmHouseBureau");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseBureauChecked"))
                view.T_PL_MortgageCognizance.HouseBureauChecked = dataReader.GetValueOrDefault<Boolean>("HouseBureauChecked");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC"))
                view.T_PL_MortgageCognizance.PBOC = dataReader.GetValueOrDefault<int>("PBOC");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmPBOC"))
                view.T_PL_MortgageCognizance.ConfirmPBOC = dataReader.GetValueOrDefault<int>("ConfirmPBOC");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOCChecked"))
                view.T_PL_MortgageCognizance.PBOCChecked = dataReader.GetValueOrDefault<Boolean>("PBOCChecked");
            if (DataReaderRowFilter.RowFilter(dataReader, "ContacTotalMoCounttPosition"))
                view.T_PL_MortgageCognizance.TotalMoCount = dataReader.GetValueOrDefault<int>("TotalMoCount");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalMoCount"))
                view.T_PL_MortgageCognizance.TotalMoCount = dataReader.GetValueOrDefault<int>("TotalMoCount");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmTotalMoCount"))
                view.T_PL_MortgageCognizance.ConfirmTotalMoCount = dataReader.GetValueOrDefault<int>("ConfirmTotalMoCount");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_Unliquidated"))
                view.T_PL_MortgageCognizance.PBOC_Unliquidated = dataReader.GetValueOrDefault<int>("PBOC_Unliquidated");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmPBOC_Unliquidated"))
                view.T_PL_MortgageCognizance.ConfirmPBOC_Unliquidated = dataReader.GetValueOrDefault<int>("ConfirmPBOC_Unliquidated");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_UnliquidatedMatch"))
                view.T_PL_MortgageCognizance.PBOC_UnliquidatedMatch = dataReader.GetValueOrDefault<int>("PBOC_UnliquidatedMatch");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmPBOC_UnliquidatedMatch"))
                view.T_PL_MortgageCognizance.ConfirmPBOC_UnliquidatedMatch = dataReader.GetValueOrDefault<int>("ConfirmPBOC_UnliquidatedMatch");
            if (DataReaderRowFilter.RowFilter(dataReader, "PBOC_SettlementMatch"))
                view.T_PL_MortgageCognizance.PBOC_SettlementMatch = dataReader.GetValueOrDefault<int>("PBOC_SettlementMatch");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmPBOC_SettlementMatch"))
                view.T_PL_MortgageCognizance.ConfirmPBOC_SettlementMatch = dataReader.GetValueOrDefault<int>("ConfirmPBOC_SettlementMatch");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalMoCount_Orgin"))
                view.T_PL_MortgageCognizance.TotalMoCount_Orgin = dataReader.GetValueOrDefault<int>("TotalMoCount_Orgin");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfirmTotalMoCount_Orgin"))
                view.T_PL_MortgageCognizance.ConfirmTotalMoCount_Orgin = dataReader.GetValueOrDefault<int>("ConfirmTotalMoCount_Orgin");

            //正估信息
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.T_PL_FormalAppraisal.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Price"))
                view.T_PL_FormalAppraisal.Price = dataReader.GetValueOrDefault<decimal>("Price");
            return view;
        }   
    }
}
