﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_CLMSHandoverMapper<T> : IRowMapper<T> where T : T_PL_CLMSHandover, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");            
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralType")) view.CollateralType = dataReader.GetValueOrDefault<String>("CollateralType");
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralSubType")) view.CollateralSubType = dataReader.GetValueOrDefault<String>("CollateralSubType");
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralDescription")) view.CollateralDescription = dataReader.GetValueOrDefault<String>("CollateralDescription");
            if (DataReaderRowFilter.RowFilter(dataReader, "Scope")) view.Scope = dataReader.GetValueOrDefault<String>("Scope");
            if (DataReaderRowFilter.RowFilter(dataReader, "RegisteredAt")) view.RegisteredAt = dataReader.GetValueOrDefault<String>("RegisteredAt");
            if (DataReaderRowFilter.RowFilter(dataReader, "Currency")) view.Currency = dataReader.GetValueOrDefault<String>("Currency");
            if (DataReaderRowFilter.RowFilter(dataReader, "FMV")) view.FMV = dataReader.GetValueOrDefault<String>("FMV");
            if (DataReaderRowFilter.RowFilter(dataReader, "Restricted")) view.Restricted = dataReader.GetValueOrDefault<String>("Restricted");
            if (DataReaderRowFilter.RowFilter(dataReader, "ExpiryDate")) view.ExpiryDate = dataReader.GetValueOrDefault<String>("ExpiryDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApplicableLVS")) view.ApplicableLVS = dataReader.GetValueOrDefault<String>("ApplicableLVS");
            if (DataReaderRowFilter.RowFilter(dataReader, "Owner")) view.Owner = dataReader.GetValueOrDefault<String>("Owner");
            if (DataReaderRowFilter.RowFilter(dataReader, "Address")) view.Address = dataReader.GetValueOrDefault<String>("Address");
            if (DataReaderRowFilter.RowFilter(dataReader, "District")) view.District = dataReader.GetValueOrDefault<String>("District");
            if (DataReaderRowFilter.RowFilter(dataReader, "TowCity")) view.TowCity = dataReader.GetValueOrDefault<String>("TowCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "Country")) view.Country = dataReader.GetValueOrDefault<String>("Country");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrencyRestriction")) view.CurrencyRestriction = dataReader.GetValueOrDefault<String>("CurrencyRestriction");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrencyCode")) view.CurrencyCode = dataReader.GetValueOrDefault<String>("CurrencyCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "SanctionDate")) view.SanctionDate = dataReader.GetValueOrDefault<String>("SanctionDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "SanctionExpiryDate")) view.SanctionExpiryDate = dataReader.GetValueOrDefault<String>("SanctionExpiryDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "StartDate")) view.StartDate = dataReader.GetValueOrDefault<String>("StartDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "DrawdownExpireDate")) view.DrawdownExpireDate = dataReader.GetValueOrDefault<String>("DrawdownExpireDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "MaturityDate")) view.MaturityDate = dataReader.GetValueOrDefault<String>("MaturityDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "NextReviewDate")) view.NextReviewDate = dataReader.GetValueOrDefault<String>("NextReviewDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "ApprovedLimit")) view.ApprovedLimit = dataReader.GetValueOrDefault<String>("ApprovedLimit");
            if (DataReaderRowFilter.RowFilter(dataReader, "AvailedLimit")) view.AvailedLimit = dataReader.GetValueOrDefault<String>("AvailedLimit");
            if (DataReaderRowFilter.RowFilter(dataReader, "Revolving")) view.Revolving = dataReader.GetValueOrDefault<String>("Revolving");
            if (DataReaderRowFilter.RowFilter(dataReader, "RiskRating")) view.RiskRating = dataReader.GetValueOrDefault<String>("RiskRating");
            if (DataReaderRowFilter.RowFilter(dataReader, "Tolerance")) view.Tolerance = dataReader.GetValueOrDefault<String>("Tolerance");
            if (DataReaderRowFilter.RowFilter(dataReader, "RiskCategory")) view.RiskCategory = dataReader.GetValueOrDefault<String>("RiskCategory");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConditionalApproveFlag")) view.ConditionalApproveFlag = dataReader.GetValueOrDefault<String>("ConditionalApproveFlag");
            if (DataReaderRowFilter.RowFilter(dataReader, "LineID")) view.LineID = dataReader.GetValueOrDefault<String>("LineID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralID")) view.CollateralID = dataReader.GetValueOrDefault<String>("CollateralID");

          
            return view;
        }
    
    }
}
