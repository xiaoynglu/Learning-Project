﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class GuarantorPhoneVerificationMapper<T> : IRowMapper<T> where T : GuarantorPhoneVerification, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            //担保人基本信息
            if (DataReaderRowFilter.RowFilter(dataReader, "GuarantorID"))
                view.T_PL_Guarantors.GuarantorID = dataReader.GetValueOrDefault<Guid>("GuarantorID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.T_PL_Guarantors.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "Name"))
                view.T_PL_Guarantors.Name = dataReader.GetValueOrDefault<String>("Name");
            if (DataReaderRowFilter.RowFilter(dataReader, "PinyinName"))
                view.T_PL_Guarantors.PinyinName = dataReader.GetValueOrDefault<String>("PinyinName");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.T_PL_Guarantors.IDNo = dataReader.GetValueOrDefault<String>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "Telephone"))
                view.T_PL_Guarantors.Telephone = dataReader.GetValueOrDefault<String>("Telephone");
            if (DataReaderRowFilter.RowFilter(dataReader, "MobileNumber"))
                view.T_PL_Guarantors.MobileNumber = dataReader.GetValueOrDefault<String>("MobileNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Relation"))
                view.T_PL_Guarantors.Relation = dataReader.GetValueOrDefault<String>("Relation");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseProvince"))
                view.T_PL_Guarantors.HouseProvince = dataReader.GetValueOrDefault<String>("HouseProvince");

            if (DataReaderRowFilter.RowFilter(dataReader, "HouseCity"))
                view.T_PL_Guarantors.HouseCity = dataReader.GetValueOrDefault<String>("HouseCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseDistrict"))
                view.T_PL_Guarantors.HouseDistrict = dataReader.GetValueOrDefault<String>("HouseDistrict");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseStreet"))
                view.T_PL_Guarantors.HouseStreet = dataReader.GetValueOrDefault<String>("HouseStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "HousePostCode"))
                view.T_PL_Guarantors.HousePostCode = dataReader.GetValueOrDefault<String>("HousePostCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingProvince"))
                view.T_PL_Guarantors.WorkingProvince = dataReader.GetValueOrDefault<String>("WorkingProvince");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingCity"))
                view.T_PL_Guarantors.WorkingCity = dataReader.GetValueOrDefault<String>("WorkingCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingDistrict"))
                view.T_PL_Guarantors.WorkingDistrict = dataReader.GetValueOrDefault<String>("WorkingDistrict");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingStreet"))
                view.T_PL_Guarantors.WorkingStreet = dataReader.GetValueOrDefault<String>("WorkingStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingPostCode"))
                view.T_PL_Guarantors.WorkingPostCode = dataReader.GetValueOrDefault<String>("WorkingPostCode");
            //电话核实信息记录
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedPhone"))
                view.T_PL_VerificationRecord.VerifiedPhone = dataReader.GetValueOrDefault<bool>("VerifiedPhone");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedInternet"))
                view.T_PL_VerificationRecord.VerifiedInternet = dataReader.GetValueOrDefault<bool>("VerifiedInternet");
            if (DataReaderRowFilter.RowFilter(dataReader, "Verified114"))
                view.T_PL_VerificationRecord.Verified114 = dataReader.GetValueOrDefault<bool>("Verified114");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedOther"))
                view.T_PL_VerificationRecord.VerifiedOther = dataReader.GetValueOrDefault<bool>("VerifiedOther");
            if (DataReaderRowFilter.RowFilter(dataReader, "VerifiedOtherRemark"))
                view.T_PL_VerificationRecord.VerifiedOtherRemark = dataReader.GetValueOrDefault<string>("VerifiedOtherRemark");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneReason"))
                view.T_PL_VerificationRecord.PhoneReason = dataReader.GetValueOrDefault<string>("PhoneReason");
            if (DataReaderRowFilter.RowFilter(dataReader, "PhoneResult"))
                view.T_PL_VerificationRecord.PhoneResult = dataReader.GetValueOrDefault<string>("PhoneResult");
            //电话核实信息
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.T_PL_PhoneVerification.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.T_PL_PhoneVerification.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ContactName"))
                view.T_PL_PhoneVerification.ContactName = dataReader.GetValueOrDefault<string>("ContactName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ContactNumber"))
                view.T_PL_PhoneVerification.ContactNumber = dataReader.GetValueOrDefault<string>("ContactNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Gender"))
                view.T_PL_PhoneVerification.Gender = dataReader.GetValueOrDefault<string>("Gender");
            if (DataReaderRowFilter.RowFilter(dataReader, "Position"))
                view.T_PL_PhoneVerification.Position = dataReader.GetValueOrDefault<string>("Position");
            if (DataReaderRowFilter.RowFilter(dataReader, "Relation"))
                view.T_PL_PhoneVerification.Relation = dataReader.GetValueOrDefault<string>("Relation_P");
            if (DataReaderRowFilter.RowFilter(dataReader, "Remarks"))
                view.T_PL_PhoneVerification.Remarks = dataReader.GetValueOrDefault<string>("Remarks");

            return view;
        }   
    }
}
