﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_Sys_UsersSimpleMapper<T> : IRowMapper<T> where T : T_Sys_UsersSimple, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            
            if (DataReaderRowFilter.RowFilter(dataReader, "SoeID"))
                view.SoeId = dataReader.GetValueOrDefault<String>("SoeID");           
            if (DataReaderRowFilter.RowFilter(dataReader, "BranchCode"))
                view.BranchCode = dataReader.GetValueOrDefault<String>("BranchCode");           

            return view;
        }
    }
}
