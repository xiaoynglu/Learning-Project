﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    class CancelAppViewMapper<T> : IRowMapper<T> where T : CancelAppView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppNo"))
                view.AppNo = dataReader.GetValueOrDefault<String>("AppNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerID"))
                view.CustomerID = dataReader.GetValueOrDefault<String>("CustomerID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerName"))
                view.CustomerName = dataReader.GetValueOrDefault<String>("CustomerName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProductName"))
                view.ProductName = dataReader.GetValueOrDefault<String>("ProductName");
            if (DataReaderRowFilter.RowFilter(dataReader, "sales"))
                view.sales = dataReader.GetValueOrDefault<String>("sales");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProductName"))
                view.ProductName = dataReader.GetValueOrDefault<String>("ProductName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DateOfApplication"))
                view.DateOfApplication = dataReader.GetValueOrDefault<String>("DateOfApplication");
            if (DataReaderRowFilter.RowFilter(dataReader, "DateOfCancel"))
                view.DateOfCancel = dataReader.GetValueOrDefault<String>("DateOfCancel");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentStage"))
                view.CurrentStage = dataReader.GetValueOrDefault<String>("CurrentStage");
            if (DataReaderRowFilter.RowFilter(dataReader, "status"))
                view.status = dataReader.GetValueOrDefault<String>("status");
            
            return view;
        }
    }
}
