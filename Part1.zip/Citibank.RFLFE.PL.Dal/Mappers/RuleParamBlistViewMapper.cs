﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class RuleParamBlistViewMapper<T> : IRowMapper<T> where T : RuleParamBlistView, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<String>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<String>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<String>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Factor"))
                view.Factor = dataReader.GetValueOrDefault<String>("Factor");
            if (DataReaderRowFilter.RowFilter(dataReader, "FactorName"))
                view.FactorName = dataReader.GetValueOrDefault<String>("FactorName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Value"))
                view.Value = dataReader.GetValueOrDefault<String>("Value");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsValid"))
                view.IsValid = dataReader.GetValueOrDefault<String>("IsValid");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<String>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<String>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "Rownumber"))
                view.Rownumber = dataReader.GetValueOrDefault<string>("Rownumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
            {
                if (dataReader.GetValueOrDefault<String>("Status") == "1")
                {
                    view.StatusName = "待审批";
                }
                if (dataReader.GetValueOrDefault<String>("Status") == "2")
                {
                    view.StatusName = "已审批";
                }
                if (dataReader.GetValueOrDefault<String>("Status") == "3")
                {
                    view.StatusName = "已拒绝";
                }
            }             

            return view;
        }
    }
}
