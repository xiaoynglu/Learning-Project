﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
   public  class T_PL_NewsMapper<T> : IRowMapper<T> where T : T_PL_News, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "title"))
                view.title = dataReader.GetValueOrDefault<string>("title");
            if (DataReaderRowFilter.RowFilter(dataReader, "newscontent"))
                view.newscontent = dataReader.GetValueOrDefault<string>("newscontent");
            if (DataReaderRowFilter.RowFilter(dataReader, "istop"))
                view.istop = dataReader.GetValueOrDefault<string>("istop") == "1" ? true : false;
            if (DataReaderRowFilter.RowFilter(dataReader, "maker"))
                view.maker = dataReader.GetValueOrDefault<string>("maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "maketime"))
                view.maketime = dataReader.GetValueOrDefault<DateTime>("maketime");
          
            return view;
        }
    }
}
