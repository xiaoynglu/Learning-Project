﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_EvaluationCompanyMapper<T> : IRowMapper<T> where T : T_PL_EvaluationCompany, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyName"))
                view.CompanyName = dataReader.GetValueOrDefault<string>("CompanyName");
            if (DataReaderRowFilter.RowFilter(dataReader, "CompanyType"))
                view.CompanyType = dataReader.GetValueOrDefault<string>("CompanyType");
            if (DataReaderRowFilter.RowFilter(dataReader, "HasSocialSecurity"))
                view.ContactName = dataReader.GetValueOrDefault<string>("ContactName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgCode"))
                view.OrgCode = dataReader.GetValueOrDefault<string>("OrgCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Phone"))
                view.Phone = dataReader.GetValueOrDefault<string>("Phone");

            return view;
        }
    }
}
