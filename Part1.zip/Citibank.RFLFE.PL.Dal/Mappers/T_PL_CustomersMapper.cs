﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_CustomersMapper<T> : IRowMapper<T> where T : T_PL_Customers, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "ApplicationNo"))
                view.AppNo = dataReader.GetValueOrDefault<String>("ApplicationNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "BorrowType"))
                view.BorrowType = dataReader.GetValueOrDefault<String>("BorrowType");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID").ToString();
            if (DataReaderRowFilter.RowFilter(dataReader, "DOB"))
                view.DOB = dataReader.GetValueOrDefault<DateTime>("DOB");
            if (DataReaderRowFilter.RowFilter(dataReader, "Education"))
                view.Education = dataReader.GetValueOrDefault<String>("Education");
            if (DataReaderRowFilter.RowFilter(dataReader, "EmploymentType"))
                view.EmploymentType = dataReader.GetValueOrDefault<String>("EmploymentType");
            if (DataReaderRowFilter.RowFilter(dataReader, "FirstName"))
                view.FirstName = dataReader.GetValueOrDefault<String>("FirstName");
            if (DataReaderRowFilter.RowFilter(dataReader, "FullName"))
                view.FullName = dataReader.GetValueOrDefault<String>("FullName");
            if (DataReaderRowFilter.RowFilter(dataReader, "FormerName"))//曾用名
                view.FormerName = dataReader.GetValueOrDefault<String>("FormerName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Gender"))
                view.Gender = dataReader.GetValueOrDefault<String>("Gender");
            if (DataReaderRowFilter.RowFilter(dataReader, "HasChildren"))
                view.HasChildren = dataReader.GetValueOrDefault<String>("HasChildren")=="True"?"1":"0";
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<String>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "Industry"))
                view.Industry = dataReader.GetValueOrDefault<String>("Industry");
            if (DataReaderRowFilter.RowFilter(dataReader, "LastName"))
                view.LastName = dataReader.GetValueOrDefault<String>("LastName");
            if (DataReaderRowFilter.RowFilter(dataReader, "LivedYear"))
                view.LivedYear = dataReader.GetValueOrDefault<Int32>("LivedYear");
            if (DataReaderRowFilter.RowFilter(dataReader, "MarriageStatus"))
                view.MarriageStatus = dataReader.GetValueOrDefault<String>("MarriageStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "Occupation"))
                view.Occupation = dataReader.GetValueOrDefault<String>("Occupation");
            if (DataReaderRowFilter.RowFilter(dataReader, "PinyinName"))
                view.PinyinName = dataReader.GetValueOrDefault<String>("PinyinName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Relation"))
                view.Relation = dataReader.GetValueOrDefault<String>("Relation");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelationShip"))
                view.RelationShip = dataReader.GetValueOrDefault<String>("RelationShip");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReportType"))
                view.ReportType = dataReader.GetValueOrDefault<String>("ReportType");
            if (DataReaderRowFilter.RowFilter(dataReader, "SharedFinancial"))
                view.SharedFinancial = dataReader.GetValueOrDefault<String>("SharedFinancial") == "True" ? "1" : "0";
            if (DataReaderRowFilter.RowFilter(dataReader, "SpouseIDNo"))
                view.SpouseIDNo = dataReader.GetValueOrDefault<String>("SpouseIDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "SpouseName"))
                view.SpouseName = dataReader.GetValueOrDefault<String>("SpouseName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgApplicationNo"))
                view.OrgApplicationNo = dataReader.GetValueOrDefault<string>("OrgApplicationNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgLoanNumber"))
                view.OrgLoanNumber = dataReader.GetValueOrDefault<string>("OrgLoanNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrgSegment"))
                view.OrgCustType = dataReader.GetValueOrDefault<string>("OrgSegment");
            if (DataReaderRowFilter.RowFilter(dataReader, "TopUpSegment"))
                view.TopUpCustType = dataReader.GetValueOrDefault<string>("TopUpSegment");
            if (DataReaderRowFilter.RowFilter(dataReader, "HasProperty"))
                view.PropertiesSituation = dataReader.GetValueOrDefault<string>("HasProperty");
            if (DataReaderRowFilter.RowFilter(dataReader, "CollateralType"))
                view.CollateralType = dataReader.GetValueOrDefault<string>("CollateralType");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyType"))
                view.PropertyType = dataReader.GetValueOrDefault<string>("PropertyType");

            //Customer Contact 
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseStatus"))
                view.HouseStatus = dataReader.GetValueOrDefault<string>("HouseStatus");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseProvince"))
                view.HouseProvince = dataReader.GetValueOrDefault<string>("HouseProvince");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseCity"))
                view.HouseCity = dataReader.GetValueOrDefault<string>("HouseCity");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseDistrict"))
                view.HouseDistrict = dataReader.GetValueOrDefault<string>("HouseDistrict");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseStreet"))
                view.HouseStreet = dataReader.GetValueOrDefault<string>("HouseStreet");
            if (DataReaderRowFilter.RowFilter(dataReader, "HousePostCode"))
                view.HousePostCode = dataReader.GetValueOrDefault<string>("HousePostCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "CommunicationAddressAs"))
                view.CommunicationAddressAs = dataReader.GetValueOrDefault<string>("CommunicationAddressAs");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseTelAreaCode"))
                view.HouseTelAreaCode = dataReader.GetValueOrDefault<string>("HouseTelAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseTelNumber"))
                view.HouseTelNumber = dataReader.GetValueOrDefault<string>("HouseTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "ResidenceTelAreaCode"))
                view.ResidenceTelAreaCode = dataReader.GetValueOrDefault<string>("ResidenceTelAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "ResidenceTelNumber"))
                view.ResidenceTelNumber = dataReader.GetValueOrDefault<string>("ResidenceTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingTelAreaCode"))
                view.WorkingTelAreaCode = dataReader.GetValueOrDefault<string>("WorkingTelAreaCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingTelNumber"))
                view.WorkingTelNumber = dataReader.GetValueOrDefault<string>("WorkingTelNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "WorkingTelExtNumber"))
                view.WorkingTelExtNumber = dataReader.GetValueOrDefault<string>("WorkingTelExtNumber");
            

            if (DataReaderRowFilter.RowFilter(dataReader, "CustNO"))
                view.CustNO = dataReader.GetValueOrDefault<string>("CustNO");

            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdId = dataReader.GetValueOrDefault<String>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<String>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsTown"))
                view.IsTown = dataReader.GetValueOrDefault<Boolean>("IsTown");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsSamePlace"))
                view.IsSamePlace = dataReader.GetValueOrDefault<Boolean>("IsSamePlace");
            if (DataReaderRowFilter.RowFilter(dataReader, "PropertyType"))
                view.PropertyType = dataReader.GetValueOrDefault<string>("PropertyType");
            if (DataReaderRowFilter.RowFilter(dataReader, "IsEmployeeLoan"))
                view.IsEmployeeLoan = dataReader.GetValueOrDefault<Boolean>("IsEmployeeLoan");

            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseLevel"))
                view.T_PL_SalaryCust.EnterpriseLevel = dataReader.GetValueOrDefault<string>("EnterpriseLevel");
            if (DataReaderRowFilter.RowFilter(dataReader, "Department"))
                view.T_PL_SalaryCust.Department = dataReader.GetValueOrDefault<String>("Department");
            if (DataReaderRowFilter.RowFilter(dataReader, "Position"))
                view.T_PL_SalaryCust.Position = dataReader.GetValueOrDefault<String>("Position");
            if (DataReaderRowFilter.RowFilter(dataReader, "Job"))
                view.T_PL_SalaryCust.Job = dataReader.GetValueOrDefault<String>("Job");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseName"))
                view.T_PL_SalaryCust.EnterpriseName = dataReader.GetValueOrDefault<String>("EnterpriseName");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseProperty"))
                view.T_PL_SalaryCust.EnterpriseProperty = dataReader.GetValueOrDefault<String>("EnterpriseProperty");
            if (DataReaderRowFilter.RowFilter(dataReader, "EnterpriseScale"))
                view.T_PL_SalaryCust.EnterpriseScale = dataReader.GetValueOrDefault<String>("EnterpriseScale");
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentWorkingLife"))
                view.T_PL_SalaryCust.CurrentWorkingLife = dataReader.GetValueOrDefault<Int32>("CurrentWorkingLife");
            if (DataReaderRowFilter.RowFilter(dataReader, "PreWorkingLife"))
                view.T_PL_SalaryCust.PreWorkingLife = dataReader.GetValueOrDefault<Int32>("PreWorkingLife");
            if (DataReaderRowFilter.RowFilter(dataReader, "TotalWorkingLife"))
                view.T_PL_SalaryCust.TotalWorkingLife = dataReader.GetValueOrDefault<Int32>("TotalWorkingLife");
            if (DataReaderRowFilter.RowFilter(dataReader, "Segment"))
                view.T_PL_SalaryCust.Segment = dataReader.GetValueOrDefault<String>("Segment");

            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentIndustryTime"))
                view.T_PL_SelfEmployedCust.CurrentIndustryTime = dataReader.GetValueOrDefault<Int32>("CurrentIndustryTime");
            if (DataReaderRowFilter.RowFilter(dataReader, "ShopName"))
                view.T_PL_SelfEmployedCust.ShopName = dataReader.GetValueOrDefault<String>("ShopName");
            if (DataReaderRowFilter.RowFilter(dataReader, "RegistrationNumber"))
                view.T_PL_SelfEmployedCust.RegistrationNumber = dataReader.GetValueOrDefault<String>("RegistrationNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "OperatorName"))
                view.T_PL_SelfEmployedCust.OperatorName = dataReader.GetValueOrDefault<String>("OperatorName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OperationPlace"))
                view.T_PL_SelfEmployedCust.OperationPlace = dataReader.GetValueOrDefault<String>("OperationPlace");
            if (DataReaderRowFilter.RowFilter(dataReader, "EmployeeNumber"))
                view.T_PL_SelfEmployedCust.EmployeeNumber = dataReader.GetValueOrDefault<Int32>("EmployeeNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "Contact"))
                view.T_PL_SelfEmployedCust.Contact = dataReader.GetValueOrDefault<String>("Contact");
            if (DataReaderRowFilter.RowFilter(dataReader, "ContactPosition"))
                view.T_PL_SelfEmployedCust.ContactPosition = dataReader.GetValueOrDefault<String>("ContactPosition");
            if (DataReaderRowFilter.RowFilter(dataReader, "PaidInsurance"))
                view.T_PL_SelfEmployedCust.PaidInsurance = dataReader.GetValueOrDefault<String>("PaidInsurance");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "OwnedEstate"))
                view.T_PL_SelfEmployedCust.OwnedEstate = dataReader.GetValueOrDefault<String>("OwnedEstate");
            if (DataReaderRowFilter.RowFilter(dataReader, "Segment"))
                view.T_PL_SelfEmployedCust.Segment = dataReader.GetValueOrDefault<String>("Segment");
            if (DataReaderRowFilter.RowFilter(dataReader, "MorgageAmount"))
                view.MorgageAmount = dataReader.GetValueOrDefault<int>("MorgageAmount");

            //customer contact
            if (DataReaderRowFilter.RowFilter(dataReader, "MobileNumber"))
                view.MobileNumber = dataReader.GetValueOrDefault<String>("MobileNumber");
            if (DataReaderRowFilter.RowFilter(dataReader, "HouseTelNumber"))
                view.HouseTelNumber = dataReader.GetValueOrDefault<String>("HouseTelNumber");
            
            //loan info
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestLoanSize"))
                view.RequestLoanSize = dataReader.GetValueOrDefault<Decimal>("RequestLoanSize");
            if (DataReaderRowFilter.RowFilter(dataReader, "RequestTenor"))
                view.RequestTenor = dataReader.GetValueOrDefault<String>("RequestTenor");
            if (DataReaderRowFilter.RowFilter(dataReader, "InterestRate")) {
                if (dataReader.GetValueOrDefault<String>("InterestRate") != "" && dataReader.GetValueOrDefault<String>("InterestRate") != null) {
                    view.InterestRate = Math.Round(Decimal.Parse(dataReader.GetValueOrDefault<String>("InterestRate")), 2).ToString(); 
                }
            }
            if (DataReaderRowFilter.RowFilter(dataReader, "MorgageCount"))
                view.MortgageCount = dataReader.GetValueOrDefault<String>("MorgageCount");

            return view;
        }
    }
}
