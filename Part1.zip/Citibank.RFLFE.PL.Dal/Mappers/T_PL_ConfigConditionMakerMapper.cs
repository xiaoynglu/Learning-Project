﻿using System;
using System.Data;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Collections.Generic;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_ConfigConditionMakerMapper<T> : IRowMapper<T> where T : T_PL_ConfigConditionMaker, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            if (DataReaderRowFilter.RowFilter(dataReader, "BorrowerType"))
                view.BorrowerType = dataReader.GetValueOrDefault<string>("BorrowerType");
            if (DataReaderRowFilter.RowFilter(dataReader, "FileName"))
                view.FileName = dataReader.GetValueOrDefault<string>("FileName");
            if (DataReaderRowFilter.RowFilter(dataReader, "AttachName"))
                view.AttachName = dataReader.GetValueOrDefault<string>("AttachName");
            if (DataReaderRowFilter.RowFilter(dataReader, "DisplayName"))
                view.DisplayName = dataReader.GetValueOrDefault<string>("DisplayName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OP"))
                view.OP = dataReader.GetValueOrDefault<string>("OP");
            if (DataReaderRowFilter.RowFilter(dataReader, "Value"))
                view.Value = dataReader.GetValueOrDefault<string>("Value");
            if (DataReaderRowFilter.RowFilter(dataReader, "GroupName"))
                view.GroupName = dataReader.GetValueOrDefault<string>("GroupName");
            if (DataReaderRowFilter.RowFilter(dataReader, "OpTypeName"))
                view.OpTypeName = dataReader.GetValueOrDefault<string>("OpTypeName");
            if (DataReaderRowFilter.RowFilter(dataReader, "StatusName"))
                view.StatusName = dataReader.GetValueOrDefault<string>("StatusName");
            if (DataReaderRowFilter.RowFilter(dataReader, "Maker"))
                view.Maker = dataReader.GetValueOrDefault<string>("Maker");
            if (DataReaderRowFilter.RowFilter(dataReader, "Checker"))
                view.Checker = dataReader.GetValueOrDefault<string>("Checker");
            //carrying other properties
            if (DataReaderRowFilter.RowFilter(dataReader, "ConditionID"))
                view.ConditionID = dataReader.GetValueOrDefault<int>("ConditionID");
            if (DataReaderRowFilter.RowFilter(dataReader, "TemplateID"))
                view.TemplateID = dataReader.GetValueOrDefault<int>("TemplateID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ParentID"))
                view.ParentID = dataReader.GetValueOrDefault<int>("ParentID");
            if (DataReaderRowFilter.RowFilter(dataReader, "TID"))
                view.TID = dataReader.GetValueOrDefault<int>("TID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ProdID"))
                view.ProdID = dataReader.GetValueOrDefault<int>("ProdID");
            if (DataReaderRowFilter.RowFilter(dataReader, "FileType"))
                view.FileType = dataReader.GetValueOrDefault<int>("FileType");
            if (DataReaderRowFilter.RowFilter(dataReader, "OrderBy"))
                view.OrderBy = dataReader.GetValueOrDefault<string>("OrderBy");
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<int>("Status");
            if (DataReaderRowFilter.RowFilter(dataReader, "ConfigID"))
                view.ConfigID = dataReader.GetValueOrDefault<Guid>("ConfigID");
            //if (DataReaderRowFilter.RowFilter(dataReader, "MakeDate"))
            //    view.MakeDate = dataReader.GetValueOrDefault<DateTime>("MakeDate");
            //if (DataReaderRowFilter.RowFilter(dataReader, "CheckDate"))
            //    view.CheckDate = dataReader.GetValueOrDefault<DateTime>("CheckDate");
            if (DataReaderRowFilter.RowFilter(dataReader, "OpType"))
                view.OpType = dataReader.GetValueOrDefault<int>("OpType");
            if (DataReaderRowFilter.RowFilter(dataReader, "TabID"))
                view.TabID = dataReader.GetValueOrDefault<String>("TabID");
            if (DataReaderRowFilter.RowFilter(dataReader, "TableName"))
                view.TableName = dataReader.GetValueOrDefault<string>("TableName");
            if (DataReaderRowFilter.RowFilter(dataReader, "ColumnName"))
                view.ColumnName = dataReader.GetValueOrDefault<string>("ColumnName");
            return view;
        }
    }
}
