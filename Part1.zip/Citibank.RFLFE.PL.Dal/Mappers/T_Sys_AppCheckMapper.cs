﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_Sys_AppCheckMapper<T> : IRowMapper<T> where T : T_PL_Application, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "App_ID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("App_ID").ToString();

            if (DataReaderRowFilter.RowFilter(dataReader, "AppNo"))
                view.ApplicationNo = dataReader.GetValueOrDefault<string>("AppNo");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerID"))
                view.IDNo = dataReader.GetValueOrDefault<string>("CustomerID");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "CustomerName"))
                view.CustomerName = dataReader.GetValueOrDefault<string>("CustomerName");

            if (DataReaderRowFilter.RowFilter(dataReader, "ProdName"))
                view.ProdName = dataReader.GetValueOrDefault<string>("ProdName");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "DateOfApplication"))
                view.CreateDate = dataReader.GetValueOrDefault<DateTime>("DateOfApplication");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentStage"))
                view.CurrentStage = dataReader.GetValueOrDefault<string>("CurrentStage");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "Status"))
                view.Status = dataReader.GetValueOrDefault<string>("Status");
            
            if (DataReaderRowFilter.RowFilter(dataReader, "CurrentProcessor"))
                view.CurrentProcessor = dataReader.GetValueOrDefault<string>("CurrentProcessor");
            if (DataReaderRowFilter.RowFilter(dataReader, "isLocked"))
                view.IsLocked = dataReader.GetValueOrDefault<string>("isLocked")=="Y"?true:false;

            return view;
        }
    }
}
