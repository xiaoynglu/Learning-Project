﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    public class T_PL_FamilyMembersMapper<T> : IRowMapper<T> where T : T_PL_FamilyMembers, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "MemberID"))
                view.MemberID = dataReader.GetValueOrDefault<Guid>("MemberID");
            if (DataReaderRowFilter.RowFilter(dataReader, "AppID"))
                view.AppID = dataReader.GetValueOrDefault<Guid>("AppID");
            if (DataReaderRowFilter.RowFilter(dataReader, "CustID"))
                view.CustID = dataReader.GetValueOrDefault<Guid>("CustID");
            if (DataReaderRowFilter.RowFilter(dataReader, "Gender"))
                view.Gender = dataReader.GetValueOrDefault<string>("Gender");
            if (DataReaderRowFilter.RowFilter(dataReader, "Name"))
                view.Name = dataReader.GetValueOrDefault<string>("Name");
            if (DataReaderRowFilter.RowFilter(dataReader, "PinyinName"))
                view.PinyinName = dataReader.GetValueOrDefault<string>("PinyinName");
            if (DataReaderRowFilter.RowFilter(dataReader, "IDNo"))
                view.IDNo = dataReader.GetValueOrDefault<string>("IDNo");
            if (DataReaderRowFilter.RowFilter(dataReader, "Relation"))
                view.Relation = dataReader.GetValueOrDefault<string>("Relation");
            if (DataReaderRowFilter.RowFilter(dataReader, "RelationShip"))
                view.RelationShip = dataReader.GetValueOrDefault<string>("RelationShip");
            if (DataReaderRowFilter.RowFilter(dataReader, "QueriedBureau"))
                view.QueriedBureau = dataReader.GetValueOrDefault<string>("QueriedBureau");

            return view;
        }
    }
}
