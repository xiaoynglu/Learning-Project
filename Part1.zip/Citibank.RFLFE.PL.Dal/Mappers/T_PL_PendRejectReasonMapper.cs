﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.Mappers
{
    class T_PL_PendRejectReasonMapper<T> : IRowMapper<T> where T : T_PL_PendRejectReason, new()
    {
        T IRowMapper<T>.MapRow(IDataReader dataReader, int rowNum)
        {
            T view = new T();
            if (DataReaderRowFilter.RowFilter(dataReader, "ID"))
                view.ID = dataReader.GetValueOrDefault<int>("ID");
            if (DataReaderRowFilter.RowFilter(dataReader, "ReasonCode"))
                view.ReasonCode = dataReader.GetValueOrDefault<String>("ReasonCode");
            if (DataReaderRowFilter.RowFilter(dataReader, "Description"))
                view.Description = dataReader.GetValueOrDefault<String>("Description");
            if (DataReaderRowFilter.RowFilter(dataReader, "ParentReasonCode"))
                view.ParentReasonCode = dataReader.GetValueOrDefault<String>("ParentReasonCode");
           
            return view;
        }
    }
}
