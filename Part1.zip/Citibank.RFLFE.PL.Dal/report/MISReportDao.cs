﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;
using System.Data;

namespace Citibank.RFLFE.PL.Dal.report
{
    public class MISReportDao : AdoDaoSupport, IMISReportDao
    {
        public CommonTResult<T_Sys_Branch> GetBranchByOrg(T_Sys_Branch brs)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", brs.OrgCode);
            parameters.AddWithValue("BranchType", brs.BranchType);
            CommonTResult<T_Sys_Branch> result = new CommonTResult<T_Sys_Branch>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_Branch>(CommandType.StoredProcedure, SPNames.PL_GetBranchByOrg, new T_Sys_BranchMapper<T_Sys_Branch>(), parameters);
            result.IsSuccess = true;
            return result;
        }

        public Boolean UploadHoliday(DataTable dt, string uploadType, T_Sys_Users loginUser)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            string WorkDate = "";
            foreach (DataRow dr in dt.Rows)
            {
                if (!string.IsNullOrEmpty(dr[0].ToString()))
                {
                    WorkDate += Convert.ToDateTime(dr[0].ToString()).ToString("yyyy/MM/dd") + ",";
                }
            }
            parameters.AddWithValue("UploadDate", WorkDate.Substring(0, WorkDate.Length - 1));
            parameters.AddWithValue("UploadType", uploadType);
            parameters.AddWithValue("Maker", loginUser.SoeID);

            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UploadHoliday, parameters);
            return true;
        }

        public Boolean DeleteHoliday()
        {
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteHoliday);
            return true;
        }

        public DataSet ExportTimeQueryByStages(string Stages, string BeginDate, string EndDate, string ProdIDs, string UserID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Stages", Stages);
            parameters.AddWithValue("BeginDate", Convert.ToDateTime(BeginDate).ToString("yyyy/MM/dd"));
            parameters.AddWithValue("EndDate", Convert.ToDateTime(EndDate).ToString("yyyy/MM/dd"));
            parameters.AddWithValue("ProdIDs", ProdIDs);
            parameters.AddWithValue("UserID", UserID);
            CommonTResult<T_PL_TempDefination> TResult = new CommonTResult<T_PL_TempDefination>();
            DataSet dsResult = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_ExportTimeQueryByStages, parameters);

            return dsResult;
        }

        public DataTable ExportProcessHistoryReport(string Stages, string StartDate, string EndDate)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Stages", Stages);
            parameters.AddWithValue("StartDate", StartDate);
            parameters.AddWithValue("EndDate", EndDate);
            return AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_MISReport_ExportProcessHistoryReport, parameters);
        }

        public CommonTResult<T_PL_TempDefination> GetMISReportTempDefination(int role, int gird, string userID, string repName)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Role", role);
            parameters.AddWithValue("GirdNo", gird);
            parameters.AddWithValue("UserID", userID);
            parameters.AddWithValue("RepName", repName);
            CommonTResult<T_PL_TempDefination> TResult = new CommonTResult<T_PL_TempDefination>();
            TResult.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_TempDefination>(CommandType.StoredProcedure, SPNames.PL_GetMISReportTempDefination, new BaseMapper<T_PL_TempDefination>(), parameters);
            TResult.IsSuccess = true;
            return TResult;
        }

        public CommonTResult<T_PL_MISReportTemplate> GetTemplateByUserId(string userID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("UserID", userID);
            CommonTResult<T_PL_MISReportTemplate> TResult = new CommonTResult<T_PL_MISReportTemplate>();
            TResult.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_MISReportTemplate>(CommandType.StoredProcedure, SPNames.PL_GetMISReportTempDefination, new BaseMapper<T_PL_MISReportTemplate>(), parameters);
            TResult.IsSuccess = true;
            return TResult;
        }

        public bool SaveTemplateSetting(string templateName, string ColumnIds, string userID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TemplateName", templateName);
            parameters.AddWithValue("Columns", ColumnIds);
            parameters.AddWithValue("UserID", userID);
            int Count = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveTemplateSetting, parameters);
            return Count > 0 ? true : false;
        }

        public bool DeleteTemplateSetting(string templateName, string userID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RepName", templateName);
            parameters.AddWithValue("UserID", userID);

            int Count = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteTemplateSetting, parameters);
            return Count > 0 ? true : false;
        }

        public CommonTResult<T_PL_MISReport_TempColumns> GetMSIReportByCondition(string OrgCode, string RepNo, string SoeId, string ProdID, string BeginDate, string EndDate, string TimeFlag, int RepFlag, int Start, int Limit)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", OrgCode);
            parameters.AddWithValue("RepNo", RepNo);
            parameters.AddWithValue("SoeId", SoeId);
            parameters.AddWithValue("ProdID", ProdID);
            parameters.AddWithValue("StartDate", BeginDate);
            parameters.AddWithValue("EndDate", EndDate);
            parameters.AddWithValue("TimeFlag", TimeFlag);
            parameters.AddWithValue("RepFlag", TimeFlag);
            parameters.AddWithValue("Start", Start);
            parameters.AddWithValue("Limit", Limit);            

            CommonTResult<T_PL_MISReport_TempColumns> TResult = new CommonTResult<T_PL_MISReport_TempColumns>();

            TResult.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_MISReport_TempColumns>(CommandType.StoredProcedure, SPNames.PL_GetMISReport, new T_PL_MISReport_DefinationMapper<T_PL_MISReport_TempColumns>(), parameters);
            TResult.IsSuccess = true;
            return TResult;
        }

        public DataTable ExportMSIReportByCondition(string OrgCode, string RepNo, string SoeId, string ProdID, string BeginDate, string EndDate, string TimeFlag, int RepFlag)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", OrgCode);
            parameters.AddWithValue("RepNo", RepNo);
            parameters.AddWithValue("SoeId", SoeId);
            parameters.AddWithValue("ProdID", ProdID);
            parameters.AddWithValue("StartDate", BeginDate);
            parameters.AddWithValue("EndDate", EndDate);
            parameters.AddWithValue("TimeFlag", TimeFlag);
            parameters.AddWithValue("RepFlag", RepFlag);

            DataTable dsResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_ExportMISReport, parameters);

            return dsResult;
        }
    }
}
