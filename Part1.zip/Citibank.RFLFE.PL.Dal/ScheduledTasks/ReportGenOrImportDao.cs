﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IDal;
using Spring.Data.Common;
using System.Data;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.Dal.Mappers;
using System.IO;
using System.Configuration;
using CitiAES;
using FileHelpers;
using System.Threading;
using log4net;

namespace Citibank.RFLFE.PL.Dal.scheduledTasks
{
    public class ReportGenOrImportDao : AdoDaoSupport, IReportGenOrImportDao
    {
        private static readonly ILog log = LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        public string GetRunJobType()
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddOut("JobName", DbType.String, 200);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_GetRunJobType, parameters);
            return (string)parameters["@JobName"].Value;
        }

        public CommonTResult<T_PL_FileDefination> GetFileDefinationByJobType(string JobType)
        {
            CommonTResult<T_PL_FileDefination> fileDef = new CommonTResult<T_PL_FileDefination>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("JobName", JobType.ToString());
            parameters.AddOut("Count", DbType.Int32);
            fileDef.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_FileDefination>(CommandType.StoredProcedure, SPNames.PL_GetFileDefinationByJobType, new BaseMapper<T_PL_FileDefination>(), parameters);
            fileDef.ResultCount = (int)parameters["@Count"].Value;
            
            return fileDef;
        }

        public CommonTResult<T> GetReportBodyForDB<T>(string FileType)
        {
            CommonTResult<T> fileDef = new CommonTResult<T>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("FileType", FileType);
            parameters.AddOut("Count", DbType.Int32);
            parameters.AddWithValue("DateBegin", "");
            parameters.AddWithValue("DateEnd", "");
            fileDef.ResultList = AdoTemplate.QueryWithRowMapper<T>(CommandType.StoredProcedure, SPNames.PL_GetReportInfoByFileType, new BaseMapper<T>(), parameters);
            fileDef.ResultCount = fileDef.ResultList.Count;

            return fileDef;
        }

        public CommonTResult<T_Sys_PathConfiguration> GetPathConfigByName(string PathName)
        {
            CommonTResult<T_Sys_PathConfiguration> configDetail = new CommonTResult<T_Sys_PathConfiguration>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("PathName", PathName);
            parameters.AddOut("Count", DbType.Int32);
            configDetail.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_PathConfiguration>(CommandType.StoredProcedure, SPNames.PL_GetPathConfigByName, new BaseMapper<T_Sys_PathConfiguration>(), parameters);
            configDetail.ResultCount = (int)parameters["@Count"].Value;

            return configDetail;
        }

        public bool CheckIsImportToday(string JobName)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("JobName", JobName);
            parameters.AddOut("Count", DbType.Int32);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_CheckIsImpTodayByJobName, parameters);
            return (int)parameters["@Count"].Value > 0 ? false : true;
        }       

        public static DataTable CreateTable(IList<T_PL_FileDefination> fileDefine)
        {
            DataTable table = new DataTable();
            foreach (var items in fileDefine)
            {
                string colName = Convert.ToString(items.ColumnName);
                string dbType = Convert.ToString(items.DataType);
                table.Columns.Add(colName, System.Type.GetType(dbType));
            }
            return table;
        }

        public DataTable ReadSourceToDt(IList<T_PL_FileDefination> fileDefine, string SourceFile)
        {
            DataTable dt = CreateTable(fileDefine);
            //开始解析source文件
            using (StreamReader sr = new StreamReader(SourceFile, Encoding.GetEncoding("GB2312")))
            {
                string line = string.Empty;
                int lineCount = 1;
                while (sr.Peek() >= 0)
                {
                    line = sr.ReadLine();
                    if (line.Trim() != "" && line.Length != 0)
                    {
                        DataRow dr = dt.NewRow();
                        foreach (var items in fileDefine)
                        {
                            string colName = Convert.ToString(items.ColumnName);
                            int StartPosition = Convert.ToInt32(items.StartPosition) - 1;
                            int Len = Convert.ToInt32(items.Length);
                            dr[colName] =  Convert.ToString(line.Substring(StartPosition, Len).Trim());
                        }
                        dt.Rows.Add(dr);
                        lineCount++;
                    }
                }
            }
            return dt;
        }

        public IList<T> ReadSourceToDt<T>(FileInfo Files)
        {
            FileHelperEngine<T> engine = new FileHelperEngine<T>();
            engine.Encoding = Encoding.Default;
            string strMessage = string.Empty;

            IList<T> alsRecords = engine.ReadFile(Files.FullName).ToList();

            return alsRecords;
        }

        //将txt文件对应数据读入datatable中；每个table最大存放500000条数据
        //Import GRB需要比对当前需要导入的文件的最后修改日期，如果与之前的文件修改日期相同，则认为该文件已经导入过，不再导入
        public CommonResult ReadSourceToGRB(IList<T_PL_FileDefination> fileDefine, string SourceFile)
        {
            CommonResult result = new CommonResult();
            DataTable dt = CreateTable(fileDefine);
            List<DataTable> list = new List<DataTable>();
            list.Clear();
            //先删除之前导入的数据
            try
            {
                bool deleteOldData = TruncateOldDataToImport("T_PL_RMInfo");
                if (deleteOldData)
                {
                    //开始解析source文件 - 先将需导入文件拷贝到本地  
                    using (FileStream stream = new FileStream(SourceFile, FileMode.Open, FileAccess.Read))
                    {
                        BinaryReader br = new BinaryReader(stream);
                        byte[] bytes = br.ReadBytes(2002);
                        string line = string.Empty;
                        int lineCount = 1;
                        while (bytes.Length > 0)
                        {
                            //去除头HDR
                            if (lineCount == 1)
                            {
                                if (!System.Text.Encoding.GetEncoding("GB2312").GetString(bytes, 0, 2002).Contains("HDR"))
                                {
                                    break;
                                }
                                lineCount++;
                                bytes = br.ReadBytes(2002);
                            }
                            else
                            {
                                if ((lineCount) % 500000 == 0)
                                {
                                    dt.TableName = "T_PL_RMInfo";
                                    BulkCopySourceToTable("RM", dt, SourceFile);
                                    dt.Clear();
                                }
                                else
                                {
                                    DataRow dr = dt.NewRow();
                                    foreach (var items in fileDefine)
                                    {
                                        string colName = Convert.ToString(items.ColumnName);
                                        int StartPosition = Convert.ToInt32(items.StartPosition) - 1;
                                        int Len = Convert.ToInt32(items.Length);
                                        if (colName == "ImportDate")
                                        {
                                            dr[colName] = DateTime.Now.ToString();
                                        }
                                        else if (Len != 0)
                                        {
                                            dr[colName] = System.Text.Encoding.GetEncoding("GB2312").GetString(bytes, StartPosition, Len);
                                        }
                                        else
                                        {
                                            dr[colName] = string.Empty;
                                        }
                                    }
                                    //去除尾TRL
                                    if (System.Text.Encoding.GetEncoding("GB2312").GetString(bytes, 0, 2002).Contains("TRL"))
                                    {
                                        break;
                                    }
                                    else
                                    {
                                        dt.Rows.Add(dr);
                                        bytes = br.ReadBytes(2002);
                                        lineCount++;
                                    }
                                }
                            }
                        }
                        dt.TableName = "T_PL_RMInfo";
                        BulkCopySourceToTable("RM", dt, SourceFile);
                    }
                    result.IsSuccess = true;
                    result.Message = "GRB import successfully!";
                }
                else
                {
                    result.IsSuccess = false;
                    result.Message = "Error - Truncate table for GRB job!";
                }
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = string.Format("Error - Bulk copy for GRB file: {0}", ex.Message);
                log.Error(string.Format("Error - Bulk copy for GRB file: {0}",ex.Message));
            }
            return result;
        }
            
        public CommonResult BulkCopySourceToTable(string JobName, DataTable dt, string file)
        {
            CommonResult result = new CommonResult();
            clsAES AES = new clsAES();
            string connPSW = AES.Decrypt(ConfigurationManager.AppSettings["LFEDB1"]) + AES.Decrypt(ConfigurationManager.AppSettings["LFEDB2"]);
            string conn = string.Format(ConfigurationManager.ConnectionStrings["LFE"].ConnectionString.ToString(), connPSW);
            
            using (SqlBulkCopy bulk = new SqlBulkCopy(conn))
            {
                try
                {
                    //批量插入数据到数据库
                    for (int i = 0; i < dt.Columns.Count; i++)
                    {
                        bulk.ColumnMappings.Add(dt.Columns[i].ColumnName, dt.Columns[i].ColumnName);
                    }
                    bulk.BatchSize = 10000;
                    bulk.BulkCopyTimeout = 1000;
                    bulk.DestinationTableName = dt.TableName;
                    bulk.WriteToServer(dt);
                    result.IsSuccess = true;
                    result.Message = "Bulk copy successfully!";
                }
                catch (Exception ex)
                {
                    //log.Debug("catch exception on bulk copy: " + ex.Message);
                    result.IsSuccess = false;
                    result.Message = ex.Message;
                }
            }
            return result;
        }

        public bool InsertImportGenerateLog(T_PL_BatchJobLog logs)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("JobName", logs.JobName);
            parameters.AddWithValue("RunStatus", logs.RunStatus);
            parameters.AddWithValue("RunMachine", logs.RunMachine);
            parameters.AddWithValue("Remark", logs.Remark);
            parameters.AddWithValue("FileName", logs.FileName);
            parameters.AddWithValue("FileWriteDate", logs.FileWriteDate);
            parameters.AddOut("Count", DbType.Int32);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_InsertJobRunLogs, parameters);
            return (int)parameters["@Count"].Value > 0 ? true : false;
        }

        public bool CheckIsImportFileByWriteDate(string file, DateTime writeDate)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("FileName", file);
            parameters.AddWithValue("WriteDate", writeDate);
            parameters.AddOut("Count", DbType.Int32);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_CheckIsImportFileByWriteDate, parameters);
            return (int)parameters["@Count"].Value > 0 ? true : false;
        }

        public bool TruncateOldDataToImport(string TableName)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TableName", TableName);
            parameters.AddOut("Count", DbType.Int32);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_TruncateOldDataToImport, parameters);
            return (int)parameters["@Count"].Value > 0 ? true : false;
        }
    }
}
