﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.workflow
{
    public class BatchCancelDao : AdoDaoSupport, IBatchCancelDao
    {
        public CommonTResult<BatchCancelView> GetBatchCancelList(int start, int limit, BatchCancelQueryView entity, string orgcode)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("AppNo", entity.AppNo.ToString());
            parameters.AddWithValue("ProductName", entity.ProductName);
            parameters.AddWithValue("CustomerID", entity.CustomerID);
            parameters.AddWithValue("CustomerName", entity.CustomerName);
            parameters.AddWithValue("DateOfApplicationStart", entity.DateOfApplicationStart);
            parameters.AddWithValue("DateOfApplicationEnd", entity.DateOfApplicationEnd);            
            parameters.AddWithValue("CurrentStage", entity.CurrentStage);
            parameters.AddWithValue("status", entity.status);
            parameters.AddWithValue("sales", entity.sales);
            parameters.AddWithValue("orgCode", orgcode);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<BatchCancelView> result = new CommonTResult<BatchCancelView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<BatchCancelView>(CommandType.StoredProcedure, SPNames.PL_GetBatchCancelList, new BatchCancelViewMapper<BatchCancelView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public bool BatchCancel(string appid, string curtime, string soeid)
        {
            try
            {
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("AppID", appid);
                parameters.AddWithValue("CurDate", curtime);
                parameters.AddWithValue("soeid", soeid);
                AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_BatchCancel, parameters);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
