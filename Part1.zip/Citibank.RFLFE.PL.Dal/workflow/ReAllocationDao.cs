﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.workflow
{
    public class ReAllocationDao : AdoDaoSupport, IReAllocationDao
    {
        public CommonTResult<ReAllocationView> GetReAllocationList(int start, int limit, ReAllocationQueryView entity )
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("AppNo", entity.AppNo.ToString());
            parameters.AddWithValue("ProductName", entity.ProductName);
            parameters.AddWithValue("CustomerID", entity.CustomerID);
            parameters.AddWithValue("CustomerName", entity.CustomerName);
            parameters.AddWithValue("DateOfApplicationStart", entity.DateOfApplicationStart);
            parameters.AddWithValue("DateOfApplicationEnd", entity.DateOfApplicationEnd);
            parameters.AddWithValue("AppCreate", entity.AppCreate);
            parameters.AddWithValue("CurrentExec", entity.CurrentExec);
            parameters.AddWithValue("BranchCode", entity.BranchCode);
            parameters.AddWithValue("LocationType", entity.LocationType);
            parameters.AddWithValue("CurrentStage", entity.CurrentStage);
            parameters.AddWithValue("status", entity.status);
            parameters.AddWithValue("sales", entity.sales);
            parameters.AddWithValue("orgcode", entity.OrgCode);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<ReAllocationView> result = new CommonTResult<ReAllocationView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<ReAllocationView>(CommandType.StoredProcedure, SPNames.PL_GetReAllocationList, new ReAllocationViewMapper<ReAllocationView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public bool ReAllocationTemp(string appid, string reallocationtype, string newexecid, string soeid)
        {
            try
            {
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("appid", appid);
                parameters.AddWithValue("reallocationtype", reallocationtype);
                parameters.AddWithValue("newexecid", newexecid);
                parameters.AddWithValue("soeid", soeid);
                AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ReAllocationTemp, parameters);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool ReAllocationForever(string appid, string reallocationtype, string newexecid, string soeid)
        {
            try
            {
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("appid", appid);
                parameters.AddWithValue("reallocationtype", reallocationtype);
                parameters.AddWithValue("newexecid", newexecid);
                parameters.AddWithValue("soeid", soeid);
                AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ReAllocationForever, parameters);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public CommonTResult<ComboboxEntity> GetAvaliableSales(string orgcode)
        {
             IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("orgcode", orgcode);

            CommonTResult<ComboboxEntity> result = new CommonTResult<ComboboxEntity>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<ComboboxEntity>(CommandType.StoredProcedure, SPNames.PL_GetAvailableSales, new ComboxMapper<ComboboxEntity>(), parameters);            
            return result;
        
        }
    }
}
