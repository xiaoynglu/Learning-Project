﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.workflow
{
    class RetriveDao : AdoDaoSupport, IRetriveDao
    {
        
        public CommonTResult<RetriveView> GetRetriveList(int start, int limit, RetriveQueryView entity, string orgcode)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("AppNo", entity.AppNo.ToString());
            parameters.AddWithValue("ProductName", entity.ProductName);
            parameters.AddWithValue("CustomerID", entity.CustomerID);
            parameters.AddWithValue("CustomerName", entity.CustomerName);
            parameters.AddWithValue("DateOfApplicationStart", entity.DateOfApplicationStart);
            parameters.AddWithValue("DateOfApplicationEnd", entity.DateOfApplicationEnd);
            parameters.AddWithValue("DateOfCancelStart", entity.DateOfCancelStart);
            parameters.AddWithValue("DateOfCancelEnd", entity.DateOfCancelEnd);
            parameters.AddWithValue("CurrentStage", entity.CurrentStage);
            parameters.AddWithValue("status", entity.status);
            parameters.AddWithValue("sales", entity.sales);
            parameters.AddWithValue("orgcode", orgcode);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<RetriveView> result = new CommonTResult<RetriveView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<RetriveView>(CommandType.StoredProcedure, SPNames.PL_GetRetriveList, new RetriveViewMapper<RetriveView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public bool RetrieveData(string AppID,string soeid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppID);
            parameters.AddWithValue("soeid", soeid);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_WorkFlowRetrieveData, parameters);
            return true;
        }
    }
}
