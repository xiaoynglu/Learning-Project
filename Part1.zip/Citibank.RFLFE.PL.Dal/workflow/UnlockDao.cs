﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.workflow
{
    public class UnlockDao : AdoDaoSupport, IUnlockDao
    {
        public CommonTResult<UnlockView> GetUnlock(int start, int limit, UnlockQueryView entity, string orgcode)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("AppNo", entity.AppNo.ToString());
            parameters.AddWithValue("ProductName", entity.ProductName);                       
            parameters.AddWithValue("dt_from", entity.DateOfEnterStart);
            parameters.AddWithValue("dt_to", entity.DateOfEnterEnd);
            parameters.AddWithValue("StageID", entity.CurrentStage);
            parameters.AddWithValue("status", entity.status);
            parameters.AddWithValue("SalesID", entity.sales);
            parameters.AddWithValue("customerID", entity.CustomerID);
            parameters.AddWithValue("customerName", entity.CustomerName);            
            parameters.AddWithValue("orgcode", orgcode);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<UnlockView> result = new CommonTResult<UnlockView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<UnlockView>(CommandType.StoredProcedure, SPNames.PL_GetUnlock, new UnlockViewMapper<UnlockView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public bool DoUnlock(string appid, string soeid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appid);
            parameters.AddWithValue("soeid", soeid);
            int i1 = AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DoUnlock,parameters);
            if (i1 > 0)
                return true;
            else
                return false;
        }

    }
}
