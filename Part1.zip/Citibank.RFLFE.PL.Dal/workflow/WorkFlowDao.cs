﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.workflow
{
    public class WorkFlowDao : AdoDaoSupport, IWorkFlowDao
    {

        private const string D_UPL_Desc4 = "DTDF-LOAN CLEARING DISBURSE - UPL";
        private const string C_UPL_Desc4 = "Nostro---CCCL";

        private const string D_HE_Desc4 = "DTDF-LOAN CLEARING DISBURSE - CNY";
        private const string C_HE_Desc4 = "Nostro---CCCL";

        private const string D_CRE_Desc4 = "DTDF-LOAN CLEARING DISBURSE - CRE";
        private const string C_CRE_Desc4 = "Nostro---CCCL";

        private const string D_MO_Desc4 = "DTDF-LOAN CLEARING DISBURSE - MO";
        private const string C_MO_Desc4 = "Nostro---CCCL";

        private const string RCCodeSuffix = "88870013";

        /// <summary>
        /// Add instance
        /// </summary>
        /// <param name="entity"></param>
        public void AddInstance(T_WF_PL_INS entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", entity.AppID.ToString()); 
            parameters.AddWithValue("SoeId", entity.SoeID);
            parameters.AddWithValue("StageID", entity.StageID);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Remarks", entity.Remarks);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_WFAddInstance, parameters);
        }

        /// <summary>
        /// add trace
        /// </summary>
        /// <param name="entity"></param>
        public void AddTrace(T_WF_PL_INS entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", entity.AppID);
            parameters.AddWithValue("ProcID", entity.SoeID);
            parameters.AddWithValue("StepID", entity.StepID);
            parameters.AddWithValue("OPDate", DateTime.Now);
            parameters.AddWithValue("Action", entity.Action);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddWithValue("PendingReason", entity.PendingReason);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_WFAddTrace, parameters);
        }

        public CommonTResult<T_Sys_Branch> GetBranchComapny()
        {
            CommonTResult<T_Sys_Branch> result = new CommonTResult<T_Sys_Branch>();
            string sql = "select orgcode,branchname from T_Sys_Branch";
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_Branch>(CommandType.Text, sql, new SysBranchNamesMapper<T_Sys_Branch>());
            return result;
        }

        public CommonTResult<IDQueryView> GetIDQueryList(int start, int limit, string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string Status, string starttime, string endtime)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("AppNo", AppNo);
            parameters.AddWithValue("BorrowType", BorrowType);
            parameters.AddWithValue("IDNo", IDNo);
            parameters.AddWithValue("CustName", CustName);
            parameters.AddWithValue("OrgCode", orgcode);             
            parameters.AddWithValue("starttime", starttime);
            parameters.AddWithValue("endtime", endtime);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<IDQueryView> result = new CommonTResult<IDQueryView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<IDQueryView>(CommandType.StoredProcedure, SPNames.PL_GetIDQueryList, new IDQueryViewMapper<IDQueryView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<AfterLoanMaintainView> GetAfterLoanMaintainList(int start, int limit, string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string Status, string starttime, string endtime)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("AppNo", AppNo);
            parameters.AddWithValue("BorrowType", BorrowType);
            parameters.AddWithValue("IDNo", IDNo);
            parameters.AddWithValue("CustName", CustName);
            parameters.AddWithValue("OrgCode", orgcode);            
            parameters.AddWithValue("starttime", starttime);
            parameters.AddWithValue("endtime", endtime);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<AfterLoanMaintainView> result = new CommonTResult<AfterLoanMaintainView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<AfterLoanMaintainView>(CommandType.StoredProcedure, SPNames.PL_GetAfterLoanMaintainList, new AfterLoanMaintainViewMapper<AfterLoanMaintainView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<AfterLoanMaintainView> GetAfterLoanMaintainListAll(string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string starttime, string endtime)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();            
            parameters.AddWithValue("AppNo", AppNo);
            parameters.AddWithValue("BorrowType", BorrowType);
            parameters.AddWithValue("IDNo", IDNo);
            parameters.AddWithValue("CustName", CustName);
            parameters.AddWithValue("OrgCode", orgcode);
            parameters.AddWithValue("starttime", starttime);
            parameters.AddWithValue("endtime", endtime);            
            CommonTResult<AfterLoanMaintainView> result = new CommonTResult<AfterLoanMaintainView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<AfterLoanMaintainView>(CommandType.StoredProcedure, SPNames.PL_GetAfterLoanMaintainListWithoutLog, new AfterLoanMaintainViewMapper<AfterLoanMaintainView>(), parameters);            
            return result;
        }

        public CommonTResult<AfterLoanMaintainView> GetAfterLoanMaintainListWithLog(string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string starttime, string endtime)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppNo", AppNo);
            parameters.AddWithValue("BorrowType", BorrowType);
            parameters.AddWithValue("IDNo", IDNo);
            parameters.AddWithValue("CustName", CustName);
            parameters.AddWithValue("OrgCode", orgcode);
            parameters.AddWithValue("starttime", starttime);
            parameters.AddWithValue("endtime", endtime);
            CommonTResult<AfterLoanMaintainView> result = new CommonTResult<AfterLoanMaintainView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<AfterLoanMaintainView>(CommandType.StoredProcedure, SPNames.PL_GetAfterLoanMaintainListAll, new AfterLoanMaintainViewMapper<AfterLoanMaintainView>(), parameters);
            return result;
        }

        public CommonTResult<IDQueryView> GetIDQueryList( string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string Status, string starttime, string endtime)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();            
            parameters.AddWithValue("AppNo", AppNo);
            parameters.AddWithValue("BorrowType", BorrowType);
            parameters.AddWithValue("IDNo", IDNo);
            parameters.AddWithValue("CustName", CustName);
            parameters.AddWithValue("OrgCode", orgcode);            
            parameters.AddWithValue("starttime", starttime);
            parameters.AddWithValue("endtime", endtime);
            
            CommonTResult<IDQueryView> result = new CommonTResult<IDQueryView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<IDQueryView>(CommandType.StoredProcedure, SPNames.PL_GetIDQueryListAll, new IDQueryViewMapper<IDQueryView>(), parameters);
            
            return result;
        }

        public CommonTResult<IDQueryView> GetIDChangeLogAll(string AppNo, string BorrowType, string IDNo, string CustName, string orgcode, string Status, string starttime, string endtime)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppNo", AppNo);
            parameters.AddWithValue("BorrowType", BorrowType);
            parameters.AddWithValue("IDNo", IDNo);
            parameters.AddWithValue("CustName", CustName);
            parameters.AddWithValue("OrgCode", orgcode);
            parameters.AddWithValue("starttime", starttime);
            parameters.AddWithValue("endtime", endtime);

            CommonTResult<IDQueryView> result = new CommonTResult<IDQueryView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<IDQueryView>(CommandType.StoredProcedure, SPNames.PL_GetIDQueryListLogAll, new IDQueryViewMapper<IDQueryView>(), parameters);

            return result;
        }

        public CommonTResult<T_WF_PL_INS> GetInstances(int start, int limit, string orgCode, int roleType, string soeID, T_WF_PL_INS entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("AppNo", entity.AppNo);
            parameters.AddWithValue("CustomerID", entity.IDNo);
            parameters.AddWithValue("CustomerName", entity.CustomerName);
            parameters.AddWithValue("ProdID", entity.ProdID==0?"":entity.ProdID.ToString());
            parameters.AddWithValue("ProcID", entity.CurrentProcessor);
            parameters.AddWithValue("Status", entity.Status == "0" ? "" : entity.Status);
            parameters.AddWithValue("ExecID", entity.ExecID);
            parameters.AddWithValue("SalesID", entity.SalesID);
            parameters.AddWithValue("OrgCode", orgCode);
            parameters.AddWithValue("DateBegin", entity.DateBegin);
            parameters.AddWithValue("DateEnd", entity.DateEnd);
            parameters.AddWithValue("StageId", entity.StageID);
            parameters.AddWithValue("RoleType", roleType == 0 ? "":roleType.ToString());
            parameters.AddWithValue("SoeID", soeID);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<T_WF_PL_INS> result = new CommonTResult<T_WF_PL_INS>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_WF_PL_INS>(CommandType.StoredProcedure,
                SPNames.PL_WFGetInstances, new T_WF_PL_INSRowMapper<T_WF_PL_INS>(), parameters);
            result.ResultCount = Convert.IsDBNull(parameters["@Count"].Value) ? 0 : (int)parameters["@Count"].Value;
            return result;
        }

        public string GetIDStatus(string CustID,string IDNo)
        {
            string getcountsql = @"select count(*) from T_PL_IDChangeLog where CustID='"+CustID+@"' and IDNo='"+IDNo+"'";
            object o1 = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.Text, getcountsql);
            if (o1 != null)
            {
                if(Convert.ToInt32(o1)>1)
                {
                    return "已更新";                        
                }
                else
                {
                    return "未更新";
                }
            }                
            else
                return "";
        }

        public IList<T_WF_PL_INS> GetLastDate(Guid appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            return AdoTemplate.QueryWithRowMapper<T_WF_PL_INS>(CommandType.StoredProcedure,
                SPNames.PL_WFGetLastDate, new T_WF_PL_INSRowMapper<T_WF_PL_INS>(), parameters);
        }

        public string GetCurrentStatus(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            string sql = "select Status from T_WF_PL_INS where appid=@APPID";
            object obj= AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.Text, sql, parameters);
            if(obj!=null)
                return obj.ToString();
            else
                return "";
        }

        public Dictionary<string, string> GetFMSParameters()
        {
            Dictionary<string, string> fmsParameters = new Dictionary<string, string>();

            string sql = "select [Key], [Value] from T_Sys_Parameters where ParamID = 'FMS'";
            DataTable dt= AdoTemplate.ClassicAdoTemplate.DataTableCreate(CommandType.Text, sql);
            foreach (DataRow dr in dt.Rows)
            {
                fmsParameters.Add(dr["Key"].ToString(), dr["Value"].ToString());
            }
            
            return fmsParameters;

        }

        public string GetRCCode(string appId)
        {
            string sql = @"select RCCode from T_sys_branch where orgcode= (select top 1 orgcode from t_pl_application where appid='" + appId + "')";
            try
            {
                object obj = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.Text, sql);
                if (obj != null)
                    return obj.ToString();
                else
                    return "";
            }
            catch (Exception ex)
            {
                return "";
            }
            
        }

        private string GetAccountNO(string appId, string prod)
        {
            string tableName = (prod.ToUpper().Trim() == "UPL") ? "T_PL_ALS_UPL" : "T_PL_ALS_COL";
            string selectSql = string.Format("select AccountNumber from {0} where AppID = '{1}'", tableName, appId);
            object obj=AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.Text,selectSql);
            if (obj != null)
                return obj.ToString();
            else
                return "";
        }


        private decimal GetAmount(string appId,string prodname)
        {
            string selectSql ="";
            if(prodname=="UPL")
                selectSql = string.Format(@"select LoanProceeds from T_PL_ALS_UPL where AppId = '{0}'", appId);
            else
                selectSql = string.Format(@"select LoanProceeds from T_PL_ALS_COL where AppId = '{0}'", appId);
            DataTable dt = AdoTemplate.ClassicAdoTemplate.DataTableCreate(CommandType.Text, selectSql);
            Nullable<decimal> amount = null;
            foreach (DataRow dr in dt.Rows)
            {
                if (dr["LoanProceeds"] != null)
                { 
                    if(!string.IsNullOrEmpty(dr["LoanProceeds"].ToString()))
                    {
                        amount = Convert.ToDecimal( dr["LoanProceeds"].ToString());
                        break; 
                    }
                }                    
            }
            
            if (amount == null)
                amount = 0;
            return amount.Value;
        }
        private Dictionary<string, string> GetProdDetails(string appid)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            string sql = "select CreditAcc,DebitAcc from T_sys_Products where prodId=(select prodid from T_PL_Application where appid='" + appid + "')";
            DataTable dt = AdoTemplate.ClassicAdoTemplate.DataTableCreate(CommandType.Text, sql);
            if (dt != null && dt.Rows.Count > 0)
            {
                dic.Add("CreditAcc", dt.Rows[0]["CreditAcc"].ToString());
                dic.Add("DebitAcc", dt.Rows[0]["DebitAcc"].ToString());
            }
            else
            {
                dic.Add("CreditAcc", "");
                dic.Add("DebitAcc", "");
            }
            return dic;
        }

        public void SaveHandOverFWMS(Ent_Aplication entApp, string batchNO, IDictionary<string, string> fmsParameters)
        {
            string insertSql = @"insert into T_HandOver_FMS (AppID, [Batch No.], [SRC IND], [AC No.], 
            AMOUNT, [TRN CODE], DC, [CCY CODE], [RC No.], [CO No.], DESC2, DESC3, DESC4 )
            values ( '{0}', '{1}', '{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}', '{11}', '{12}' )";

            //Ent_SaleAndApp ent_SaleAndApp = GetSaleAndAppData(entApp.AppID.ToString());
            Dictionary<string,string> dic= GetProdDetails(entApp.AppID);

            string RCNO = GetRCCode(entApp.AppID);
            string AccountNO = GetAccountNO(entApp.AppID.ToString(), entApp.ProdName);

            string D_Desc4 = null;
            string C_Desc4 = null;

            switch (entApp.ProdName.ToUpper())
            {
                case "UPL":
                    D_Desc4 = D_UPL_Desc4;
                    C_Desc4 = C_UPL_Desc4;
                    break;
                case "HE":
                    D_Desc4 = D_HE_Desc4;
                    C_Desc4 = C_HE_Desc4;
                    break;
                case "CRE":
                    D_Desc4 = D_CRE_Desc4;
                    C_Desc4 = C_CRE_Desc4;
                    break;
                case "MO":
                    D_Desc4 = D_MO_Desc4;
                    C_Desc4 = C_MO_Desc4;
                    break;
            }

            decimal amount = GetAmount(entApp.AppID.ToString(),entApp.ProdName);

            //Modified by Zhangweiwei 2009-03-30 for VT
            string[] values = new string[] { entApp.AppID.ToString(), batchNO, fmsParameters["SIND"], dic["DebitAcc"], amount.ToString(),
                fmsParameters["D"], "D", fmsParameters["CCYC"], this.GetRCCode(), fmsParameters["CONO"], entApp.ApplicationNo, AccountNO, D_Desc4 };

            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.Text, string.Format(insertSql, values));
            

            values = new string[] { entApp.AppID.ToString(), batchNO, fmsParameters["SIND"], dic["CreditAcc"], amount.ToString(),
                fmsParameters["C"], "C", fmsParameters["CCYC"], RCNO, fmsParameters["CONO"], entApp.ApplicationNo, AccountNO, C_Desc4 };

            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.Text, string.Format(insertSql, values));
        }

        private string GetRCCode()
        {
            string sql = @"select RCCode=isnull((select RCCode from T_Sys_Branch 
                            where orgcode='01020201'),'')";
            object obj = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.Text,sql);
            if (!SqlHelper.IsNullOrDbNull(obj))
            {
                string rccode = obj.ToString();
                if (rccode.Length <= 2)
                {
                    return rccode + RCCodeSuffix;
                }
                else
                {
                    return rccode.Substring(0, 2) + RCCodeSuffix;
                }
            }
            else
            {
                return string.Empty;
            }
        }


        public int TryLock(string appid, string soeid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appid);
            parameters.AddWithValue("soeid", soeid);
            parameters.AddOut("resultstatus", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_TryToLock, parameters);
            int returnresult= (int)parameters["@resultstatus"].Value;
            return returnresult;
        }

        public void SetVaild(string guidAppID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("APPID", guidAppID);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SetVaild, parameters);
        }

        public IList<T_WF_PL_STEP> GetNextStageID(T_WF_PL_INS entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("StageID", entity.StageID);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Action", entity.Action);
            return AdoTemplate.QueryWithRowMapper<T_WF_PL_STEP>(CommandType.StoredProcedure,
                SPNames.PL_WFGetNextStageId, new T_WF_PL_STEPRowMapper<T_WF_PL_STEP>(), parameters);
        }
        public IList<T_WF_PL_INS> GetStageID(Guid appID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appID);

            return AdoTemplate.QueryWithRowMapper<T_WF_PL_INS>(CommandType.StoredProcedure,
                SPNames.PL_WFGetStageId, new T_WF_PL_INSRowMapper<T_WF_PL_INS>(), parameters);
        }

        public IList<T_WF_PL_INS> HasInstance(Guid appID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appID);
            return AdoTemplate.QueryWithRowMapper<T_WF_PL_INS>(CommandType.StoredProcedure,
                SPNames.PL_WFHasInstance, new T_WF_PL_INSRowMapper<T_WF_PL_INS>(), parameters);
        }

        public void SetInsToHis(Guid appID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appID);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_WFSetInsToHis, parameters);
        }

        public void SetLastDate(Guid appID, DateTime time)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appID);
            parameters.AddWithValue("time", time);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_WFSetLastDate, parameters);
        }

        public IList<T_WF_PL_HIS> HasHistory(Guid appID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appID);
            return AdoTemplate.QueryWithRowMapper<T_WF_PL_HIS>(CommandType.StoredProcedure,
                SPNames.PL_WFHasHistory, new T_WF_PL_HISRowMapper<T_WF_PL_HIS>(), parameters);
        }

        public CommonTResult<ProcessHistory> GetProcHistory(Guid appId, int limit, int start)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<ProcessHistory> result = new CommonTResult<ProcessHistory>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<ProcessHistory>(CommandType.StoredProcedure,
                SPNames.PL_WFGetProcHis, new ProcessHistoryRowMapper<ProcessHistory>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public void UpdateInstance(T_WF_PL_INS entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", entity.AppID);
            parameters.AddWithValue("StageID", entity.StageID);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("ProcDate", DateTime.Now);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddWithValue("ProcID", entity.SoeID);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_WFUpdateInstance, parameters);
        }
        public bool AddNewIDChangeLog(string NewIDNo, string NewExpireDate, string NewIssueDate,string NewIssuePlace,string CustID,string soeid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("NewIDNo", NewIDNo);
            parameters.AddWithValue("NewExpireDate", NewExpireDate);
            parameters.AddWithValue("NewIssueDate", NewIssueDate);
            parameters.AddWithValue("NewIssuePlace", NewIssuePlace);
            parameters.AddWithValue("CustID", CustID);
            parameters.AddWithValue("soeid", soeid);

            int i1 = AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_AddNewIDChangeLog, parameters);
            if (i1 > 0)
                return true;
            else
                return false;
        }

        public bool AddNewAfterLoanChangeLog(string CommunicationAddressAs, string NewProvince, string NewCity, string NewDistrict, string NewStreet, string NewMobileNumber, string NewTelAreaCode, string NewTelNumber, string soeid, string CustID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CommunicationAddressAs", CommunicationAddressAs);
            parameters.AddWithValue("CustID", CustID);            
            parameters.AddWithValue("NewProvince", NewProvince);
            parameters.AddWithValue("NewCity", NewCity);
            parameters.AddWithValue("NewDistrict", NewDistrict);
            parameters.AddWithValue("NewStreet", NewStreet);
            parameters.AddWithValue("NewMobileNumber", NewMobileNumber);
            parameters.AddWithValue("NewTelAreaCode", NewTelAreaCode);
            parameters.AddWithValue("NewTelNumber", NewTelNumber);
            parameters.AddWithValue("soeid", soeid);

            int i1 = AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_AddNewAfterLoanChangeLog, parameters);
            if (i1 > 0)
                return true;
            else
                return false;
        }

        public CommonTResult<T_PL_IDChangeLog> GetIDChangeLog(int start, int limit, string CustID, string IDNo)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", CustID);
            parameters.AddWithValue("IDNo", IDNo);
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<T_PL_IDChangeLog> result = new CommonTResult<T_PL_IDChangeLog>();

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_IDChangeLog>(CommandType.StoredProcedure, SPNames.PL_GetIDChangeLog, new T_PL_IDChangeLogMapper<T_PL_IDChangeLog>(), parameters);            
            return result;
        }
        public CommonTResult<T_PL_AfterLoanChangeLogView> GetAfterLoanChangeLog(int start, int limit, string CustID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", CustID);
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<T_PL_AfterLoanChangeLogView> result = new CommonTResult<T_PL_AfterLoanChangeLogView>();

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_AfterLoanChangeLogView>(CommandType.StoredProcedure, SPNames.PL_GetAfterLoanChangeLog, new T_PL_AfterLoanChangeLogMapper<T_PL_AfterLoanChangeLogView>(), parameters);
            return result;

        }
        public CommonTResult<ComboboxEntity> GetWFStages()
        {
            CommonTResult<ComboboxEntity> result = new CommonTResult<ComboboxEntity>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<ComboboxEntity>(CommandType.StoredProcedure, SPNames.PL_GetWFStages, new ComboxMapper<ComboboxEntity>());
            return result;
        }

        public CommonTResult<T_PL_PendRejectReason> GetRejectReasonsView()
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            CommonTResult<T_PL_PendRejectReason> result = new CommonTResult<T_PL_PendRejectReason>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_PendRejectReason>(
                CommandType.StoredProcedure, SPNames.PL_GetRejectReasonsView, new T_PL_PendRejectReasonMapper<T_PL_PendRejectReason>(), parameters);
            return result;
        }
        public CommonTResult<DataEntryView> QueryWaitDataEntry(int start, int limit, DataEntryView entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("RoleType", entity.RoleType);
            parameters.AddWithValue("soeid", entity.soeid);
            parameters.AddWithValue("orgcode", entity.orgcode);
            parameters.AddOut("count", DbType.Int32);
            CommonTResult<DataEntryView> result = new CommonTResult<DataEntryView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<DataEntryView>(CommandType.StoredProcedure, SPNames.PL_GetWaitDataEntry, new DataEntryViewMapper<DataEntryView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;

        }

        public CommonTResult<DataEntryView> QueryHistoryDataEntry(int start, int limit, DataEntryView entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("RoleType", entity.RoleType);
            parameters.AddWithValue("soeid", entity.soeid);
            parameters.AddWithValue("orgcode", entity.orgcode);

            parameters.AddWithValue("AppNO", entity.AppNO);
            parameters.AddWithValue("CustomerId", entity.CustomerID);
            parameters.AddWithValue("CustomerName", entity.CustomerName);
            parameters.AddWithValue("prodid", entity.Product);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("starttime", entity.StartTime);
            parameters.AddWithValue("endtime", entity.EndTime);

            parameters.AddOut("count", DbType.Int32);
            CommonTResult<DataEntryView> result = new CommonTResult<DataEntryView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<DataEntryView>(CommandType.StoredProcedure, SPNames.PL_GetHistoryDataEntry, new DataEntryViewMapper<DataEntryView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;

        }


        public string GetWFStatusByAppID(string appId)
        {
           IDbParameters parameters = AdoTemplate.CreateDbParameters();
           parameters.AddWithValue("AppId", appId);
           parameters.AddOut("Result", DbType.String, 50);
           int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(
               CommandType.StoredProcedure, SPNames.PL_GetWFStatusByAppID, parameters);
           string result = parameters["@Result"].Value == System.DBNull.Value ? string.Empty : (string)parameters["@Result"].Value;
           if (!string.IsNullOrEmpty(result))
               return result;
           else
               return "";
        }

        public string GetCurrentStepByAppId(string appId)
        {
            var result = "";
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddOut("Result", DbType.String,100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_GetCurrentStepByAppID, parameters);
            if (parameters["@Result"].Value != System.DBNull.Value) {
                result = parameters["@Result"].Value.ToString();
            }
            return result;
        }


        public bool CheckStepIDByAppIDAndStepID(string appId, string stepId)
        {
            var result = false;
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddWithValue("StepID", stepId);
            parameters.AddOut("Result", DbType.Boolean);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_CheckStepIDByAppIDAndStepID, parameters);
            if (parameters["@Result"].Value != System.DBNull.Value)
            {
                result = Boolean.Parse(parameters["@Result"].Value.ToString());
            }
            return result;
        }
    }
}
