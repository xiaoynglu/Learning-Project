﻿using System;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Collections;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using Citigroup.Australia.GCG.GeminiTileTransfer.Scheduler.Common.Cipher;

namespace Citibank.RFLFE.PL.Dal
{
    public enum CONN_TYPE
    {
        CNRF_LFE,
        PBOC_ALS,
        CNRF_AP
    }

    /// <summary>
    /// The SqlHelper class is intended to encapsulate high performance, 
    /// scalable best practices for common uses of SqlClient.
    /// </summary>
    public abstract class SqlHelper
    {
        #region Connection String
        public static string GetConnectionString(CONN_TYPE ct)
        {
            switch (ct)
            {
                case CONN_TYPE.CNRF_LFE:
                    return ConnectionStringDefault;
                case CONN_TYPE.PBOC_ALS:
                    return ConnectionStringDefaultPBOC;
                case CONN_TYPE.CNRF_AP:
                    return ConnectionStringDefaultAP;
                default:
                    return ConnectionStringDefault;
            }
        }

        //public static readonly string ConnectionStringDefault = @"Data Source=dbddev02;Initial Catalog=SITCNRF_LFEDB;Persist Security Info=True;User ID=sa; Password=dbddev";
        protected static string ConnectionStringDefault
        {
            get
            {
                string strConn = ConfigurationManager.ConnectionStrings["LFE"].ToString();
                CitiAES.clsAES AES = new CitiAES.clsAES();
                string password = AES.Decrypt(ConfigurationManager.AppSettings["LFEDB1"]) + AES.Decrypt(ConfigurationManager.AppSettings["LFEDB2"]);
                return string.Format(strConn, password);
            }
        }

        protected static string ConnectionStringDefaultAP
        {
            get
            {
                string strSQLServer = ConfigurationManager.AppSettings.Get("PBOC_SQLServerName");
                string strDatabase = ConfigurationManager.AppSettings.Get("AP_SQLDatabase");
                string strUserId = ConfigurationManager.AppSettings.Get("PBOC_SQLUserId");
                string strPwd1 = ConfigurationManager.AppSettings.Get("PBOC_SQLPwd1");
                string strPwd2 = ConfigurationManager.AppSettings.Get("PBOC_SQLPwd2");
                string strPassword = DescryptDB(strPwd1) + DescryptDB(strPwd2);
                return string.Format("Data Source={0};Initial Catalog={1};Persist Security Info=True;User ID={2}; Password={3}", strSQLServer, strDatabase, strUserId, strPassword);
            }
        }

        protected static string ConnectionStringDefaultPBOC
        {
            get
            {
                string strSQLServer = ConfigurationManager.AppSettings.Get("PBOC_SQLServerName");
                string strDatabase = ConfigurationManager.AppSettings.Get("PBOC_SQLDatabase");
                string strUserId = ConfigurationManager.AppSettings.Get("PBOC_SQLUserId");
                string strPwd1 = ConfigurationManager.AppSettings.Get("PBOC_SQLPwd1");
                string strPwd2 = ConfigurationManager.AppSettings.Get("PBOC_SQLPwd2");
                string strPassword = DescryptDB(strPwd1) + DescryptDB(strPwd2);
                return string.Format("Data Source={0};Initial Catalog={1};Persist Security Info=True;User ID={2}; Password={3}", strSQLServer, strDatabase, strUserId, strPassword);
            }
        }

        private static string DescryptDB(string plainText)
        {
            string strRtn = "";
            CipherResultStruct result;
            AESFIPSDecryption decrypt = new AESFIPSDecryption();
            result = decrypt.Decrypt(plainText);
            strRtn = result.DecryptedText;
            return strRtn;
        }

        private static string GetConnectionTimeOut()
        {
            return ConfigurationManager.AppSettings["TimeOut"];
        }

        #endregion


        #region private utility methods & constructors

        // Hashtable to store cached parameters
        private static Hashtable parmCache = Hashtable.Synchronized(new Hashtable());
        /// <summary>
        /// This method is used to attach array of SqlParameters to a SqlCommand.
        /// 
        /// This method will assign a value of DbNull to any parameter with a direction of
        /// InputOutput and a value of null.  
        /// 
        /// This behavior will prevent default values from being used, but
        /// this will be the less common case than an intended pure output parameter (derived as InputOutput)
        /// where the user provided no input value.
        /// </summary>
        /// <param name="command">The command to which the parameters will be added</param>
        /// <param name="commandParameters">an array of SqlParameters tho be added to command</param>
        private static void AttachParameters(SqlCommand command, SqlParameter[] commandParameters)
        {
            foreach (SqlParameter p in commandParameters)
            {
                //check for derived output value with no value assigned
                if ((p.Direction == ParameterDirection.InputOutput) && (p.Value == null))
                {
                    p.Value = DBNull.Value;
                }

                command.Parameters.Add(p);
            }
        }

        /// <summary>
        /// This method assigns an array of values to an array of SqlParameters.
        /// </summary>
        /// <param name="commandParameters">array of SqlParameters to be assigned values</param>
        /// <param name="parameterValues">array of objects holding the values to be assigned</param>
        private static void AssignParameterValues(SqlParameter[] commandParameters, object[] parameterValues)
        {
            if ((commandParameters == null) || (parameterValues == null))
            {
                //do nothing if we get no data
                return;
            }

            // we must have the same number of values as we pave parameters to put them in
            if (commandParameters.Length != parameterValues.Length)
            {
                throw new ArgumentException("Parameter count does not match Parameter Value count.");
            }

            //iterate through the SqlParameters, assigning the values from the corresponding position in the 
            //value array
            for (int i = 0, j = commandParameters.Length; i < j; i++)
            {
                commandParameters[i].Value = parameterValues[i];
            }
        }


        #endregion private utility methods & constructors

        #region ExecuteDataSet

        /// <summary>
        /// Execute a sql against the database specified in the connection string 
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  DataSet ds = ExecuteDataset(connString, "select * from t where id=@id", new SqlParameter("@id", 24));
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>a dataset containing the resultset generated by the command</returns>
        public static DataSet ExecuteDataset(string connectionString, string commandText, params SqlParameter[] commandParameters)
        {
            SqlDatabase db = new SqlDatabase(connectionString);
            {
                DbCommand cmd = db.GetSqlStringCommand(commandText);

                if (!String.IsNullOrEmpty(GetConnectionTimeOut()))
                {
                    cmd.CommandTimeout = Convert.ToInt32(GetConnectionTimeOut());
                }
                if (commandParameters == null || commandParameters.Length == 0)
                {
                    return db.ExecuteDataSet(CommandType.Text, commandText);
                }
                else
                {
                    cmd.Parameters.AddRange(commandParameters);
                    return db.ExecuteDataSet(cmd);
                }
            }
        }
        public static DataSet ExecuteDataset(string connectionString, string commandText)
        {
            return ExecuteDataset(connectionString, commandText, null);
        }
        public static DataSet ExecuteDatasetDefault(string commandText, SqlParameter commandParameters)
        {
            return ExecuteDataset(ConnectionStringDefault, commandText, new SqlParameter[] { commandParameters });
        }
        public static DataSet ExecuteDatasetDefault(string commandText, params SqlParameter[] commandParameters)
        {
            //pass through the call providing null for the set of SqlParameters
            return ExecuteDataset(ConnectionStringDefault, commandText, commandParameters);
        }
        public static DataSet ExecuteDatasetDefault(string commandText)
        {
            //pass through the call providing null for the set of SqlParameters
            return ExecuteDataset(ConnectionStringDefault, commandText, null);
        }

        /// <summary>
        /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the database specified in 
        /// the connection string using the provided parameter values.  This method will query the database to discover the parameters for the 
        /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
        /// </summary>
        /// <remarks>
        /// This method provides no access to output parameters or the stored procedure's return value parameter.
        /// 
        /// e.g.:  
        ///  DataSet ds = ExecuteDatasetSp(connString, "GetOrders", 24, 36);
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="spName">the name of the stored procedure</param>
        /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
        /// <returns>a dataset containing the resultset generated by the command</returns>
        /// 
        public static DataSet ExecuteDatasetSp_Default(string connectionString, CommandType strType, string spName, params SqlParameter[] parameterValues)
        {
            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            PrepareCommand(cmd, new SqlConnection(connectionString), null, strType, spName, parameterValues);
            if (!String.IsNullOrEmpty(GetConnectionTimeOut()))
            {
                cmd.CommandTimeout = Convert.ToInt32(GetConnectionTimeOut());
            }
            //create the DataAdapter & DataSet
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();

            //fill the DataSet using default values for DataTable names, etc.
            da.Fill(ds);

            // detach the SqlParameters from the command object, so they can be used again.
            cmd.Parameters.Clear();

            //return the dataset
            return ds;
            //return new SqlDatabase(connectionString).ExecuteDataSet(spName, parameterValues);
        }
        public static DataSet ExecuteDatasetSp(string connectionString, string spName, params SqlParameter[] parameterValues)
        {
            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            PrepareCommand(cmd, new SqlConnection(connectionString), null, CommandType.StoredProcedure, spName, parameterValues);
            if (!String.IsNullOrEmpty(GetConnectionTimeOut()))
            {
                cmd.CommandTimeout = Convert.ToInt32(GetConnectionTimeOut());
            }
            //create the DataAdapter & DataSet
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();

            //fill the DataSet using default values for DataTable names, etc.
            da.Fill(ds);

            // detach the SqlParameters from the command object, so they can be used again.
            cmd.Parameters.Clear();

            //return the dataset
            return ds;
            //return new SqlDatabase(connectionString).ExecuteDataSet(spName, parameterValues);
        }

        public static DataSet ExecuteDatasetSp(string connectionString, string spName, params object[] parameterValues)
        {
            return new SqlDatabase(connectionString).ExecuteDataSet(spName, parameterValues);
        }

        /// <summary>
        /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the database specified in 
        /// the connection string using the provided parameter values.  This method will query the database to discover the parameters for the 
        /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
        /// </summary>
        /// <remarks>
        /// This method provides no access to output parameters or the stored procedure's return value parameter.
        /// 
        /// e.g.:  
        ///  DataSet ds = ExecuteDatasetSpDefault(connString, "GetOrders", 24, 36);
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="spName">the name of the stored procedure</param>
        /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
        /// <returns>a dataset containing the resultset generated by the command</returns>
        public static DataSet ExecuteDatasetSpDefault(string spName, params object[] parameterValues)
        {
            return ExecuteDatasetSp(ConnectionStringDefault, spName, parameterValues);
        }

        public static DataSet ExecuteDatasetSpDefault(string spName, params SqlParameter[] parameterValues)
        {
            return ExecuteDatasetSp(ConnectionStringDefault, spName, parameterValues);
        }

        /// <summary>
        /// Execute a SqlCommand (that returns a resultset) against the specified SqlTransaction
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  DataSet ds = ExecuteDataset(trans, CommandType.StoredProcedure, "GetOrders", new SqlParameter("@prodid", 24));
        /// </remarks>
        /// <param name="transaction">a valid SqlTransaction</param>
        /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>a dataset containing the resultset generated by the command</returns>
        public static DataSet ExecuteDataset(SqlTransaction transaction, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            PrepareCommand(cmd, transaction.Connection, transaction, commandType, commandText, commandParameters);
            if (!String.IsNullOrEmpty(GetConnectionTimeOut()))
            {
                cmd.CommandTimeout = Convert.ToInt32(GetConnectionTimeOut());
            }
            //create the DataAdapter & DataSet
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();

            //fill the DataSet using default values for DataTable names, etc.
            da.Fill(ds);

            // detach the SqlParameters from the command object, so they can be used again.
            cmd.Parameters.Clear();

            //return the dataset
            return ds;
        }

        /// <summary>
        /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the specified 
        /// SqlTransaction using the provided parameter values.  This method will query the database to discover the parameters for the 
        /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
        /// </summary>
        /// <remarks>
        /// This method provides no access to output parameters or the stored procedure's return value parameter.
        /// 
        /// e.g.:  
        ///  DataSet ds = ExecuteDataset(trans, "GetOrders", 24, 36);
        /// </remarks>
        /// <param name="transaction">a valid SqlTransaction</param>
        /// <param name="spName">the name of the stored procedure</param>
        /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
        /// <returns>a dataset containing the resultset generated by the command</returns>
        public static DataSet ExecuteDataset(SqlTransaction transaction, string spName, params object[] parameterValues)
        {
            //if we receive parameter values, we need to figure out where they go
            if ((parameterValues != null) && (parameterValues.Length > 0))
            {
                //pull the parameters for this stored procedure from the parameter cache (or discover them & populate the cache)
                SqlParameter[] commandParameters = SqlHelperParameterCache.GetSpParameterSet(transaction.Connection.ConnectionString, spName);

                //assign the provided values to these parameters based on parameter order
                AssignParameterValues(commandParameters, parameterValues);

                //call the overload that takes an array of SqlParameters
                return ExecuteDataset(transaction, CommandType.StoredProcedure, spName, commandParameters);
            }
            //otherwise we can just call the SP without params
            else
            {
                return ExecuteDataset(transaction, CommandType.StoredProcedure, spName);
            }
        }

        #endregion ExecuteDataSet

        #region ExecuteDataTable

        /// <summary>
        /// Execute a SqlCommand (that returns a resultset) against the database specified in the connection string 
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  DataTable ds = ExecuteDataTable(connString, "select * from t where id=@id", new SqlParameter("@id", 24));
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>a DataTable containing the resultset generated by the command</returns>
        public static DataTable ExecuteDataTable(string connectionString, string commandText, params SqlParameter[] commandParameters)
        {
            return ExecuteDataset(connectionString, commandText, commandParameters).Tables[0];
        }
        public static DataTable ExecuteDataTable(string connectionString, string commandText)
        {
            return ExecuteDataset(connectionString, commandText, null).Tables[0];
        }
        public static DataTable ExecuteDataTableDefault(string commandText, SqlParameter commandParameters)
        {
            return ExecuteDataset(ConnectionStringDefault, commandText, new SqlParameter[] { commandParameters }).Tables[0];
        }
        public static DataTable ExecuteDataTableDefault(string commandText, params SqlParameter[] commandParameters)
        {
            return ExecuteDataset(ConnectionStringDefault, commandText, commandParameters).Tables[0];
        }
        public static DataTable ExecuteDataTableDefault(string commandText)
        {
            return ExecuteDataset(ConnectionStringDefault, commandText, null).Tables[0];
        }
        /// <summary>
        /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the database specified in 
        /// the connection string using the provided parameter values.  This method will query the database to discover the parameters for the 
        /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
        /// </summary>
        /// <remarks>
        /// This method provides no access to output parameters or the stored procedure's return value parameter.
        /// 
        /// e.g.:  
        ///  DataTable ds = ExecuteDataTable(connString, "GetOrders", 24, 36);
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="spName">the name of the stored procedure</param>
        /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
        /// <returns>a DataTable containing the resultset generated by the command</returns>
        public static DataTable ExecuteDataTableSp(string connectionString, string spName, params object[] parameterValues)
        {
            return ExecuteDatasetSp(connectionString, spName, parameterValues).Tables[0];
        }

        public static DataTable ExecuteDataTableSp(string spName, params SqlParameter[] parameterValues)
        {
            DataSet ds = ExecuteDatasetSp(ConnectionStringDefault, spName, parameterValues);
            if (ds.Tables.Count > 0)
            {
                return ds.Tables[0];
            }
            else
            {
                return null;
            }
            
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="connectionString"></param>
        /// <param name="spName"></param>
        /// <param name="parameterValues"></param>
        /// <returns></returns>
        /// 
        public static DataTable ExecuteDataTableSp(string connectionString, CommandType strType, string spName, params SqlParameter[] parameterValues)
        {
            return ExecuteDatasetSp_Default(connectionString, strType, spName, parameterValues).Tables[0];
        }
        public static DataTable ExecuteDataTableSp(string connectionString, string spName, params SqlParameter[] parameterValues)
        {
            return ExecuteDatasetSp(connectionString, spName, parameterValues).Tables[0];
        }

        public static DataTable ExecuteDataTableSpDefault(string spName, params SqlParameter[] parameterValues)
        {
            return ExecuteDataTableSp(ConnectionStringDefault, spName, parameterValues);
        }

        /// <summary>
        /// Execute a SqlCommand (that returns a resultset) against the specified SqlTransaction
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  DataTable ds = ExecuteDataTable(trans, CommandType.StoredProcedure, "GetOrders", new SqlParameter("@prodid", 24));
        /// </remarks>
        /// <param name="transaction">a valid SqlTransaction</param>
        /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>a DataTable containing the resultset generated by the command</returns>
        public static DataTable ExecuteDataTable(SqlTransaction transaction, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
        {
            return ExecuteDataset(transaction, commandType, commandText, commandParameters).Tables[0];
        }

        /// <summary>
        /// Execute a stored procedure via a SqlCommand (that returns a resultset) against the specified 
        /// SqlTransaction using the provided parameter values.  This method will query the database to discover the parameters for the 
        /// stored procedure (the first time each stored procedure is called), and assign the values based on parameter order.
        /// </summary>
        /// <remarks>
        /// This method provides no access to output parameters or the stored procedure's return value parameter.
        /// 
        /// e.g.:  
        ///  DataTable ds = ExecuteDataTable(trans, "GetOrders", 24, 36);
        /// </remarks>
        /// <param name="transaction">a valid SqlTransaction</param>
        /// <param name="spName">the name of the stored procedure</param>
        /// <param name="parameterValues">an array of objects to be assigned as the input values of the stored procedure</param>
        /// <returns>a DataTable containing the resultset generated by the command</returns>
        public static DataTable ExecuteDataTable(SqlTransaction transaction, string spName, params object[] parameterValues)
        {
            return ExecuteDataset(transaction, spName, parameterValues).Tables[0];
        }

        #endregion ExecuteDataTable

        #region ExecuteNonQuery
        /// <summary>
        /// Execute a SqlCommand (that returns no resultset) against the database specified in the connection string 
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  int result = ExecuteNonQuery(connString, CommandType.StoredProcedure, "PublishOrders", new SqlParameter("@prodid", 24));
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>an int representing the number of rows affected by the command</returns>
        public static int ExecuteNonQuery(string connectionString, CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            SqlDatabase db = new SqlDatabase(connectionString);
            if (commandParameters == null || commandParameters.Length == 0)
            {
                return db.ExecuteNonQuery(cmdType, cmdText);
            }
            else
            {
                DbCommand cmd = null;
                if (cmdType == CommandType.Text)
                {
                    cmd = db.GetSqlStringCommand(cmdText);
                }
                else
                {
                    cmd = db.GetStoredProcCommand(cmdText);
                }
                if (!String.IsNullOrEmpty(GetConnectionTimeOut()))
                {
                    cmd.CommandTimeout = Convert.ToInt32(GetConnectionTimeOut());
                }
                //cmd.Parameters.AddRange(commandParameters);
                CopyParameters(cmd,commandParameters);
                return db.ExecuteNonQuery(cmd);
            }
        }

        public static void CopyParameters(DbCommand cmd,  params SqlParameter[] commandParameters)
        {
            cmd.Parameters.Clear();
            for (int i = 0; i < commandParameters.Length; i++)
            {
                if (((SqlParameter)commandParameters[i]).Value == null)
                {
                    ((SqlParameter)commandParameters[i]).Value = DBNull.Value;
                }
                cmd.Parameters.Add(commandParameters[i]);
            }
 
        }

        public static int ExecuteNonQuery(string connectionString, string cmdText, params SqlParameter[] commandParameters)
        {
            SqlDatabase db = new SqlDatabase(connectionString);

            if (commandParameters == null || commandParameters.Length == 0)
            {
                return db.ExecuteNonQuery(CommandType.Text, cmdText);
            }
            else
            {
                DbCommand cmd = db.GetSqlStringCommand(cmdText);
                cmd.Parameters.AddRange(commandParameters);
                if (!String.IsNullOrEmpty(GetConnectionTimeOut()))
                {
                    cmd.CommandTimeout = Convert.ToInt32(GetConnectionTimeOut());
                }
                return db.ExecuteNonQuery(cmd);
            }
        }

        public static int ExecuteNonQueryDefault(string cmdText, SqlParameter commandParameters)
        {
            return ExecuteNonQueryDefault(cmdText, new SqlParameter[] { commandParameters });
        }
        public static int ExecuteNonQueryDefault(string cmdText, params SqlParameter[] commandParameters)
        {
            return ExecuteNonQuery(ConnectionStringDefault, CommandType.Text, cmdText, commandParameters);
        }
        public static int ExecuteNonQueryDefault(string cmdText)
        {
            return ExecuteNonQuery(ConnectionStringDefault, CommandType.Text, cmdText, null);
        }
        public static int ExecuteNonQuerySpDefault(string spName, params SqlParameter[] commandParameters)
        {
            return ExecuteNonQuery(ConnectionStringDefault, CommandType.StoredProcedure, spName, commandParameters);
        }
        public static int ExecuteNonQuerySp(string connectionString, string spName, params SqlParameter[] commandParameters)
        {
            return ExecuteNonQuery(connectionString, CommandType.StoredProcedure, spName, commandParameters);
        }


        /// <summary>
        /// Execute a SqlCommand (that returns no resultset) using an existing SQL Transaction 
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  int result = ExecuteNonQuery(connString, CommandType.StoredProcedure, "PublishOrders", new SqlParameter("@prodid", 24));
        /// </remarks>
        /// <param name="trans">an existing sql transaction</param>
        /// <param name="commandType">the CommandType (stored procedure, text, etc.)</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>an int representing the number of rows affected by the command</returns>
        public static int ExecuteNonQuery(SqlTransaction trans, CommandType cmdType, string cmdText, params SqlParameter[] commandParameters)
        {
            SqlCommand cmd = new SqlCommand();
            PrepareCommand(cmd, trans.Connection, trans, cmdType, cmdText, commandParameters);
            if (!String.IsNullOrEmpty(GetConnectionTimeOut()))
            {
                cmd.CommandTimeout = Convert.ToInt32(GetConnectionTimeOut());
            }
            int val = cmd.ExecuteNonQuery();
            cmd.Parameters.Clear();
            return val;
        }

        #endregion ExecuteNonQuery

        #region ExecuteReader
        /// <summary>
        /// Execute a SqlCommand that returns a resultset against the database specified in the connection string 
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  SqlDataReader r = ExecuteReader(connString, "select * from t where id=@id", new SqlParameter("@id", 24));
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>A SqlDataReader containing the results</returns>
        public static IDataReader ExecuteReader(string connectionString, string cmdText, params SqlParameter[] commandParameters)
        {
            SqlDatabase db = new SqlDatabase(connectionString);
            DbCommand cmd = db.GetSqlStringCommand(cmdText);
            if (!String.IsNullOrEmpty(GetConnectionTimeOut()))
            {
                cmd.CommandTimeout = Convert.ToInt32(GetConnectionTimeOut());
            }
            if (commandParameters != null && commandParameters.Length != 0)
            {
                cmd.Parameters.AddRange(commandParameters);
            }
            return db.ExecuteReader(cmd);
        }
        public static IDataReader ExecuteReaderDefault(string cmdText, SqlParameter commandParameters)
        {
            return ExecuteReaderDefault(cmdText, new SqlParameter[] { commandParameters });
        }
        public static IDataReader ExecuteReaderDefault(string cmdText, params SqlParameter[] commandParameters)
        {
            return ExecuteReader(ConnectionStringDefault, cmdText, commandParameters);
        }
        public static IDataReader ExecuteReaderDefault(string cmdText)
        {
            return ExecuteReader(ConnectionStringDefault, cmdText, null);
        }
        public static IDataReader ExecuteReaderSp(string connectionString, string spName, params object[] commandParameters)
        {
            return new SqlDatabase(connectionString).ExecuteReader(spName, commandParameters);
        }
        public static IDataReader ExecuteReaderSpDefault(string spName, params SqlParameter[] commandParameters)
        {
            return ExecuteReaderSp(ConnectionStringDefault, spName, commandParameters);
        }

        #endregion ExecuteReader

        #region ExecuteScalar
        /// <summary>
        /// Execute a SqlCommand that returns the first column of the first record against the database specified in the connection string 
        /// using the provided parameters.
        /// </summary>
        /// <remarks>
        /// e.g.:  
        ///  Object obj = ExecuteScalar(connString, "select * from t where id=@id", new SqlParameter("@id", 24));
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters used to execute the command</param>
        /// <returns>An object that should be converted to the expected type using Convert.To{Type}</returns>
        public static object ExecuteScalar(string connectionString, string cmdText, params SqlParameter[] commandParameters)
        {
            SqlDatabase db = new SqlDatabase(connectionString);

            if (commandParameters == null || commandParameters.Length == 0)
            {
                return db.ExecuteScalar(CommandType.Text, cmdText);
            }
            else
            {
                DbCommand cmd = db.GetSqlStringCommand(cmdText);
                cmd.Parameters.AddRange(commandParameters);
                if (!String.IsNullOrEmpty(GetConnectionTimeOut()))
                {
                    cmd.CommandTimeout = Convert.ToInt32(GetConnectionTimeOut());
                }
                return db.ExecuteScalar(cmd);
            }
        }
        public static object ExecuteScalar(string connectionString, string cmdText)
        {
            return ExecuteScalar(connectionString, cmdText, null);
        }
        public static object ExecuteScalarDefault(string cmdText, SqlParameter commandParameters)
        {
            return ExecuteScalar(ConnectionStringDefault, cmdText, new SqlParameter[] { commandParameters });
        }
        public static object ExecuteScalarDefault(string cmdText, params SqlParameter[] commandParameters)
        {
            return ExecuteScalar(ConnectionStringDefault, cmdText, commandParameters);
        }
        public static object ExecuteScalarDefault(string cmdText)
        {
            return ExecuteScalar(ConnectionStringDefault, cmdText, null);
        }

        public static object ExecuteScalarSPDefault(string spName, params SqlParameter[] parameterValues)
        {
            //create a command and prepare it for execution
            SqlCommand cmd = new SqlCommand();
            PrepareCommand(cmd, new SqlConnection(ConnectionStringDefault), null, CommandType.StoredProcedure, spName, parameterValues);
            if (!String.IsNullOrEmpty(GetConnectionTimeOut()))
            {
                cmd.CommandTimeout = Convert.ToInt32(GetConnectionTimeOut());
            }
            object obj = cmd.ExecuteScalar();
            cmd.Parameters.Clear();
            return obj;
        }


        #endregion ExecuteScalar

        /// <summary>
        /// add parameter array to the cache
        /// </summary>
        /// <param name="cacheKey">Key to the parameter cache</param>
        /// <param name="cmdParms">an array of SqlParamters to be cached</param>
        public static void CacheParameters(string cacheKey, params SqlParameter[] commandParameters)
        {
            parmCache[cacheKey] = commandParameters;
        }

        /// <summary>
        /// Retrieve cached parameters
        /// </summary>
        /// <param name="cacheKey">key used to lookup parameters</param>
        /// <returns>Cached SqlParamters array</returns>
        public static SqlParameter[] GetCachedParameters(string cacheKey)
        {
            SqlParameter[] cachedParms = (SqlParameter[])parmCache[cacheKey];

            if (cachedParms == null)
                return null;

            SqlParameter[] clonedParms = new SqlParameter[cachedParms.Length];

            for (int i = 0, j = cachedParms.Length; i < j; i++)
                clonedParms[i] = (SqlParameter)((ICloneable)cachedParms[i]).Clone();

            return clonedParms;
        }

        /// <summary>
        /// Prepare a command for execution
        /// </summary>
        /// <param name="cmd">SqlCommand object</param>
        /// <param name="conn">SqlConnection object</param>
        /// <param name="trans">SqlTransaction object</param>
        /// <param name="cmdType">Cmd type e.g. stored procedure or text</param>
        /// <param name="cmdText">Command text, e.g. Select * from Products</param>
        /// <param name="cmdParms">SqlParameters to use in the command</param>
        private static void PrepareCommand(SqlCommand cmd, SqlConnection conn, SqlTransaction trans, CommandType cmdType, string cmdText, SqlParameter[] cmdParms)
        {

            if (conn.State != ConnectionState.Open)
                conn.Open();

            cmd.Connection = conn;
            cmd.CommandText = cmdText;

            if (trans != null)
                cmd.Transaction = trans;

            cmd.CommandType = cmdType;

            if (cmdParms != null)
            {
                foreach (SqlParameter parm in cmdParms)
                    cmd.Parameters.Add(parm);
            }
        }

        public static SqlParameter CreateParam(string prmName, SqlDbType prmType, object prmValue)
        {
            SqlParameter prm = new SqlParameter(prmName, prmType);
            prm.Value = prmValue;
            return prm;
        }

        public static SqlParameter CreateParam(string prmName, SqlDbType prmType, int size, object prmValue)
        {
            SqlParameter prm = new SqlParameter(prmName, prmType, size);
            prm.Value = prmValue;
            return prm;
        }

        #region Others
        public static bool IsNullOrDbNull(object obj)
        {
            if (obj == null || obj == DBNull.Value)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        #endregion


        #region save DataTable
        /// <summary>
        /// Save DataTable back to Database.
        /// The "selCmd" must have the PK field.
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="dt"></param>
        /// <param name="selCmd"></param>
        public static void SaveDataTable(CONN_TYPE ct, DataTable dt, string selCmd)
        {
            if (dt.Rows.Count > 0)
                using (SqlConnection conn = new SqlConnection(GetConnectionString(ct)))
                {
                    SqlDataAdapter da = new SqlDataAdapter();
                    da.SelectCommand = new SqlCommand(selCmd, conn);
                    SqlCommandBuilder MyCmd = new SqlCommandBuilder(da);
                    da.Update(dt);
                }
        }

        #endregion

        #region SqlBulkCopy

        public static int BulkCopy(DataTable dt, string tableName)
        {
            SqlBulkCopy sbc = new SqlBulkCopy(ConnectionStringDefault, SqlBulkCopyOptions.UseInternalTransaction);
            sbc.BulkCopyTimeout = 5000;
            sbc.NotifyAfter = dt.Rows.Count;
            foreach (DataColumn col in dt.Columns)
            {
                sbc.ColumnMappings.Add(col.ColumnName, col.ColumnName);
            }

            try
            {
                sbc.DestinationTableName = tableName;
                sbc.WriteToServer(dt);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return sbc.NotifyAfter;
        }

        #endregion
    }

    /// <summary>
    /// SqlHelperParameterCache provides functions to leverage a static cache of procedure parameters, and the
    /// ability to discover parameters for stored procedures at run-time.
    /// </summary>
    public sealed class SqlHelperParameterCache
    {
        #region private methods, variables, and constructors

        //Since this class provides only static methods, make the default constructor private to prevent 
        //instances from being created with "new SqlHelperParameterCache()".
        private SqlHelperParameterCache() { }

        private static Hashtable paramCache = Hashtable.Synchronized(new Hashtable());

        /// <summary>
        /// resolve at run time the appropriate set of SqlParameters for a stored procedure
        /// </summary>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="spName">the name of the stored procedure</param>
        /// <param name="includeReturnValueParameter">whether or not to include their return value parameter</param>
        /// <returns></returns>
        private static SqlParameter[] DiscoverSpParameterSet(string connectionString, string spName, bool includeReturnValueParameter)
        {
            using (SqlConnection cn = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(spName, cn))
            {
                cn.Open();
                cmd.CommandType = CommandType.StoredProcedure;

                SqlCommandBuilder.DeriveParameters(cmd);

                if (!includeReturnValueParameter)
                {
                    cmd.Parameters.RemoveAt(0);
                }

                SqlParameter[] discoveredParameters = new SqlParameter[cmd.Parameters.Count]; ;

                cmd.Parameters.CopyTo(discoveredParameters, 0);

                return discoveredParameters;
            }
        }

        //deep copy of cached SqlParameter array
        private static SqlParameter[] CloneParameters(SqlParameter[] originalParameters)
        {
            SqlParameter[] clonedParameters = new SqlParameter[originalParameters.Length];

            for (int i = 0, j = originalParameters.Length; i < j; i++)
            {
                clonedParameters[i] = (SqlParameter)((ICloneable)originalParameters[i]).Clone();
            }

            return clonedParameters;
        }

        #endregion private methods, variables, and constructors

        #region caching functions

        /// <summary>
        /// add parameter array to the cache
        /// </summary>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <param name="commandParameters">an array of SqlParamters to be cached</param>
        public static void CacheParameterSet(string connectionString, string commandText, params SqlParameter[] commandParameters)
        {
            string hashKey = connectionString + ":" + commandText;

            paramCache[hashKey] = commandParameters;
        }

        /// <summary>
        /// retrieve a parameter array from the cache
        /// </summary>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="commandText">the stored procedure name or T-SQL command</param>
        /// <returns>an array of SqlParamters</returns>
        public static SqlParameter[] GetCachedParameterSet(string connectionString, string commandText)
        {
            string hashKey = connectionString + ":" + commandText;

            SqlParameter[] cachedParameters = (SqlParameter[])paramCache[hashKey];

            if (cachedParameters == null)
            {
                return null;
            }
            else
            {
                return CloneParameters(cachedParameters);
            }
        }

        #endregion caching functions

        #region Parameter Discovery Functions

        /// <summary>
        /// Retrieves the set of SqlParameters appropriate for the stored procedure
        /// </summary>
        /// <remarks>
        /// This method will query the database for this information, and then store it in a cache for future requests.
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="spName">the name of the stored procedure</param>
        /// <returns>an array of SqlParameters</returns>
        public static SqlParameter[] GetSpParameterSet(string connectionString, string spName)
        {
            return GetSpParameterSet(connectionString, spName, false);
        }

        /// <summary>
        /// Retrieves the set of SqlParameters appropriate for the stored procedure
        /// </summary>
        /// <remarks>
        /// This method will query the database for this information, and then store it in a cache for future requests.
        /// </remarks>
        /// <param name="connectionString">a valid connection string for a SqlConnection</param>
        /// <param name="spName">the name of the stored procedure</param>
        /// <param name="includeReturnValueParameter">a bool value indicating whether the return value parameter should be included in the results</param>
        /// <returns>an array of SqlParameters</returns>
        public static SqlParameter[] GetSpParameterSet(string connectionString, string spName, bool includeReturnValueParameter)
        {
            string hashKey = connectionString + ":" + spName + (includeReturnValueParameter ? ":include ReturnValue Parameter" : "");

            SqlParameter[] cachedParameters;

            cachedParameters = (SqlParameter[])paramCache[hashKey];

            if (cachedParameters == null)
            {
                cachedParameters = (SqlParameter[])(paramCache[hashKey] = DiscoverSpParameterSet(connectionString, spName, includeReturnValueParameter));
            }

            return CloneParameters(cachedParameters);
        }

        #endregion Parameter Discovery Functions

    }

}