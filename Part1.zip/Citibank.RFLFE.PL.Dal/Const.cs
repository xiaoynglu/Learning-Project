﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Dal
{
     public  class Const
    {
         public enum ESysParameter
         {
             OtherApplicationRelations = 16,
             LoanPurpose =3,
             LoanMainIndustry =11,
             LoanCategory =2,
             LoanSourceCode = 17,
             LoanWhereKnow = 18,
             LoanPayType = 99,
             StatusParamID=58,
             OpTypeParamID=57,
             CompanyTypeParamID=64,
             EvaluationCompanyTypeParamid=66,
             IDQueryStatus = 77,

         }
    }
}
