﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Dal.Mappers;


namespace Citibank.RFLFE.PL.Dal.approval
{
    public class TopupVerificationDao : AdoDaoSupport, ITopupVerificationDao
    {
        #region "TOPUP核实" 
        public CommonTResult<BorrowerVerificationDetail> GetBorrowerVerification(string AppID, string CustId)
        {
            CommonTResult<BorrowerVerificationDetail> result = new CommonTResult<BorrowerVerificationDetail>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppId", new Guid(AppID));
            parameters.AddWithValue("CustId", new Guid(CustId));

            result.ResultList = AdoTemplate.QueryWithRowMapper<BorrowerVerificationDetail>(
                CommandType.StoredProcedure, SPNames.PL_GET_BORROWERVERIFICATION, new BorrowerVerificationDetailMapper<BorrowerVerificationDetail>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_PhoneVerification> GetPhoneVerification(int limit, int start, Guid CustID)
        {
            CommonTResult<T_PL_PhoneVerification> result = new CommonTResult<T_PL_PhoneVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", CustID);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_PhoneVerification>(CommandType.StoredProcedure,
                SPNames.PL_GET_PHONEVERIFICATION, new T_PL_PhoneVerificationMapper<T_PL_PhoneVerification>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<T_PL_SiteVerification> GetSiteVerification(int limit, int start, Guid CustID)
        {
            CommonTResult<T_PL_SiteVerification> result = new CommonTResult<T_PL_SiteVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", CustID);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_SiteVerification>(CommandType.StoredProcedure,
                SPNames.PL_GET_SITEVERIFICATION, new T_PL_SiteVerificationMapper<T_PL_SiteVerification>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<T_PL_HouseVerification> GetHouseVerification(int limit, int start, Guid CustID)
        {
            CommonTResult<T_PL_HouseVerification> result = new CommonTResult<T_PL_HouseVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", CustID);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_HouseVerification>(CommandType.StoredProcedure,
                SPNames.PL_GET_HOUSEVERIFICATION, new T_PL_HouseVerificationMapper<T_PL_HouseVerification>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<T_PL_ExternalVerification> GetExternalVerification(int limit, int start, Guid CustID)
        {
            CommonTResult<T_PL_ExternalVerification> result = new CommonTResult<T_PL_ExternalVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", CustID);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_ExternalVerification>(CommandType.StoredProcedure,
                SPNames.PL_GET_EXTERNALVERIFICATION, new T_PL_ExternalVerificationMapper<T_PL_ExternalVerification>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<T_PL_WorkingVerification> GetWorkingVerification(int limit, int start, Guid CustID)
        {
            CommonTResult<T_PL_WorkingVerification> result = new CommonTResult<T_PL_WorkingVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", CustID);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_WorkingVerification>(CommandType.StoredProcedure,
                SPNames.PL_GET_WORKINGVERIFICATION, new T_PL_WorkingVerificationMapper<T_PL_WorkingVerification>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<CreditPaymentDetail> GetCreditPaymentDetail(string AppID)
        {
            CommonTResult<CreditPaymentDetail> result = new CommonTResult<CreditPaymentDetail>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", new Guid(AppID));

            result.ResultList = AdoTemplate.QueryWithRowMapper<CreditPaymentDetail>(
                CommandType.StoredProcedure, SPNames.PL_GET_CREDITPAYMENTBYAPPID, new CreditPaymentDetailMapper<CreditPaymentDetail>(), parameters);
            return result;
        }

        public bool SaveCreditPaymentDetail(CreditPaymentDetail entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", entity.T_PL_Application.AppID);
            parameters.AddWithValue("PayType", entity.PayType);
            parameters.AddWithValue("DebitBankName", entity.T_PL_SelfPay.DebitBankName);
            parameters.AddWithValue("DebitSubBankName", entity.T_PL_SelfPay.DebitSubBankName);
            parameters.AddWithValue("DebitAccount", entity.T_PL_SelfPay.DebitAccount);
            parameters.AddWithValue("DebitReason", entity.T_PL_SelfPay.DebitReason);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_CREDITPAYMENTDETAIL, parameters) > 0 ? true : false;
        }

        public int SavePhoneVerification(T_PL_PhoneVerification entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("CustID", entity.CustID);
            parameters.AddWithValue("ContactName", entity.ContactName);
            parameters.AddWithValue("ContactNumber", entity.ContactNumber);
            parameters.AddWithValue("Gender", entity.Gender);
            parameters.AddWithValue("Position", entity.Position);
            parameters.AddWithValue("Relation", entity.Relation);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddWithValue("CheckerID", entity.CheckerID);
            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ALT_PHONEVERIFICATION, parameters);
            return (int)parameters["@Result"].Value;
        }

        public int SaveSiteVerification(T_PL_SiteVerification entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("CustID", entity.CustID);
            parameters.AddWithValue("SiteAddress", entity.SiteAddress);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddWithValue("CheckerID", entity.CheckerID);
            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ALT_SITEVERIFICATION, parameters);
            return (int)parameters["@Result"].Value;
        }

        public int SaveHouseVerification(T_PL_HouseVerification entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("CustID", entity.CustID);
            parameters.AddWithValue("HouseAddress", entity.HouseAddress);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddWithValue("CheckerID", entity.CheckerID);
            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ALT_HOUSEVERIFICATION, parameters);
            return (int)parameters["@Result"].Value;
        }

        public int SaveExternalVerification(T_PL_ExternalVerification entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("CustID", entity.CustID);
            parameters.AddWithValue("HasSocialSecurity", entity.HasSocialSecurity);
            parameters.AddWithValue("PensionStatus", entity.PensionStatus);
            parameters.AddWithValue("PensionAmount", entity.PensionAmount);
            parameters.AddWithValue("PensionNumber", entity.PensionNumber);
            parameters.AddWithValue("TaxesStatus", entity.TaxesStatus);
            parameters.AddWithValue("CreditStatus", entity.CreditStatus);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddWithValue("CheckerID", entity.CheckerID);
            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ALT_EXTERNALVERIFICATION, parameters);
            return (int)parameters["@Result"].Value;
        }

        public bool SaveVerificationRecord(T_PL_VerificationRecord entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", entity.CustID);
            parameters.AddWithValue("VerifiedPhone", entity.VerifiedPhone);
            parameters.AddWithValue("VerifiedInternet", entity.VerifiedInternet);
            parameters.AddWithValue("Verified114", entity.Verified114);
            parameters.AddWithValue("VerifiedOther", entity.VerifiedOther);
            parameters.AddWithValue("VerifiedOtherRemark", entity.VerifiedOtherRemark);
            parameters.AddWithValue("PhoneReason", entity.PhoneReason);
            parameters.AddWithValue("PhoneResult", entity.PhoneResult);
            parameters.AddWithValue("VerifiedSite", entity.VerifiedSite);
            parameters.AddWithValue("SiteReason", entity.SiteReason);
            parameters.AddWithValue("SiteResult", entity.SiteResult);
            parameters.AddWithValue("VerifiedHouse", entity.VerifiedHouse);
            parameters.AddWithValue("HouseReason", entity.HouseReason);
            parameters.AddWithValue("HouseResult", entity.HouseResult);
            parameters.AddWithValue("VerifiedExternal", entity.VerifiedExternal);
            parameters.AddWithValue("ExternalReason", entity.ExternalReason);
            parameters.AddWithValue("ExternalResult", entity.ExternalResult);
            parameters.AddWithValue("VerifiedWorking", entity.VerifiedWorking);
            parameters.AddWithValue("WorkingReason", entity.WorkingReason);
            parameters.AddWithValue("WorkingResult", entity.WorkingResult);

            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_VERIFICATIONRECORD, parameters) > 0 ? true : false;
        }

        //PROC_保存工作场所核实信息

        public int SaveWorkingVerification(T_PL_WorkingVerification Entity) {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", Entity.TID);
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("WorkingAddress", Entity.WorkingAddress);
            parameters.AddWithValue("Remarks", Entity.Remarks);
            parameters.AddWithValue("CheckerID", Entity.CheckerID);
            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ALT_WORKINGVERIFICATION, parameters);
            return (int)parameters["@Result"].Value;
        
        }

        public bool DeletePhoneVerification(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DEL_PHONEVERIFICATION, parameters) >0 ? true : false;
        }

        public bool DeleteSiteVerification(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DEL_SITEVERIFICATION, parameters) > 0 ? true : false;
        }

        public bool DeleteHouseVerification(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DEL_HOUSEVERIFICATION, parameters) > 0 ? true : false;
        }

        public bool DeleteExternalVerification(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DEL_EXTERNALVERIFICATION, parameters) > 0 ? true : false;
        }

        public bool DeleteWorkingVerification(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DEL_WORKINGVERIFICATION, parameters) > 0 ? true : false;
        }
        #endregion

        #region "TOPUP第一审批"
        public CommonTResult<T_PL_TopupUploadMaker> GetTopupUploadLoan(string AppID)
        {
            CommonTResult<T_PL_TopupUploadMaker> result = new CommonTResult<T_PL_TopupUploadMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", new Guid(AppID));

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_TopupUploadMaker>(
                CommandType.StoredProcedure, SPNames.PL_GET_TOPUPLOADLOAN, new T_PL_TopupUploadMakerMapper<T_PL_TopupUploadMaker>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_VerificationRecord> GetVerificationRecord(string AppID, string CustID)
        {
            CommonTResult<T_PL_VerificationRecord> result = new CommonTResult<T_PL_VerificationRecord>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", new Guid(AppID));
            parameters.AddWithValue("CustID", new Guid(CustID));

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_VerificationRecord>(
                CommandType.StoredProcedure, SPNames.PL_GET_VERIFICATIONRECORD, new T_PL_VerificationRecordMapper<T_PL_VerificationRecord>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_LoanApproval> GetLoanApproval(string AppID, int StageID)
        {
            CommonTResult<T_PL_LoanApproval> result = new CommonTResult<T_PL_LoanApproval>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", new Guid(AppID));
            parameters.AddWithValue("StageID", StageID);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_LoanApproval>(
                CommandType.StoredProcedure, SPNames.PL_GET_LOANAPPROVAL, new T_PL_LoanApprovalMapper<T_PL_LoanApproval>(), parameters);
            return result;
        }

        #endregion       
    }
}
