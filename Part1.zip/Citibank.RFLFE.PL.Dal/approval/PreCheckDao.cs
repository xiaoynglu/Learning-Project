﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;


namespace Citibank.RFLFE.PL.Dal.approval
{
    public class PreCheckDao : AdoDaoSupport, IPreCheckDao
    {
        #region "预批与核实" 
        public CommonTResult<GuarantorPhoneVerification> GetGuarantorPhoneVerification(string appId)
        {
            CommonTResult<GuarantorPhoneVerification> result = new CommonTResult<GuarantorPhoneVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", appId);

            result.ResultList = AdoTemplate.QueryWithRowMapper<GuarantorPhoneVerification>(
                CommandType.StoredProcedure, SPNames.PL_GetGuarantorByAppId, new GuarantorPhoneVerificationMapper<GuarantorPhoneVerification>(), parameters);
            return result;
        }
        public CommonTResult<BorrowerCollateralDetail> GetBorrowerCollateralDetail(string appId)
        {
            CommonTResult<BorrowerCollateralDetail> result = new CommonTResult<BorrowerCollateralDetail>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppId", new Guid(appId));

            result.ResultList = AdoTemplate.QueryWithRowMapper<BorrowerCollateralDetail>(
                CommandType.StoredProcedure, SPNames.PL_GetCollateralByAppId, new BorrowerCollateralDetailMapper<BorrowerCollateralDetail>(), parameters);
            return result;
          
        }
        public CommonTResult<T_PL_OralAppraisal> GetOralAppraisal(int limit, int start, Guid appID)
        {
            CommonTResult<T_PL_OralAppraisal> result = new CommonTResult<T_PL_OralAppraisal>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appID);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_OralAppraisal>(CommandType.StoredProcedure,
                SPNames.PL_GET_ORALAPPRAISALS, new T_PL_OralAppraisalMapper<T_PL_OralAppraisal>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }
        public int SaveOralAppraisal(T_PL_OralAppraisal entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("CompanyID", entity.CompanyID);
            parameters.AddWithValue("AcceptDate", entity.AcceptDate);
            parameters.AddWithValue("RequestDate", entity.RequestDate);
            parameters.AddWithValue("Fee", entity.Fee);
            parameters.AddWithValue("Price", entity.Price);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddWithValue("CreateID", entity.CreateID);
            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ALT_ORALAPPRAISAL, parameters);
            return (int)parameters["@Result"].Value;
        }
        public int SaveOralAppraisalPrice(T_PL_OralAppraisal entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("Price", entity.Price);
            parameters.AddWithValue("CreateID", entity.CreateID);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_ORALAPPRAISALPRICE, parameters);
        }
        public bool DeleteOralAppraisal(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DEL_ORALAPPRAISAL, parameters) > 0 ? true : false;
        }
        public int SaveBorrowerCollateralDetail(BorrowerCollateralDetail bcd)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", bcd.T_PL_Collateral.AppID);
            parameters.AddWithValue("Province", bcd.T_PL_Collateral.Province);
            parameters.AddWithValue("City", bcd.T_PL_Collateral.City);
            parameters.AddWithValue("Region", bcd.T_PL_Collateral.Region);
            parameters.AddWithValue("Address", bcd.T_PL_Collateral.Address);
            parameters.AddWithValue("PostCode", bcd.T_PL_Collateral.PostCode);
            parameters.AddWithValue("CurrentStatus", bcd.T_PL_Collateral.CurrentStatus);
            parameters.AddWithValue("CompletedDate", bcd.T_PL_Collateral.CompletedDate);
            parameters.AddWithValue("LandArea", bcd.T_PL_Collateral.LandArea);
            parameters.AddWithValue("CollateralType", bcd.T_PL_Collateral.CollateralType);
            parameters.AddWithValue("RentRemainingDate", bcd.T_PL_Collateral.RentRemainingDate);
            parameters.AddWithValue("LandUsingYear", bcd.T_PL_Collateral.LandUsingYear);
            parameters.AddWithValue("HouseValue", bcd.T_PL_Collateral.HouseValue);
            parameters.AddWithValue("HouseAge", bcd.T_PL_Collateral.HouseAge);
            parameters.AddWithValue("SoilUsingYear", bcd.T_PL_Collateral.SoilUsingYear);
            parameters.AddWithValue("TotalPrice", bcd.T_PL_Collateral.TotalPrice);

            parameters.AddWithValue("IsPartialMortgage", bcd.T_PL_Loan.IsPartialMortgage);

            parameters.AddWithValue("TID", bcd.T_PL_FormalAppraisal.TID);
            parameters.AddWithValue("Price", bcd.T_PL_FormalAppraisal.Price);

            parameters.AddWithValue("CustDeclare", bcd.T_PL_MortgageCognizance.CustDeclare);
            parameters.AddWithValue("ConfirmCustDeclare", bcd.T_PL_MortgageCognizance.ConfirmCustDeclare);
            parameters.AddWithValue("HouseBureau", bcd.T_PL_MortgageCognizance.HouseBureau);
            parameters.AddWithValue("ConfirmHouseBureau", bcd.T_PL_MortgageCognizance.ConfirmHouseBureau);
            parameters.AddWithValue("PBOC", bcd.T_PL_MortgageCognizance.PBOC);
            parameters.AddWithValue("ConfirmPBOC", bcd.T_PL_MortgageCognizance.ConfirmPBOC);
            parameters.AddWithValue("TotalMoCount", bcd.T_PL_MortgageCognizance.TotalMoCount);
            parameters.AddWithValue("ConfirmTotalMoCount", bcd.T_PL_MortgageCognizance.ConfirmTotalMoCount);
            parameters.AddWithValue("PBOC_Unliquidated", bcd.T_PL_MortgageCognizance.PBOC_Unliquidated);
            parameters.AddWithValue("ConfirmPBOC_Unliquidated", bcd.T_PL_MortgageCognizance.ConfirmPBOC_Unliquidated);
            parameters.AddWithValue("PBOC_UnliquidatedMatch", bcd.T_PL_MortgageCognizance.PBOC_UnliquidatedMatch);
            parameters.AddWithValue("ConfirmPBOC_UnliquidatedMatch", bcd.T_PL_MortgageCognizance.ConfirmPBOC_UnliquidatedMatch);
            parameters.AddWithValue("PBOC_SettlementMatch", bcd.T_PL_MortgageCognizance.PBOC_SettlementMatch);
            parameters.AddWithValue("ConfirmPBOC_SettlementMatch", bcd.T_PL_MortgageCognizance.ConfirmPBOC_SettlementMatch);
            parameters.AddWithValue("TotalMoCount_Orgin", bcd.T_PL_MortgageCognizance.TotalMoCount_Orgin);
            parameters.AddWithValue("ConfirmTotalMoCount_Orgin", bcd.T_PL_MortgageCognizance.ConfirmTotalMoCount_Orgin);

            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ALT_BORROWERCOLLATERALDETAIL, parameters);
            return (int)parameters["@Result"].Value;
        }
        public bool SavePhoneVerificationRecord(T_PL_VerificationRecord entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", entity.CustID);
            parameters.AddWithValue("VerifiedPhone", entity.VerifiedPhone);
            parameters.AddWithValue("VerifiedInternet", entity.VerifiedInternet);
            parameters.AddWithValue("Verified114", entity.Verified114);
            parameters.AddWithValue("VerifiedOther", entity.VerifiedOther);
            parameters.AddWithValue("VerifiedOtherRemark", entity.VerifiedOtherRemark);
            parameters.AddWithValue("PhoneReason", entity.PhoneReason);
            //parameters.AddWithValue("PhoneResult", entity.PhoneResult);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_PHONEVERIFICATIONRECORD, parameters) > 0 ? true : false;
        }
        #endregion


        public CommonTResult<T_PL_RunResult> GetRunResultByAppId(string appId)
        {
            CommonTResult<T_PL_RunResult> result = new CommonTResult<T_PL_RunResult>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppId", new Guid(appId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_RunResult>(
                CommandType.StoredProcedure, SPNames.PL_GetRunResultByAppId, new T_PL_RunResultMapper<T_PL_RunResult>(), parameters);
            return result;
        }


        public CommonTResult<T_PL_CRDup> GetCRDupByAppId(string appId)
        {
            CommonTResult<T_PL_CRDup> result = new CommonTResult<T_PL_CRDup>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppId", new Guid(appId));

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_CRDup>(
                CommandType.StoredProcedure, SPNames.PL_GetCRDupByAppId, new T_PL_CRDupMapper<T_PL_CRDup>(), parameters);
            return result;
        }


        public bool SavePreCheckLTVDetail(T_PL_Collateral Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("BaseLTV", Entity.BaseLTV);
            parameters.AddWithValue("ReducedLTV", Entity.ReducedLTV);
            parameters.AddWithValue("MaxAllowedLTV", Entity.MaxAllowedLTV);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SavePreCheckLTVDetail, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }


        public DataSet GetCustomersAndHouseBureauByAppID(string appId)
        {
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_GetCustomersAndHouseBureauByAppID, parameters);
            return ds;
        }


        public CommonTResult<T_PL_Customers> GetHouseBureauObjectsListByAppId(string appId)
        {
            CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppId", new Guid(appId));

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(
                CommandType.StoredProcedure, SPNames.PL_GetHouseBureauObjectsListByAppId, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_MoHouseBureau> GetHouseBureauListByAppId(string appId)
        {
            CommonTResult<T_PL_MoHouseBureau> result = new CommonTResult<T_PL_MoHouseBureau>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppId", new Guid(appId));

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_MoHouseBureau>(
                CommandType.StoredProcedure, SPNames.PL_GetHouseBureauListByAppId, new T_PL_MoHouseBureauMapper<T_PL_MoHouseBureau>(), parameters);
            return result;
        }


        public T_PL_Collateral GetHouseBurueauInfoByAppId(string appId)
        {
            T_PL_Collateral result = new T_PL_Collateral();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_GetHouseBurueauInfoByAppId, parameters);
            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0) {
                result.NeedCheckHouseBureau = ds.Tables[0].Rows[0][0] == System.DBNull.Value ? false : !(Boolean)ds.Tables[0].Rows[0][0];
                result.HouseBureauRemarks = ds.Tables[0].Rows[0][1].ToString();
            }
            return result;
        }

        public bool SaveHouseBureauObject(T_PL_MoHouseBureau Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", Entity.TID);
            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("PropertyValue", Entity.PropertyValue);
            parameters.AddWithValue("TotalPropertyValue", Entity.TotalPropertyValue);
            parameters.AddWithValue("Remarks", Entity.Remarks);
            parameters.AddWithValue("CreateID", Entity.CreateID);
            parameters.AddWithValue("UpdateID", Entity.UpdateID);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveHouseBureauObject, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool DeleteHouseBureauObject(string tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteHouseBureauObject, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }


        public bool SaveHouseBureau(string appId, string needCheckHouseBureau, string houseBureauRemarks)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddWithValue("NeedCheckHouseBureau", needCheckHouseBureau == "true" ? "0" : "1");
            parameters.AddWithValue("HouseBureauRemarks", houseBureauRemarks);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveHouseBureau, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }


        public CommonTResult<T_PL_CRPersonVel> GetFraudVelocity(string appId)
        {
            CommonTResult<T_PL_CRPersonVel> result = new CommonTResult<T_PL_CRPersonVel>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", new Guid(appId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_CRPersonVel>(
                CommandType.StoredProcedure, SPNames.PL_GetFraudVelocityList, new T_PL_CRPersonVelMapper<T_PL_CRPersonVel>(), parameters);
            return result;
        }


        public CommonTResult<T_PL_CRVel> GetVelocityCheck(string personId)
        {
            CommonTResult<T_PL_CRVel> result = new CommonTResult<T_PL_CRVel>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("PersonId", personId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_CRVel>(
                CommandType.StoredProcedure, SPNames.PL_GetVelocityCheck, new T_PL_CRVelMapper<T_PL_CRVel>(), parameters);
            return result;
        }


        public String GetLastRACbyApp(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);            
            parameters.AddOut("Result", DbType.String,100);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetLastRACByAppID, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? "" : parameters["@Result"].Value.ToString();
        }


        public List<string> ShowVerifiedDetailsItems(string custId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            var phoneResult = "";
            var siteResult = "";
            var houseResult = "";
            var externalResult = "";
            List<String> resultList = new List<string>();
            parameters.AddWithValue("CustID", custId);
            parameters.AddOut("PhoneResult", DbType.String, 100);
            parameters.AddOut("SiteResult", DbType.String, 100);
            parameters.AddOut("HouseResult", DbType.String, 100);
            parameters.AddOut("ExternalResult", DbType.String, 100);
            parameters.AddOut("WorkingResult", DbType.String, 100);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ShowVerifiedDetailsItemsByAppID, parameters);
            phoneResult = parameters["@PhoneResult"].Value == System.DBNull.Value ? "" : parameters["@PhoneResult"].Value.ToString();
            siteResult = parameters["@SiteResult"].Value == System.DBNull.Value ? "" : parameters["@SiteResult"].Value.ToString();
            houseResult = parameters["@HouseResult"].Value == System.DBNull.Value ? "" : parameters["@HouseResult"].Value.ToString();
            externalResult = parameters["@ExternalResult"].Value == System.DBNull.Value ? "" : parameters["@ExternalResult"].Value.ToString();
            externalResult = parameters["@WorkingResult"].Value == System.DBNull.Value ? "" : parameters["@WorkingResult"].Value.ToString();
            resultList.Add(phoneResult=="0"?"false":"true");
            resultList.Add(siteResult == "0" ? "false" : "true");
            resultList.Add(houseResult == "0" ? "false" : "true");
            resultList.Add(externalResult == "0" ? "false" : "true");
            return resultList;
        }


        public CommonTResult<T_PL_PhoneVerification> GetAllPhoneVerificationByAppID(string appId)
        {
            CommonTResult<T_PL_PhoneVerification> result = new CommonTResult<T_PL_PhoneVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_PhoneVerification>(CommandType.StoredProcedure,
                SPNames.PL_GetAllPhoneVerificationByAppID, new T_PL_PhoneVerificationMapper<T_PL_PhoneVerification>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_SiteVerification> GetAllSiteVerificationByAppID(string appId)
        {
            CommonTResult<T_PL_SiteVerification> result = new CommonTResult<T_PL_SiteVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_SiteVerification>(CommandType.StoredProcedure,
                SPNames.PL_GetAllSiteVerificationByAppID, new T_PL_SiteVerificationMapper<T_PL_SiteVerification>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_HouseVerification> GetAllHouseVerificationByAppID(string appId)
        {
            CommonTResult<T_PL_HouseVerification> result = new CommonTResult<T_PL_HouseVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_HouseVerification>(CommandType.StoredProcedure,
                SPNames.PL_GetAllHouseVerificationByAppID, new T_PL_HouseVerificationMapper<T_PL_HouseVerification>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_ExternalVerification> GetAllExternalVerificationByAppID(string appId)
        {
            CommonTResult<T_PL_ExternalVerification> result = new CommonTResult<T_PL_ExternalVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_ExternalVerification>(CommandType.StoredProcedure,
                SPNames.PL_GetAllExternalVerificationByAppID, new T_PL_ExternalVerificationMapper<T_PL_ExternalVerification>(), parameters);
            return result;
        }


        public CommonTResult<CompareBureauInfoCustInfoView> GetCompareBureauInfoCustInfoByAppID(string appId)
        {
            CommonTResult<CompareBureauInfoCustInfoView> result = new CommonTResult<CompareBureauInfoCustInfoView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<CompareBureauInfoCustInfoView>(CommandType.StoredProcedure,
                SPNames.PL_GetCompareBureauInfoCustInfoByAppID, new CompareBureauInfoCustInfoViewMapper<CompareBureauInfoCustInfoView>(), parameters);
            return result;
        }


        public CommonTResult<T_PL_VerificationRecord> GetVerificationDetailsListByAppID(string appId)
        {
            CommonTResult<T_PL_VerificationRecord> result = new CommonTResult<T_PL_VerificationRecord>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_VerificationRecord>(CommandType.StoredProcedure,
                SPNames.PL_GetVerificationDetailsListByAppID, new T_PL_VerificationRecordMapper<T_PL_VerificationRecord>(), parameters);
            return result;
        }


        public T_PL_MortgageCognizance GetMoCheck(string appId)
        {
            CommonTResult<T_PL_MortgageCognizance> result = new CommonTResult<T_PL_MortgageCognizance>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_MortgageCognizance>(CommandType.StoredProcedure,
                SPNames.PL_GetMoCheckByAppID, new T_PL_MortgageCognizanceMapper<T_PL_MortgageCognizance>(), parameters);
            if (result.ResultList.Count > 0) {
                return result.ResultList.FirstOrDefault();
            }
            return null;
        }


        public T_PL_MortgageCognizance InitMoCheck(string appId)
        {
            T_PL_MortgageCognizance result = new T_PL_MortgageCognizance();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_InitMoCheckByAppID, parameters);
            if (ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
            {
                result.CustDeclare = ds.Tables[0].Rows[0][0] == System.DBNull.Value ? 0 : (Int32)ds.Tables[0].Rows[0][0];
                result.ConfirmCustDeclare = ds.Tables[0].Rows[0][1] == System.DBNull.Value ? 0 : (Int32)ds.Tables[0].Rows[0][1];
                result.HouseBureau = ds.Tables[0].Rows[0][2] == System.DBNull.Value ? 0 : (Int32)ds.Tables[0].Rows[0][2];
                result.ConfirmHouseBureau = ds.Tables[0].Rows[0][3] == System.DBNull.Value ? 0 : (Int32)ds.Tables[0].Rows[0][3];
                result.HouseBureauChecked = ds.Tables[0].Rows[0][4] == System.DBNull.Value ? false : ((Boolean)ds.Tables[0].Rows[0][4]);
            }
            return result;
        }


        public Dictionary<T_PL_Customers, List<T_PL_FamilyMembers>> GetMoCustomers(string appId)
        {
            Dictionary<T_PL_Customers, List<T_PL_FamilyMembers>> result = new Dictionary<T_PL_Customers, List<T_PL_FamilyMembers>>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddWithValue("CustId", "");          
            DataSet customersDT = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_GetCustomers, parameters);
            if (customersDT.Tables.Count > 0 && customersDT.Tables[0].Rows.Count > 0) {
                for (var i=0;i< customersDT.Tables[0].Rows.Count;i++) {
                    T_PL_Customers customers = new T_PL_Customers();
                    List<T_PL_FamilyMembers> familyMembersList = new List<T_PL_FamilyMembers>();
                    customers.CustID = customersDT.Tables[0].Rows[i][0] != System.DBNull.Value ? customersDT.Tables[0].Rows[i][0].ToString() : "";
                    customers.IDNo = customersDT.Tables[0].Rows[i][8]!= System.DBNull.Value ? customersDT.Tables[0].Rows[i][8].ToString() : "";
                    customers.FullName = customersDT.Tables[0].Rows[i][5] != System.DBNull.Value ? customersDT.Tables[0].Rows[i][5].ToString() : "";
                    IDbParameters parameters2 = AdoTemplate.CreateDbParameters();
                    parameters2.AddWithValue("CustId", appId);
                    DataSet familyMembersDT = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetFamilyMembersByCustId, parameters2);
                    if (familyMembersDT.Tables.Count > 0 && familyMembersDT.Tables[0].Rows.Count > 0) {
                        for (var j= 0; j < familyMembersDT.Tables[0].Rows.Count; j++)
                        {
                            T_PL_FamilyMembers familyMember = new T_PL_FamilyMembers();
                            familyMember.CustID = familyMembersDT.Tables[0].Rows[i][2] != System.DBNull.Value ? new Guid(familyMembersDT.Tables[0].Rows[i][2].ToString()) : new Guid("00000000-0000-0000-0000-000000000000");
                            familyMember.Name = familyMembersDT.Tables[0].Rows[i][4] != System.DBNull.Value ? familyMembersDT.Tables[0].Rows[i][4].ToString() : "";
                            familyMember.IDNo = familyMembersDT.Tables[0].Rows[i][7] != System.DBNull.Value ? familyMembersDT.Tables[0].Rows[i][7].ToString() : "";
                            familyMembersList.Add(familyMember);
                        }
                    }
                    result.Add(customers, familyMembersList);
                }
            }
            return result;
        }

        public DataSet GetPBOCLocal(string appId, string idNo)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddWithValue("IDNO", idNo);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_GetPBOCLocalByAppIDAndIDNo, parameters);
            return ds;
        }


        public DataSet GetPBOC_Loan( string idNo, string importDate)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("IDNO", idNo);
            parameters.AddWithValue("ImportDate", importDate);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_GetLoanByAppIdAndImportDate, parameters);
            return ds;
        }

        public CommonTResult<T_PL_WorkingVerification> GetAllWorkingVerificationByAppID(string appId)
        {
            CommonTResult<T_PL_WorkingVerification> result = new CommonTResult<T_PL_WorkingVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_WorkingVerification>(CommandType.StoredProcedure,
                SPNames.PL_GetAllWorkingVerificationByAppID, new T_PL_WorkingVerificationMapper<T_PL_WorkingVerification>(), parameters);
            return result;
        }


        public bool SaveMortgageCognizance(T_PL_MortgageCognizance entity)
        {
            CommonTResult<T_PL_WorkingVerification> result = new CommonTResult<T_PL_WorkingVerification>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("ConfirmCustDeclare", entity.ConfirmCustDeclare);
            parameters.AddWithValue("ConfirmHouseBureau", entity.ConfirmHouseBureau);
            parameters.AddWithValue("ConfirmPBOC_Unliquidated", entity.ConfirmPBOC_Unliquidated);
            parameters.AddWithValue("ConfirmPBOC_UnliquidatedMatch", entity.ConfirmPBOC_UnliquidatedMatch);
            parameters.AddWithValue("ConfirmTotalMoCount",entity.ConfirmTotalMoCount);
            parameters.AddWithValue("ConfirmPBOC", entity.ConfirmPBOC);
            parameters.AddWithValue("ConfirmPBOC_SettlementMatch", entity.ConfirmPBOC_SettlementMatch);
            parameters.AddWithValue("ConfirmTotalMoCount_Orgin", entity.ConfirmTotalMoCount_Orgin);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveMortgageCognizance, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }
    }
}
