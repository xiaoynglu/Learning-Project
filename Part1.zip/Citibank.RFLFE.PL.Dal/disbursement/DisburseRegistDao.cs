﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Transaction.Interceptor;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;
using System.Reflection;

namespace Citibank.RFLFE.PL.Dal.disbursement
{
    public class DisburseRegistDao : AdoDaoSupport, IDisburseRegistDao
    {
        public string GetALSEmployerCD(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddOut("Result",DbType.String,50 );
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_GetALSEmployerCD, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : (string)parameters["@Result"].Value.ToString();
        }

        public Dictionary<string, string> GetDetails(string appid)
        {            
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appid);
            DataTable dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetBorrowTypeANDIDNoByAppID, parameters);
            DataTable dt1 = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetRemarkByAppID, parameters);
            DataTable dt2 = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetProdPayTypeAndAccOpenDateByAppID, parameters);          
            Dictionary<string, string> dicParamPackage = new Dictionary<string, string>();
            foreach (DataRow dr in dt.Rows)
            {
                dicParamPackage.Add(dr["BorrowType"].ToString(),dr["IDNo"].ToString());
            }
            if (dt1 != null && dt1.Rows.Count > 0)
            {
                dicParamPackage.Add("remarks", dt1.Rows[0]["remarks"].ToString());
            }
            if (dt2 != null && dt2.Rows.Count > 0) {
                dicParamPackage.Add("prodname", dt2.Rows[0]["ProdName"].ToString());
                dicParamPackage.Add("paytype", dt2.Rows[0]["PayType"].ToString());
                dicParamPackage.Add("accopendate", dt2.Rows[0]["AccOpenDate"].ToString());
            }            
            return dicParamPackage;
        }

        public bool DoProcess(string islock,string appid,string soeid,string appno,string stageid)
        { 
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            IDbParameters parameters1 = AdoTemplate.CreateDbParameters();
            IDbParameters parameters3 = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            parameters1.AddWithValue("AppId", appid);
            parameters1.AddOut("Result", DbType.Int32);
            parameters3.AddWithValue("AppId", appid);
            parameters3.AddWithValue("CustId", "");
            if (islock == "N" && appno.Contains("T"))
            {
                AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_SaveLoanDate, parameters);
            }
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_IsExitT_PL_EclipseHandover, parameters1);
            int icount = parameters1["@Result"].Value == System.DBNull.Value ? 0 : Int32.Parse(parameters1["@Result"].Value.ToString()); ;
            if (icount == 0)
            {
                CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
                result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(CommandType.StoredProcedure,
                     SPNames.PL_GetCustomers, new T_PL_CustomersMapper<T_PL_Customers>(), parameters3);
                IList<T_PL_Customers> dtcust = result.ResultList;
                foreach (T_PL_Customers drcustitem in dtcust)
                {
                    CommonTResult<T_PL_CustomerContact> CustomerContactList = new CommonTResult<T_PL_CustomerContact>();
                  
                    IDbParameters parameters2 = AdoTemplate.CreateDbParameters();
                    parameters2.AddWithValue("CustId", new Guid(drcustitem.CustID));
                    CustomerContactList.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_CustomerContact>(CommandType.StoredProcedure, SPNames.PL_GetCustomerContactByCustId, new T_PL_CustomerContactMapper<T_PL_CustomerContact>(), parameters2);
                    IList<T_PL_CustomerContact> dtcontact = CustomerContactList.ResultList;
                    T_PL_CustomerContact contactentity = new T_PL_CustomerContact();
                    if (dtcontact.Count > 0)
                    {
                        contactentity = dtcontact[0];
                        InitEclipse(appid, contactentity, drcustitem, stageid);
                    }
                    else
                    {
                        InitEclipse(appid, contactentity, drcustitem, stageid);
                    }
                }
                T_PL_Guarantors gua = getGuarantor(appid);
                if (gua != null && gua.Name != string.Empty)
                {
                    InitGuarantorEclipse(appid,stageid);
                }

                IList<T_PL_Mortgagors> Mor = GetMortgagorNumber(appid);
                if (Mor.Count > 0)
                {
                    InitMortgagorEclipse(appid,stageid);
                }
            }
            return true;
        }

        public DataTable GetFeeCode(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            return AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetFeeCode, parameters);
        }
        
        public Dictionary<string, string> GetFeeData(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            parameters.AddOut("ProcFee", DbType.Decimal);
            parameters.AddOut("LegalFee", DbType.Decimal);
            parameters.AddOut("MainFee", DbType.Decimal);
            parameters.AddOut("ValFee", DbType.Decimal);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetFeeData, parameters);
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic.Add("ProcFee", parameters["@ProcFee"].Value == System.DBNull.Value ? string.Empty : parameters["@ProcFee"].Value.ToString());
            dic.Add("LegalFee", parameters["@LegalFee"].Value == System.DBNull.Value ? string.Empty : parameters["@LegalFee"].Value.ToString());
            dic.Add("MaintainFee", parameters["@MainFee"].Value == System.DBNull.Value ? string.Empty : parameters["@MainFee"].Value.ToString());
            dic.Add("ValFee", parameters["@ValFee"].Value == System.DBNull.Value ? string.Empty : parameters["@ValFee"].Value.ToString());
            return dic;
        }

        public CommonTResult<T_PL_CLMSHandover> GetCLMS(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appId);
            CommonTResult<T_PL_CLMSHandover> result = new CommonTResult<T_PL_CLMSHandover>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_CLMSHandover>(CommandType.StoredProcedure, SPNames.PL_GetCLMS, new T_PL_CLMSHandoverMapper<T_PL_CLMSHandover>(), parameters);
            return result;
        }

        public decimal GetCallFullValByAppId(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_GetCallFullVal, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? Decimal.Zero : Decimal.Parse(parameters["@Result"].Value.ToString());
        }

        public string GetOwnerByAppID(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_GetOwnerByAppID, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public DataTable GetCollateral(string appid)
        {
            T_PL_Collateral collateral = new T_PL_Collateral();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            return AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetCollateralByAppId, parameters);
        }

        public DataTable GetParamForCLMS(string appid)
        {
            T_PL_Collateral collateral = new T_PL_Collateral();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            return AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetParamForCLMSByAppId, parameters);
        }

        public CommonTResult<T_PL_EclipseHandover> GetEclipse(string AppId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", AppId);
            parameters.AddWithValue("IDNum", "00000000-0000-0000-0000-000000000000");
            CommonTResult<T_PL_EclipseHandover> result = new CommonTResult<T_PL_EclipseHandover>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_EclipseHandover>(CommandType.StoredProcedure, SPNames.PL_GetEclipse,new T_PL_EclipseHandoverMapper<T_PL_EclipseHandover>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_EclipseHandover> GetEclipseByIDNum(string AppId,string itemid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", AppId);
            parameters.AddWithValue("IDNum", itemid);
            CommonTResult<T_PL_EclipseHandover> result = new CommonTResult<T_PL_EclipseHandover>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_EclipseHandover>(CommandType.StoredProcedure, SPNames.PL_GetEclipse, new T_PL_EclipseHandoverMapper<T_PL_EclipseHandover>(), parameters);
            return result;
        }

        public string GetProdCodeByAppId(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetProdCodeByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetLoanPurpose(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetLoanPurpose, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public Dictionary<string, string> GetAppProdDtlByAppId(string appId)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            var dt =AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetParamForCLMSByAppId, parameters);
            if (dt != null && dt.Rows.Count > 0)
            {
                dic.Add("CACSLocCode", dt.Rows[0]["CACSLocCode"].ToString());
                dic.Add("RateIndex", dt.Rows[0]["RateIndex"].ToString());
                dic.Add("CACSCityCode", dt.Rows[0]["CACSCityCode"].ToString());
                dic.Add("PRODID", dt.Rows[0]["PRODID"].ToString());
            }
            else
            {
                dic.Add("CACSLocCode", "");
                dic.Add("RateIndex", "");
                dic.Add("CACSCityCode", "");
                dic.Add("PRODID", "");
            }
            return dic;
        }

        public CommonTResult<T_PL_EclipseHandover> GetOscarByAppId(string AppId, string IDNum)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", AppId);
            parameters.AddWithValue("IDNum", IDNum);
            CommonTResult<T_PL_EclipseHandover> result = new CommonTResult<T_PL_EclipseHandover>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_EclipseHandover>(CommandType.StoredProcedure, SPNames.PL_GetEclipse,new T_PL_EclipseHandoverMapper<T_PL_EclipseHandover>(), parameters);
            return result;
        }

        public void InitMortgagorEclipse(string appid,string stageid)
        {
            IList<T_PL_Mortgagors> MorList = GetMortgagorNumber(appid);

            foreach(T_PL_Mortgagors Mor in MorList)
            {
                T_PL_EclipseHandover oscar = getMBOscarInfo(appid,stageid);
                oscar.SurName = Mor.Name.Substring(0, 1);
                oscar.FirstName = Mor.Name.Substring(1);
                int y = Convert.ToInt32(Mor.IDNo.Substring(6, 4));
                int m = Convert.ToInt32(Mor.IDNo.Substring(10, 2));
                int d = Convert.ToInt32(Mor.IDNo.Substring(12, 2));
                DateTime DOB = new DateTime(y, m, d);
                oscar.DOB = DOB.ToShortDateString();
                oscar.IDNum = Mor.IDNo;//IDType
                oscar.Prefix = Convert.ToInt32(Mor.IDNo.Substring(16, 1)) % 2 == 1 ? "先生" : "小姐";
                oscar.MomMaidenName = oscar.SurName;
                oscar.PPName = Mor.PinyinName;
                oscar.MaritalStatus = Mor.SpouseName == null || String.IsNullOrEmpty(Mor.SpouseName) ? "SINGLE" : "MARRIED";
                oscar.Gender = Convert.ToInt32(Mor.IDNo.Substring(16, 1)) % 2 == 1 ? "MALE" : "FEMALE";
                oscar.MobilePhone = Mor.MobileNumber;
                oscar.AreaCodeH = "";
                oscar.PhoneH = Mor.Telephone;
                oscar.Add1H = Mor.HouseStreet;
                oscar.ProvinceH = GetProvinceByCode(Mor.HouseProvince);
                oscar.CityDistrictH = GetCityByCode(Mor.HouseProvince,Mor.HouseCity)+Mor.HouseDistrict;
                oscar.PostCodeH = Mor.HousePostCode;

                oscar.AreaCodeO = "";
                oscar.PhoneO = "";
                oscar.Add1O = "";
                oscar.ProvinceO = "";
                oscar.CityDistrictO = "";
                oscar.PostCodeO = "";
                oscar.PhoneTypeC = "";
                oscar.CountryCodeC = "";
                oscar.AreaCodeC = "";
                oscar.PhoneC = "";
                oscar.ExtnC = "";
                oscar.Add1L = "";
                oscar.Add2L = "";
                oscar.Add3L = "";
                oscar.Add4L = "";
                oscar.ProvinceL = "";
                oscar.CityDistrictL = "";
                oscar.PostCodeL = "";
                oscar.CountryL = "";
                oscar.IndustryCode = "";
                oscar.SellerChineseName = "";
                oscar.SellerEngName = "";
                oscar.SellerGender = "";
                oscar.SellerIDNum = "";
                this.SaveEclipse(oscar);
            }
        }

        public IList<T_PL_Mortgagors> GetMortgagorNumber(string appid)
        {
            CommonTResult<T_PL_Mortgagors> result = new CommonTResult<T_PL_Mortgagors>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Mortgagors>(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetMortgagorNumberByAppId, new T_PL_MortgagorsMapper<T_PL_Mortgagors>(), parameters);
            return result.ResultList;
        }

        public Dictionary<string, string> GetCountPackage(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("APPID", appid);
            parameters.AddOut("borrowcount",DbType.Int32);
            parameters.AddOut("morcount", DbType.Int32);
            parameters.AddOut("Guacount", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_GetCountPackage, parameters);
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic.Add("borrowcount",parameters["@borrowcount"].Value.ToString());
            dic.Add("morcount", parameters["@morcount"].Value.ToString());
            dic.Add("Guacount", parameters["@Guacount"].Value.ToString());
            return dic;
        }

        public CustNOForDisburseView GetCustNOs(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("APPID", appid);
            parameters.AddOut("MBID", DbType.Guid);
            parameters.AddOut("MBNO", DbType.String,20);
            parameters.AddOut("CB1ID", DbType.Guid);
            parameters.AddOut("CB1NO", DbType.String, 20);
            parameters.AddOut("CB2ID", DbType.Guid);
            parameters.AddOut("CB2NO", DbType.String, 20);
            parameters.AddOut("MOR1ID", DbType.Guid);
            parameters.AddOut("MOR1NO", DbType.String, 20);
            parameters.AddOut("MOR2ID", DbType.Guid);
            parameters.AddOut("MOR2NO", DbType.String, 20);
            parameters.AddOut("MOR3ID", DbType.Guid);
            parameters.AddOut("MOR3NO", DbType.String, 20);
            parameters.AddOut("GUAID", DbType.Guid);
            parameters.AddOut("GUANO", DbType.String, 20);
            parameters.AddOut("RELNO", DbType.String, 50);            

            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_GetCustNOForDisburse, parameters);
            CustNOForDisburseView entity = new CustNOForDisburseView();
            entity.MBID = parameters["@MBID"].Value.ToString();
            entity.MBNO = parameters["@MBNO"].Value.ToString();
            entity.CB1ID = parameters["@CB1ID"].Value.ToString();
            entity.CB1NO = parameters["@CB1NO"].Value.ToString();
            entity.CB2ID = parameters["@CB2ID"].Value.ToString();
            entity.CB2NO = parameters["@CB2NO"].Value.ToString();
            entity.MOR1ID = parameters["@MOR1ID"].Value.ToString();
            entity.MOR1NO = parameters["@MOR1NO"].Value.ToString();
            entity.MOR2ID = parameters["@MOR2ID"].Value.ToString();
            entity.MOR2NO = parameters["@MOR2NO"].Value.ToString();
            entity.MOR3ID = parameters["@MOR3ID"].Value.ToString();
            entity.MOR3NO = parameters["@MOR3NO"].Value.ToString();
            entity.GUAID = parameters["@GUAID"].Value.ToString();
            entity.GUANO = parameters["@GUANO"].Value.ToString();
            entity.RelNO = parameters["@RELNO"].Value.ToString();

            return entity;
        }

        public string GetExpireDay(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetExpireDayByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public void SaveLineCollateralID(string appId, string lineId, string collateralId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("LineID", lineId);
            parameters.AddWithValue("CollateralID", collateralId);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_SaveCLMSInfor, parameters);
        }

        public CommonTResult<T_PL_EclipseHandover> ExportReport(string IDType,string appid)
        {
             IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("IDType", IDType);
            parameters.AddWithValue("appid", appid);
            CommonTResult<T_PL_EclipseHandover> result = new CommonTResult<T_PL_EclipseHandover>();
             result.ResultList=AdoTemplate.QueryWithRowMapper<T_PL_EclipseHandover>(CommandType.StoredProcedure, SPNames.PL_GetContentForDisburseExport, new T_PL_EclipseHandoverMapper<T_PL_EclipseHandover>(), parameters);
             return result;            
        }

        public DataTable GetALsShowInfo(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("APPID", appid);
            CommonTResult<ApplicationInofView> result = new CommonTResult<ApplicationInofView>();
            DataTable dt=AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetALsShowInfo,  parameters);
            return dt;            
        }

        public CommonTResult<ApplicationInofView> GetApplicationInof(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("APPID", appid);

            CommonTResult<ApplicationInofView> result=new CommonTResult<ApplicationInofView>();
            result.ResultList= AdoTemplate.QueryWithRowMapper<ApplicationInofView>(CommandType.StoredProcedure,SPNames.PL_GetApplicationInof,new ApplicationInofViewMapper<ApplicationInofView>(),parameters);
            return result;            
        }

        public object GetExpireDay(Guid appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetExpireDayByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ?  null : parameters["@Result"].Value;
        }

        public void InitGuarantorEclipse(string appid,string stageid)
        {
            T_PL_EclipseHandover oscar = getMBOscarInfo(appid,stageid);
            T_PL_Guarantors gua = getGuarantor(appid);
            oscar.SurName = gua.Name.Substring(0, 1);
            oscar.FirstName = gua.Name.Substring(1);
            int y = Convert.ToInt32(gua.IDNo.Substring(6, 4));
            int m = Convert.ToInt32(gua.IDNo.Substring(10, 2));
            int d = Convert.ToInt32(gua.IDNo.Substring(12, 2));
            DateTime DOB = new DateTime(y, m, d);
            oscar.DOB = DOB.ToShortDateString();
            oscar.IDNum = gua.IDNo;
            oscar.Prefix = "先生/小姐";
            oscar.MomMaidenName = oscar.SurName;
            oscar.PPName = gua.PinyinName;
            ////oscar.PPName = gua.GuarantorCnName;
            oscar.MaritalStatus = "";
            oscar.Gender = "";
            oscar.MobilePhone = gua.MobileNumber;
            oscar.AreaCodeH = gua.Telephone.Split('-')[0].Split('－')[0].ToString();
            oscar.PhoneH = gua.Telephone.Replace(oscar.AreaCodeH, "");
            oscar.AreaCodeO = gua.Telephone.Split('-')[0].Split('－')[0].ToString();
            oscar.PhoneO = gua.Telephone.Replace(oscar.AreaCodeH, "");
            oscar.Add1H = gua.HouseStreet;
            oscar.ProvinceH = GetProvinceByCode(gua.HouseProvince);            

            oscar.CityDistrictH = GetCityByCode(gua.HouseProvince, gua.HouseCity) + gua.HouseDistrict;
            oscar.PostCodeH = gua.HousePostCode;

            oscar.Add1O = gua.WorkingStreet;
            oscar.ProvinceO = GetProvinceByCode(gua.WorkingProvince);
            oscar.CityDistrictO = GetCityByCode(gua.WorkingProvince, gua.WorkingCity) + gua.WorkingDistrict;
            oscar.PostCodeO = gua.WorkingPostCode;
            oscar.PhoneTypeC = "";
            oscar.CountryCodeC = "";
            oscar.AreaCodeC = "";
            oscar.PhoneC = "";
            oscar.ExtnC = "";
            oscar.Add1L = "";
            oscar.Add2L = "";
            oscar.Add3L = "";
            oscar.Add4L = "";
            oscar.ProvinceL = "";
            oscar.CityDistrictL = "";
            oscar.PostCodeL = "";
            oscar.CountryL = "";
            oscar.IndustryCode = "";
            oscar.SellerChineseName = "";
            oscar.SellerEngName = "";
            oscar.SellerGender = "";
            oscar.SellerIDNum = "";

            this.SaveEclipse(oscar);
        }

        public void SaveEclipse(T_PL_EclipseHandover entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("SurName", entity.SurName);
            parameters.AddWithValue("FirstName", entity.FirstName);
            parameters.AddWithValue("DOB", entity.DOB);
            parameters.AddWithValue("IDType", entity.IDType);
            parameters.AddWithValue("IDNum", entity.IDNum);
            parameters.AddWithValue("CustSubType", entity.CustSubType);
            parameters.AddWithValue("Prefix", entity.Prefix);

            parameters.AddWithValue("MomMaidenName", entity.MomMaidenName);

            parameters.AddWithValue("PPName", entity.PPName);
            parameters.AddWithValue("MaritalStatus", entity.MaritalStatus);
            parameters.AddWithValue("Gender", entity.Gender);
            parameters.AddWithValue("MailingInstruction", entity.MailingInstruction);
            parameters.AddWithValue("HoldInstruction", entity.HoldInstruction);
            parameters.AddWithValue("CorrespondenceLanguage", entity.CorrespondenceLanguage);
            parameters.AddWithValue("SpokenLanguage", entity.SpokenLanguage);
            parameters.AddWithValue("IDExpiryDate", entity.IDExpiryDate);
            parameters.AddWithValue("IDExpiryYear", entity.IDExpiryYear);
            parameters.AddWithValue("IDExpiryMonth", entity.IDExpiryMonth);
            parameters.AddWithValue("IDExpiryDay", entity.IDExpiryDay);
            parameters.AddWithValue("Nationality", entity.Nationality);
            parameters.AddWithValue("PremanentResident", entity.PremanentResident);
            parameters.AddWithValue("Domicile", entity.Domicile);
            parameters.AddWithValue("WHTax", entity.WHTax);
            parameters.AddWithValue("TaxDomicile", entity.TaxDomicile);
            parameters.AddWithValue("VIPType", entity.VIPType);
            parameters.AddWithValue("Staff", entity.Staff);
            parameters.AddWithValue("FaxIndemnity", entity.FaxIndemnity);
            parameters.AddWithValue("CustomerDeceased", entity.CustomerDeceased);
            parameters.AddWithValue("PCBankingIndicator", entity.PCBankingIndicator);
            parameters.AddWithValue("CustomerDisabled", entity.CustomerDisabled);
            parameters.AddWithValue("SafeBox", entity.SafeBox);
            parameters.AddWithValue("RCCode", entity.RCCode);
            parameters.AddWithValue("AOCode", entity.AOCode);
            parameters.AddWithValue("BankAtWork", entity.BankAtWork);
            parameters.AddWithValue("Email1", entity.Email1);
            parameters.AddWithValue("OKtoMail1", entity.OKtoMail1);
            parameters.AddWithValue("MobilePhone", entity.MobilePhone);
            parameters.AddWithValue("PhoneTypeH", entity.PhoneTypeH);
            parameters.AddWithValue("CountryCodeH", entity.CountryCodeH);
            parameters.AddWithValue("AreaCodeH", entity.AreaCodeH);
            parameters.AddWithValue("PhoneH", entity.PhoneH);
            parameters.AddWithValue("ExtnH", entity.ExtnH);
            parameters.AddWithValue("PhoneTypeO", entity.PhoneTypeO);
            parameters.AddWithValue("CountryCodeO", entity.CountryCodeO);
            parameters.AddWithValue("AreaCodeO", entity.AreaCodeO);
            parameters.AddWithValue("PhoneO", entity.PhoneO);
            parameters.AddWithValue("ExtnO", entity.ExtnO);
            parameters.AddWithValue("PhoneTypeC", entity.PhoneTypeC);
            parameters.AddWithValue("CountryCodeC", entity.CountryCodeC);
            parameters.AddWithValue("AreaCodeC", entity.AreaCodeC);
            parameters.AddWithValue("PhoneC", entity.PhoneC);
            parameters.AddWithValue("ExtnC", entity.ExtnC);

            parameters.AddWithValue("MailAddInd", entity.MailAddInd);            
            parameters.AddWithValue("AddressTypeH", entity.AddressTypeH);

            parameters.AddWithValue("Add1H", entity.Add1H);
            parameters.AddWithValue("Add2H", entity.Add2H);
            parameters.AddWithValue("Add3H", entity.Add3H);
            parameters.AddWithValue("Add4H", entity.Add4H);
            parameters.AddWithValue("ProvinceH", entity.ProvinceH);
            parameters.AddWithValue("CityDistrictH", entity.CityDistrictH);
            parameters.AddWithValue("PostCodeH", entity.PostCodeH);
            parameters.AddWithValue("CountryH", entity.PostCodeH);
            parameters.AddWithValue("OKtoMailH", entity.OKtoMailH);
            
            parameters.AddWithValue("AddressTypeO", entity.AddressTypeO);

            parameters.AddWithValue("Add1O", entity.Add1O);
            parameters.AddWithValue("Add2O", entity.Add2O);
            parameters.AddWithValue("Add3O", entity.Add3O);
            parameters.AddWithValue("Add4O", entity.Add4O);
            parameters.AddWithValue("ProvinceO", entity.ProvinceO);
            parameters.AddWithValue("CityDistrictO", entity.CityDistrictO);
            parameters.AddWithValue("PostCodeO", entity.PostCodeO);
            parameters.AddWithValue("CountryO", entity.CountryO);
            parameters.AddWithValue("OKtoMailO", entity.OKtoMailO);

            parameters.AddWithValue("AddressTypeL", entity.AddressTypeL);

            parameters.AddWithValue("Add1L", entity.Add1L);
            parameters.AddWithValue("Add2L", entity.Add2L);
            parameters.AddWithValue("Add3L", entity.Add3L);
            parameters.AddWithValue("Add4L", entity.Add4L);
            parameters.AddWithValue("ProvinceL", entity.ProvinceL);
            parameters.AddWithValue("CityDistrictL", entity.CityDistrictL);
            parameters.AddWithValue("PostCodeL", entity.PostCodeL);
            parameters.AddWithValue("CountryL", entity.CountryL);
            parameters.AddWithValue("OKtoMailL", entity.OKtoMailL);
            parameters.AddWithValue("EqualtoMAdd", entity.EqualtoMAdd);

            parameters.AddWithValue("SourceOfWealth", entity.SourceOfWealth);

            parameters.AddWithValue("OccupationCodeKYC", entity.OccupationCodeKYC);
            parameters.AddWithValue("OccupationCodeEmployment", entity.OccupationCodeEmployment);
            parameters.AddWithValue("AnnualFundingRange", entity.AnnualFundingRange);
            parameters.AddWithValue("EmployerName", entity.EmployerName);
            parameters.AddWithValue("ApplicationNo", entity.ApplicationNo);
            parameters.AddWithValue("IndustryCode", entity.IndustryCode);

            parameters.AddWithValue("SellerChineseName", entity.SellerChineseName);
            parameters.AddWithValue("SellerEngName", entity.SellerEngName);
            parameters.AddWithValue("SellerGender", entity.SellerGender);
            parameters.AddWithValue("SellerIDNum", entity.SellerIDNum);
            parameters.AddWithValue("IDIssueDate", entity.IDIssueDate);
            parameters.AddWithValue("IDIssuePlace", entity.IDIssuePlace);

            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_InitEclipse, parameters);
        }

        public T_PL_EclipseHandover getMBOscarInfo(string appid,string stageid)
        {
            T_PL_Customers mapCust=new T_PL_Customers();
            T_PL_CustomerContact mapContact = new T_PL_CustomerContact();
            CommonTResult<T_PL_Customers> customersResult = new CommonTResult<T_PL_Customers>();
            CommonTResult<T_PL_CustomerContact> customerContactResult = new CommonTResult<T_PL_CustomerContact>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            IDbParameters parameter1 = AdoTemplate.CreateDbParameters();
            IDbParameters parameter2 = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            parameter2.AddWithValue("AppId", appid);
            parameter2.AddWithValue("CustId", "");
            customersResult.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(CommandType.StoredProcedure,
                SPNames.PL_GetCustomers, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            if (customersResult.ResultList.Count > 0) {
                mapCust = customersResult.ResultList.FirstOrDefault();
            }
            parameter1.AddWithValue("CustId", mapCust.CustID);
            customerContactResult.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_CustomerContact>(CommandType.StoredProcedure,
               SPNames.PL_GetCustomerContactByCustId, new T_PL_CustomerContactMapper<T_PL_CustomerContact>(), parameters);
            if (customerContactResult.ResultList.Count > 0) {
                mapContact = customerContactResult.ResultList.FirstOrDefault();
            }
            string soeId = this.GetSalesIdByAppID(appid);
            string agentCode = this.GetAgentCodeByAppId(appid);

            T_PL_EclipseHandover mapOscar = new T_PL_EclipseHandover();
            mapOscar.SurName = mapCust.FullName;
            mapOscar.FirstName = mapCust.FullName;
            mapOscar.DOB = mapCust.DOB.ToString("dd/MM/yyyy");
            mapOscar.IDType = "IC/TEMP IC/PASSPORT/HOUSEHOLD REGTR";
            mapOscar.IDNum = mapCust.IDNo;
            mapOscar.CustSubType = "ACCOUNT HOLDER";
            mapOscar.Prefix = GetOcCarGender(mapCust.Gender);

            if (this.IsUPL(appid))
            {
                mapOscar.MomMaidenName = mapContact==null?"":mapContact.RelativeName;
            }
            else
            {
                mapOscar.MomMaidenName = mapContact == null ? "" : mapContact.OtherContactName;
            }
            mapOscar.PPName = mapCust.PinyinName;
            mapOscar.MaritalStatus = GetMarryStatus(mapCust.MarriageStatus);
            mapOscar.Gender = (mapCust.Gender.Trim() == ((int)Sex.man).ToString().Trim()) ? "MALE" : "FEMALE";
            mapOscar.MailingInstruction = "NORMAL MAIL";
            mapOscar.HoldInstruction = "NORMAL MAIL";
            mapOscar.CorrespondenceLanguage = "CHINESE";
            mapOscar.SpokenLanguage = "CHINESE";
            mapOscar.IDExpiryDate = mapContact == null ? "" : mapContact.IDExpireDate.ToString("dd/MM/yyyy");
            mapOscar.IDIssueDate = mapContact == null ? string.Empty : DateTime.ParseExact(mapContact.IDIssueDate.ToString(), "yyyy-MM-dd", System.Globalization.CultureInfo.CurrentCulture).ToString("ddMMyyyy");
            mapOscar.IDIssuePlace = mapContact == null ? string.Empty : (string.IsNullOrEmpty(mapContact.IDIssuePlace) ? string.Empty : mapContact.IDIssuePlace);

            mapOscar.IDExpiryDay = mapContact == null ? "" : mapContact.IDExpireDate.ToString("dd");
            mapOscar.IDExpiryMonth = mapContact == null ? "" : mapContact.IDExpireDate.ToString("MM");
            mapOscar.IDExpiryYear = mapContact == null ? "" : mapContact.IDExpireDate.ToString("yy");
            
            mapOscar.Nationality = "CHINA";
            mapOscar.PremanentResident = "CHINA";

            mapOscar.Domicile = "CHINA";
            mapOscar.WHTax = "5%";
            mapOscar.TaxDomicile = "CHINA";
            mapOscar.VIPType = "OTHER";
            mapOscar.Staff = this.GetOscarStaff(appid);
            mapOscar.FaxIndemnity = "OFF";
            mapOscar.CustomerDeceased = "OFF";
            mapOscar.PCBankingIndicator = "OFF";
            mapOscar.CustomerDisabled = "OFF";
            mapOscar.SafeBox = "OFF";
            mapOscar.RCCode = this.GetRCCode(appid, soeId);
            mapOscar.AOCode = "00" + agentCode.Substring(2);
            mapOscar.BankAtWork = "#0";
            mapOscar.Email1 = mapContact == null ? "" : mapContact.Email;
            mapOscar.OKtoMail1 = "Yes";
            mapOscar.PhoneTypeH = "HOME TELEPHONE";
            mapOscar.CountryCodeH = "0086";
            mapOscar.AreaCodeH = mapContact == null ? "" : mapContact.HouseTelAreaCode;
            mapOscar.PhoneH = mapContact == null ? "" : mapContact.HouseTelNumber;
            mapOscar.PhoneTypeO = "OFFICE TELEPHONE";
            mapOscar.CountryCodeO = "0086";
            mapOscar.AreaCodeO = mapContact == null ? "" : mapContact.WorkingTelAreaCode;
            mapOscar.PhoneO = mapContact == null ? "" : mapContact.WorkingTelNumber;
            mapOscar.ExtnO = mapContact == null ? "" : mapContact.WorkingTelExtNumber;
            mapOscar.CountryCodeC = "0086";
            mapOscar.MailAddInd = mapContact == null ? "" : mapContact.CommunicationAddressAs;

            mapOscar.AddressTypeH = "HOME ADDRESS";
            if (mapOscar.MailAddInd.ToUpper() == "H")
                mapOscar.AddressTypeH = "MAILING ADDRESS";

            mapOscar.Add1H = mapContact == null ? "" : mapContact.HouseStreet;

            mapOscar.ProvinceH = mapContact == null ? "" : GetProvinceByCode(mapContact.HouseProvince);
            mapOscar.CityDistrictH = mapContact == null ? "" : GetCityByCode(mapContact.HouseProvince, mapContact.HouseCity) + mapContact.HouseDistrict;
            mapOscar.PostCodeH = mapContact == null ? "" : mapContact.HousePostCode;
            mapOscar.CountryH = "中国";

            mapOscar.AddressTypeO = "OFFICE ADDRESS";
            if (mapOscar.MailAddInd.ToUpper() == "O")
                mapOscar.AddressTypeO = "MAILING ADDRESS";

            mapOscar.Add1O = mapContact == null ? "" : mapContact.WorkingStreet;
            mapOscar.ProvinceO = mapContact == null ? "" : GetProvinceByCode(mapContact.WorkingProvince);
            mapOscar.CityDistrictO = mapContact == null ? "" : GetCityByCode(mapContact.WorkingProvince, mapContact.WorkingCity) + mapContact.WorkingDistrict;
            mapOscar.PostCodeO = mapContact == null ? "" : mapContact.WorkingPostCode;
            mapOscar.CountryO = "中国";
            mapOscar.OKtoMailO = "YES";

            mapOscar.AddressTypeL = "HUKOU ADDRESS";
            if (mapOscar.MailAddInd.ToUpper() == "K")
                mapOscar.AddressTypeL = "MAILING ADDRESS";

            mapOscar.Add1L = mapContact == null ? "" : mapContact.ResidenceStreet;
            mapOscar.ProvinceL = mapContact == null ? "" : GetProvinceByCode(mapContact.ResidenceProvince);
            mapOscar.CityDistrictL = mapContact == null ? "" : GetCityByCode(mapContact.ResidenceProvince, mapContact.ResidenceCity) + mapContact.ResidenceDistrict;
            mapOscar.PostCodeL = mapContact == null ? "" : mapContact.ResidencePostCode;
            mapOscar.CountryL = "中国";
            mapOscar.OKtoMailL = "YES";
            mapOscar.EqualtoMAdd = "YES";
            mapOscar.ApplicationNo = this.GetAppNoByAppId(appid);
            mapOscar.EmployerName = "";
            mapOscar.AnnualFundingRange = this.GetAnnualFundingRange(appid,mapCust.CustID,stageid);
            string occupationCode = GetOccupationCode(mapCust.Occupation);
            mapOscar.OccupationCodeEmployment = occupationCode;
            mapOscar.OccupationCodeKYC = occupationCode;
            mapOscar.IndustryCode = mapCust.Occupation;
            mapOscar.AppID = new Guid(appid);

            mapOscar.OKtoMailH = "YES";
            if (this.IsMainBoEmployee(appid))
            {
                mapOscar.SourceOfWealth = "Salary";
            }
            else
            {
                mapOscar.SourceOfWealth = "Business Income";
            }
            mapOscar.MobilePhone = mapContact == null ? "" : mapContact.MobileNumber;

            mapOscar.SellerChineseName = string.Empty;
            mapOscar.SellerEngName = string.Empty;
            mapOscar.SellerGender = string.Empty;
            mapOscar.SellerIDNum = string.Empty;
            DataTable sellers = this.GetSellerInfos(appid);
            for (int i = 0; i < sellers.Rows.Count; i++)
            {
                if (i == 0)
                {
                    mapOscar.SellerChineseName = sellers.Rows[i]["Name"].ToString().Trim();
                    mapOscar.SellerEngName = sellers.Rows[i]["PinyinName"].ToString().Trim();
                    mapOscar.SellerGender = sellers.Rows[i]["Gender"].ToString().Trim().Equals("0") ? "MALE" : "FEMALE";
                    mapOscar.SellerIDNum = sellers.Rows[i]["IDNo"].ToString().Trim();
                }
                else
                {
                    mapOscar.SellerChineseName += ", " + sellers.Rows[i]["Name"].ToString().Trim();
                    mapOscar.SellerEngName += ", " + sellers.Rows[i]["PinyinName"].ToString().Trim();
                    string gender = sellers.Rows[i]["Gender"].ToString().Trim().Equals("0") ? "MALE" : "FEMALE";
                    mapOscar.SellerGender += ", " + gender;
                    mapOscar.SellerIDNum += ", " + sellers.Rows[i]["IDNo"].ToString().Trim();
                }
            }
            return mapOscar;
            
        }

        public T_PL_Guarantors getGuarantor(string appid)
        {
            T_PL_Guarantors Guarantor = new T_PL_Guarantors();
            CommonTResult<T_PL_Guarantors> result = new CommonTResult<T_PL_Guarantors>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appid);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Guarantors>(CommandType.StoredProcedure, SPNames.PL_GuarantorsByAppID, new T_PL_GuarantorsMapper<T_PL_Guarantors>(), parameters);
            if (result.ResultList.Count > 0) {
                Guarantor = result.ResultList.FirstOrDefault();
            }
            return Guarantor;
        }

        public string GetOcCarGender(string gender)
        {
            if (!string.IsNullOrEmpty(gender))
            {
                if (gender.Trim() == ((int)Sex.man).ToString().Trim())
                    return "先生";
                else
                    return "小姐";
            }
            return "";
        }

        public bool IsUPL(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetProdNameByAppId, parameters);
            var result = parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
            if (result == EProductName.UPL.ToString().ToLower().Trim())
            {
                return true;
            }
            else 
            {
                return false;
            }
        }

        public string GetMarryStatus(string marry)
        {
            if (!string.IsNullOrEmpty(marry))
            {
                switch (marry.Trim())
                {
                    case "D":
                        return "SINGLE";
                    case "Q":
                        return "OTHERS";
                    case "Y":
                        return "MARRIED";
                }
            }
            return "";
        }

        public string GetOscarStaff(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetOscarStaff, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetRCCode(string appId, string soeId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetRCCode, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetCityByCode(string procode, string citycode)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProCode", procode);
            parameters.AddWithValue("CityCode", procode);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetCityByCode, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetNewLoanSize(string AppID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppID);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetNewLoanSize, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public bool SaveCLMS(T_PL_CLMSHandover entity)
        { 
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", entity.AppID); 
            parameters.AddWithValue("CollateralType", entity.CollateralType); 
            parameters.AddWithValue("CollateralSubType", entity.CollateralSubType); 
            parameters.AddWithValue("CollateralDescription", entity.CollateralDescription); 
            parameters.AddWithValue("Scope", entity.Scope);  
            parameters.AddWithValue("RegisteredAt", entity.Scope); 
            parameters.AddWithValue("Currency", entity.Currency); 
            parameters.AddWithValue("FMV", Convert.ToDecimal( entity.FMV)); 
            parameters.AddWithValue("Restricted", entity.Restricted); 
            parameters.AddWithValue("ExpiryDate", entity.ExpiryDate); 
            parameters.AddWithValue("ApplicableLVS", entity.ApplicableLVS); 
            parameters.AddWithValue("Owner", entity.Owner); 
            parameters.AddWithValue("Address", entity.Address);  
            parameters.AddWithValue("District", entity.District); 
            parameters.AddWithValue("TowCity", entity.TowCity);  
            parameters.AddWithValue("Country", entity.Country); 
            parameters.AddWithValue("CurrencyRestriction", entity.CurrencyRestriction); 
            parameters.AddWithValue("CurrencyCode", entity.CurrencyCode);  
            parameters.AddWithValue("SanctionDate", entity.SanctionDate);  
            parameters.AddWithValue("SanctionExpiryDate", entity.SanctionExpiryDate);  
            parameters.AddWithValue("StartDate", entity.StartDate);  
            parameters.AddWithValue("DrawdownExpireDate", entity.DrawdownExpireDate);  
            parameters.AddWithValue("MaturityDate", entity.MaturityDate);  
            parameters.AddWithValue("NextReviewDate", entity.NextReviewDate);  
            parameters.AddWithValue("ApprovedLimit", Convert.ToDecimal( entity.ApprovedLimit));
            parameters.AddWithValue("AvailedLimit", Convert.ToDecimal(entity.AvailedLimit));  
            parameters.AddWithValue("Revolving", entity.Revolving);  
            parameters.AddWithValue("RiskRating", entity.RiskRating);  
            parameters.AddWithValue("Tolerance", entity.Tolerance);  
            parameters.AddWithValue("RiskCategory", entity.RiskCategory); 
            parameters.AddWithValue("ConditionalApproveFlag", entity.ConditionalApproveFlag); 
            parameters.AddWithValue("LineID", entity.LineID); 
            parameters.AddWithValue("CollateralID", entity.CollateralID);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure,SPNames.PL_InsertCLMS,parameters);
            return true;
        }

        public string GetSecondApproveOPDate(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appId", appId);
            parameters.AddOut("aptime", DbType.DateTime);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_GetSecondApproveOPDate, parameters);
            string aptime = parameters["@aptime"].Value.ToString();
            return aptime;
        }

        public void SetCLMSDate(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_SetCLMSDate, parameters);
        }

        public CommonTResult<T_PL_ALSView> GetALS(string appid, bool istopup, string productname)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("APPID", appid);
            parameters.AddWithValue("IsTopup", istopup ? '1' : '0');
            parameters.AddWithValue("ProductName", productname);

            CommonTResult<T_PL_ALSView> result = new CommonTResult<T_PL_ALSView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_ALSView>(CommandType.StoredProcedure, SPNames.PL_GetALS,new T_PL_ALSViewMapper<T_PL_ALSView>(),parameters);
            return result;

        }

        public CommonTResult<T_PL_ALSCOLView> GetALSCOL(string appid, bool istopup, string productname)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("APPID", appid);
            parameters.AddWithValue("IsTopup", istopup ? '1' : '0');
            parameters.AddWithValue("ProductName", productname);

            CommonTResult<T_PL_ALSCOLView> result = new CommonTResult<T_PL_ALSCOLView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_ALSCOLView>(CommandType.StoredProcedure, SPNames.PL_GetALS, new T_PL_ALSCOLViewMapper<T_PL_ALSCOLView>(), parameters);
            return result;

        }

        public void SaveCLMSInfor(string appId, string accOpenDate, string CLMSLineID, string CLMSCollateralID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("LineID", CLMSLineID);
            parameters.AddWithValue("CollateralID", CLMSCollateralID);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_SaveCLMSInfor, parameters);
        }

        public Dictionary<string, string> GetCLMSInfor(string appId)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            var dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetCLMSInfor, parameters);
            if (dt != null && dt.Rows.Count > 0)
            {
                dic.Add("LineID", dt.Rows[0]["LineID"].ToString());
                dic.Add("CollateralID", dt.Rows[0]["CollateralID"].ToString());
            }
            else
            {
                dic.Add("LineID", "");
                dic.Add("CollateralID", "");
            }
            return dic;
        }

        public void SaveRemarks(string appId, string remarks)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("Remarks", remarks);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_SaveRemarks, parameters);
        }

        public bool IsTopupBatch(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            parameters.AddOut("Result", DbType.Boolean);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_IsTopupBatch, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? false : bool.Parse(parameters["@Result"].Value.ToString());
        }

        public string GetProvinceByCode(string procode)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Procode", procode);
            parameters.AddOut("Result", DbType.String,100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetProvinceByCode, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetOccupationCode(string oldCode)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Id", oldCode);
            parameters.AddWithValue("Type", ESysParameter.FieldOccupational.ToString());
            parameters.AddOut("Result", DbType.String,100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetOccupationCode, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetAnnualFundingRange(string appId,string CustID,string stageid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustId", CustID);
            parameters.AddWithValue("StageId", stageid  );
            parameters.AddOut("Result", DbType.Decimal);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetAnnualFundingRange, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public void InitEclipse(string appid, T_PL_CustomerContact mapContact, T_PL_Customers mapCust, string stageid)
        {
            string soeId = this.GetSalesIdByAppID(appid);
            string agentCode = this.GetAgentCodeByAppId(appid);

            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appid);
            parameters.AddWithValue("SurName", mapCust.FullName);
            parameters.AddWithValue("FirstName", mapCust.FullName);
            parameters.AddWithValue("DOB", mapCust.DOB);
            parameters.AddWithValue("IDType", "IC/TEMP IC/PASSPORT/HOUSEHOLD REGTR");
            parameters.AddWithValue("IDNum", mapCust.IDNo);
            parameters.AddWithValue("CustSubType", "ACCOUNT HOLDER");
            parameters.AddWithValue("Prefix", GetOcCarGender(mapCust.Gender));
            if (this.IsUPL(appid))
            {
                parameters.AddWithValue("MomMaidenName", mapContact!=null? mapContact.RelativeName:"");                
            }
            else
            {
                parameters.AddWithValue("MomMaidenName", mapContact!=null?mapContact.OtherContactName:"");                
            }
            
            parameters.AddWithValue("PPName", mapCust.PinyinName);
            parameters.AddWithValue("MaritalStatus", GetMarryStatus(mapCust.MarriageStatus));
            parameters.AddWithValue("Gender", (mapCust.Gender.Trim() == ((int)Sex.man).ToString().Trim()) ? "MALE" : "FEMALE");
            parameters.AddWithValue("MailingInstruction", "NORMAL MAIL");
            parameters.AddWithValue("HoldInstruction", "NORMAL MAIL");
            parameters.AddWithValue("CorrespondenceLanguage", "CHINESE");
            parameters.AddWithValue("SpokenLanguage", "CHINESE");
            parameters.AddWithValue("IDExpiryDate", mapContact!=null?mapContact.IDExpireDate.ToString("dd/MM/yyyy"):"");
            parameters.AddWithValue("IDExpiryYear", mapContact!=null?mapContact.IDExpireDate.ToString("yyyy"):"");
            parameters.AddWithValue("IDExpiryMonth", mapContact!=null?mapContact.IDExpireDate.ToString("MM"):"");
            parameters.AddWithValue("IDExpiryDay", mapContact != null ? mapContact.IDExpireDate.ToString("dd") : "");
            parameters.AddWithValue("Nationality", "CHINA");
            parameters.AddWithValue("PremanentResident", "CHINA");
            parameters.AddWithValue("Domicile", "CHINA");
            parameters.AddWithValue("WHTax", "5%");
            parameters.AddWithValue("TaxDomicile", "CHINA");
            parameters.AddWithValue("VIPType", "OTHER");
            parameters.AddWithValue("Staff", GetOscarStaff(appid));
            parameters.AddWithValue("FaxIndemnity", "OFF");
            parameters.AddWithValue("CustomerDeceased", "OFF");
            parameters.AddWithValue("PCBankingIndicator", "OFF");
            parameters.AddWithValue("CustomerDisabled", "OFF");
            parameters.AddWithValue("SafeBox", "OFF");
            parameters.AddWithValue("RCCode", GetRCCode(appid, soeId));
            parameters.AddWithValue("AOCode", "00" + agentCode.Substring(2));
            parameters.AddWithValue("BankAtWork", "#0");
            parameters.AddWithValue("Email1", mapContact == null ? "":mapContact.Email);
            parameters.AddWithValue("OKtoMail1", "Yes");
            parameters.AddWithValue("MobilePhone", mapContact == null ? "": mapContact.MobileNumber);
            parameters.AddWithValue("PhoneTypeH", "HOME TELEPHONE");
            parameters.AddWithValue("CountryCodeH", "0086");
            parameters.AddWithValue("AreaCodeH", mapContact == null ? "": mapContact.HouseTelAreaCode);
            parameters.AddWithValue("PhoneH", mapContact == null ? "": mapContact.HouseTelNumber);
            parameters.AddWithValue("ExtnH", "");
            parameters.AddWithValue("PhoneTypeO", "OFFICE TELEPHONE");
            parameters.AddWithValue("CountryCodeO", "0086");
            parameters.AddWithValue("AreaCodeO", mapContact == null ? "": mapContact.WorkingTelAreaCode);
            parameters.AddWithValue("PhoneO", mapContact == null ? "": mapContact.WorkingTelNumber);
            parameters.AddWithValue("ExtnO", mapContact == null ? "" : mapContact.WorkingTelExtNumber);
            parameters.AddWithValue("PhoneTypeC", "");
            parameters.AddWithValue("CountryCodeC", "0086");
            parameters.AddWithValue("AreaCodeC", "");
            parameters.AddWithValue("PhoneC", "");
            parameters.AddWithValue("ExtnC", "");
            string mailadd = "";
            string CommunicationAddressAs = mapContact == null ? "" : mapContact.CommunicationAddressAs;
            switch (CommunicationAddressAs)
            {
                case "H": mailadd = mapContact.HouseProvince + mapContact.HouseCity + mapContact.HouseDistrict + mapContact.HouseStreet; break;
                case "K": mailadd = mapContact.ResidenceProvince + mapContact.ResidenceCity + mapContact.ResidenceDistrict + mapContact.ResidenceStreet; break;
                case "O": mailadd = mapContact.WorkingProvince + mapContact.WorkingCity + mapContact.WorkingDistrict + mapContact.WorkingStreet; break;
                default:  break;
            }

            parameters.AddWithValue("MailAddInd", mapContact == null ? "" : mapContact.CommunicationAddressAs);
            if (CommunicationAddressAs=="H")
                parameters.AddWithValue("AddressTypeH", "MAILING ADDRESS");
            else
                parameters.AddWithValue("AddressTypeH", "HOME ADDRESS");

            parameters.AddWithValue("Add1H", mapContact == null ? "" : mapContact.HouseStreet);
            parameters.AddWithValue("Add2H", "");
            parameters.AddWithValue("Add3H", "");
            parameters.AddWithValue("Add4H", "");
            parameters.AddWithValue("ProvinceH", GetProvinceByCode(mapContact == null ? "" : mapContact.HouseProvince));
            parameters.AddWithValue("CityDistrictH", GetCityByCode(mapContact == null ? "" : mapContact.HouseProvince, mapContact == null ? "" : mapContact.HouseCity) + mapContact == null ? "" : mapContact.HouseDistrict);
            parameters.AddWithValue("PostCodeH", mapContact == null ? "" : mapContact.HousePostCode);
            parameters.AddWithValue("CountryH", "中国");
            parameters.AddWithValue("OKtoMailH", "");
            if (CommunicationAddressAs == "O")
                parameters.AddWithValue("AddressTypeO", "MAILING ADDRESS");
            else
                parameters.AddWithValue("AddressTypeO", "OFFICE ADDRESS");
            parameters.AddWithValue("Add1O", mapContact == null ? "" : mapContact.WorkingStreet);
            parameters.AddWithValue("Add2O", "");
            parameters.AddWithValue("Add3O", "");
            parameters.AddWithValue("Add4O", "");
            parameters.AddWithValue("ProvinceO", mapContact == null ? "" : GetProvinceByCode(mapContact.WorkingProvince));
            parameters.AddWithValue("CityDistrictO", mapContact == null ? "" : GetCityByCode(mapContact.WorkingProvince, mapContact.WorkingCity) + mapContact.WorkingDistrict);
            parameters.AddWithValue("PostCodeO", mapContact == null ? "" : mapContact.WorkingPostCode);
            parameters.AddWithValue("CountryO", "中国");
            parameters.AddWithValue("OKtoMailO", "YES");
            if (CommunicationAddressAs == "K")
                parameters.AddWithValue("AddressTypeL", "MAILING ADDRESS");
            else
                parameters.AddWithValue("AddressTypeL", "HUKOU ADDRESS");
            parameters.AddWithValue("Add1L", mapContact == null ? "" : mapContact.ResidenceStreet);
            parameters.AddWithValue("Add2L", "");
            parameters.AddWithValue("Add3L", "");
            parameters.AddWithValue("Add4L", "");
            parameters.AddWithValue("ProvinceL", mapContact == null ? "" : GetProvinceByCode(mapContact.ResidenceProvince));
            parameters.AddWithValue("CityDistrictL", mapContact == null ? "" : GetCityByCode(mapContact.ResidenceProvince, mapContact.ResidenceCity) + mapContact.ResidenceDistrict);
            parameters.AddWithValue("PostCodeL", mapContact == null ? "" : mapContact.ResidencePostCode);
            parameters.AddWithValue("CountryL", "中国");
            parameters.AddWithValue("OKtoMailL", "YES");
            parameters.AddWithValue("EqualtoMAdd", "YES");

            if (IsMainBoEmployee(appid))
            {
                parameters.AddWithValue("SourceOfWealth", "Salary");
            }
            else
            {
                parameters.AddWithValue("SourceOfWealth", "Business Income");
            }
            
            string occupationCode = GetOccupationCode(mapCust.Occupation);
            parameters.AddWithValue("OccupationCodeKYC", occupationCode);
            parameters.AddWithValue("OccupationCodeEmployment", occupationCode);
            parameters.AddWithValue("AnnualFundingRange", GetAnnualFundingRange(appid, mapCust.CustID,stageid));
            parameters.AddWithValue("EmployerName", "");
            parameters.AddWithValue("ApplicationNo", GetAppNoByAppId(appid));
            parameters.AddWithValue("IndustryCode", mapCust.Occupation);
            DataTable dtsell = GetSellerInfos(appid);
            string SellerChineseName = "";
            string SellerEngName = "";
            string SellerGender = "";
            string SellerIDNum = "";
            for (int i = 0; i < dtsell.Rows.Count; i++)
            {
                if (i == 0)
                {
                    SellerChineseName = dtsell.Rows[i]["Name"].ToString().Trim();
                    SellerEngName = dtsell.Rows[i]["PinyinName"].ToString().Trim();
                    SellerGender = dtsell.Rows[i]["Gender"].ToString().Trim().Equals("0") ? "MALE" : "FEMALE";
                    SellerIDNum = dtsell.Rows[i]["IDNo"].ToString().Trim();
                }
                else
                {
                    SellerChineseName += ", " + dtsell.Rows[i]["Name"].ToString().Trim();
                    SellerEngName += ", " + dtsell.Rows[i]["PinyinName"].ToString().Trim();
                    string gender = dtsell.Rows[i]["Gender"].ToString().Trim().Equals("0") ? "MALE" : "FEMALE";
                    SellerGender += ", " + gender;
                    SellerIDNum += ", " + dtsell.Rows[i]["IDNo"].ToString().Trim();
                }
            }
            parameters.AddWithValue("SellerChineseName", SellerChineseName);
            parameters.AddWithValue("SellerEngName", SellerEngName);
            parameters.AddWithValue("SellerGender", SellerGender);
            parameters.AddWithValue("SellerIDNum", SellerIDNum);
            parameters.AddWithValue("IDIssueDate", mapContact == null ? "" : mapContact.IDIssueDate.ToString());
            parameters.AddWithValue("IDIssuePlace", mapContact == null ? "" : mapContact.IDIssuePlace);

            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_InitEclipse, parameters);

        }

        public DataTable GetSellerInfos(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            return AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetSellerInfos, parameters);
        }

        public bool IsMainBoEmployee(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            parameters.AddOut("Result", DbType.Boolean);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_IsMainBoEmployee, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? false : Boolean.Parse(parameters["@Result"].Value.ToString());
        }

        public string GetMBCertID(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetMBCertID, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public decimal GetTopUpBaseRate(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            parameters.AddOut("Result", DbType.Decimal);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetTopUpBaseRate, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? 0 : decimal.Parse(parameters["@Result"].Value.ToString());
        }

        public decimal GetProductBaserateFromADR(string appID, string ProdId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appID);
            parameters.AddWithValue("ProdId", ProdId);
            parameters.AddOut("Result", DbType.Decimal);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetProductBaserateFromADR, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? 0 : decimal.Parse(parameters["@Result"].Value.ToString());
        }

        public CommonTResult<T_PL_LoanApproval> GetSaleAndAppByAppId(string appId)
        {
            CommonTResult<T_PL_LoanApproval> result = new CommonTResult<T_PL_LoanApproval>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_LoanApproval>(
                CommandType.StoredProcedure, SPNames.PL_GET_LOANAPPROVAL, new T_PL_LoanApprovalMapper<T_PL_LoanApproval>(), parameters);
            return result;
        }

        public string GetSalesIdByAppID(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetSalesIdByAppID, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetAgentCodeByAppId(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetAgentCodeByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public void SaveAccOpenDate(string appId, string date)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("Date", date);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_SaveAccOpenDate, parameters);
        }
        
        public string GetProductName(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetProductNameByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetSourceCode(string soeId, string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetSourceCodeByAppId, parameters);
            return this.GetBranchCodeByAppId(appId) + (parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString());
        }

        public string GetBranchCodeByAppId(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetBranchCodeByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetSegmentID(string appId, string soeId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetSegmentIDByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }       

        public string GetProdName(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetProdNameByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetALSCityCodeBySoeId(string soeId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("SoeId", soeId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetALSCityCodeBySoeId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public T_PL_Collateral GetCollByAppId(string appId)
        {
            T_PL_Collateral Collateral = new Entities.T_PL_Collateral();
            CommonTResult<T_PL_Collateral> result = new CommonTResult<T_PL_Collateral>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Collateral>(
                CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetCollateralByAppId, new T_PL_CollateralMapper<T_PL_Collateral>(), parameters);
            if (result.ResultList.Count > 0) {
                Collateral = result.ResultList.FirstOrDefault();
            }
            return Collateral;
        }

        public Dictionary<string, string> GetApplicationMap(string appid)
        {
            Dictionary<string, string> dicapp = new Dictionary<string, string>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appid);
            var dt =  AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetApplicationMap, parameters);
            if (dt != null && dt.Rows.Count > 0)
            {
                dicapp.Add("SigningDate", dt.Rows[0]["ContractSignDate"].ToString());
                dicapp.Add("AccOpenDate", dt.Rows[0]["AccOpenDate"].ToString());
                dicapp.Add("PayType", dt.Rows[0]["PayType"].ToString());
            }
            else {
                dicapp.Add("SigningDate", "");
                dicapp.Add("AccOpenDate", "");
                dicapp.Add("PayType", "");
            }
            return dicapp;
        }

        public bool IsExisitAlsUpl(Guid? appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.Boolean);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_IsExisitAlsUpl, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? false : Boolean.Parse(parameters["@Result"].Value.ToString());
        }

        public bool SaveNumber(string appId, string customerNumber,string custID, string co1CustNumber,string cust1ID, string co2CustNumber,string cust2ID, string GuaNo,string GuaID, string relationshipNumber, string Mo1No,string Mo1ID, string Mo2No,string Mo2ID, string Mo3No,string Mo3ID)
        { 
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddWithValue("customerNumber", customerNumber);
            parameters.AddWithValue("custID", custID);
            parameters.AddWithValue("co1CustNumber", co1CustNumber);
            parameters.AddWithValue("cust1ID", cust1ID);
            parameters.AddWithValue("co2CustNumber", co2CustNumber);
            parameters.AddWithValue("cust2ID", cust2ID);
            parameters.AddWithValue("GuaNo", GuaNo);
            parameters.AddWithValue("GuaID", GuaID);
            parameters.AddWithValue("relationshipNumber", relationshipNumber);
            parameters.AddWithValue("Mo1No", Mo1No);
            parameters.AddWithValue("Mo1ID", Mo1ID);
            parameters.AddWithValue("Mo2No", Mo2No);
            parameters.AddWithValue("Mo2ID", Mo2ID);
            parameters.AddWithValue("Mo3No", Mo3No);
            parameters.AddWithValue("Mo3ID", Mo3ID);

            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseSaveNumber,parameters);
            return true;
        }

        public string GetRCNumberByAppId(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetRCNumberByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public void SaveDetails(string appid, string remarks, string accopendate, string paymethods)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appid);
            parameters.AddWithValue("remarks", remarks);
            parameters.AddWithValue("accopendate", accopendate);
            parameters.AddWithValue("paymethods", paymethods);

            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveDisburseDetails, parameters);
        }

        public DataTable GetItemDetailInfo(string appid,string itemtype,string itemid)
        {
            DataTable resultdt = new DataTable();
            resultdt.Columns.Add("colname");
            resultdt.Columns.Add("value");
            if (itemtype == "HE" || itemtype == "ALS")
            {
                bool istopup = false;
                string appno = this.GetAppNoByAppId(appid);
                if (appno.Length > 0)
                {
                    if (appno.Substring(0, 1) == "T")
                    {
                        istopup = true;
                    }
                }
                CommonTResult<T_PL_ALSView> entitylist = this.GetALS(appid, istopup, GetProdName(appid));
                T_PL_ALSView entity = new T_PL_ALSView();
                if (entitylist.ResultList.Count > 0)
                {
                    entity = entitylist.ResultList[0];
                }
                Type type = typeof(T_PL_ALSView);
                PropertyInfo[] plist = type.GetProperties();
                foreach (PropertyInfo pone in plist)
                {
                    DataRow dr1 = resultdt.NewRow();
                    System.Reflection.PropertyInfo propertyInfo = type.GetProperty(pone.Name);
                    dr1["colname"] = pone.Name;
                    if (pone.Name == "Tolerance")
                    {
                        dr1["value"] = propertyInfo.GetValue(entity, null) == null ? "" : propertyInfo.GetValue(entity, null).ToString() + "%";
                    }
                    else
                    {
                        dr1["value"] = propertyInfo.GetValue(entity, null) == null ? "" : propertyInfo.GetValue(entity, null).ToString();
                    }
                    resultdt.Rows.Add(dr1);
                }
                return resultdt;
            }
            if (itemtype == "CLMS")
            {
                CommonTResult<T_PL_CLMSHandover> entitylist = GetCLMS(appid);
                T_PL_CLMSHandover entity = new T_PL_CLMSHandover();
                if (entitylist.ResultList.Count > 0)
                {
                    entity = entitylist.ResultList[0];
                }
                Type type = typeof(T_PL_CLMSHandover);
                PropertyInfo[] plist = type.GetProperties();
                foreach (PropertyInfo pone in plist)
                {
                    DataRow dr1 = resultdt.NewRow();
                    System.Reflection.PropertyInfo propertyInfo = type.GetProperty(pone.Name);
                    dr1["colname"] = pone.Name;
                    if (pone.Name == "Tolerance")
                    {
                        dr1["value"] = propertyInfo.GetValue(entity, null) == null ? "" : propertyInfo.GetValue(entity, null).ToString() + "%";
                    }
                    else
                    {
                        dr1["value"] = propertyInfo.GetValue(entity, null) == null ? "" : propertyInfo.GetValue(entity, null).ToString();
                    }
                    resultdt.Rows.Add(dr1);
                }
                return resultdt;
            }
            if (itemtype == "Eclipse")
            {
                CommonTResult<T_PL_EclipseHandover> entitylist = GetEclipseByIDNum(appid, itemid);
                T_PL_EclipseHandover entity = new T_PL_EclipseHandover();
                if (entitylist.ResultList.Count > 0)
                {
                    entity = entitylist.ResultList[0];
                }
                Type type = typeof(T_PL_EclipseHandover);
                PropertyInfo[] plist = type.GetProperties();
                foreach (PropertyInfo pone in plist)
                {
                    DataRow dr1 = resultdt.NewRow();
                    System.Reflection.PropertyInfo propertyInfo = type.GetProperty(pone.Name);
                    dr1["colname"] = pone.Name;
                    if (pone.Name == "Tolerance")
                    {
                        dr1["value"] = propertyInfo.GetValue(entity, null) == null ? "" : propertyInfo.GetValue(entity, null).ToString() + "%";
                    }
                    else
                    {
                        dr1["value"] = propertyInfo.GetValue(entity, null) == null ? "" : propertyInfo.GetValue(entity, null).ToString();
                    }
                    resultdt.Rows.Add(dr1);
                }
                return resultdt;
            }
            return null;
        }

        public void SaveALSHE(T_PL_ALS_COL map)
        {
            if (map != null)
            {
                Guid? appId = map.AppID;
                if (appId.HasValue && appId.Value != Guid.Empty)
                {
                    string sql = String.Empty;
                    IDbParameters parameters = AdoTemplate.CreateDbParameters();
                    parameters.AddWithValue("AppID", map.AppID);
                    parameters.AddWithValue("AccountNumber", map.AccountNumber);
                    parameters.AddWithValue("ProductCode", map.ProductCode);
                    parameters.AddWithValue("LoanAmount", map.LoanAmount);
                    parameters.AddWithValue("LoanProceeds", map.LoanProceeds);
                    parameters.AddWithValue("InterestRate", map.InterestRate);
                    parameters.AddWithValue("CustomerNumber", map.CustomerNumber);
                    parameters.AddWithValue("RelationshipNumber", map.RelationshipNumber);
                    parameters.AddWithValue("RCNumber", map.RCNumber);
                    parameters.AddWithValue("ContractDate", map.ContractDate);
                    parameters.AddWithValue("FirstDueDate", map.FirstDueDate);
                    parameters.AddWithValue("Term", map.Term);
                    parameters.AddWithValue("MaturityDate", map.MaturityDate);
                    parameters.AddWithValue("PrimBranch", map.PrimBranch);
                    parameters.AddWithValue("IndustryCode", map.IndustryCode);
                    parameters.AddWithValue("CACSCity", map.CACSCity);
                    parameters.AddWithValue("CACSLoc", map.CACSLoc);
                    parameters.AddWithValue("CityCode", map.CityCode);
                    parameters.AddWithValue("ACF", map.ACF);
                    parameters.AddWithValue("RateIndex", map.Rate_Index);
                    parameters.AddWithValue("Purpose", map.Purpose);
                    parameters.AddWithValue("AgentCode", map.AgentCode);
                    parameters.AddWithValue("SourceCode", map.SourceCode);
                    parameters.AddWithValue("IncomeType", map.IncomeType);
                    parameters.AddWithValue("EmployerCD", map.EmployerCD);
                    parameters.AddWithValue("SegmentID", map.SegmentID);
                    parameters.AddWithValue("OriginalAccNo", map.OriginalAccNo);
                    parameters.AddWithValue("OriginalSegmentId", map.OriginalSegmentId);
                    parameters.AddWithValue("LoanDirection", map.LoanDirection);
                    parameters.AddWithValue("DisbursementMethod", map.DisbursementMethod);
                    parameters.AddWithValue("LineID", map.LineID);
                    parameters.AddWithValue("CollateralID", map.CollateralID);

                    AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveALSCOL, parameters);
                }
            }
        }

        public void SaveALSUPL(T_PL_ALS_UPL map)
        {
            if (map != null)
            {
                Guid? appId = map.AppID;
                if (appId.HasValue && appId.Value != Guid.Empty)
                {
                    string sql = String.Empty;
                    IDbParameters parameters = AdoTemplate.CreateDbParameters();
                    parameters.AddWithValue("AppID", map.AppID);
                    parameters.AddWithValue("AccountNumber", map.AccountNumber);
                    parameters.AddWithValue("ProductCode", map.ProductCode);
                    parameters.AddWithValue("LoanAmount", map.LoanAmount);
                    parameters.AddWithValue("LoanProceeds", map.LoanProceeds);
                    parameters.AddWithValue("InterestRate", map.InterestRate);
                    parameters.AddWithValue("CustomerNumber", map.CustomerNumber);
                    parameters.AddWithValue("RelationshipNumber", map.RelationshipNumber);
                    parameters.AddWithValue("RCNumber", map.RCNumber);
                    parameters.AddWithValue("ContractDate", map.ContractDate);
                    parameters.AddWithValue("FirstDueDate", map.FirstDueDate);
                    parameters.AddWithValue("Term", map.Term);
                    parameters.AddWithValue("MaturityDate", map.MaturityDate);
                    parameters.AddWithValue("PrimBranch", map.PrimBranch);
                    parameters.AddWithValue("IndustryCode", map.IndustryCode);
                    parameters.AddWithValue("CACSCity", map.CACSCity);
                    parameters.AddWithValue("CACSLoc", map.CACSLoc);
                    parameters.AddWithValue("CityCode", map.CityCode);
                    parameters.AddWithValue("ACF", map.ACF);
                    parameters.AddWithValue("RateIndex", map.RateIndex);
                    parameters.AddWithValue("Purpose", map.Purpose);
                    parameters.AddWithValue("AgentCode", map.AgentCode);
                    parameters.AddWithValue("SourceCode", map.SourceCode);
                    parameters.AddWithValue("IncomeType", map.IncomeType);
                    parameters.AddWithValue("EmployerCD", map.EmployerCD);
                    parameters.AddWithValue("SegmentID", map.SegmentID);
                    parameters.AddWithValue("OriginalAccNo", map.OriginalAccNo);
                    parameters.AddWithValue("OriginalSegmentId", map.OriginalSegmentId);
                    parameters.AddWithValue("LoanDirection", map.LoanDirection);
                    parameters.AddWithValue("DisbursementMethod", map.DisbursementMethod);
                    parameters.AddWithValue("LineID", map.LineID);
                    parameters.AddWithValue("CollateralID", map.CollateralID);

                    AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveALSUPL,parameters);
                   
                }
            }
        }

        public string GetCityCodeBySoeId(string soeId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("SoeID", soeId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetCityCodeBySoeId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public DataTable IsTopUp(string AppId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppId);
            return AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_IsTopUp, parameters);
        }

        public string GetLoanIndustry(string AppId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetLoanIndustryByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }


        public string GetOrgRcCodeBySoeId(string soeId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("SoeId", soeId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetOrgRcCodeBySoeId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetLastLoan(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetLastLoanByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public void SaveAccountNumber(string code, string sequence)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Code", code);
            parameters.AddWithValue("Seq", sequence);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetAppNoByAppId, parameters);
        }

        public string GetSequence(string code)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Code", code);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetAppNoByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetProdTypeByAppID(string appId)
        {
            string sql = @"select ProdType from T_Sys_Products where prodid in (select prodid from t_pl_application where appid='" + appId + "')";
            try
            {
                object obj = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.Text, sql);

                string prodType = Convert.ToString(obj);

                if (prodType == "12")
                {
                    sql = @"select CollateralType from T_PL_Collateral where appid = '"+appId+"' ";

                    obj = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.Text, sql);

                    if (Convert.ToString(obj).ToUpper().Trim() == CollaterialType.M.ToString())
                    {
                        prodType = "13";
                    }
                }
                return prodType;
            }
            catch (Exception ex)
            {
                return "";
            }
        }


        public string GetAppNoByAppId(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetAppNoByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetExisitAccountNumber(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetExisitAccountNumberByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public string GetALSIncomeType(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_GetALSIncomeTypeByAppId, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : parameters["@Result"].Value.ToString();
        }

        public T_PL_SelfPay GetSelfPayInfo(string AppID)
        {
            CommonTResult<T_PL_SelfPay> result = new CommonTResult<T_PL_SelfPay>();
            T_PL_SelfPay Entity = new T_PL_SelfPay();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", new Guid(AppID));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_SelfPay>(
                CommandType.StoredProcedure, SPNames.PL_GetSelfPayInfo, new T_PL_SelfPayMapper<T_PL_SelfPay>(), parameters);
            if (result.ResultList.Count > 0) {
                Entity = result.ResultList.FirstOrDefault();
            }
            return Entity;
            
        }
    }
}
