﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Transaction.Interceptor;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.disbursement
{
    public class VerDocProcessingDao : AdoDaoSupport, IVerDocProcessingDao
    {
        public CommonTResult<T_PL_DocSubmitted> GetDocListByAppID(string appid, int stageid)
        {
            CommonTResult<T_PL_DocSubmitted> result = new CommonTResult<T_PL_DocSubmitted>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appid);
            parameters.AddWithValue("StageID", stageid);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_DocSubmitted>(
                CommandType.StoredProcedure, SPNames.PL_GetDocListByAppID, new T_PL_DocSubmittedMapper<T_PL_DocSubmitted>(), parameters);
            result.IsSuccess = true;
            result.ResultCount = result.ResultList.Count;

            return result;
        }

        public CommonTResult<T_PL_AppraisalFee> GetAppraisalFeeByAppID(string appid)
        {
            CommonTResult<T_PL_AppraisalFee> result = new CommonTResult<T_PL_AppraisalFee>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appid);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_AppraisalFee>(
                CommandType.StoredProcedure, SPNames.PL_GetAppraisalFeeByAppID, new BaseMapper<T_PL_AppraisalFee>(), parameters);
            result.IsSuccess = true;
            result.ResultCount = result.ResultList.Count;

            return result;
        }

        public CommonResult SaveAppraisalFee(T_PL_AppraisalFee fees)
        {
            CommonResult result = new CommonResult();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ApplicationNo", fees.ApplicationNo);
            parameters.AddWithValue("Price", fees.Price);
            parameters.AddWithValue("LandValue", fees.LandValue);
            parameters.AddWithValue("BuildingValue", fees.BuildingValue);
            parameters.AddWithValue("Fee", fees.Fee);
            parameters.AddWithValue("InsuranceFee", fees.InsuranceFee);
            parameters.AddWithValue("RegisterFee", fees.RegisterFee);

            int Count = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveAppraisalFee, parameters);

            result.IsSuccess = Count > 0 ? true : false;
            result.Message = Count > 0 ? "保存成功！" : "保存失败！";

            return result;
        }
    }
}
