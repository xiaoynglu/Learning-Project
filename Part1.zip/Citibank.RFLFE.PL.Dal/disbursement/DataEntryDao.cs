﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Transaction.Interceptor;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;
using System.Reflection;

namespace Citibank.RFLFE.PL.Dal.disbursement
{
    public class DataEntryDao : AdoDaoSupport, IDataEntryDao
    {
        public CommonTResult<DataEntryView> QueryWaitDataEntry(int start,int limit,DataEntryView entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("RoleType", entity.RoleType);
            parameters.AddWithValue("soeid", entity.soeid);
            parameters.AddWithValue("orgcode", entity.orgcode);
            parameters.AddOut("count",DbType.Int32);
            CommonTResult<DataEntryView> result = new CommonTResult<DataEntryView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<DataEntryView>(CommandType.StoredProcedure, SPNames.PL_GetWaitDataEntry,new DataEntryViewMapper<DataEntryView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;

        }

        public CommonTResult<DataEntryView> QueryHistoryDataEntry(int start, int limit, DataEntryView entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("RoleType", entity.RoleType);
            parameters.AddWithValue("soeid", entity.soeid);
            parameters.AddWithValue("orgcode", entity.orgcode);

            parameters.AddWithValue("AppNO", entity.AppNO);
            parameters.AddWithValue("CustomerId", entity.CustomerID);
            parameters.AddWithValue("CustomerName", entity.CustomerName);
            parameters.AddWithValue("prodid", entity.Product);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("starttime", entity.StartTime);
            parameters.AddWithValue("endtime", entity.EndTime);
            
            parameters.AddOut("count", DbType.Int32);
            CommonTResult<DataEntryView> result = new CommonTResult<DataEntryView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<DataEntryView>(CommandType.StoredProcedure, SPNames.PL_GetHistoryDataEntry, new DataEntryViewMapper<DataEntryView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;

        }
    }
}
