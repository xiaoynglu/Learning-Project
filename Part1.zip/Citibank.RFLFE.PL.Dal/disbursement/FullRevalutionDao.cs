﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Transaction.Interceptor;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;
using System.Reflection;

namespace Citibank.RFLFE.PL.Dal.disbursement
{
    public class FullRevalutionDao : AdoDaoSupport, IFullRevalutionDao
    {
        public CommonTResult<FullRevalutionView> GetFullRevalutionView(int start, int limit, string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appId);
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddOut("Count",DbType.Int32);

            CommonTResult<FullRevalutionView> result = new CommonTResult<FullRevalutionView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<FullRevalutionView>(CommandType.StoredProcedure, SPNames.PL_GetFullRevalution, new FullRevalutionViewMapper<FullRevalutionView>(), parameters);
            return result;
        }

        public CommonTResult<FullRevalutionValuesView> GetValues(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appid);

            CommonTResult<FullRevalutionValuesView> result = new CommonTResult<FullRevalutionValuesView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<FullRevalutionValuesView>(CommandType.StoredProcedure, SPNames.PL_GetFullRevalutionValues, new FullRevalutionValuesViewMapper<FullRevalutionValuesView>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_EvaluationCompany> GetEvaluationCompany(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appid);

            CommonTResult<T_PL_EvaluationCompany> result = new CommonTResult<T_PL_EvaluationCompany>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_EvaluationCompany>(CommandType.StoredProcedure, SPNames.PL_GetEvaluationCompany, new T_PL_EvaluationCompanyMapper<T_PL_EvaluationCompany>(), parameters);
            return result;
        }

        public bool SaveEvl(T_PL_OralAppraisal entity,string itemoperator)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("CompanyID", entity.CompanyID);
            parameters.AddWithValue("RequestDate", entity.RequestDate);
            parameters.AddWithValue("AcceptDate", entity.AcceptDate);
            parameters.AddWithValue("Price", entity.Price);
            parameters.AddWithValue("Fee", entity.Fee);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddWithValue("CreateID", itemoperator);
                        
            int i1= AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveEvl, parameters);
            return i1 > 0 ? true : false;
        }

        public bool DeleteEvl(string TID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteEvl, parameters);
            return i1 > 0 ? true : false;
        }

        public bool ApplyEvl(string appid,string TID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appid);
            parameters.AddWithValue("TID", TID);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApplyEvl, parameters);
            return i1 > 0 ? true : false;
        }

        public bool IsApplied(Guid appid)
        {            
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appid);            

            object ob = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetFRIsApplied, parameters);
            if (ob == null)
                return false;
            else
            {
                if (Convert.ToInt32(ob) > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        public int getLoanSizeByPropertyValue(Guid appID)
        {
            int result = 0;
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appID);   
            object o1 = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetLoanSizeByPropertyValue, parameters);
            if (o1 != null&& o1!=System.DBNull.Value)
            {
                result = Int32.Parse(o1.ToString());
            }
            return result;
        }

        public CommonTResult<T_PL_RunResult> GetEvlApprovalList(string appid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appid", appid);

            CommonTResult<T_PL_RunResult> result = new CommonTResult<T_PL_RunResult>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_RunResult>(CommandType.StoredProcedure, SPNames.PL_GetEvlApprovalList, new T_PL_RunResultMapper<T_PL_RunResult>(), parameters);
            return result;
        }

        public bool GetISMO(string appid)
        {
            Boolean result = false;
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", new Guid(appid));
            parameters.AddOut("Result", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetISMO, parameters);
            if (parameters["@Result"].Value != null && parameters["@Result"].Value != System.DBNull.Value)
            {
                result = parameters["@Result"].Value.ToString() =="1"?true:false;
            }
            return result;
        }

        public long GetCallFullValByAppId(Guid AppId)
        {
            long result = 0;
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppId);
            parameters.AddOut("Result", DbType.Int32);            
            AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetCallFullValByAppId, parameters);
            if (parameters["@Result"].Value != null && parameters["@Result"].Value != System.DBNull.Value)
            {
                result = Int64.Parse(parameters["@Result"].Value.ToString());
            }
            return result;           
        }

        public CommonTResult<FullRevalutionApproveView> GetCreditInfo_2ndAppoval(Guid guidAPPID,int stageid)
        {
             IDbParameters parameters = AdoTemplate.CreateDbParameters();
             parameters.AddWithValue("AppID", guidAPPID);
             parameters.AddWithValue("stageid", stageid);   

            CommonTResult<FullRevalutionApproveView> result = new CommonTResult<FullRevalutionApproveView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<FullRevalutionApproveView>(CommandType.StoredProcedure, SPNames.PL_GetFullRevalutionApproveInfo, new FullRevalutionApproveViewMapper<FullRevalutionApproveView>(), parameters);
            return result;
        }

        public CommonTResult<EvlReportListView> GetEvlReportList(string APPIDs)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("APPIDs", APPIDs);

            CommonTResult<EvlReportListView> result = new CommonTResult<EvlReportListView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<EvlReportListView>(CommandType.StoredProcedure, SPNames.PL_GetEvlReportList, new EvlReportListViewMapper<EvlReportListView>(), parameters);
            return result;
        }

        public static decimal calcInstallment(decimal loanSize, int tenor, decimal rate)
        {
            if (loanSize <= 0 || tenor <= 0 || rate <= 0)
                return 0.0M;

            decimal installment = loanSize * (rate / 12 * decimalPow((1 + rate / 12), tenor) / (decimalPow((1 + rate / 12), tenor) - 1));
            return installment;
        }

        private static decimal decimalPow(decimal x, decimal y)
        {
            decimal result = 1.0M;

            for (int i = 0; i < y; i++)
            {
                result = decimal.Multiply(result, x);
            }

            return result;
        }

        public bool updateAggreateRunResultInCallFullValuation(Guid appID, int stageid, int newApprovedLoanSize)
        {                      
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appID", appID);
            parameters.AddWithValue("STAGEID", stageid);

            DataTable dtCustIncomeAndDebt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetCustIncomeAndDebt, parameters);

            IList<Ent_RPCustData> custs = new List<Ent_RPCustData>();
            for (int i = 0; i < dtCustIncomeAndDebt.Rows.Count; i++)
            {
                DataRow custRow = dtCustIncomeAndDebt.Rows[i];
                Ent_RPCustData custData = new Ent_RPCustData();
                custData.CustID = new Guid(Convert.ToString(custRow["CustID"]));
                custData.ProvenIncome = Convert.ToInt32(custRow["ProvenIncome"]);
                custData.Debt = Convert.ToInt32(custRow["Debt"]);
                custData.BorrowType = Convert.ToString(custRow["BorrowType"]).Trim();
                custData.SharedFinancial = false;
                custs.Add(custData);
            }
            //Home income
            decimal homeIncome = 0;
            IDbParameters parameters2 = AdoTemplate.CreateDbParameters();
            parameters2.AddWithValue("appID", appID);

            DataTable dt= AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetFinanceSurvey, parameters2);
            if (dt != null && dt.Rows.Count > 0)
                homeIncome = dt.Rows[0]["FamilyOtherMonthlyIncome"]!=System.DBNull.Value? Convert.ToDecimal(dt.Rows[0]["FamilyOtherMonthlyIncome"]):0;

            //string sqlFinancial = @"select isnull(HomeIncom,0) as HomeIncome from T_Financial where AppID = @appID";
            //object obFinancial= AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.Text, sqlFinancial);
            
            

            //if (obFinancial != null)
            //{
            //    homeIncome = Convert.ToDecimal(obFinancial);
            //}

            //calculate all income and debt
            decimal allIncome = 0;
            decimal allDebt = 0;
            bool hasSharedBA = false;
            for (int i = 0; i < custs.Count; i++)
            {
                if (custs[i].BorrowType == "MB" || !custs[i].SharedFinancial)
                {
                    allIncome += custs[i].ProvenIncome;
                    allDebt += custs[i].Debt;
                }
                else
                {
                    hasSharedBA = true;
                }
            }

            if (hasSharedBA)
            {
                allIncome += homeIncome;
            }

            IDbParameters parameters3= AdoTemplate.CreateDbParameters();
            parameters3.AddWithValue("appID", appID);
            DataTable dtAppInfo = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetPropertyValueTenorAndRateByAppID, parameters2);

//            //get property value,tenor,rate
//            string getAppInfo = @"select isnull(T_PL_FormalAppraisal.Price,0) as FullValResult,ApprovedTenor as Tenor,
//                                    cast(InterestRate as float) as Rate 
//                                    from T_PL_Loan 
//                                   inner join T_PL_FormalAppraisal on T_PL_Loan.AppID = T_PL_FormalAppraisal.AppID
       //                             where T_PL_Loan.AppID = '" + appID.ToString() + "' and IsApplied = '1'";
            //DataTable dtAppInfo = AdoTemplate.ClassicAdoTemplate.DataTableCreate(CommandType.Text,getAppInfo);
            int propertyValue = 0, tenor = 0;
            decimal rate = 0.0M;
            if (dtAppInfo.Rows.Count > 0)
            {
                propertyValue = Convert.ToInt32(dtAppInfo.Rows[0]["FullValResult"]);
                tenor = Convert.ToInt32(dtAppInfo.Rows[0]["Tenor"]);
                rate = Convert.ToDecimal(dtAppInfo.Rows[0]["Rate"]);
            }

            if (allIncome > 0 && propertyValue > 0)
            {
                //calculate monthly installment
                decimal installment = Math.Round(calcInstallment(newApprovedLoanSize, tenor, rate / 100), 2);
                allDebt += installment;
                //calculate DBR this loan
                decimal currDBR = Math.Round(installment / allIncome * 100, 2);

                //calculate DBR total
                decimal totalDBR = Math.Round(allDebt / allIncome * 100, 2);

                //calculate LTV(actual ltv)
                decimal ltv = Math.Round((decimal)newApprovedLoanSize / propertyValue * 100, 2);  
                    IDbParameters parameters1 = AdoTemplate.CreateDbParameters();
                    parameters1.AddWithValue("AppID", appID);
                    parameters1.AddWithValue("CurrDBR", currDBR);
                    parameters1.AddWithValue("TotalDBR", totalDBR);
                    parameters1.AddWithValue("Ltv", ltv);
                    parameters1.AddWithValue("Installment", installment);

                    AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateRunResult, parameters1);
                    
                    //update the T_PL_Loan 
                    IDbParameters parameters4 = AdoTemplate.CreateDbParameters();
                    parameters4.AddWithValue("AppID", appID);
                    parameters4.AddWithValue("Ltv", ltv);
                    parameters4.AddWithValue("Installment", installment);
                    AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_FullRevalution_UpdateLoanInfo, parameters4);
            }
            return true;
        }

        public string GetFirstPercent(string appid, string OrgCode)
        {

            IDbParameters parameters1 = AdoTemplate.CreateDbParameters();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            string MOCount = "";
            string Collateralpe = "";
            string result = "";
            parameters1.AddWithValue("AppID", new Guid(appid));
            DataTable dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetMorgageCountAndCollateralTypeByAppId, parameters1);
            if (dt.Rows.Count > 0) {
                MOCount = dt.Rows[0][0].ToString();
                Collateralpe = dt.Rows[0][1].ToString();
            }
            parameters.AddWithValue("MOCount",MOCount!=""? int.Parse(MOCount):0);
            parameters.AddWithValue("OrgCode", OrgCode);
            parameters.AddWithValue("Collateralpe", Collateralpe);
            object o1 = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetFirstPercent, parameters);
            if (o1 != null)
            {
                result = o1.ToString();
            }
            else
            {
                result = "";
            }
            return result;
        }
       


        public int getLoanSizeByPropertyValueMO(Guid appID, decimal buySellPrice, decimal payAmount, decimal tailAmount)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appID);   
            int result = 0;
            string strGetPropertyInfo = @"select p.ProdName, isnull(apd.MaxLtv,0) as MaxLtv, isnull(cr.Price,0) as FullValResult
                                            from T_PL_Application a 
											left join T_RP_ADR apd on (a.AppID = apd.AppID and T_RP_ADR.ProdID='5')
											left join T_PL_FormalAppraisal cr on a.AppID = cr.AppID
											left join T_Sys_Products p on p.ProdID = a.ProdID
											where a.AppID = @AppID and cr.IsApplied = '1'";

            DataTable dtPropertyInfo = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.Text, strGetPropertyInfo, parameters);

            string verbolResult = @"select min(Price) as VerbolResult from T_PL_OralAppraisal where AppID =@AppID";
            DataTable dtVerbolResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.Text, verbolResult, parameters);

            if (dtPropertyInfo.Rows.Count > 0)
            {
                decimal maxLtv = Convert.ToDecimal(dtPropertyInfo.Rows[0]["MaxLtv"]);
                decimal propertyValue = Convert.ToDecimal(dtPropertyInfo.Rows[0]["FullValResult"]);

                if (dtPropertyInfo.Rows[0]["ProdName"].ToString().Equals("MO"))
                {
                    decimal verbolValue = Convert.ToDecimal(dtVerbolResult.Rows[0]["VerbolResult"]);

                    //取正式评估价格、口估价格、房屋买卖价格三者最低
                    decimal price = propertyValue;
                    if (price > verbolValue)
                        price = verbolValue;
                    if (price > buySellPrice)
                        price = buySellPrice;

                    //两种算法取最低。算法二：price －“首付款金额”－“尾款金额”
                    int result1 = Convert.ToInt32(maxLtv / 100 * price);
                    int result2 = Convert.ToInt32(price - payAmount - tailAmount);
                    result = result1 < result2 ? result1 : result2;
                }
                else //will not used
                {
                    result = Convert.ToInt32(maxLtv / 100 * propertyValue);
                }
            }
            return result;
        }



        public bool UpdateFullRevalutionInfo(string appId, string completedYear, string housePrice, string firstPayment, string tailAmount)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("CompletedYear", completedYear);
            parameters.AddWithValue("HousePrice", housePrice);
            parameters.AddWithValue("FirstPayment", firstPayment);
            parameters.AddWithValue("TailAmount", tailAmount);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DisburseRegist_UpdateFullRevalutionInfo, parameters);
            return i1 > 0 ? true : false;
        }
    }
}
