﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Transaction.Interceptor;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;
using System.Reflection;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Dal.disbursement
{
    public class CustAndContractDao : AdoDaoSupport, ICustAndContractDao
    {

        public IDictionary<string,string> GetApplicationAndLoanInfoByAppID(string appId)
        {
            var result = new Dictionary<string,string>();
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_Get_ApplicationAndLoanInfoByAppID, parameters);
            if (ds != null) {
                result.Add("AppID", ds.Tables[0].Rows[0].ItemArray[0].ToString());
                result.Add("AppNo", ds.Tables[0].Rows[0].ItemArray[1].ToString());
                result.Add("ProdName", ds.Tables[0].Rows[0].ItemArray[2].ToString());
                result.Add("ApprovedLoanSize", ds.Tables[0].Rows[0].ItemArray[3].ToString());
                result.Add("ApprovedTenor", ds.Tables[0].Rows[0].ItemArray[4].ToString());
                result.Add("InterestRate", ds.Tables[0].Rows[0].ItemArray[5].ToString());
                result.Add("Installment", ds.Tables[0].Rows[0].ItemArray[6].ToString());
                result.Add("CustomerName", ds.Tables[0].Rows[0].ItemArray[7].ToString());
                
            }
            return result;
        }


        public CommonTResult<T_PL_Customers> GetCustAndContractCustInfoByAppID(string appId)
        {
            CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(CommandType.StoredProcedure, SPNames.PL_Get_CustAndContractCustInfoByAppID, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            return result;
        }


        public bool SaveCustAndContractContacts(T_PL_CustomerContact Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("HouseProvince", Entity.HouseProvince);
            parameters.AddWithValue("HouseCity", Entity.HouseCity);
            parameters.AddWithValue("HouseDistrict", Entity.HouseDistrict);
            parameters.AddWithValue("HousePostCode", Entity.HousePostCode);
            parameters.AddWithValue("HouseStreet", Entity.HouseStreet);
            parameters.AddWithValue("HouseTelAreaCode", Entity.HouseTelAreaCode);
            parameters.AddWithValue("HouseTelNumber", Entity.HouseTelNumber);
            parameters.AddWithValue("HouseSameAsResidence", Entity.HouseSameAsResidence);
            parameters.AddWithValue("ResidenceProvince", Entity.ResidenceProvince);
            parameters.AddWithValue("ResidenceCity", Entity.ResidenceCity);
            parameters.AddWithValue("ResidenceDistrict", Entity.ResidenceDistrict);
            parameters.AddWithValue("ResidenceStreet", Entity.ResidenceStreet);
            parameters.AddWithValue("ResidencePostCode", Entity.ResidencePostCode);
            parameters.AddWithValue("ResidenceTelAreaCode", Entity.ResidenceTelAreaCode);
            parameters.AddWithValue("ResidenceTelNumber", Entity.ResidenceTelNumber);
            parameters.AddWithValue("WorkingProvince", Entity.WorkingProvince);
            parameters.AddWithValue("WorkingCity", Entity.WorkingCity);
            parameters.AddWithValue("WorkingDistrict", Entity.WorkingDistrict);
            parameters.AddWithValue("WorkingStreet", Entity.WorkingStreet);
            parameters.AddWithValue("WorkingPostCode", Entity.WorkingPostCode);
            parameters.AddWithValue("WorkingTelAreaCode", Entity.WorkingTelAreaCode);
            parameters.AddWithValue("WorkingTelNumber", Entity.WorkingTelNumber);
            parameters.AddWithValue("WorkingTelExtNumber", Entity.WorkingTelExtNumber);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_Save_CustAndContractContacts, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }


        public IDictionary<string, string> GetCustConfirmInfoAndFeeByAppId(string appId)
        {
            var result = new Dictionary<string, string>();
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_Get_CustConfirmInfoAndFeeByAppId, parameters);
            if (ds != null)
            {
                result.Add("ContractConfirmed", ds.Tables[0].Rows[0].ItemArray[0].ToString().Trim());
                result.Add("ContractSignDate", CommonUtility.GetFormatedDate1(ds.Tables[0].Rows[0].ItemArray[1].ToString()));
                result.Add("ContractConfirmDate", CommonUtility.GetFormatedDate1(ds.Tables[0].Rows[0].ItemArray[2].ToString()));
                result.Add("Fee", ds.Tables[0].Rows[0].ItemArray[3].ToString().Trim());
                result.Add("LegalFee", ds.Tables[0].Rows[0].ItemArray[4].ToString().Trim());
                result.Add("ApprovedLoanSize", ds.Tables[0].Rows[0].ItemArray[5].ToString().Trim());
            }
            return result;
        }

        

        public bool SaveCustAndContractPayMethodCustConfirmInfoAndFee(CustAndContractPayMethodCustConfirmInfoAndFeeView Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("PaymentMethod", Entity.PaymentMethod);
            parameters.AddWithValue("DebitName", Entity.DebitName);
            parameters.AddWithValue("DebitBankName", Entity.DebitBankName);
            parameters.AddWithValue("DebitSubBankName", Entity.DebitSubBankName);
            parameters.AddWithValue("DebitAccount", Entity.DebitAccount);
            parameters.AddWithValue("DebitReason", Entity.DebitReason);
            parameters.AddWithValue("DebitRemarks", Entity.DebitRemarks);
            parameters.AddWithValue("PaymentAmount", Entity.PaymentAmount);
            parameters.AddWithValue("ContractConfirmed", Entity.ContractConfirmed);
            parameters.AddWithValue("ContractSignDate", Entity.ContractSignDate);
            parameters.AddWithValue("ContractConfirmDate", Entity.ContractConfirmDate);
            parameters.AddWithValue("Fee", Entity.Fee);
            parameters.AddWithValue("LegalFee", Entity.LegalFee);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_Save_CustAndContractPayMethodCustConfirmInfoAndFee, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }


        public System.Data.DataSet GetGuarantorByAppID(string appID)
        {
            DataSet result = new System.Data.DataSet();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appID);
            result = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_GuarantorsByAppID, parameters);
            return result;
        }


        public System.Data.DataSet GetMergeDataSourceByAppNo(string appNo)
        {
            DataSet result = new System.Data.DataSet();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ApplicationNo", appNo);
            result = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_CustAndContract_GetMergeDateSourceByAppNo, parameters);
            return result;
        }

        public Dictionary<string,string> GetFileNameAndPathByProdID(string prodID)
        {
            Dictionary<string, string> result = new Dictionary<string, string>();
            DataSet ds = new System.Data.DataSet();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", prodID);
            ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_CustAndContract_GetFileNameAndPathByProdID, parameters);
            if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0) { 
                result.Add("FileName",ds.Tables[0].Rows[0][0].ToString());
                result.Add("FilePath", ds.Tables[0].Rows[0][1].ToString());
            }
            return result;
        }

        public CommonTResult<AttachmentFilesAndConditionsEntity> GetAttachmentFilesAndConditionListByProdID(string prodId)
        {
            CommonTResult<AttachmentFilesAndConditionsEntity> result = new CommonTResult<AttachmentFilesAndConditionsEntity>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", prodId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<AttachmentFilesAndConditionsEntity>(CommandType.StoredProcedure,
                SPNames.PL_CustAndContract_getAttachmentFilesListByProdID, new AttachmentFilesAndConditionsEntityMapper<AttachmentFilesAndConditionsEntity>(), parameters);
            return result;
        }

        public IList<T_Sys_Parameters> GetConditionColumnsName()
        {
            IList<T_Sys_Parameters> list = AdoTemplate.QueryWithRowMapper<T_Sys_Parameters>(CommandType.StoredProcedure, SPNames.PL_CustAndContract_GetConditionColumnsName, new T_Sys_ParametersMapper<T_Sys_Parameters>());
            return list;
        }

        public System.Data.DataSet getGuarantorInfo(string appId)
        {
            DataSet result = new System.Data.DataSet();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            result = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_GuarantorsByAppID, parameters);
            return result;
        }

        public bool IsPartMo(string appId)
        { 
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            object o1 = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetIsPartMo, parameters);
            if (o1 != null)
            {
                return o1.ToString() == "True" ? true : false;
            }
            else
            {
                return o1.ToString() == "False" ? true : false;
            }
        }


        public int CompareTenor(string appId)
        {   
            decimal ATenor;
            decimal RentTenor;

            DataSet ds = GetCompareTenor(appId);

            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                decimal tempTenor = 0.0m;

                Decimal.TryParse(ds.Tables[0].Rows[0]["ATenor"].ToString(), out tempTenor);

                ATenor = tempTenor / 12;

                Decimal.TryParse(ds.Tables[0].Rows[0]["RentTenor"].ToString(), out tempTenor);

                RentTenor = tempTenor;

                int ProdId = Convert.ToInt32(ds.Tables[0].Rows[0]["ProdId"]);


                if (ProdId == 5)
                {
                    if (RentTenor >= 6)
                    {
                        return 1;
                    }
                    return -1;
                }
                else
                {
                    if (RentTenor >= 6 && RentTenor / 12 < 3)
                    {
                        return 1;
                    }

                    if (RentTenor / 12 >= 3 || RentTenor / 12 >= ATenor)
                    {
                        return 2;
                    }
                }
            }
            return -1;
        }

        public DataSet GetCompareTenor(string appId)
        {
            DataSet result = new System.Data.DataSet();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            result = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_GetCompareTenor, parameters);
            return result;
        }
    }
}
