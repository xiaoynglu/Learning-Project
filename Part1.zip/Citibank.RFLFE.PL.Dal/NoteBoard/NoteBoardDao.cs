﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.NoteBoard
{
    public class NoteBoardDao : AdoDaoSupport, INoteBoardDao
    {
        public CommonTResult<T_PL_News> GetNewsList(int Start, int Limit, string keyword)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Start", Start);
            parameters.AddWithValue("Limit", Limit);
            parameters.AddWithValue("keyword", keyword);
            
            parameters.AddOut("Count", DbType.Int32);

            CommonTResult<T_PL_News> result = new CommonTResult<T_PL_News>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_News>(CommandType.StoredProcedure, SPNames.PL_GetNewsList, new T_PL_NewsMapper<T_PL_News>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<T_PL_NoteWaitConfig> GetNoteWait(int Start, int Limit, string SOEID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Start", Start);
            parameters.AddWithValue("Limit", Limit);
            parameters.AddWithValue("SOEID", SOEID);
            parameters.AddOut("Count", DbType.Int32);

            CommonTResult<T_PL_NoteWaitConfig> result = new CommonTResult<T_PL_NoteWaitConfig>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_NoteWaitConfig>(CommandType.StoredProcedure, SPNames.PL_GetNoteWait, new T_PL_NoteWaitConfigMapper<T_PL_NoteWaitConfig>(), parameters);
            //result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public bool SaveItem(int TID,string title,string content,string soeid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
            parameters.AddWithValue("title", title);
            parameters.AddWithValue("content", content);
            parameters.AddWithValue("soeid", soeid);            

            CommonTResult<T_PL_NoteWaitConfig> result = new CommonTResult<T_PL_NoteWaitConfig>();
            int i1= AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure,SPNames.PL_SaveNews,parameters);
            return i1 > 0 ? true : false;
        }
        public bool DeleteItem(int TID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
           

            CommonTResult<T_PL_NoteWaitConfig> result = new CommonTResult<T_PL_NoteWaitConfig>();
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DelNews, parameters);
            return i1 > 0 ? true : false;
        }

        public CommonTResult<T_PL_NoteWaitConfig> GetNoteCurrent(int Start, int Limit,string SOEID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Start", Start);
            parameters.AddWithValue("Limit", Limit);
            parameters.AddWithValue("SOEID", SOEID);
            parameters.AddOut("Count", DbType.Int32);

            CommonTResult<T_PL_NoteWaitConfig> result = new CommonTResult<T_PL_NoteWaitConfig>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_NoteWaitConfig>(CommandType.StoredProcedure, SPNames.PL_GetNoteCurrent, new T_PL_NoteWaitConfigMapper<T_PL_NoteWaitConfig>(), parameters);
            //result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public IList<T_Sys_Branch> GetNotePageBanks(string orgcode)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("orgcode", orgcode);
            IList<T_Sys_Branch> result=AdoTemplate.QueryWithRowMapper<T_Sys_Branch>(CommandType.StoredProcedure, SPNames.PL_GetNotePageBanks,new T_Sys_BranchMapper<T_Sys_Branch>(), parameters);
            return result;
        }

        public bool SaveMessageReadLog(string soeid,string TID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("soeid", soeid);
            parameters.AddWithValue("TID", TID);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveMessageReadLog,  parameters);
            return i1 > 0 ? true : false;
        }

        public CommonTResult<T_Sys_Roles> GetSystemRoles()
        {
            CommonTResult<T_Sys_Roles> result = new CommonTResult<T_Sys_Roles>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_Roles>(CommandType.StoredProcedure, SPNames.PL_NoteBoard_GetSystemRoles, new T_Sys_RolesMapper<T_Sys_Roles>());
            return result;
        }

        public int GetMessageLastReadID(string soeid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("SoeId", soeid);
            parameters.AddOut("Result", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_NoteBoard_GetMessageLastReadID, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? -1 : Int32.Parse(parameters["@Result"].Value.ToString());
        }

        public CommonTResult<T_PL_MessageAndNotice> GetMessageContent(int start,int limit,int typevalue,string soeid,string orgcode)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("soeid", soeid);
            parameters.AddWithValue("orgcode", orgcode);
            parameters.AddWithValue("typevalue", typevalue);
            parameters.AddOut("Count", DbType.Int32);

            CommonTResult<T_PL_MessageAndNotice> result = new CommonTResult<T_PL_MessageAndNotice>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_MessageAndNotice>(CommandType.StoredProcedure, SPNames.PL_GetMessageContent, new T_PL_MessageAndNoticeMapper<T_PL_MessageAndNotice>(), parameters);
            return result;
        }

        public bool SaveMessage(T_PL_MessageAndNotice entity,string soeid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("typevalue", entity.typevalue);
            parameters.AddWithValue("contentvalue", entity.contentvalue);
            parameters.AddWithValue("starttime", entity.starttime);
            parameters.AddWithValue("endtime", entity.endtime);
            parameters.AddWithValue("orgcode", entity.orgcode);
            parameters.AddWithValue("roletype", entity.roletype);
            parameters.AddWithValue("soeid", soeid);

            int i1= AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure,SPNames.PL_NoteBoardSaveMessage,parameters);
            return i1 > 0 ? true : false;
        }

    }
}
