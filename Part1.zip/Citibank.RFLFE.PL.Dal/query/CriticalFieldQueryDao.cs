﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.query
{
    public class CriticalFieldQueryDao :AdoDaoSupport, ICriticalFieldQueryDao
    {
        public CommonTResult<T_PL_AppAuditLog> QueryList(int start, int limit, CriticalFieldQueryView entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("AppNO", entity.AppNO);
            parameters.AddWithValue("StageID", entity.StageID);
            parameters.AddWithValue("StartTime", entity.StartTime);
            parameters.AddWithValue("EndTime", entity.EndTime);
            parameters.AddWithValue("soeid", entity.Soeid);
            parameters.AddOut("Count",DbType.Int32);
            CommonTResult<T_PL_AppAuditLog> result = new CommonTResult<T_PL_AppAuditLog>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_AppAuditLog>(CommandType.StoredProcedure, SPNames.PL_GetCriticalFieldList, new T_PL_AppAuditLogMapper<T_PL_AppAuditLog>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public List<string> GetParameterLogData(string rfid)
        {
            List<string> result = new List<string>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("GroupNumber", rfid);
            var dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_CriticalFieldQuery_GetParameterLogData, parameters);
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    result.Add(dr["logcontent"].ToString());
                }
            }
            return result;
        }

        public CommonTResult<T_PL_ParameterAuditLog> QueryParameterList(int start, int limit, CriticalFieldQueryView entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);                        
            parameters.AddWithValue("StartTime", entity.StartTime);
            parameters.AddWithValue("EndTime", entity.EndTime);
            parameters.AddWithValue("soeid", entity.Soeid);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<T_PL_ParameterAuditLog> result = new CommonTResult<T_PL_ParameterAuditLog>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_ParameterAuditLog>(CommandType.StoredProcedure, SPNames.PL_GetCriticalFieldParameterList, new T_PL_ParameterAuditLogMapper<T_PL_ParameterAuditLog>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public string GetTableName(string rfid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("GroupNumber", rfid);
            parameters.AddOut("Result", DbType.String, 100);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_CriticalFieldQuery_GetTableName, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : (string)parameters["@Result"].Value.ToString();
        }

        public bool GetIsCriticalField(string tablename,string fieldname)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TableName", tablename);
            parameters.AddWithValue("FieldName", fieldname);
            parameters.AddOut("Result", DbType.Boolean);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_CriticalFieldQuery_GetIsCriticalField, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? false : Boolean.Parse(parameters["@Result"].Value.ToString());
        }

        public List<string> GetCriticalField(string tablename)
        {
            List<string> result = new List<string>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TableName", tablename);
            var dt =  AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_CriticalFieldQuery_GetCriticalField, parameters);
            foreach (DataRow dr in dt.Rows)
            {
                result.Add(dr["field"].ToString());
            }
            return result;
        }

        public List<string> GetLogData(string rfid)
        {
            List<string> result = new List<string>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("GroupNumber", rfid);
            var dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_CriticalFieldQuery_GetLogData, parameters);
            foreach (DataRow dr in dt.Rows)
            {
                result.Add(dr["logcontent"].ToString());
            }
            return result;
        }
    }
}
