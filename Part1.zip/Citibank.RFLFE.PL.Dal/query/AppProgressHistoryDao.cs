﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;


namespace Citibank.RFLFE.PL.Dal.query
{
    public class AppProgressHistoryDao : AdoDaoSupport, IAppProgressHistoryDao
    {
        public CommonTResult<AppProgressHistoryView> GetAppProgressHistory(int start, int limit, string AppID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("AppID", AppID);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<AppProgressHistoryView> map = new CommonTResult<AppProgressHistoryView>();
            map.ResultList = AdoTemplate.QueryWithRowMapper<AppProgressHistoryView>(CommandType.StoredProcedure, SPNames.PL_GetProcessHistory, new AppProgressHistoryViewMapper<AppProgressHistoryView>(), parameters);
            map.ResultCount = (int)parameters["@Count"].Value;
            return map;

        }        
    }
}
