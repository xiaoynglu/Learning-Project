﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using System.Data;
using Citibank.RFLFE.PL.Entities;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.query
{
    public class QueryDao : AdoDaoSupport, IQueryDao
    {
        public DataTable GetDWHInfo(T_PL_DWH condition)
        {
            DataTable dt = new DataTable();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("FileType", condition.FileType);
            parameters.AddWithValue("DateBegin", condition.DateBegin);
            parameters.AddWithValue("DateEnd", condition.DateEnd);
            parameters.AddOut("Count", DbType.Int32);
            dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetReportInfoByFileType, parameters);
            return dt;
        }

        public CommonTResult<T_PL_BureauQueryResult> GetAppInfoByIDNum(string ID_NUMBER, int start, int limit)
        {
            CommonTResult<T_PL_BureauQueryResult> result = new CommonTResult<T_PL_BureauQueryResult>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ID_NUMBER", ID_NUMBER);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_BureauQueryResult>(
                CommandType.StoredProcedure, SPNames.PL_GetAppInfoByIDNum, new BaseMapper<T_PL_BureauQueryResult>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value; 
            result.IsSuccess = true;
            return result;
        }

        public CommonTResult<T_PL_BureauQueryResult> GetCustInfoByOrgCode(string OrgCode, int start, int limit)
        {
            CommonTResult<T_PL_BureauQueryResult> result = new CommonTResult<T_PL_BureauQueryResult>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", OrgCode);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_BureauQueryResult>(
                CommandType.StoredProcedure, SPNames.PL_GetCustInfoByOrgCode, new BaseMapper<T_PL_BureauQueryResult>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            result.IsSuccess = true;
            return result;
        }

        public CommonTResult<T_WF_PL_Stage> GetAllStageNameInQuery(int QueryPage)
        {
            CommonTResult<T_WF_PL_Stage> result = new CommonTResult<T_WF_PL_Stage>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("QueryPage", QueryPage);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_WF_PL_Stage>(
                CommandType.StoredProcedure, SPNames.PL_GetAllStageNameInQuery, new BaseMapper<T_WF_PL_Stage>(), parameters);
            result.ResultCount = result.ResultList.Count;
            result.IsSuccess = true;
            return result;
        }

        public CommonTResult<T_PL_LongOrder> GetLongApplyByDay(T_PL_Application app, int day, int start, int limit)
        {
            CommonTResult<T_PL_LongOrder> result = new CommonTResult<T_PL_LongOrder>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ApplicationNo", app.ApplicationNo);
            parameters.AddWithValue("Day", day);
            parameters.AddWithValue("StageID", app.StageID);
            parameters.AddWithValue("OrgCode", app.OrgCode);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_LongOrder>(
                CommandType.StoredProcedure, SPNames.PL_GetLongApplyByDay, new BaseMapper<T_PL_LongOrder>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            result.IsSuccess = true;
            return result;
        }

        public CommonTResult<T_Sys_Users> GetSalesIDByOrgCode(string orgCode, string soeID, int roleType)
        {
            CommonTResult<T_Sys_Users> result = new CommonTResult<T_Sys_Users>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", orgCode);
            parameters.AddWithValue("SoeID", soeID);
            parameters.AddWithValue("RoleType", roleType);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_Users>(
                CommandType.StoredProcedure, SPNames.PL_GetSalesIDByOrgCode, new BaseMapper<T_Sys_Users>(), parameters);
            result.ResultCount = result.ResultList.Count;
            result.IsSuccess = true;
            return result;
        }

        public CommonTResult<T_WF_PL_INS> GetUserProcessInstance(T_PL_Application condition, int start, int limit)
        {
            CommonTResult<T_WF_PL_INS> result = new CommonTResult<T_WF_PL_INS>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppNo", string.IsNullOrEmpty(condition.ApplicationNo)?"":condition.ApplicationNo);
            parameters.AddWithValue("ProcID", condition.CurrentProcessor);
            parameters.AddWithValue("OrgCode", condition.OrgCode);
            parameters.AddWithValue("DateBegin", condition.DateBegin);
            parameters.AddWithValue("DateEnd", condition.DateEnd);
            parameters.AddWithValue("StageId", string.IsNullOrEmpty(condition.StageID) ? "" : condition.StageID);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_WF_PL_INS>(
                CommandType.StoredProcedure, SPNames.PL_GetUserProcessInstance, new T_WF_PL_INSRowMapper<T_WF_PL_INS>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            result.IsSuccess = true;
            return result;
        }

        public CommonTResult<T_PL_UserProcess> ExportUserProcessByAppID(string appids)
        {
            CommonTResult<T_PL_UserProcess> result = new CommonTResult<T_PL_UserProcess>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppIDs", appids);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_UserProcess>(
                CommandType.StoredProcedure, SPNames.PL_ExportUserProcessByAppID, new BaseMapper<T_PL_UserProcess>(), parameters);
            result.ResultCount = result.ResultList.Count;
            result.IsSuccess = true;
            return result;
        }

        public CommonTResult<T_PL_Deviation> GetDeviationList(T_PL_Application condition, int start, int limit)
        {
            CommonTResult<T_PL_Deviation> result = new CommonTResult<T_PL_Deviation>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppNo", string.IsNullOrEmpty(condition.ApplicationNo) ? "" : condition.ApplicationNo);
            parameters.AddWithValue("ProdID", condition.ProdID);
            parameters.AddWithValue("IDNo", condition.IDNo);
            parameters.AddWithValue("FullName", string.IsNullOrEmpty(condition.CustomerName) ? "" : condition.CustomerName);
            parameters.AddWithValue("DateBegin", condition.DateBegin);
            parameters.AddWithValue("DateEnd", condition.DateEnd);            
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Deviation>(
                CommandType.StoredProcedure, SPNames.PL_GetDeviationList, new BaseMapper<T_PL_Deviation>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            result.IsSuccess = true;
            return result;
        }

        public CommonTResult<T_PL_DeviationTotalInfo> GetDeviationTotalInfo(T_PL_Application condition)
        {
            CommonTResult<T_PL_DeviationTotalInfo> result = new CommonTResult<T_PL_DeviationTotalInfo>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppNo", string.IsNullOrEmpty(condition.ApplicationNo) ? "" : condition.ApplicationNo);
            parameters.AddWithValue("ProdID", condition.ProdID);
            parameters.AddWithValue("IDNo", condition.IDNo);
            parameters.AddWithValue("FullName", string.IsNullOrEmpty(condition.CustomerName) ? "" : condition.CustomerName);
            parameters.AddWithValue("DateBegin", condition.DateBegin);
            parameters.AddWithValue("DateEnd", condition.DateEnd);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_DeviationTotalInfo>(
                CommandType.StoredProcedure, SPNames.PL_GetDeviationTotalInfo, new BaseMapper<T_PL_DeviationTotalInfo>(), parameters);
            result.ResultCount = result.ResultList.Count;
            result.IsSuccess = true;
            return result;
        }

        public CommonTResult<T_PL_ApprovalInfo> GetApprovalInfoByAppId(string AppID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppID);
            CommonTResult<T_PL_ApprovalInfo> result = new CommonTResult<T_PL_ApprovalInfo>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_ApprovalInfo>(CommandType.StoredProcedure, SPNames.PL_GetApprovalInfoByAppId, new BaseMapper<T_PL_ApprovalInfo>(), parameters);
            result.IsSuccess = result.ResultList.Count > 0 ? true : false;
            return result;
        }
    }
}
