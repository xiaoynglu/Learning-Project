﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.query
{
    public class AppProgressQueryDao : AdoDaoSupport, IAppProgressQueryDao
    {

        public CommonTResult<appProgressDetailView> GetAppDetail(string AppID, string AppNo)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppID);
            parameters.AddWithValue("AppNo", AppNo);            
            CommonTResult<appProgressDetailView> map = new CommonTResult<appProgressDetailView>();
            map.ResultList = AdoTemplate.QueryWithRowMapper<appProgressDetailView>(CommandType.StoredProcedure, SPNames.PL_tools_CS_SPROC_InquiryDtl, new appProgressDetailViewMapper<appProgressDetailView>(), parameters);
            return map;

        }
        /// <summary>
        /// Add instance
        /// </summary>
        /// <param name="entity"></param>
        public CommonTResult<appProgressView> GetappProgress(int start, int limit, string strParam, string strType, string orgCode)
        {

            if (strType == "RequestNo")
            {
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("ApplicationNo", strParam);
                parameters.AddWithValue("OrgCode", orgCode);                
                parameters.AddWithValue("start", start);
                parameters.AddWithValue("limit", limit);
                parameters.AddOut("Count", DbType.Int32);
                CommonTResult<appProgressView> map = new CommonTResult<appProgressView>();
                map.ResultList = AdoTemplate.QueryWithRowMapper<appProgressView>(CommandType.StoredProcedure, SPNames.PL_tools_CS_SPROC_InquiryByAppNo, new appProgressViewMapper<appProgressView>(), parameters);
                map.ResultCount = (int)parameters["@Count"].Value;
                return map;
            }
            else if (strType == "CustId")
            {
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("CustID", strParam);
                parameters.AddWithValue("OrgCode", orgCode);
                parameters.AddWithValue("start", start);
                parameters.AddWithValue("limit", limit);
                parameters.AddOut("Count", DbType.Int32);
                CommonTResult<appProgressView> map = new CommonTResult<appProgressView>();
                map.ResultList = AdoTemplate.QueryWithRowMapper<appProgressView>(CommandType.StoredProcedure, SPNames.PL_tools_CS_SPROC_InquiryByCustID, new appProgressViewMapper<appProgressView>(), parameters);
                map.ResultCount = (int)parameters["@Count"].Value;
                return map;
               
            }
            else if (strType == "CustName")
            {
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("CustName", strParam);
                parameters.AddWithValue("OrgCode", orgCode);
                parameters.AddWithValue("start", start);
                parameters.AddWithValue("limit", limit);
                parameters.AddOut("Count", DbType.Int32);
                CommonTResult<appProgressView> map = new CommonTResult<appProgressView>();
                map.ResultList = AdoTemplate.QueryWithRowMapper<appProgressView>(CommandType.StoredProcedure, SPNames.PL_tools_CS_SPROC_InquiryByCustName, new appProgressViewMapper<appProgressView>(), parameters);
                map.ResultCount = (int)parameters["@Count"].Value;
                return map;                
            }
            else
            {
                return null;
            }
        }

        public bool CheckSoeIdRight(string soeId, string stageId)
        {
            bool result = false;
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("SoeID", soeId);
            parameters.AddOut("Result", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_CheckSoeIdRight, parameters);
            if (parameters["@Result"].Value != System.DBNull.Value) {
                if (Int32.Parse(parameters["@Result"].Value.ToString()) > 0)
                    result =  true;
            }
            return result;
        }
    }
}
