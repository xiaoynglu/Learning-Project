﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Dal
{ 
    public class SPNames
    {

        #region application
        // ------------------------------------new proposal----------------------------------------
        public const string PL_GetNPProductList = "dbo.SP_PL_GetNPProductList";
        public const string PL_InitNewProposal = "dbo.SP_PL_InitNewProposal";
        public const string PL_GetPreviouseCasesByIDNo = "dbo.SP_PL_GetPreviouseCasesByIDNo";
        public const string PL_SystemDecideVerifyInfo = "dbo.SP_PL_SystemDecideVerifyInfo";
        public const string PL_CheckIsDoNewProposalSystemDecided = "dbo.SP_PL_CheckIsDoNewProposalSystemDecided";
        public const string PL_CopyFinanceInfoToNextStage = "dbo.SP_PL_CopyFinanceInfoToNextStage";
        //----------------------------------------------------------------------------
        public const string PL_GetProdNameByProdID = "dbo.SP_PL_GetProdNameByProdID";
        public const string PL_UpdateAppSubmit = "dbo.SP_PL_UpdateAppSubmit";
        public const string PL_GetProdIDbyProdName = "dbo.SP_PL_GetProdIDbyProdName";
        public const string PL_GetApplicationNoByAppId = "dbo.SP_PL_GetApplicationNoByAppId";
        public const string PL_GetLoanByAppId = "dbo.SP_PL_GetLoanByAppId";
        public const string PL_GetCustomers = "dbo.SP_PL_GetCustomers";
        public const string PL_GetAppCheckerCustInfo = "dbo.SP_PL_GetAppCheckerCustInfo";
        public const string PL_GetApplicationDetail = "dbo.SP_PL_GetApplicationDetail";
        public const string PL_GetApplicationByAppId = "dbo.SP_PL_GetApplicationByAppId";
        public const string PL_GetApplicationByAppNo = "dbo.SP_PL_GetApplicationByAppNo";
        public const string PL_GetCustDetailInfoByCustId = "dbo.SP_PL_GetCustDetailInfoByCustId";
        public const string PL_AppCheckerGetDocListRoles = "dbo.SP_PL_PL_AppCheckerGetDocListRoles";
        public const string PL_GetGuarantorsByAppId = "dbo.SP_PL_GetCustDetailInfoByCustId";
        public const string PL_GetGuarantorByAppId = "dbo.SP_PL_GetGuarantorByAppId";
        public const string PL_GetFamilyMembersByCustId = "dbo.SP_PL_GetFamilyMembersByCustId";
        public const string PL_GetCustomerContactByCustId = "dbo.SP_PL_GetCustomerContactByCustId";
        public const string PL_GetFinanceSalaryByCustId = "dbo.SP_PL_GetFinanceSalaryByCustId";
        public const string PL_GetFinanceSelfByCustId = "dbo.SP_PL_GetFinanceSelfByCustId";
        public const string PL_GetCollateralByAppId = "dbo.SP_PL_GetCollateralByAppId";
        public const string PL_GetLTVFactors = "dbo.SP_PL_GetLTVFactors";
        public const string PL_GetLTVParams = "dbo.SP_PL_GetLTVParams";
        public const string PL_GetVendorListByAppId = "dbo.SP_PL_GetVendorListByAppId";
        public const string PL_GetMortgagorListByAppId = "dbo.SP_PL_GetMortgagorListByAppId";
        public const string PL_GetLoanPurpose = "dbo.SP_PL_GetLoanPurpose";
        public const string PL_SaveAppCheckerReviewDocList = "dbo.SP_PL_SaveAppCheckerReviewDocList";
        public const string PL_SaveApplicationByAppId = "dbo.SP_PL_SaveApplicationByAppId";
        public const string PL_SaveCustomerInfo = "dbo.SP_PL_SaveCustomerInfo";
        public const string PL_GetAppSuffix = "dbo.SP_PL_GetAppSuffix";
        public const string PL_SaveAppNo = "dbo.SP_PL_SaveAppNo";
        public const string PL_SaveLoanByAppId = "dbo.SP_PL_SaveLoanByAppId";
        public const string PL_GetCustIDListByAppID = "dbo.SP_PL_GetCustIDListByAppID";
        public const string PL_GetOrgCodeByAppId = "dbo.SP_PL_GetOrgCodeByAppId";

        //---------------------Bureau Check Start--------------------------
        public const string PL_QueryPersonalInfoByIdAndAppId = "dbo.SP_PL_QueryPersonalInfoByIdAndAppId";
        public const string PL_GetBureauLoanDetails = "dbo.SP_PL_GetBureauLoanDetails";
        public const string PL_GetBureauCardDetails = "dbo.SP_PL_GetBureauCardDetails";
        public const string PL_GetCustInfoByAppID = "dbo.SP_PL_GetCustInfoByAppID";
        public const string PL_GetBureauHTMLFileName = "dbo.SP_PL_GetBureauHTMLFileName";
        public const string PL_RefreshBureauBasicInfo = "dbo.SP_PL_RefreshBureauBasicInfo";
        public const string PL_SaveBureauBasicInfo = "dbo.SP_PL_SaveBureauBasicInfo";
       // public const string PL_SaveBureauCheckDocSubmitByCustProduct = "SP_PL_SaveBureauCheckDocSubmitByCustProduct";
        
        //---------------------Amend Application begin----------------------------
        public const string PL_UpdateDocListToAppChecker = "dbo.SP_PL_UpdateDocListToAppChecker";
        public const string PL_GetCollateralTypeByAppId = "dbo.SP_PL_GetCollateralTypeByAppId";
        public const string PL_GetMortgageCountByAppId = "dbo.SP_PL_GetMortgageCountByAppId";
        public const string PL_GetAmendAppRACMapping = "dbo.SP_PL_GetAmendAppRACMapping";
        //---------------------Amend Application end----------------------------

        //---------------------Topup Upload start--------------------------
        public const string PL_ADD_TOPUPUPLOADMAKER = "dbo.SP_PL_AddTopupUploadMaker";
        public const string PL_GET_TOPUPUPLOADMAKERLIST = "dbo.SP_PL_GetTopupUploadMakerList";
        public const string PL_ARE_TOPUPUPLOADMAKER = "dbo.SP_PL_CreateMultiTopupData";
        public const string PL_REJ_TOPUPUPLOADMAKER = "dbo.SP_PL_RejectTopuploadMaker";
        //---------------------Topup Upload end----------------------------

        //---------------------ApplyInfoDao start--------------------------
        public const string PL_GET_APPLYDETAILBYAPPNO = "dbo.SP_PL_GetApplyDetailByAppNo";
        public const string PL_ALT_LOANINDUSTRYMAKER = "dbo.SP_PL_SaveLoanIndustryMaker";
        public const string PL_ALT_NOSOFCOLLATERALMAKER = "dbo.SP_PL_SaveNosOfCollateralMaker";
        public const string PL_ARE_NOSOFCOLLATERALMAKER = "dbo.SP_PL_ApproveNosOfCollateralMaker";
        public const string PL_REJ_NOSOFCOLLATERALMAKER = "dbo.SP_PL_RejectNosOfCollateralMaker";
        public const string PL_ARE_LOANINDUSTRYMAKER = "dbo.SP_PL_ApproveLoanIndustryMaker";
        public const string PL_REJ_LOANINDUSTRYMAKER = "dbo.SP_PL_RejectLoanIndustryMaker";
        public const string PL_ARE_MORTGAGORMAKER = "dbo.SP_PL_ApproveMortgagorMaker";
        public const string PL_REJ_MORTGAGORMAKER = "dbo.SP_PL_RejectMortgagorMaker";
        //---------------------ApplyInfoDao end----------------------------

        #endregion

        #region ExceptionApprove
        public const string PL_ExceptionApprove_UpdatePricingDeviatedAndRate = "SP_PL_ExceptionApprove_UpdatePricingDeviatedAndRate";
        #endregion

        #region approval
        //---------------------TOPUP Verification start----------------------------
        //PROC_获取贷款人审核信息
        public const string PL_GET_BORROWERVERIFICATION = "dbo.SP_PL_GetBorrowerVerification";
        //PROC_获取电话核实信息
        public const string PL_GET_PHONEVERIFICATION = "dbo.SP_PL_GetPhoneVerification";
        //PROC_保存电话核实信息
        public const string PL_ALT_PHONEVERIFICATION = "dbo.SP_PL_SavePhoneVerification";
        //PROC_删除电话核实信息
        public const string PL_DEL_PHONEVERIFICATION = "dbo.SP_PL_DeletePhoneVerification";
        //PROC_获取场所核实信息
        public const string PL_GET_SITEVERIFICATION = "dbo.SP_PL_GetSiteVerification";
        //PROC_保存场所核实信息
        public const string PL_ALT_SITEVERIFICATION = "dbo.SP_PL_SaveSiteVerification";
        //PROC_删除场所核实信息
        public const string PL_DEL_SITEVERIFICATION = "dbo.SP_PL_DeleteSiteVerification";
        //PROC_获取住宅核实信息
        public const string PL_GET_HOUSEVERIFICATION = "dbo.SP_PL_GetHouseVerification";
        //PROC_保存住宅核实信息
        public const string PL_ALT_HOUSEVERIFICATION = "dbo.SP_PL_SaveHouseVerification";
        //PROC_删除住宅核实信息
        public const string PL_DEL_HOUSEVERIFICATION = "dbo.SP_PL_DeleteHouseVerification";
        //PROC_获取外部核实信息
        public const string PL_GET_EXTERNALVERIFICATION = "dbo.SP_PL_GetExternalVerification";
        //PROC_保存外部核实信息
        public const string PL_ALT_EXTERNALVERIFICATION = "dbo.SP_PL_SaveExternalVerification";
        //PROC_删除外部核实信息
        public const string PL_DEL_EXTERNALVERIFICATION = "dbo.SP_PL_DeleteExternalVerification";
        //PROC_获取工作场所核实信息
        public const string PL_GET_WORKINGVERIFICATION = "dbo.SP_PL_GetWorkingVerification";
        //PROC_保存工作场所核实信息
        public const string PL_ALT_WORKINGVERIFICATION = "dbo.SP_PL_SaveWorkingVerification";
        //PROC_删除工作场所核实信息
        public const string PL_DEL_WORKINGVERIFICATION = "dbo.SP_PL_DeleteWorkingVerification";
        //PROC_保存核实记录
        public const string PL_ALT_VERIFICATIONRECORD = "dbo.SP_PL_SaveVerificationRecord";
        //PROC_获取上传贷款人信息
        public const string PL_GET_TOPUPLOADLOAN = "dbo.SP_PL_GetTopupUploadLoan";
        //PROC_获取审批记录信息
        public const string PL_GET_VERIFICATIONRECORD = "dbo.SP_PL_GetVerificationRecord";
        //PROC_获取贷款核实信息
        public const string PL_GET_LOANAPPROVAL = "dbo.SP_PL_GetLoanApproval";
        //PROC_获取支付方式信息
        public const string PL_GET_CREDITPAYMENTBYAPPID = "dbo.SP_PL_GetCreditPaymentByAppID";
        //PROC_保存支付方式信息
        public const string PL_ALT_CREDITPAYMENTDETAIL = "dbo.SP_PL_SaveCreditPaymentDetail";
        //---------------------TOPUP Verification end------------------------------
        //---------------------PreCheck And Verification start----------------------------
        //PROC_获取口估记录
        public const string PL_GET_ORALAPPRAISALS = "dbo.SP_PL_GetOralAppraisals";
        //PROC_保存口估记录
        public const string PL_ALT_ORALAPPRAISAL = "dbo.SP_PL_SaveOralAppraisal";
        //PROC_保存口估记录的Price
        public const string PL_ALT_ORALAPPRAISALPRICE = "dbo.SP_PL_SaveOralAppraisalPrice";
        //PROC_删除口估记录
        public const string PL_DEL_ORALAPPRAISAL = "dbo.SP_PL_DeleteOralAppraisal";
        //PROC_保存抵押房产信息_预批
        public const string PL_ALT_BORROWERCOLLATERALDETAIL = "dbo.SP_PL_SaveBorrowerCollateralDetail";
        //PROC_保存电话核实记录
        public const string PL_ALT_PHONEVERIFICATIONRECORD = "dbo.SP_PL_SavePhoneVerificationRecord";
        //获取审批状态
        public const string PL_GetRunResultByAppId = "dbo.SP_PL_GetRunResultByAppId";
        //获取"重复贷款建议检查"
        public const string PL_GetCRDupByAppId = "dbo.SP_PL_GetCRDupByAppId";
        //保存贷款成数
        public const string PL_SavePreCheckLTVDetail = "dbo.SP_PL_SavePreCheckLTVDetail";
        //验证产调核实时候获取所有用户和产调核实
        public const string PL_GetCustomersAndHouseBureauByAppID = "dbo.SP_PL_GetCustomersAndHouseBureauByAppID";
        //产调核实的核实对象列表
        public const string PL_GetHouseBureauObjectsListByAppId = "dbo.SP_PL_GetHouseBureauObjectsListByAppId";
        //产调核实列表
        public const string PL_GetHouseBureauListByAppId = "dbo.SP_PL_GetHouseBureauListByAppId";
        //
        public const string PL_GetHouseBurueauInfoByAppId = "SP_PL_GetHouseBurueauInfoByAppId";
        //添加产调核实对象
        public const string PL_SaveHouseBureauObject = "dbo.SP_PL_SaveHouseBureauObject";
        //删除产调核实对象
        public const string PL_DeleteHouseBureauObject = "dbo.SP_PL_DeleteHouseBureauObject";
        //保存产调核实页面
        public const string PL_SaveHouseBureau = "dbo.SP_PL_SaveHouseBureau";
        //
        public const string PL_SaveMortgageCognizance = "dbo.SP_PL_SaveMortgageCognizance";
        //
        public const string PL_UpdateCustIncome = "dbo.SP_PL_UpdateCustIncome";
        //获取可疑欺诈名单
        public const string PL_GetFraudVelocityList = "dbo.SP_PL_GetFraudVelocityList";
        //获取可疑欺诈详情
        public const string PL_GetVelocityCheck = "dbo.SP_PL_GetVelocityCheck";
        //
        public const string PL_GetLastRACByAppID = "dbo.SP_PL_GetLastRACByAppID";
        //根据appId 获取所有的电话核实记录
        public const string PL_GetAllPhoneVerificationByAppID = "dbo.SP_PL_GetAllPhoneVerificationByAppID";
        //根据appId 获取所有的营业场所核实记录
        public const string PL_GetAllSiteVerificationByAppID = "dbo.SP_PL_GetAllSiteVerificationByAppID";
        //根据appId 获取所有的住宅地址核实记录
        public const string PL_GetAllHouseVerificationByAppID = "dbo.SP_PL_GetAllHouseVerificationByAppID";
        //根据appId 获取所有的外部核实记录
        public const string PL_GetAllExternalVerificationByAppID = "dbo.SP_PL_GetAllExternalVerificationByAppID";
        //根据appId 获取所有的工作场所核实记录
        public const string PL_GetAllWorkingVerificationByAppID = "dbo.SP_PL_GetAllWorkingVerificationByAppID";
        //根据appId获取申请表客户信息和征信报告显示客户信息
        public const string PL_GetCompareBureauInfoCustInfoByAppID ="dbo.SP_PL_GetCompareBureauInfoCustInfoByAppID";
        public const string PL_GetVerificationDetailsListByAppID = "dbo.SP_PL_GetVerificationDetailsListByAppID";
        public const string PL_GetMoCheckByAppID = "dbo.SP_PL_GetMoCheckByAppID";
        public const string PL_InitMoCheckByAppID = "dbo.SP_PL_InitMoCheckByAppID";
        public const string PL_GetPBOCLocalByAppIDAndIDNo = "dbo.SP_PL_GetPBOCLocalByAppIDAndIDNo";
        public const string PL_GetLoanByAppIdAndImportDate = "dbo.SP_PL_GetLoanByAppIdAndImportDate";
        //---------------------PreCheck And Verification end------------------------------
        #endregion

        #region customer

        public const string PL_SaveFamilyMember = "dbo.SP_PL_SaveFamilyMember";
        public const string PL_DeleteCustomerByCustId = "dbo.SP_PL_DeleteCustomerByCustId";
        public const string PL_SaveGuarantorByAppId = "dbo.SP_PL_SaveGuarantorByAppId";
        public const string PL_SaveBorrowerContact = "dbo.SP_PL_SaveBorrowerContact";
        public const string PL_SaveFinanceSalaryByCustId = "dbo.SP_PL_SaveFinanceSalaryByCustId";
        public const string PL_SaveFinanceSelByCustId = "dbo.SP_PL_SaveFinanceSelByCustId";
        public const string PL_SaveSalaryCust = "dbo.SP_PL_SaveSalaryCust";
        public const string PL_SaveSelfEmployedCust = "dbo.SP_PL_SaveSelfEmployedCust";
        public const string PL_SaveBorrowCustomer = "dbo.SP_PL_SaveBorrowCustomer";
        public const string PL_RemoveVendor = "dbo.SP_PL_RemoveVendor";
        public const string PL_SaveVendor = "dbo.SP_PL_SaveVendor";
        public const string PL_DeleteFamilyMemberByMemberId = "dbo.SP_PL_DeleteFamilyMemberByMemberId";
        public const string PL_SaveCustomer = "dbo.SP_PL_SaveCustomer";
        public const string PL_GetFinanceSurvey = "dbo.SP_PL_GetFinanceSurvey";
        public const string PL_GetBorrowCustomer = "dbo.SP_PL_GetBorrowCustomer";
        public const string PL_SaveEntrusPay = "dbo.SP_PL_SaveEntrusPay";
        public const string PL_GetCustIDByBorrowType = "dbo.SP_PL_GetCustIDByBorrowType";
        public const string PL_GetEntrusPayListByAppId = "dbo.SP_PL_GetEntrusPayListByAppId";
        public const string PL_SaveOtherInfo = "dbo.SP_PL_SaveOtherInfo";
        public const string PL_CopyCoLoanerInfoByAppID = "dbo.SP_PL_CopyCoLoanerInfoByAppID";
        public const string PL_GetCustomerByAppId = "dbo.SP_PL_GetCustomerByAppId";
        public const string PL_GetIncomeDetails = "dbo.SP_PL_GetIncomeDetails";
        public const string PL_GetCustDebt = "dbo.SP_PL_GetCustDebt";
        public const string PL_GetOtherInfo = "dbo.SP_PL_GetOtherInfo";
        public const string PL_GetCustIDByAppIdAndBorrowType = "dbo.SP_PL_GetCustIDByAppIdAndBorrowType";
        public const string PL_UpdateScoringCard = "dbo.SP_PL_UpdateScoringCard";
        public const string PL_UpdateSalaryWorkInfo = "dbo.SP_PL_UpdateSalaryWorkInfo";
        public const string PL_UpdateSelfEmploymentWorkInfo = "dbo.SP_PL_UpdateSelfEmploymentWorkInfo";
        public const string PL_SaveBorrowerDetailsInfoOfCreditApproval = "dbo.SP_PL_SaveBorrowerDetailsInfoOfCreditApproval";
        public const string PL_SaveFinanceSurveyOfCreditApproval = "dbo.SP_PL_SaveFinanceSurveyOfCreditApproval";
        public const string PL_SaveIncomeDetailsOfCreditApproval = "dbo.SP_PL_SaveIncomeDetailsOfCreditApproval";
        public const string PL_SaveCustDebtOfCreditApproval = "dbo.SP_PL_SaveCustDebtOfCreditApproval";
        public const string PL_DeleteEntrusPayByEntrusPayID = "dbo.SP_PL_DeleteEntrusPayByEntrusPayID";
        public const string PL_ShowVerifiedDetailsItemsByAppID = "dbo.SP_PL_ShowVerifiedDetailsItemsByAppID";
        public const string PL_GetCompanyList = "dbo.SP_PL_GetCompanyList";
        public const string PL_SaveSelfPay = "dbo.SP_PL_SaveSelfPay";
        #endregion

        #region loan
        public const string PL_SaveLoanParameters = "dbo.SP_PL_SaveLoanParameters";
        public const string PL_GetFirstPercent = "dbo.SP_PL_GetFirstPercent";
        public const string PL_SaveCustCollateralInfo = "dbo.SP_PL_SaveCustCollateralInfo";
        public const string PL_SaveLTVFactors = "dbo.SP_PL_SaveLTVFactors";
        public const string PL_SaveLTVFactors2 = "dbo.SP_PL_SaveLTVFactors2";

        public const string PL_GetHasPropertyandPropertyTypeByAppId = "dbo.SP_PL_GetHasPropertyandPropertyTypeByAppId";
        public const string PL_SaveMortgagor = "dbo.SP_PL_SaveMortgagor";
        public const string PL_SaveLoanPurpose = "dbo.SP_PL_SaveLoanPurpose";
        public const string PL_RemoveMortgagor = "dbo.SP_PL_RemoveMortgagor";
        public const string PL_GetBaseAndMaxLtv = "dbo.SP_PL_GetBaseAndMaxLtv";
        public const string PL_GetApprovalLoanInfoByAppId = "dbo.SP_PL_GetApprovalLoanInfoByAppId";
        public const string PL_GetBeforeAndCurrentRateByAppId = "dbo.SP_PL_GetBeforeAndCurrentRateByAppId";
        public const string PL_UpdateRateException = "dbo.SP_PL_UpdateRateException";
        public const string PL_GetSalesRate = "dbo.SP_PL_GetSalesRate";
        public const string PL_RefreshRate = "dbo.SP_PL_RefreshRate";
        public const string PL_SaveLoanApprovaltOfCreditApproval = "dbo.SP_PL_SaveLoanApprovaltOfCreditApproval";
        public const string PL_DeleteMortgatarbyAppID = "dbo.SP_PL_DeleteMortgatarbyAppID";
        public const string PL_DeleteCollateralbyAppID = "dbo.SP_PL_DeleteCollateralbyAppID";
        public const string PL_UpdateDeviationed = "dbo.SP_PL_UpdateDeviationed";
        public const string PL_UpdateRateDeviationedByAppId = "dbo.SP_PL_UpdateRateDeviationedByAppId";
        public const string PL_GetNewCurrLoanForPrescreen = "dbo.SP_PL_GetNewCurrLoanForPrescreen";
        public const string PL_GetLoanParametersByAppId = "dbo.SP_PL_GetLoanParametersByAppId";
        public const string PL_ExportDisbursementFileByAppId = "dbo.SP_PL_ExportDisbursementFileByAppId";
        public const string PL_SaveLoanApproval = "dbo.SP_PL_SaveLoanApproval";
        public const string PL_UpdateLoanInfoAndInsertRecordIntoLoanApproval = "dbo.SP_PL_UpdateLoanInfoAndInsertRecordIntoLoanApproval";
        #endregion

        #region parameter setup
        //---------------------Fraud data start----------------------------
        public const string PL_GetFraudDataByID = "dbo.SP_PL_GetFraudDataByID";
        public const string PL_InsertFraudData = "dbo.SP_PL_InsertFraudData";
        public const string PL_DeleteFraudData = "dbo.SP_PL_DeleteFraudData";
        public const string PL_UpdateFraudData = "dbo.SP_PL_UpdateFraudData";
        public const string PL_GetFraudDataMaker = "dbo.SP_PL_GetFraudDataMaker";
        public const string PL_SaveFraudDataMaker = "dbo.SP_PL_SaveFraudDataMaker";
        public const string PL_DeleteFraudDataMaker = "dbo.SP_PL_DeleteFraudDataMaker";
        public const string PL_UpdateFraudDataMaker = "dbo.SP_PL_UpdateFraudDataMaker";
        public const string PL_ApproveFraudDataMaker = "dbo.SP_PL_ApproveFraudMakerData";
        public const string PL_RejectFraudDataMaker = "dbo.SP_PL_RejectFraudMakerData";
        //---------------------Fraud data end----------------------------

        //---------------------Related person start----------------------------
        public const string PL_GetRelatedPersonMaker = "dbo.SP_PL_GetRelatedPersonMaker";
        public const string PL_SaveRelatedPersonMaker = "dbo.SP_PL_SaveRelatedPersonMaker";
        public const string PL_DeleteRelatedPersonMaker = "dbo.SP_PL_DeleteRelatedPersonMaker";
        public const string PL_UpdateRelatedPersonMaker = "dbo.SP_PL_UpdateRelatedPersonMaker";
        public const string PL_ApproveRelatedPersonMaker = "dbo.SP_PL_ApproveRelatedPersonMaker";
        public const string PL_RejectRelatedPersonMaker = "dbo.SP_PL_RejectRelatedPersonMaker";
        public const string PL_GetRelatedPersonByID = "dbo.SP_PL_GetRelatedPersonByID";
        //---------------------Related person end----------------------------

        //---------------------login start----------------------------
        public const string PL_GetUserInfoBySoeID = "dbo.SP_PL_GetUserInfoBySoeID";
        public const string PL_GetUserRoleBySoeID = "dbo.SP_PL_GetUserInfoBySoeID";
        
        public const string PL_GetMenuTree = "dbo.SP_PL_SearchTree";
        //---------------------login end----------------------------

        //---------------------Branch start----------------------------
        public const string PL_GetSysBranchMaker = "dbo.SP_PL_GetSysBranchMaker";
        public const string PL_UpdateBranchMaker = "dbo.SP_PL_UpdateBranchDataMaker";
        public const string PL_MergeBranchDataMaker = "dbo.SP_PL_MergeBranchDataMaker";
        public const string PL_GetSysBranchPendingChecker = "dbo.SP_PL_GetSysBranchPendingChecker";
        public const string PL_ApproveBranchDataMaker = "dbo.SP_PL_ApproveBranchMakerData";
        public const string PL_RejectBranchDataMaker = "dbo.SP_PL_RejectBranchMakerData";
        public const string PL_GetBranchCompanyMaker = "dbo.SP_PL_GetBranchCompanyMaker";
        public const string PL_MergeBranchCompanyMaker = "dbo.SP_PL_MergeBranchCompanyMaker";
        public const string PL_ApproveBranchCompanyMaker = "dbo.SP_PL_ApproveBranchCompanyData";
        public const string PL_RejectBranchCompanyMaker = "dbo.SP_PL_RejectBranchCompanyData";
        public const string PL_DeleteBranchCompanyMaker = "dbo.SP_PL_DeleteBranchCompanyData";
        public const string PL_GetEvaluationCompanyMaker = "dbo.SP_PL_GetEvaluationCompanyMaker";
        public const string PL_MergeBranchEvaluationCompanyMaker = "dbo.SP_PL_MergeBranchEvaluationCompanyMaker";
        public const string PL_DeleteBranchEvaluationCompanyMaker = "dbo.SP_PL_DeleteBranchEvaluationCompanyMaker";
        public const string PL_ApproveBranchEvaluationCompanyMaker = "dbo.SP_PL_ApproveBranchEvaluationCompanyMaker";
        public const string PL_RejectBranchEvaluationCompanyMaker = "dbo.SP_PL_RejectBranchEvaluationCompanyMaker";
        public const string PL_GetSysBranchNamesMaker = "dbo.SP_PL_GetSysBranchNamesMaker";
        public const string PL_AddNewBranch = "dbo.SP_PL_AddNewBranch";
        public const string PL_GetBrahchCheckerData = "dbo.SP_PL_GetBrahchCheckerData";
        public const string PL_GetBranchName = "dbo.SP_PL_GetBranchName";
        public const string PL_InsertNewBranchToChecker = "dbo.SP_PL_InsertNewBranchToChecker";
        public const string PL_RejectBranch = "dbo.SP_PL_RejectBranch";
        public const string PL_GetBranchType = "dbo.SP_PL_GetBranchType";
        public const string PL_GetBranchOrgcode = "dbo.SP_PL_GetBranchOrgcode";


        //---------------------Branch end----------------------------

        //---------------------FraudDataAndNgtvData start-------------------
        public const string PL_GetFraudData = "dbo.SP_PL_GetFraudDataByID";
        public const string PL_GetNgtvMakerData = "dbo.SP_PL_GetNgtvMakerData";
        public const string PL_AddNgtvMakerData = "dbo.SP_PL_AddNgtvMakerData";
        public const string PL_UptNgtvMakerData = "dbo.SP_PL_UptNgtvMakerData";
        public const string PL_DelNgtvMakerData = "dbo.SP_PL_DelNgtvMakerData";
        public const string PL_GetNgtvCheckerData = "dbo.SP_PL_GetNgtvCheckerData";
        public const string PL_ApproveNgtvData = "dbo.SP_PL_ApproveNgtvData";
        public const string PL_RejectNgtvData = "dbo.SP_PL_RejectNgtvData";
        public const string PL_GetFraudDataForDownload = "dbo.SP_PL_GetFraudDataForDownload";
        public const string PL_GetNgtvDataForDownload = "dbo.SP_PL_GetNgtvDataForDownload";
        //---------------------FraudDataAndNgtvData end-------------------

        //--------------------DisburseBank

        public const string PL_GetDisburseBankList = "dbo.SP_PL_GetDisburseBankList";
        public const string PL_AddOrUpdateDisburseBank = "dbo.SP_PL_AddOrUpdateDisburseBank";
        public const string PL_DeleteDisburseBank = "dbo.SP_PL_DeleteDisburseBank";
        public const string PL_ApproveDisburseBankMaker = "dbo.SP_PL_ApproveDisburseBankMaker";
        public const string PL_RejectDisburseBankMaker = "dbo.SP_PL_RejectDisburseBankMaker";

        //--------------------DisburseBank

        //---------------------RP Rules start----------------------------

        public const string PL_GetRPRulesMaker = "dbo.SP_PL_GetRPRulesMaker";
        public const string PL_UpdateRPRulesMaker = "dbo.SP_PL_UpdateRPRulesMaker";
        public const string PL_ApproveRPRulesMaker = "dbo.SP_PL_ApproveRPRulesMaker";
        public const string PL_RejectRPRulesMaker = "dbo.SP_PL_RejectRPRulesMaker";
        public const string PL_GetRuleNamesMaker = "dbo.SP_PL_GetRuleNamesMaker";
        public const string PL_GetRPResultDetails = "dbo.SP_PL_GetRPResultDetails";
        public const string PL_GetApplicationADR = "dbo.SP_PL_GetApplicationADR";
        public const string PL_SaveApplicationADR = "dbo.SP_PL_SaveApplicationADR";
        public const string PL_GetRuleParamListByRuleID = "dbo.SP_PL_GetRuleParamListByRuleID";
        public const string PL_GetRPRuleParamValueMakerPivot = "dbo.SP_PL_GetRPRuleParamValueMaker";
        public const string PL_GetRPRuleParamValueCheckerPivot = "dbo.SP_PL_GetRPRuleParamValueChecker";
        public const string PL_SaveRPRuleParamValueMaker = "dbo.SP_PL_SaveRPRuleParamValueMaker";
        public const string PL_ApproveRPRuleParamValueMaker = "dbo.SP_PL_ApproveRPRuleParamValueMaker";
        public const string PL_RejectRPRuleParamValueMaker = "dbo.SP_PL_RejectRPRuleParamValueMaker";
        public const string PL_UpdateExpireDay = "dbo.SP_PL_UpdateExpireDay";
        public const string PL_ApproveExpireDay = "dbo.SP_PL_ApproveExpireDay";
        public const string PL_GetRuleParamBlistMaker = "dbo.SP_PL_GetRuleParamBlistMaker";
        public const string PL_SaveLTVValueMaker = "dbo.SP_PL_SaveLTVValueMaker";
        public const string PL_SaveLTVParamMaker = "dbo.SP_PL_SaveLTVParamMaker";
        public const string PL_ApproveLTVValueMaker = "dbo.SP_PL_ApproveLTVValueMaker";
        public const string PL_ApproveLTVParamMaker = "dbo.SP_PL_ApproveLTVParamMaker";
        public const string PL_GetRuleParamAlistMaker = "dbo.SP_PL_GetRuleParamAlistMaker";
        public const string PL_GetRuleParamListCheckerByRuleID = "dbo.SP_PL_GetRuleParamListCheckerByRuleID";
        public const string PL_RPRulesMaker_GetExpireDateList = "dbo.SP_PL_RPRulesMaker_GetExpireDateList";
        //---------------------RP Rules end----------------------------

        //---------------------Template start----------------------------
        //PROC_获取合同模板维护列表
        public const string PL_GET_FILETEMPLATEMAKERLIST = "dbo.SP_PL_GetFileTemplateMakerList";
        //PROC_获取模板附件条件设置列表
        public const string PL_GET_TEMPLATECONDITIONMAKERLIST = "dbo.SP_PL_GetTemplateConditionMakerList";
        //PROC_修改模板文件名称更新
        public const string PL_ALT_TEMPLATENAME = "dbo.SP_PL_ChangeTemplateName";
        //PROC_获取条件显示名称--combox list
        public const string PL_GET_CONDITIONDISPLAYNAMES = "dbo.SP_PL_GetConditionDisplayNames";
        //PROC_获取条件组名称--combox list
        public const string PL_GET_CONDITIONGROUPNAMES = "dbo.SP_PL_GetConditionGroupNames";
        //PROC_获取模板文件名称--combox list
        public const string PL_GET_TEMPLATEFILENAMES = "dbo.SP_PL_GetTemplateFileNames";
        //PROC_添加模板附件条件
        public const string PL_ADD_CONFIGCONDITIONMAKER = "dbo.SP_PL_AddConfigConditionMaker";
        //PROC_添加模板文件
        public const string PL_ADD_FILETEMPLATEMAKER = "dbo.SP_PL_AddFileTemplateMaker";
        //PROC_删除模板文件
        public const string PL_DEL_FILETEMPLATEMAKER = "dbo.SP_PL_DelFileTemplateMaker";
        //PROC_删除模板文件附件条件
        public const string PL_DEL_CONFIGCONDITIONMAKER = "dbo.SP_PL_DelConfigConditionMaker";
        //PROC_获取模板文件路径
        public const string PL_GET_TEMPLATEFILEPATH_BYTID = "dbo.SP_PL_GetTemplateFilePathByTID";
        //PROC_审批模板文件
        public const string PL_APPROVE_FILETEMPLATEMAKER = "dbo.SP_PL_ApproveFileTemplateMaker";
        //PROC_拒绝模板文件
        public const string PL_REJECT_FILETEMPLATEMAKER = "dbo.SP_PL_RejectFileTemplateMaker";
        //PROC_审批模板文件条件
        public const string PL_APPROVE_CONFIGCONDITIONMAKER = "dbo.SP_PL_ApproveConfigConditionMaker";
        //PROC_拒绝模板文件条件
        public const string PL_REJECT_CONFIGCONDITIONMAKER = "dbo.SP_PL_RejectConfigConditionMaker";
        //获取已经上传了的产品
        public const string PL_CTMaintainMaker_Get_UploadedProd = "dbo.SP_PL_CTMaintainMaker_Get_UploadedProd";
        //获取已经上传了的文档名称和附件列表
        public const string PL_GetUploadedFileNameAndAttachmentListByProdID = "dbo.SP_PL_GetUploadedFileNameAndAttachmentListByProdID";
        //---------------------Template end----------------------------

        //---------------------ProductParameter start----------------------------
        //PROC_根据产品编号获取基础利率
        public const string PL_GET_BASERATEBYPRODID = "dbo.SP_PL_GetBaseRateByProdID";
        //PROC_根据产品编号和分行代码获取基础利率Checker
        public const string PL_GET_BASERATE = "dbo.SP_PL_GetBaseRate";
        //PROC_根据OrgCode获取MO产品的基础利率
        public const string PL_GET_BASERATEMOBYORGCODE = "dbo.SP_PL_GetBaseRateMOByOrgCode";
        //PROC_修改产品的基础利率
        public const string PL_ALT_MAKEPRODBASERATE = "dbo.SP_PL_MakeProdBaseRate";
        //PROC_批准基础利率
        public const string PL_ARE_BASERATEMAKER = "dbo.SP_PL_ApproveBaseRateMaker";
        //PROC_拒绝基础利率
        public const string PL_REJ_BASERATEMAKER = "dbo.SP_PL_RejectBaseRateMaker";
        //PROC_修改产品利率
        public const string PL_ALT_SAVERATEMAKER = "dbo.SP_PL_SaveRateMaker";
        //PROC_修改产品费用
        public const string PL_ALT_SAVEFEEMAKER = "dbo.SP_PL_SaveFeeMaker";
        //PROC_根据就业类型获取对应企业类别-combox list
        public const string PL_GET_CUSTSEGMENTS = "dbo.SP_PL_GetCustSegments";
        //PROC_获取产品文档列表数据-grid list
        public const string PL_GET_DOCLISTMAKER = "dbo.SP_PL_GetDocListMaker";
        //PROC_新增产品文档列表Maker
        public const string PL_ADD_DOCLISTMAKER = "dbo.SP_PL_AddDocListMaker";
        //PROC_更新产品文档列表Maker
        public const string PL_ALT_DOCLISTMAKER = "dbo.SP_PL_SaveDocListMaker";
        //PROC_删除产品文档列表Maker
        public const string PL_DEL_DOCLISTMAKER = "dbo.SP_PL_DelDocListMaker";
        //PROC_批准文档信息
        public const string PL_ARE_DOCLISTMAKER = "dbo.SP_PL_ApproveDocListMaker";
        //PROC_拒绝文档信息
        public const string PL_REJ_DOCLISTMAKER = "dbo.SP_PL_RejectDocListMaker";
        //PROC_获取利率
        public const string PL_GET_RATEMAKERS = "dbo.SP_PL_GetRateMakers";
        //PROC_获取费用
        public const string PL_GET_FEEMAKERS = "dbo.SP_PL_GetFeeMakers";
        //PROC_获取利率根据TID
        public const string PL_GET_RATEMAKERBYTID = "dbo.SP_PL_GetRateMakerByTID";
        //PROC_获取费用根据TID
        public const string PL_GET_FEEMAKERBYTID = "dbo.SP_PL_GetFeeMakerByTID";
        //PROC_批准利率
        public const string PL_ARE_RATEMAKER = "dbo.SP_PL_ApproveRateMaker";
        //PROC_拒绝利率
        public const string PL_REJ_RATEMAKER = "dbo.SP_PL_RejectRateMaker";
        //PROC_批准费用
        public const string PL_ARE_FEEMAKER = "dbo.SP_PL_ApproveFeeMaker";
        //PROC_拒绝费用
        public const string PL_REJ_FEEMAKER = "dbo.SP_PL_RejectFeeMaker";

        //---------------------ProductParameter end----------------------------

        //---------------------Parameter start----------------------------
        //Common-获取系统字典表参数值-combox list
        public const string PL_GET_SYSPARAMLISTBYID = "dbo.SP_PL_GetSysParamListByID";
        //Common-获取系统产品参数名-combox list
        public const string PL_GET_SYSPRODNAMES = "dbo.SP_PL_GetSysProdNames";
        //Common-获取系统分行参数名-combox list
        public const string PL_GET_SYSBRANCHNAMES = "dbo.SP_PL_GetSysBranchNames";
        //Common-获取所有的省
        public const string PL_GetProvinces = "dbo.SP_PL_GetProvinces";
        //Common-根据省获取市
        public const string PL_GetCities = "dbo.SP_PL_GetCities";
        //Common-获取贷款人-combox list
        public const string PL_GET_BORROWERNAMES = "dbo.SP_PL_GetBorrowerNames";
        //获取T_SYS_parameters 中所有的参数
        public const string PL_GetAllParameters = "dbo.SP_PL_GetAllParameters";
        //获取T_SYS_region 表中所有的数据
        public const string PL_GetAllRegionInfo = "dbo.SP_PL_GetAllRegionInfo";
        public const string PL_GetRegionCode = "dbo.SP_PL_GetRegionCode";
        //获取所有的role
        public const string PL_GetAllSysRoles = "dbo.SP_PL_GetAllSysRoles";
        //---------------------Parameter end----------------------------
        #endregion

        #region WorkFlow
        public const string PL_WFHasInstance = "dbo.SP_PL_WF_HasInstance";
        public const string PL_WFGetInstances = "dbo.SP_PL_WF_GetInstances";
        public const string PL_WFGetStageId = "dbo.SP_PL_WF_GetStageId";
        public const string PL_WFSetLastDate = "dbo.SP_PL_WF_SetLastDate";
        public const string PL_WFGetLastDate = "dbo.SP_PL_WF_GetLastDate";
        public const string PL_WFGetNextStageId = "dbo.SP_PL_WF_GetNextStageId";
        public const string PL_WFAddTrace = "dbo.SP_PL_WF_AddTrace";
        public const string PL_WFUpdateInstance = "dbo.SP_PL_WF_UpdateInstance";
        public const string PL_WFAddInstance = "dbo.SP_PL_WF_AddInstance";
        public const string PL_WFSetInsToHis = "dbo.SP_PL_WF_SetInsToHis";
        public const string PL_WFHasHistory = "dbo.SP_PL_WF_HasHistory";
        public const string PL_WFGetProcHis = "dbo.SP_PL_WF_GetProcHistory";
        public const string PL_GetIDQueryList = "dbo.SP_PL_GetIDQueryList";
        public const string PL_AddNewIDChangeLog = "dbo.SP_PL_AddNewIDChangeLog";
        public const string PL_GetIDQueryListAll = "dbo.SP_PL_GetIDQueryListAll";
        public const string PL_GetAfterLoanMaintainList = "dbo.SP_PL_GetAfterLoanMaintainList";
        public const string PL_AddNewAfterLoanChangeLog = "dbo.SP_PL_AddNewAfterLoanChangeLog";
        public const string PL_GetAfterLoanMaintainListAll = "dbo.SP_PL_GetAfterLoanMaintainListAll";
        public const string PL_GetAfterLoanMaintainListWithoutLog = "dbo.SP_PL_GetAfterLoanMaintainListWithoutLog";
        public const string PL_GetIDQueryListLogAll = "dbo.SP_PL_GetIDQueryListLogAll";
        public const string PL_tools_CS_SPROC_InquiryDtl = "dbo.SP_PL_tools_CS_SPROC_InquiryDtl";
        public const string PL_tools_CS_SPROC_InquiryByAppNo = "dbo.SP_PL_tools_CS_SPROC_InquiryByAppNo";
        public const string PL_tools_CS_SPROC_InquiryByCustID = "dbo.SP_PL_tools_CS_SPROC_InquiryByCustID";
        public const string PL_tools_CS_SPROC_InquiryByCustName = "dbo.SP_PL_tools_CS_SPROC_InquiryByCustName";
        public const string PL_GetProcessHistory = "dbo.SP_PL_GetProcessHistory";
        public const string PL_SaveCreditOfficerUserLevelInfo = "dbo.SP_PL_SaveCreditOfficerUserLevelInfo";
        public const string PL_GetCancelAppContentList = "dbo.SP_PL_GetCancelAppContentList";
        public const string PL_RetrieveData = "dbo.SP_PL_RetrieveData";
        public const string PL_GetBatchCancelList = "dbo.SP_PL_GetBatchCancelList";
        public const string PL_BatchCancel = "dbo.SP_PL_BatchCancel";
        public const string PL_GetRetriveList = "dbo.SP_PL_GetRetriveList";
        public const string PL_WorkFlowRetrieveData = "dbo.SP_PL_WorkFlowRetrieveData";
        public const string PL_GetReAllocationList = "dbo.SP_PL_GetReAllocationList";
        public const string PL_RetriveCanceledApp = "dbo.SP_PL_RetriveCanceledApp";
        public const string PL_ReAllocationTemp = "dbo.SP_PL_ReAllocationTemp";
        public const string PL_ReAllocationForever = "dbo.SP_PL_ReAllocationForever";
        public const string PL_GetUnlock = "dbo.SP_PL_GetUnlock";
        public const string PL_DoUnlock = "dbo.SP_PL_DoUnlock";
        public const string PL_GetAvailableSales = "dbo.SP_PL_GetAvailableSales";
        public const string PL_GetWFStages = "dbo.SP_PL_GetWFStages";
        public const string PL_GetIDChangeLog = "dbo.SP_PL_GetIDChangeLog";
        public const string PL_GetAfterLoanChangeLog = "dbo.SP_PL_GetAfterLoanChangeLog";
        public const string PL_SetVaild = "dbo.SP_PL_SetVaild";
        public const string PL_TryToLock = "dbo.SP_PL_TryToLock";
        public const string PL_GetRejectReasonsView = "dbo.SP_PL_GetRejectReasonsView";
        public const string PL_GetCurrentStepByAppID = "dbo.SP_PL_GetCurrentStepByAppID";
        public const string PL_CheckStepIDByAppIDAndStepID = "dbo.SP_PL_CheckStepIDByAppIDAndStepID";
        public const string PL_GetWFStatusByAppID = "dbo.SP_PL_GetWFStatusByAppID";
        #endregion

        #region userlevel
        public const string PL_GetCreditRatingCheckerViewList = "dbo.SP_PL_GetCreditRatingCheckerViewList";
        public const string PL_GetCreditRatingCheckerApproval = "dbo.SP_PL_GetCreditRatingCheckerApproval";
        public const string PL_QueryCreditOfficerUserLevelInfo = "dbo.SP_PL_QueryCreditOfficerUserLevelInfo";
        public const string PL_QueryCreditOfficerUserInfo = "dbo.SP_PL_QueryCreditOfficerUserInfo";
        public const string PL_UserLevelQueryUser = "dbo.SP_PL_UserLevelQueryUser";
        public const string PL_UserLevelQueryUserWithCondition = "dbo.SP_PL_UserLevelQueryUserWithCondition";
        public const string PL_WorkFlow_AddTrace = "dbo.SP_PL_WorkFlow_AddTrace";
        public const string PL_CreditRating_QueryCreditLevel = "dbo.SP_PL_CreditRating_QueryCreditLevel";
        #endregion

        #region DocList
        public const string PL_GetSubmittedDocList = "dbo.SP_PL_GetSubmittedDocList";
        public const string PL_SaveSubmittedDoc = "dbo.SP_PL_SaveSubmittedDoc";
        public const string PL_GetLackDoc = "dbo.SP_PL_GetLackDoc";
        public const string PL_GetDocumentList = "dbo.SP_PL_GetDocumentList";
        #endregion

        public const string PL_CheckSoeIdRight = "dbo.SP_PL_CheckSoeIdRight";

        #region Scheduled Task
        public const string PL_GetRunJobType = "dbo.SP_PL_GetRunJobByTime";
        public const string PL_GetFileDefinationByJobType = "dbo.SP_PL_GetFileDefinationByJobType";
        public const string PL_GetReportInfoByFileType = "dbo.SP_PL_GetReportInfoByFileType";
        public const string PL_GetPathConfigByName = "dbo.SP_PL_GetPathConfigByName";
        public const string PL_CheckIsImpTodayByJobName = "dbo.SP_PL_CheckIsImpTodayByJobName";
        public const string PL_InsertJobRunLogs = "dbo.SP_PL_InsertJobRunLogs";
        public const string PL_CheckIsImportFileByWriteDate = "dbo.SP_PL_CheckIsImportFileByWriteDate";
        public const string PL_TruncateOldDataToImport = "dbo.SP_PL_TruncateOldDataToImport";         
        #endregion

        #region query
        public const string PL_GetAppInfoByIDNum = "dbo.SP_PL_GetAppInfoByIDNum";
        public const string PL_GetCustInfoByOrgCode = "dbo.SP_PL_GetCustInfoByOrgCode";
        public const string PL_UpdateBureauQueryStatus = "dbo.SP_PL_UpdateQueryListStatus";
        public const string PL_GetAllStageNameInQuery = "dbo.SP_PL_GetAllStageNameInQuery";
        public const string PL_GetLongApplyByDay = "dbo.SP_PL_GetLongApplyByDay";
        public const string PL_GetSalesIDByOrgCode = "dbo.SP_PL_GetSalesIDByOrgCode";
        public const string PL_GetUserProcessInstance = "dbo.SP_PL_GetUserProcessInstance";
        public const string PL_ExportUserProcessByAppID = "dbo.SP_PL_ExportUserProcessByAppID";
        public const string PL_GetDeviationList = "dbo.SP_PL_GetDeviationList";
        public const string PL_GetDeviationTotalInfo = "dbo.SP_PL_GetDeviationTotalInfo";
        public const string PL_GetCriticalFieldList = "dbo.SP_PL_GetCriticalFieldList";
        public const string PL_GetCriticalFieldParameterList = "dbo.SP_PL_GetCriticalFieldParameterList";
        public const string PL_GetCriticalFieldListAll = "dbo.SP_PL_GetCriticalFieldListAll";
        public const string PL_GetApprovalInfoByAppId = "dbo.SP_PL_GetApprovalInfoByAppId";
        public const string PL_CriticalFieldQuery_GetParameterLogData = "dbo.SP_PL_CriticalFieldQuery_GetParameterLogData";
        public const string PL_CriticalFieldQuery_GetTableName = "dbo.SP_PL_CriticalFieldQuery_GetTableName";
        public const string PL_CriticalFieldQuery_GetIsCriticalField = "dbo.SP_PL_CriticalFieldQuery_GetIsCriticalField";
        public const string PL_CriticalFieldQuery_GetCriticalField="dbo.SP_PL_CriticalFieldQuery_GetCriticalField";
        public const string PL_CriticalFieldQuery_GetLogData ="dbo.SP_PL_CriticalFieldQuery_GetCriticalField";
        #endregion

        #region disbursement
        public const string PL_GetBorrowTypeANDIDNoByAppID = "dbo.SP_PL_GetBorrowTypeANDIDNoByAppID";
        public const string PL_GetRemarkByAppID = "dbo.SP_PL_GetRemarkByAppID";
        public const string PL_InitEclipse = "dbo.SP_PL_InitEclipse";
        public const string PL_GetEclipse = "dbo.SP_PL_GetEclipse";
        public const string PL_GetCLMS = "dbo.SP_PL_GetCLMS";
        public const string PL_InsertCLMS = "dbo.SP_PL_InsertCLMS";
        public const string PL_GetSecondApproveOPDate = "dbo.SP_PL_GetSecondApproveOPDate";
        public const string PL_GetALS = "dbo.SP_PL_GetALS";
        public const string PL_GetApplicationInof = "dbo.SP_PL_GetApplicationInof";
        public const string PL_GetALsShowInfo = "dbo.SP_PL_GetALsShowInfo";
        public const string PL_GetCountPackage = "dbo.SP_PL_GetCountPackage";
        public const string PL_GetContentForDisburseExport = "dbo.SP_PL_GetContentForDisburseExport";
        public const string PL_SaveALSUPL = "dbo.SP_PL_SaveALSUPL";
        public const string PL_SaveALSCOL = "dbo.SP_PL_SaveALSCOL";
        public const string PL_DisburseSaveNumber = "dbo.SP_PL_DisburseSaveNumber";
        public const string PL_GetCustNOForDisburse = "dbo.SP_PL_GetCustNOForDisburse";
        public const string PL_SaveDisburseDetails = "dbo.SP_PL_SaveDisburseDetails";
        public const string PL_GetWaitDataEntry = "dbo.SP_PL_GetWaitDataEntry";
        public const string PL_GetHistoryDataEntry = "dbo.SP_PL_GetHistoryDataEntry";
        public const string PL_GetFullRevalution = "dbo.SP_PL_GetFullRevalution";
        public const string PL_GetFullRevalutionValues = "dbo.SP_PL_GetFullRevalutionValues";
        public const string PL_SaveEvl = "dbo.SP_PL_SaveEvl";
        public const string PL_DeleteEvl = "dbo.SP_PL_DeleteEvl";
        public const string PL_ApplyEvl = "dbo.SP_PL_ApplyEvl";
        public const string PL_GetFRIsApplied = "dbo.SP_PL_GetFRIsApplied";
        public const string PL_GetFullRevalutionApproveInfo = "dbo.SP_PL_GetFullRevalutionApproveInfo";
        public const string PL_GetEvlReportList = "dbo.SP_PL_GetEvlReportList";
        public const string PL_GetEvlApprovalList = "dbo.SP_PL_GetEvlApprovalList";
        public const string PL_GetCustIncomeAndDebt = "dbo.SP_PL_GetCustIncomeAndDebt";
        public const string PL_UpdateRunResult = "dbo.SP_PL_UpdateRunResult";
        public const string PL_FullRevalution_UpdateLoanInfo = "dbo.SP_PL_FullRevalution_UpdateLoanInfo";
        public const string PL_GetEvaluationCompany = "dbo.SP_PL_GetEvaluationCompany";
        public const string PL_GetMorgageCountAndCollateralTypeByAppId = "dbo.SP_PL_GetMorgageCountAndCollateralTypeByAppId";
        public const string PL_GetLoanSizeByPropertyValue = "dbo.SP_PL_GetLoanSizeByPropertyValue";
        public const string PL_GetISMO = "dbo.SP_PL_GetISMO";
        public const string PL_GetCallFullValByAppId = "dbo.SP_PL_GetCallFullValByAppId";
        public const string PL_GetPropertyValueTenorAndRateByAppID = "dbo.SP_PL_GetPropertyValueTenorAndRateByAppID";
        public const string PL_GetSelfPayInfo = "dbo.SP_PL_GetSelfPayInfo";
        public const string PL_GetALSEmployerCD = "dbo.SP_PL_GetALSEmployerCD";
        public const string PL_GetProdPayTypeAndAccOpenDateByAppID = "dbo.SP_PL_GetProdPayTypeAndAccOpenDateByAppID";
        public const string PL_GetFeeCode = "dbo.SP_PL_GetFeeCodeByAppID";
        public const string PL_GetCallFullVal = "dbo.SP_PL_GetCallFullVal";
        public const string PL_GetOwnerByAppID = "dbo.SP_PL_GetOwnerByAppID";
        public const string PL_DisburseRegist_GetCollateralByAppId = "dbo.SP_PL_DisburseRegist_GetCollateralByAppId";
        public const string PL_DisburseRegist_GetParamForCLMSByAppId = "dbo.SP_PL_DisburseRegist_GetParamForCLMSByAppId";
        public const string PL_DisburseRegist_GetProdCodeByAppId = "dbo.SP_PL_DisburseRegist_GetProdCodeByAppId";
        public const string PL_DisburseRegist_GetLoanPurpose = "dbo.SP_PL_DisburseRegist_GetLoanPurpose";
        public const string PL_DisburseRegist_GetAppProdDtlByAppId = "dbo.SP_PL_DisburseRegist_GetAppProdDtlByAppId";
        public const string PL_DisburseRegist_GetMortgagorNumberByAppId = "dbo.SP_PL_DisburseRegist_GetMortgagorNumberByAppId";
        public const string PL_DisburseRegist_GetExpireDayByAppId = "dbo.SP_PL_DisburseRegist_GetExpireDayByAppId";
        public const string PL_DisburseRegist_GetExpireDay = "dbo.SP_PL_DisburseRegist_GetExpireDay";
        public const string PL_DisburseRegist_GetALSIncomeTypeByAppId = "dbo.SP_PL_DisburseRegist_GetALSIncomeTypeByAppId";
        public const string PL_DisburseRegist_GetExisitAccountNumberByAppId = "dbo.SP_PL_DisburseRegist_GetExisitAccountNumberByAppId";
        public const string PL_DisburseRegist_GetAppNoByAppId = "dbo.SP_PL_DisburseRegist_GetAppNoByAppId";
        public const string PL_DisburseRegist_GetSequence = "dbo.SP_PL_DisburseRegist_GetSequence";
        public const string PL_DisburseRegist_SaveAccountNumber = "dbo.SP_PL_DisburseRegist_SaveAccountNumber";
        public const string PL_DisburseRegist_GetLastLoanByAppId = "dbo.SP_PL_DisburseRegist_GetLastLoanByAppId";
        public const string PL_DisburseRegist_GetOrgRcCodeBySoeId = "dbo.SP_PL_DisburseRegist_GetOrgRcCodeBySoeId";
        public const string PL_DisburseRegist_GetLoanIndustryByAppId = "dbo.SP_PL_DisburseRegist_GetLoanIndustryByAppId";
        public const string PL_DisburseRegist_IsTopUp = "dbo.SP_PL_DisburseRegist_IsTopUp";
        public const string PL_DisburseRegist_GetCityCodeBySoeId = "dbo.SP_PL_DisburseRegist_GetCityCodeBySoeId";
        public const string PL_DisburseRegist_GetRCNumberByAppId = "dbo.SP_PL_DisburseRegist_GetRCNumberByAppId";
        public const string PL_DisburseRegist_IsExisitAlsUpl="dbo.SP_PL_DisburseRegist_IsExisitAlsUpl";
        public const string PL_DisburseRegist_GetApplicationMap="dbo.SP_PL_DisburseRegist_GetApplicationMap";
        public const string PL_DisburseRegist_GetALSCityCodeBySoeId="dbo.SP_PL_DisburseRegist_GetALSCityCodeBySoeId";
        public const string PL_DisburseRegist_GetProdNameByAppId ="dbo.SP_PL_DisburseRegist_GetProdNameByAppId";
        public const string PL_DisburseRegist_GetSegmentIDByAppId = "dbo.SP_PL_DisburseRegist_GetSegmentIDByAppId";
        public const string PL_DisburseRegist_GetBranchCodeByAppId="dbo.SP_PL_DisburseRegist_GetBranchCodeByAppId";
        public const string PL_DisburseRegist_GetSourceCodeByAppId = "dbo.SP_PL_DisburseRegist_GetSourceCodeByAppId";
        public const string PL_DisburseRegist_GetProductNameByAppId = "dbo.SP_PL_DisburseRegist_GetProductNameByAppId";
        public const string PL_DisburseRegist_SaveAccOpenDate ="dbo.SP_PL_DisburseRegist_SaveAccOpenDate";
        public const string PL_DisburseRegist_GetAgentCodeByAppId ="dbo.SP_PL_DisburseRegist_GetAgentCodeByAppId";
        public const string PL_DisburseRegist_GetSalesIdByAppID = "dbo.SP_PL_DisburseRegist_GetSalesIdByAppID";
        public const string PL_DisburseRegist_GetProductBaserateFromADR ="dbo.SP_PL_DisburseRegist_GetProductBaserateFromADR";
        public const string PL_DisburseRegist_GetTopUpBaseRate ="dbo.SP_PL_DisburseRegist_GetTopUpBaseRate";
        public const string PL_DisburseRegist_GetMBCertID="dbo.SP_PL_DisburseRegist_GetMBCertID";
        public const string PL_DisburseRegist_IsMainBoEmployee="dbo.SP_PL_DisburseRegist_IsMainBoEmployee";
        public const string PL_DisburseRegist_GetSellerInfos="dbo.SP_PL_DisburseRegist_GetSellerInfos";
        public const string PL_DisburseRegist_GetAnnualFundingRange="dbo.SP_PL_DisburseRegist_GetAnnualFundingRange";
        public const string PL_DisburseRegist_GetOccupationCode = "dbo.SP_PL_DisburseRegist_GetOccupationCode";
        public const string PL_DisburseRegist_GetProvinceByCode="dbo.SP_PL_DisburseRegist_GetProvinceByCode";
        public const string PL_DisburseRegist_IsTopupBatch ="dbo.SP_PL_DisburseRegist_IsTopupBatch";
        public const string PL_DisburseRegist_SaveRemarks ="dbo.SP_PL_DisburseRegist_SaveRemarks";
        public const string PL_DisburseRegist_GetCLMSInfor="dbo.SP_PL_DisburseRegist_GetCLMSInfor";
        public const string PL_DisburseRegist_SaveCLMSInfor="dbo.SP_PL_DisburseRegist_SaveCLMSInfor";
        public const string PL_DisburseRegist_SetCLMSDate="dbo.SP_PL_DisburseRegist_SetCLMSDate";
        public const string PL_DisburseRegist_GetNewLoanSize ="dbo.SP_PL_DisburseRegist_GetNewLoanSize";
        public const string PL_DisburseRegist_GetCityByCode = "dbo.SP_PL_DisburseRegist_GetCityByCode";
        public const string PL_DisburseRegist_GetRCCode="dbo.SP_PL_DisburseRegist_GetRCCode";
        public const string PL_DisburseRegist_GetOscarStaff ="dbo.SP_PL_DisburseRegist_GetOscarStaff";
        public const string PL_DisburseRegist_SaveLoanDate = "dbo.SP_PL_DisburseRegist_SaveLoanDate";
        public const string PL_DisburseRegist_IsExitT_PL_EclipseHandover="dbo.SP_PL_DisburseRegist_IsExitT_PL_EclipseHandover";
        public const string PL_DisburseRegist_GetFeeData="dbo.SP_PL_DisburseRegist_GetFeeData";
        public const string PL_DisburseRegist_GetMBOscarInfo = "dbo.SP_PL_DisburseRegist_GetMBOscarInfo";
        public const string PL_DisburseRegist_UpdateFullRevalutionInfo = "dbo.SP_PL_DisburseRegist_UpdateFullRevalutionInfo";
        #endregion


        #region Print
        public const string PL_GetMergeDefinationByJobType = "dbo.SP_PL_GetMergeDefinationByJobType";
        public const string PL_GetPrintCondtion = "dbo.SP_PL_GetPrintCondtion";
        public const string PL_GetPrintCondtions = "dbo.SP_PL_GetPrintCondtions";

        public const string PL_UpLoanMergeStatus = "dbo.SP_PL_UpLoanMergeStatus";
        public const string PL_GetPrintApplicationFormDataSource = "dbo.SP_PL_GetPrintApplicationFormDataSource";
        #endregion

        #region disbursement
        public const string PL_GetDocListByAppID = "dbo.SP_PL_GetDocListByAppID";
        public const string PL_GetAppraisalFeeByAppID = "dbo.SP_PL_GetAppraisalFeeByAppID";
        public const string PL_SaveAppraisalFee = "dbo.SP_PL_SaveAppraisalFee";
        #endregion

        #region System Decision

        public const string PL_GetNewPrososalRACMapping = "dbo.SP_PL_GetNewPrososalRACMapping";
        public const string PL_ProposalDataCleaner = "dbo.SP_PL_ProposalDataCleaner";
        public const string PL_RuleFactoryGetRuleNamesByStageIDProdID = "dbo.SP_PL_RuleFactoryGetRuleNamesByStageIDProdID";
        public const string PL_GetStageIDbyAppid = "dbo.SP_PL_GetStageIDbyAppid";
        public const string PL_ProposalDataGenGetAppinfoByAppID = "dbo.SP_PL_ProposalDataGenGetAppinfoByAppID";
        public const string PL_ProposalDataGenGetCustinfoByAppID = "dbo.SP_PL_ProposalDataGenGetCustinfoByAppID";
        public const string PL_ProposalDataGenGetCustFinanceQ = "dbo.SP_PL_ProposalDataGenGetCustFinanceQ";
        public const string PL_ProposalDataGenGetCustFinanceG = "dbo.SP_PL_ProposalDataGenGetCustFinanceG";
        public const string PL_ProposalDataGenGetScoringCardQ = "dbo.SP_PL_ProposalDataGenGetScoringCardQ";
        public const string PL_InternalFileMatchDataGenGetAppInfo = "dbo.SP_PL_InternalFileMatchDataGenGetAppInfo";
        public const string PL_InternalFileMatchDataGenGetCustInfo = "dbo.SP_PL_InternalFileMatchDataGenGetCustInfo";
        public const string PL_DataGenGetMortgagor = "dbo.SP_PL_DataGenGetMortgagor";
        public const string PL_FirstRACDataGenGetAppInfo = "dbo.SP_PL_FirstRACDataGenGetAppInfo";
        public const string PL_FirstRACDataGenGetCustInfo = "dbo.SP_PL_FirstRACDataGenGetCustInfo";
        public const string PL_FirstRACDataGenGetBureauInfo = "dbo.SP_PL_FirstRACDataGenGetBureauInfo";
        public const string PL_FirstRACDataGenGetMaxBureauImportDate = "dbo.SP_PL_FirstRACDataGenGetMaxBureauImportDate";
        public const string PL_GetPBOCChecked = "dbo.SP_PL_GetPBOCChecked";
        public const string PL_FirstRacDataGenGetFinalcial = "dbo.SP_PL_FirstRacDataGenGetFinalcial";
        public const string PL_FirstRacDataGenGetDocList = "dbo.SP_PL_FirstRacDataGenGetDocList";
        public const string PL_DataCleaner = "dbo.SP_PL_DataCleaner";
        public const string PL_ThirdRACDataGenGetAppInfo = "dbo.SP_PL_ThirdRACDataGenGetAppInfo";
        public const string PL_ThirdRACDataGenGetCustInfo = "dbo.SP_PL_ThirdRACDataGenGetCustInfo";
        public const string PL_TopupFraudDataGenGetAppInfo = "dbo.SP_PL_TopupFraudDataGenGetAppInfo";
        public const string PL_DataGenGetVerbalValuation = "dbo.SP_PL_DataGenGetVerbalValuation";
        public const string PL_TopupFraudDataGenGetCustInfo = "dbo.SP_PL_TopupFraudDataGenGetCustInfo";
        public const string PL_ProposalDataCollectorRuleResult = "dbo.SP_PL_ProposalDataCollectorRuleResult";
        public const string PL_ProposalDataCollectorRuleResultDtl = "dbo.SP_PL_ProposalDataCollectorRuleResultDtl";
        public const string PL_ProposalDataCollectorADR = "dbo.SP_PL_ProposalDataCollectorADR";
        public const string PL_FirstRACDataCollectorUpdateADR = "dbo.SP_PL_FirstRACDataCollectorUpdateADR";
        public const string PL_DataCollectorHelperGetRunResultById = "dbo.SP_PL_DataCollectorHelperGetRunResultById";
        public const string PL_DataCollectorHelperGetSqlRunResultDtl = "dbo.SP_PL_DataCollectorHelperGetSqlRunResultDtl";
        public const string PL_DataCollectorHelperGetCurrStage = "dbo.SP_PL_DataCollectorHelperGetCurrStage";
        public const string PL_DataCollectorHelperGetSaleAndApp = "dbo.SP_PL_DataCollectorHelperGetSaleAndApp";
        public const string PL_DataCollectorHelperSaveOrUpdateSaleAndApp = "dbo.SP_PL_DataCollectorHelperSaveOrUpdateSaleAndApp";
        public const string PL_DataCollectorHelperUpdateConfirmedInstallment = "dbo.SP_PL_DataCollectorHelperUpdateConfirmedInstallment";
        public const string PL_DataCollectorHelperUpdateRunResultWorkFlowField = "dbo.SP_PL_DataCollectorHelperUpdateRunResultWorkFlowField";
        public const string PL_DataCollectorHelperInsertRunResultBlank = "dbo.SP_PL_DataCollectorHelperInsertRunResultBlank";
        public const string PL_DataCollectorHelperUpdateRunResult = "dbo.SP_PL_DataCollectorHelperUpdateRunResult";
        public const string PL_GetSharedFinancialByCustID = "dbo.SP_PL_GetSharedFinancialByCustID";
        public const string PL_GuarantorsByAppID = "dbo.SP_PL_GuarantorsByAppID";

        public const string PL_GetSABudgetFinanceByCustID = "dbo.SP_PL_GetSABudgetFinanceByCustID";
        public const string PL_GetSEBudgetFinanceByCustID = "dbo.SP_PL_GetSEBudgetFinanceByCustID";
        public const string PL_GetSABudgetSalary = "dbo.SP_PL_GetSABudgetSalary";
        public const string PL_GetSEBudgetSalary = "dbo.SP_PL_GetSEBudgetSalary";
        public const string PL_DeleteCRDupByAppid = "dbo.SP_PL_DeleteCRDupByAppid";
        public const string PL_GetdupDBByAppID = "dbo.SP_PL_GetdupDBByAppID";
        public const string PL_GetCustCountInDiffAppCase = "dbo.SP_PL_GetCustCountInDiffAppCase";
        public const string PL_GetCustInfoInDiffAppCase = "dbo.SP_PL_GetCustInfoInDiffAppCase";
        public const string PL_InsertCRDup = "dbo.SP_PL_InsertCRDup";
        public const string PL_GetProdIdandISSamePlace = "dbo.SP_PL_GetProdIdandISSamePlace";
        public const string PL_DeleteCRFraudByAppID = "dbo.SP_PL_DeleteCRFraudByAppID";

        public const string PL_GetT_RP_FraudData = "dbo.SP_PL_GetT_RP_FraudData";
        public const string PL_InsertT_PL_CRFraud = "dbo.SP_PL_InsertT_PL_CRFraud";
        public const string PL_InsertT_PL_CRPersonFraud = "dbo.SP_PL_InsertT_PL_CRPersonFraud";
        public const string PL_DeleteT_PL_CRNgtv = "dbo.SP_PL_DeleteT_PL_CRNgtv";

        public const string PL_InsertT_PL_CRNgtv = "dbo.SP_PL_InsertT_PL_CRNgtv";
        public const string PL_DeleteT_PL_CRRP = "dbo.SP_PL_DeleteT_PL_CRRP";
        public const string PL_GetT_RP_RelatedPerson = "dbo.SP_PL_GetT_RP_RelatedPerson";
        public const string PL_InsertT_PL_CRRP = "dbo.SP_PL_InsertT_PL_CRRP";
        public const string PL_GetMaxIDfromT_PL_CRPersonVel = "dbo.SP_PL_GetMaxIDfromT_PL_CRPersonVel";
        public const string PL_DeleteT_PL_CRPersonVel = "dbo.SP_PL_DeleteT_PL_CRPersonVel";
        public const string PL_DeleteT_PL_CRVel = "dbo.SP_PL_DeleteT_PL_CRVel";
        public const string PL_VelocityRuleGetCustInfo = "dbo.SP_PL_VelocityRuleGetCustInfo";
        public const string PL_InsertT_PL_CRVel = "dbo.SP_PL_InsertT_PL_CRVel";
        public const string PL_InsertT_PL_CRPersonVel = "dbo.SP_PL_InsertT_PL_CRPersonVel";
        public const string PL_GetT_PL_PBOC_PersonalInfo = "dbo.SP_PL_GetT_PL_PBOC_PersonalInfo";

        public const string PL_GetConfirmPBOCData = "dbo.SP_PL_GetConfirmPBOCData";
        public const string PL_GetSysParam = "dbo.SP_PL_GetSysParam";
        public const string PL_GetVerifiedMoCount = "dbo.SP_PL_GetVerifiedMoCount";
        public const string PL_GetT_RP_ADRByAppidProdid = "dbo.SP_PL_GetT_RP_ADRByAppidProdid";
        public const string PL_GetT_RP_RuleResult = "dbo.SP_PL_GetT_RP_RuleResult";
        public const string PL_GetT_RP_RuleResultDtl = "dbo.SP_PL_GetT_RP_RuleResultDtl";
        public const string PL_GetRuleByRuleidOrgCodeProdidCustType = "dbo.SP_PL_GetRuleByRuleidOrgCodeProdidCustType";

        public const string PL_GetLeadingRate = "dbo.SP_PL_GetLeadingRate";
        public const string PL_GetT_PL_BaseRate = "dbo.SP_PL_GetT_PL_BaseRate";
        public const string PL_GetPrintSourceByFileType = "dbo.SP_PL_GetPrintSourceByFileType";
        public const string PL_GetT_RP_NegativeData = "dbo.SP_PL_GetT_RP_NegativeData";
        public const string PL_GetRPRules = "dbo.SP_PL_GetRPRules";
        public const string PL_GetCollateralType = "dbo.SP_PL_GetCollateralType";
        public const string PL_UpdateResultForEmp = "dbo.SP_PL_UpdateResultForEmp";
        public const string PL_Delete_CRPersonFraudByAppID = "dbo.SP_PL_Delete_CRPersonFraudByAppID";

        public const string PL_GetBaseLTV = "dbo.SP_PL_GetBaseLTV";
        public const string PL_GetRuleUtilLTVFactors = "dbo.SP_PL_GetRuleUtilLTVFactors";
        public const string PL_GetRuleUtilHighPropertyDeduction = "dbo.SP_PL_GetRuleUtilHighPropertyDeduction";
        public const string PL_IsTopup = "dbo.SP_PL_IsTopup";
        public const string PL_GetRACDetails = "dbo.SP_PL_GetRACDetails";
        public const string PL_GetRACResult = "dbo.SP_PL_GetRACResult";
        public const string PL_GetMType = "SP_PL_GetMType";
        public const string PL_GetHighPropertyParamByAppID = "dbo.SP_PL_GetHighPropertyParamByAppID";
        public const string PL_IsSelectedHighPropertyFactor = "dbo.SP_PL_IsSelectedHighPropertyFactor";
        public const string PL_UpdateActualLTVAndApprovedLoanSize = "dbo.SP_PL_UpdateActualLTVAndApprovedLoanSize";
        #endregion

        #region notepage

        public const string PL_GetNewsList = "dbo.SP_PL_GetNewsList";
        public const string PL_GetNoteWait = "dbo.SP_PL_GetNoteWait";
        public const string PL_SaveNews = "dbo.SP_PL_SaveNews";
        public const string PL_DelNews = "dbo.SP_PL_DelNews";
        public const string PL_GetNoteCurrent = "dbo.SP_PL_GetNoteCurrent";
        public const string PL_GetNotePageBanks = "dbo.SP_PL_GetNotePageBanks";
        public const string PL_GetMessageContent = "dbo.SP_PL_GetMessageContent";
        public const string PL_NoteBoardSaveMessage = "dbo.SP_PL_NoteBoardSaveMessage";
        public const string PL_SaveMessageReadLog = "dbo.SP_PL_SaveMessageReadLog";
        public const string PL_NoteBoard_GetSystemRoles  = "dbo.SP_PL_NoteBoard_GetSystemRoles";
        public const string PL_NoteBoard_GetMessageLastReadID = "dbo.SP_PL_GetMessageLastReadID";
        #endregion

        #region cust and contract
        public const string PL_Get_ApplicationAndLoanInfoByAppID = "dbo.SP_PL_Get_ApplicationAndLoanInfoByAppID";
        public const string PL_Get_CustAndContractCustInfoByAppID = "dbo.SP_PL_Get_CustAndContractCustInfoByAppID";
        public const string PL_Save_CustAndContractContacts = "dbo.SP_PL_Save_CustAndContractContacts";
        public const string PL_Get_CustConfirmInfoAndFeeByAppId = "dbo.SP_PL_Get_CustConfirmInfoAndFeeByAppId";
        public const string PL_Save_CustAndContractPayMethodCustConfirmInfoAndFee = "dbo.SP_PL_Save_CustAndContractPayMethodCustConfirmInfoAndFee";
        //获取生成模板的数据
        public const string PL_CustAndContract_GetMergeDateSourceByAppNo = "dbo.SP_PL_CustAndContract_GetMergeDateSourceByAppNo";
        //根据产品获取模板名称和存放路径
        public const string PL_CustAndContract_GetFileNameAndPathByProdID = "dbo.SP_PL_CustAndContract_GetFileNameAndPathByProdID";
        //根据产品获取附件列表
        public const string PL_CustAndContract_getAttachmentFilesListByProdID = "dbo.SP_PL_CustAndContract_getAttachmentFilesListByProdID";
        //获取所有条件相关的列名
        public const string PL_CustAndContract_GetConditionColumnsName = "dbo.SP_PL_CustAndContract_GetConditionColumnsName";
        //
        public const string PL_GetIsPartMo = "dbo.SP_PL_GetIsPartMo";
        //
        public const string PL_GetCompareTenor = "dbo.SP_PL_GetCompareTenor";
        #endregion

        #region MIS Report
        public const string PL_GetBranchByOrg = "dbo.SP_PL_GetBranchByOrg";
        public const string PL_UploadHoliday = "dbo.SP_PL_UploadHoliday";
        public const string PL_DeleteHoliday = "dbo.SP_PL_DeleteHoliday";
        public const string PL_GetMISReportTempDefination = "dbo.SP_PL_GetMISReportTempDefination";
        public const string PL_SaveTemplateSetting = "dbo.SP_PL_SaveTemplateSetting";
        public const string PL_DeleteTemplateSetting = "dbo.SP_PL_DeleteTemplateSetting";
        public const string PL_ExportTimeQueryByStages = "dbo.SP_PL_ExportTimeQueryByStages";
        public const string PL_GetMISReport = "dbo.SP_PL_GetMISReport";
        public const string PL_ExportMISReport = "dbo.SP_PL_ExportMISReport";
        public const string PL_MISReport_ExportProcessHistoryReport = "dbo.SP_PL_MISReport_ExportProcessHistoryReport";
        public const string PL_MISReport_GetTemplateByUserId = "dbo.SP_PL_MISReport_GetTemplateByUserId";

        #endregion

        #region system paramters
        public const string PL_GetParamKeyByIDAndValue = "dbo.P_PL_GetParamKeyByIDAndValue";
        #endregion

        #region common
        public const string PL_Common_GetAppIdByApplicationNo = "dbo.SP_PL_Common_GetAppIdByApplicationNo";
        #endregion

        #region PBOC
        public const string PL_PBOC_DeleteExchRateByDataYM = "dbo.SP_PL_PBOC_DeleteExchRateByDataYM";
        public const string PL_PBOC_DeletePRALSByDataYM = "dbo.SP_PL_PBOC_DeletePRALSByDataYM";
        public const string PL_PBOC_GetReportDefinationByPreFileName = "dbo.SP_PL_PBOC_GetReportDefinationByPreFileName";
        public const string PL_PBOC_GetReportDefinationDetails = "dbo.SP_PL_PBOC_GetReportDefinationDetails";
        public const string PL_PBOC_ClearImportData = "dbo.SP_PL_PBOC_ClearImportData";
        public const string PL_PBOC_GetPBOCRecordByDataYM = "dbo.SP_PL_PBOC_GetPBOCRecordByDataYM";
        public const string PL_PBOC_AddFileHeader = "dbo.SP_PL_PBOC_AddFileHeader";
        public const string PL_PBOC_GetExchRateByDataYM = "dbo.SP_PL_PBOC_GetExchRateByDataYM";
        public const string PL_PBOC_GetMatchWord = "dbo.SP_PL_PBOC_GetMatchWord";
        public const string PL_PBOC_GetLastDeliHisStatus = "dbo.SP_PL_PBOC_GetLastDeliHisStatus";
        public const string PL_PBOC_SELECTPBOC = "dbo.SP_PL_PBOC_SELECTPBOC";
        public const string PL_getMAX_RT_ORIG_LOAN_AMT = "dbo.SP_PL_getMAX_RT_ORIG_LOAN_AMT";
        public const string PL_PBOC_SelectReportByDataYM = "dbo.SP_PL_PBOC_SelectReportByDataYM";//
        public const string PL_PBOC_GetHeaderDataByDataYM = "dbo.SP_PL_PBOC_GetHeaderDataByDataYM";
        public const string PL_PBOC_InsertChangeeOffAmount = "dbo.SP_PL_PBOC_InsertChangeeOffAmount";
        public const string PL_PBOC_SaveRemainingMonth = "dbo.SP_PL_PBOC_SaveRemainingMonth";
        public const string PL_PBOC_DeleteHeaderDataByDataYM = "dbo.SP_PL_PBOC_DeleteHeaderDataByDataYM";
        public const string PL_PBOC_DeleteBodyDataByDataYM = "dbo.SP_PL_PBOC_DeleteBodyDataByDataYM";
        public const string PL_PBOC_GetBodyDataByDataYM = "dbo.SP_PL_PBOC_GetBodyDataByDataYM";
        public const string PL_PBOC_GetALSDataByDataYM = "dbo.SP_PL_PBOC_GetALSDataByDataYM";
        #endregion

    }


}
