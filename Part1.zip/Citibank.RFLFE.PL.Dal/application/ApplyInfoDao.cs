﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Dal.Mappers;


namespace Citibank.RFLFE.PL.Dal.application
{
    public class ApplyInfoDao : AdoDaoSupport, IApplyInfoDao
    {
        public CommonTResult<ApplyInfoDetail> GetApplyInfoDetail(string appNo, string fullName, string idNo, bool isChecker, string maker)
        {
            CommonTResult<ApplyInfoDetail> result = new CommonTResult<ApplyInfoDetail>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("ApplicationNo", appNo);
            parameters.AddWithValue("FullName", fullName);
            parameters.AddWithValue("IDNo", idNo);
            parameters.AddWithValue("Maker", maker);
            parameters.AddWithValue("IsChecker", isChecker);
            result.ResultList = AdoTemplate.QueryWithRowMapper<ApplyInfoDetail>(
                CommandType.StoredProcedure, SPNames.PL_GET_APPLYDETAILBYAPPNO, new ApplyInfoDetailMapper<ApplyInfoDetail>(), parameters);
            return result;
        }

        public int SaveLoanIndustryMaker(T_PL_LoanIndustryMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("Category", entity.Category);
            parameters.AddWithValue("Purpose1", entity.Purpose1);
            parameters.AddWithValue("Purpose2", entity.Purpose2);
            parameters.AddWithValue("Purpose3", entity.Purpose3);
            parameters.AddWithValue("MainIndustry", entity.MainIndustry);
            parameters.AddWithValue("SubIndustry", entity.SubIndustry);
            parameters.AddWithValue("DecorationProvince", entity.DecorationProvince);
            parameters.AddWithValue("DecorationCity", entity.DecorationCity);
            parameters.AddWithValue("DecorationRegion", entity.DecorationRegion);
            parameters.AddWithValue("DecorationAddress", entity.DecorationAddress);
            parameters.AddWithValue("DecorationRelation", entity.DecorationRelation);
            parameters.AddWithValue("IsPropertySelf", entity.IsPropertySelf);
            parameters.AddWithValue("DecorationPropertyValue1", entity.DecorationPropertyValue1);
            parameters.AddWithValue("DecorationPropertyValue2", entity.DecorationPropertyValue2);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddWithValue("IsChecker", entity.IsChecker);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_LOANINDUSTRYMAKER, parameters);
        }

        public int SaveNosOfCollateralMaker(Guid AppID,string RightNoOfLand, string PropertyPermits, string maker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppID);
            parameters.AddWithValue("RightNoOfLand", RightNoOfLand);
            parameters.AddWithValue("PropertyPermits", PropertyPermits);
            parameters.AddWithValue("Maker", maker);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_NOSOFCOLLATERALMAKER, parameters);
        }

        public bool ApproveNosOfCollateralMaker(Guid AppID, string RightNoOfLand, string PropertyPermits, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppID);
            parameters.AddWithValue("RightNoOfLand", RightNoOfLand);
            parameters.AddWithValue("PropertyPermits", PropertyPermits);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ARE_NOSOFCOLLATERALMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectNosOfCollateralMaker(Guid AppID, string RightNoOfLand, string PropertyPermits, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppID);
            parameters.AddWithValue("RightNoOfLand", RightNoOfLand);
            parameters.AddWithValue("PropertyPermits", PropertyPermits);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJ_NOSOFCOLLATERALMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool ApproveLoanIndustryMaker(Guid AppID, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppID);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ARE_LOANINDUSTRYMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectLoanIndustryMaker(Guid AppID, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppID);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJ_LOANINDUSTRYMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool ApproveMortgagorMaker(Guid AppID, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppID);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ARE_MORTGAGORMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectMortgagorMaker(Guid AppID, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", AppID);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJ_MORTGAGORMAKER, parameters);
            return result > 0 ? true : false;
        }
    }
}
