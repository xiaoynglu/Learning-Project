﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Dal.Mappers;


namespace Citibank.RFLFE.PL.Dal.application
{
    public class TopuploadDao : AdoDaoSupport, ITopuploadDao
    {
        public int AddTopupDataOverBatch(T_PL_TopupUploadMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AgentCode", entity.AgentCode);
            parameters.AddWithValue("OrgApplicationNo", entity.OrgApplicationNo);
            parameters.AddWithValue("ReportType", entity.ReportType);
            parameters.AddWithValue("MainBorrower", entity.MainBorrower);
            parameters.AddWithValue("ID_No", entity.ID_No);
            parameters.AddWithValue("TopUpApprovedLoanSize", entity.TopUpApprovedLoanSize);
            parameters.AddWithValue("TopUpRate", entity.TopUpRate);
            parameters.AddWithValue("TopUpApprovedTenor", entity.TopUpApprovedTenor);
            parameters.AddWithValue("TopUpSegment", entity.TopUpSegment);
            parameters.AddWithValue("AddressType", entity.AddressType);
            parameters.AddWithValue("ZipCode", entity.ZipCode);
            parameters.AddWithValue("AddProvince", entity.AddProvince);
            parameters.AddWithValue("AddCity", entity.AddCity);
            parameters.AddWithValue("AddArea", entity.AddArea);
            parameters.AddWithValue("AddStreet", entity.AddStreet);
            parameters.AddWithValue("MainBorrowerSpouse", entity.MainBorrowerSpouse);
            parameters.AddWithValue("MainBorrowerSpouseID", entity.MainBorrowerSpouseID);
            parameters.AddWithValue("LoanPrupose", entity.LoanPrupose);
            parameters.AddWithValue("LoanIndustry", entity.LoanIndustry);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Maker", entity.Maker);
            
            parameters.AddOut("Result", DbType.Int32);

            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ADD_TOPUPUPLOADMAKER, parameters);
            return (int)parameters["@Result"].Value;
        }
        public CommonTResult<T_PL_TopupUploadMaker> GetTopupUploadMakerList(int limit, int start, T_PL_TopupUploadMaker topup)
        {
            CommonTResult<T_PL_TopupUploadMaker> result = new CommonTResult<T_PL_TopupUploadMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgApplicationNo", topup.OrgApplicationNo);
            parameters.AddWithValue("TopUpSegment", topup.TopUpSegment);
            parameters.AddWithValue("ID_No", topup.ID_No);
            parameters.AddWithValue("MainBorrower", topup.MainBorrower);
            parameters.AddWithValue("Maker", topup.Maker);
            parameters.AddWithValue("Status", topup.Status);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_TopupUploadMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_TOPUPUPLOADMAKERLIST, new T_PL_TopupUploadMakerMapper<T_PL_TopupUploadMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }
        public bool ApproveTopuploadMaker(Guid? tid, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TopupID", tid);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ARE_TOPUPUPLOADMAKER, parameters);
            return result > 0 ? true : false;
        }
        public bool RejectTopuploadMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TopupIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJ_TOPUPUPLOADMAKER, parameters);
            return result > 0 ? true : false;
        }
    }
}
