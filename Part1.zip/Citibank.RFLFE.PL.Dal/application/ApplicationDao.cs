﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Framework.Extensions;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.application
{
    public class ApplicationDao : AdoDaoSupport, IApplicationDao
    {
        public CommonTResult<ProductListView> GetNPProductList(string AppId)
        {

            CommonTResult<ProductListView> result = new CommonTResult<ProductListView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<ProductListView>(CommandType.StoredProcedure, SPNames.PL_GetNPProductList, new ProductListViewMapper<ProductListView>(), parameters);
            return result;
        }

        /// <summary>
        /// Get application by AppId
        /// </summary>
        /// <param name="appID">application id</param>
        /// <returns>application entity</returns>
        public T_PL_Application GetApplicationByAppId(Guid appID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appID);

            return AdoTemplate.QueryForObject<T_PL_Application>(
                CommandType.StoredProcedure, SPNames.PL_GetApplicationByAppId, new T_PL_ApplicationMapper<T_PL_Application>(), parameters);
        }

        /// <summary>
        /// Get application details
        /// </summary>
        /// <param name="appID">application id</param>
        /// <param name="stageID">stage id</param>
        /// <returns>application details</returns>
        public ApplicationDetail GetApplicationDetail(Guid appID, int stageID)
        {
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appID);
            parameters.AddWithValue("StageID", stageID);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_GetApplicationDetail, parameters);
            if (ds != null && ds.Tables.Count == 22)
            {   
                appInfo.Application = ds.Tables[0].ConvertToList<T_PL_Application>().Count > 0 ? ds.Tables[0].ConvertToList<T_PL_Application>()[0] : null;
                appInfo.Loan = ds.Tables[1].ConvertToList<T_PL_Loan>().Count > 0 ? ds.Tables[1].ConvertToList<T_PL_Loan>()[0] : null;
                appInfo.Borrowers = ds.Tables[2].ConvertToList<T_PL_Customers>().Count > 0 ? ds.Tables[2].ConvertToList<T_PL_Customers>() : null;
                appInfo.Mortgagtors = ds.Tables[3].ConvertToList<T_PL_Mortgagors>().Count > 0 ? ds.Tables[3].ConvertToList<T_PL_Mortgagors>() : null;
                appInfo.Guarantors = ds.Tables[4].ConvertToList<T_PL_Guarantors>().Count > 0 ? ds.Tables[4].ConvertToList<T_PL_Guarantors>() : null;
                appInfo.LoanIndustry = ds.Tables[5].ConvertToList<T_PL_LoanIndustry>().Count > 0 ? ds.Tables[5].ConvertToList<T_PL_LoanIndustry>() : null;
                appInfo.LTVFactors = ds.Tables[6].ConvertToList<T_PL_LTVFactors>().Count > 0 ? ds.Tables[6].ConvertToList<T_PL_LTVFactors>() : null;
                appInfo.Collateral = ds.Tables[7].ConvertToList<T_PL_Collateral>().Count > 0 ? ds.Tables[7].ConvertToList<T_PL_Collateral>()[0] : null;
                appInfo.AcceptServices = ds.Tables[8].ConvertToList<T_PL_AcceptService>().Count > 0 ? ds.Tables[8].ConvertToList<T_PL_AcceptService>(): null;
                appInfo.EntrustPay = ds.Tables[9].ConvertToList<T_PL_EntrusPay>().Count > 0 ? ds.Tables[9].ConvertToList<T_PL_EntrusPay>()[0] : null;
                appInfo.SelfPay = ds.Tables[10].ConvertToList<T_PL_SelfPay>().Count > 0 ? ds.Tables[10].ConvertToList<T_PL_SelfPay>()[0] : null;
                appInfo.SalaryCust = ds.Tables[11].ConvertToList<T_PL_SalaryCust>().Count > 0 ? ds.Tables[11].ConvertToList<T_PL_SalaryCust>() : null;
                appInfo.SelfEmployedCust = ds.Tables[12].ConvertToList<T_PL_SelfEmployedCust>().Count > 0 ? ds.Tables[12].ConvertToList<T_PL_SelfEmployedCust>() : null;
                appInfo.CustomerContacts = ds.Tables[13].ConvertToList<T_PL_CustomerContact>().Count > 0 ? ds.Tables[13].ConvertToList<T_PL_CustomerContact>() : null;
                appInfo.SABudget = ds.Tables[14].ConvertToList<T_PL_SABudget>().Count > 0 ? ds.Tables[14].ConvertToList<T_PL_SABudget>() : null;
                appInfo.SEBudget = ds.Tables[15].ConvertToList<T_PL_SEBudget>().Count > 0 ? ds.Tables[15].ConvertToList<T_PL_SEBudget>() : null;
                appInfo.CustIncomeDebt = ds.Tables[16].ConvertToList<T_PL_CustDebt>().Count > 0 ? ds.Tables[16].ConvertToList<T_PL_CustDebt>() : null;
                appInfo.OralAppraisal = ds.Tables[17].ConvertToList<T_PL_OralAppraisal>().Count > 0 ? ds.Tables[17].ConvertToList<T_PL_OralAppraisal>() : null;
                appInfo.LoanApproval = ds.Tables[18].ConvertToList<T_PL_LoanApproval>().Count > 0 ? ds.Tables[18].ConvertToList<T_PL_LoanApproval>()[0] : null;
                appInfo.FamilyMembers = ds.Tables[19].ConvertToList<T_PL_FamilyMembers>().Count > 0 ? ds.Tables[19].ConvertToList<T_PL_FamilyMembers>() : null;
                appInfo.SellerInfo = ds.Tables[20].ConvertToList<T_PL_SellerInfo>().Count > 0 ? ds.Tables[20].ConvertToList<T_PL_SellerInfo>()[0] : null;
                appInfo.VerificationRecords = ds.Tables[21].ConvertToList<T_PL_VerificationRecord>().Count > 0 ? ds.Tables[20].ConvertToList<T_PL_VerificationRecord>() : null;
            }
            return null;
        }

        /// <summary>
        /// Insert/Update new application by AppId
        /// </summary>
        /// <param name="entity">application entity</param>
        /// <returns></returns>
        public int SaveApplicationByAppId(T_PL_Application entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", entity.AppID.ToString());
            parameters.AddWithValue("ApplicationNo", entity.ApplicationNo);
            parameters.AddWithValue("ProdID", entity.ProdID);
            parameters.AddWithValue("PayType", entity.PayType);
            parameters.AddWithValue("SourceCode", entity.SourceCode);
            parameters.AddWithValue("AgentCode", entity.AgentCode);
            parameters.AddWithValue("WhereKnow", entity.WhereKnow);
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("CreatorID", entity.CreatorID);
            parameters.AddWithValue("CreateDate", entity.CreateDate);
            parameters.AddWithValue("IsLackDoc", entity.IsLackDoc);
            parameters.AddWithValue("IsSubmitted", entity.IsSubmitted);
            parameters.AddWithValue("IsEmployeeLoan", entity.IsEmployeeLoan);
            parameters.AddWithValue("RelationNumber", entity.RelationNumber);
            parameters.AddWithValue("IsPBOCChecked", entity.IsPBOCChecked);
            parameters.AddWithValue("IsALSChecked", entity.IsALSChecked);
            parameters.AddWithValue("UserDefined1", entity.UserDefined1);
            parameters.AddWithValue("UserDefined2", entity.UserDefined2);
            parameters.AddWithValue("UserDefined3", entity.UserDefined3);
            parameters.AddWithValue("UserDefined4", entity.UserDefined4);
            parameters.AddWithValue("UserDefined5", entity.UserDefined5);
            parameters.AddWithValue("IsTown", entity.IsTown);
            parameters.AddWithValue("IsSamePlace", entity.IsSamePlace);
            parameters.AddWithValue("Remarks", entity.Remarks);
            return AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveApplicationByAppId, parameters);
        }

        public string GetAppSuffix(string branchCode, string date) 
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("branchCode", branchCode);
            parameters.AddWithValue("date", date);
            var result = AdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetAppSuffix, parameters);
            return result == null ? string.Empty : result.ToString();          
        }

        public bool SaveAppNo(string branchCode, string date, string suffix,string remarks)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("PreFix", branchCode);
            parameters.AddWithValue("Mid", date);
            parameters.AddWithValue("Suffix", suffix);
            parameters.AddWithValue("Remarks",remarks);
            return AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveAppNo, parameters)>0?true:false;          
        }

        public bool SaveOtherInfo(OtherView entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", entity.AppId);
            parameters.AddWithValue("PolicyDeviation", entity.PolicyDeviation);
            parameters.AddWithValue("PriceDeviation", entity.PriceDeviation);
            parameters.AddWithValue("ProcessDeviation", entity.ProcessDeviation);
            parameters.AddWithValue("PolicyReason", entity.PolicyReason);
            parameters.AddWithValue("PriceReason", entity.PriceReason);
            parameters.AddWithValue("ProcessReason", entity.ProcessReason);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddWithValue("UserDefined1", entity.UserDefined1);
            parameters.AddWithValue("UserDefined2", entity.UserDefined2);
            parameters.AddWithValue("UserDefined3", entity.UserDefined3);
            parameters.AddWithValue("UserDefined4", entity.UserDefined4);
            parameters.AddWithValue("UserDefined5", entity.UserDefined5);
            return AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveOtherInfo, parameters) > 0 ? true : false;           
        }


        public CommonTResult<OtherView> GetOtherInfo(string appId)
        {
            CommonTResult<OtherView> result = new CommonTResult<OtherView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(appId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<OtherView>(CommandType.StoredProcedure, SPNames.PL_GetOtherInfo, new OtherViewMapper<OtherView>(), parameters);
            return result;           
        }

        public bool UpdateAppSubmit(string appId, string prodId, string submited, string proposalLoanSize, string proposalTenor,string productRate, string baseRate, string avaliableLTV)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("ProdId", prodId);
            parameters.AddWithValue("Submited", submited);
            parameters.AddWithValue("ProposalLoanSize", proposalLoanSize);
            parameters.AddWithValue("ProposalTenor", proposalTenor);
            parameters.AddWithValue("ProductRate", productRate);
            parameters.AddWithValue("BaseRate", baseRate);
            parameters.AddWithValue("AvaliableLTV", avaliableLTV);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateAppSubmit, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool UpdateDeviationed(string appId, string prodId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("ProdId", prodId);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateDeviationed, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool UpdateRateDeviationed(string appId, string rateDeviationed)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("RateDeviationed", rateDeviationed);

            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateRateDeviationedByAppId, parameters)>=0?true:false;
        }
        
        public string GetApplicationNoByAppId(string appId)
        {   
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            object result = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetApplicationNoByAppId, parameters);

            return result != null ? result.ToString() : "";
        }

        public T_PL_Application GetApplicationByAppNo(string ApplicationNo, string OrgCode, string CreatorID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("ApplicationNo", ApplicationNo);
            parameters.AddWithValue("OrgCode", OrgCode);
            parameters.AddWithValue("CreatorID", CreatorID);

            return AdoTemplate.QueryForObject<T_PL_Application>(
                CommandType.StoredProcedure, SPNames.PL_GetApplicationByAppNo, new T_PL_ApplicationMapper<T_PL_Application>(), parameters);
        }

        public bool IsSystemDecided(string appId, string stageId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("StageId", stageId);
            parameters.AddOut("Count", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(
                CommandType.StoredProcedure, SPNames.PL_CheckIsDoNewProposalSystemDecided, parameters);
            return parameters["@Count"].Value.ToString() == "0" ? false : true;
        }
        
        public bool CheckSingleBo(string appId, string borrowType)
        {
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddWithValue("BorrowType", borrowType);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_SystemDecideVerifyInfo, parameters);
            if (ds.Tables.Count==3 && ds.Tables[0].Rows.Count != 0 && ds.Tables[1].Rows.Count != 0 && ds.Tables[2].Rows.Count != 0)
            {
                for (var i = 0; i < ds.Tables[0].Rows[0].ItemArray.Length; i++)
                {
                    if (ds.Tables[0].Rows[0].ItemArray[i].Equals("") || ds.Tables[0].Rows[0].ItemArray[i] == null)
                    {
                        return false;
                    }
                }
                for (var i = 0; i < ds.Tables[1].Rows[0].ItemArray.Length; i++)
                {
                    if (i == 1 || i == 8 || i == 13)
                    {
                        if (ds.Tables[1].Rows[0].ItemArray[i - 1].Equals("BJ") || ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "TJ" || ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "CQ" || ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "SH" ||
                            ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "AMT" || ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "TW" || ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "XGT")
                        {
                            if (ds.Tables[1].Rows[0].ItemArray[i].ToString() != "" && ds.Tables[1].Rows[0].ItemArray[i] != null)
                            {
                                return false;
                            }
                        }
                    }
                    else if (ds.Tables[1].Rows[0].ItemArray[i].ToString() == "" || ds.Tables[1].Rows[0].ItemArray[i] == null)
                    {
                        return false;
                    }
                }
                for (var i = 0; i < ds.Tables[2].Rows[0].ItemArray.Length; i++)
                {
                    if (ds.Tables[2].Rows[0].ItemArray[i].Equals("") || ds.Tables[2].Rows[0].ItemArray[i] == null)
                    {
                        return false;
                    }
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        public CommonTResult<DocumentItem> GetDocumentList(string strCustType, string strProdID, string custSegment)
        {
            CommonTResult<DocumentItem> result = new CommonTResult<DocumentItem>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustType", strCustType);
            parameters.AddWithValue("ProdID", strProdID);
            parameters.AddWithValue("CustSegment", custSegment);
            result.ResultList = AdoTemplate.QueryWithRowMapper<DocumentItem>(CommandType.StoredProcedure, SPNames.PL_GetDocumentList, new DocumentItemMapper<DocumentItem>(), parameters);
            return result;
        }

        public string GetProdNameByProdId(string prodId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdId", prodId);
            parameters.AddOut("Result", DbType.String,50);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(
                CommandType.StoredProcedure, SPNames.PL_GetProdNameByProdID, parameters);
            return parameters["@Result"].Value.ToString();
        }

        public string GetOrgCodeByAppId(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Result", DbType.String, 50);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(
                CommandType.StoredProcedure, SPNames.PL_GetOrgCodeByAppId, parameters);
            return parameters["@Result"].Value.ToString();
        }


        public string GetAppIdByApplicationNo(string applicationNo)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ApplicationNo", applicationNo);
            parameters.AddOut("Result", DbType.String, 50);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(
                CommandType.StoredProcedure, SPNames.PL_Common_GetAppIdByApplicationNo, parameters);
            return parameters["@Result"].Value.ToString();
        }
    }
}
