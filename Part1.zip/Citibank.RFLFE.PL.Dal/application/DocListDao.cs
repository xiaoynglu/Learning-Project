﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Spring.Transaction.Interceptor;

namespace Citibank.RFLFE.PL.Dal.application
{
    public class DocListDao : AdoDaoSupport, IDocListDao
    {
        public CommonTResult<T_PL_DocSubmitted> GetSubmittedDocList(string appid, int stageid, string custID)
        {
            CommonTResult<T_PL_DocSubmitted> result = new CommonTResult<T_PL_DocSubmitted>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", new Guid(appid));
            parameters.AddWithValue("StageID", stageid);
            parameters.AddWithValue("CustomerID", new Guid(custID));
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_DocSubmitted>(
                CommandType.StoredProcedure, SPNames.PL_GetSubmittedDocList, new T_PL_DocSubmittedMapper<T_PL_DocSubmitted>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_DocSubmitted> GetStageDocList(string appid, int stageid, string custID)
        {
            CommonTResult<T_PL_DocSubmitted> result = new CommonTResult<T_PL_DocSubmitted>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appid);
            parameters.AddWithValue("StageID", stageid);
            parameters.AddWithValue("CustomerID", custID);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_DocSubmitted>(
                CommandType.StoredProcedure, SPNames.PL_GetSubmittedDocList, new T_PL_DocSubmittedMapper<T_PL_DocSubmitted>(), parameters);
            return result;
        }

        public Boolean SaveSubmittedDoc(string insertStr, string updateStr)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("insertStr", insertStr);
            parameters.AddWithValue("updateStr", updateStr);
            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_SaveAppCheckerReviewDocList, parameters);
            CommonTResult<T_PL_Customers> familyMembersResult = new CommonTResult<T_PL_Customers>();
            return (int)parameters["@Result"].Value <= 0 ? false : true;
        }

        public CommonTResult<T_PL_DocSubmitted> getLackDoc(string appid, string stageId)
        {
            CommonTResult<T_PL_DocSubmitted> result = new CommonTResult<T_PL_DocSubmitted>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appid);
            parameters.AddWithValue("StageID", stageId);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_DocSubmitted>(
                CommandType.StoredProcedure, SPNames.PL_GetLackDoc, new T_PL_DocSubmittedMapper<T_PL_DocSubmitted>(), parameters);
            return result;
           
        }

        public void UpdateDocListToAppChecker(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateDocListToAppChecker, parameters);
        }
    }
}
