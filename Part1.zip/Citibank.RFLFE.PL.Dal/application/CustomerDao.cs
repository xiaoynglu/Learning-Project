﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Dal.application
{
    public class CustomerDao : AdoDaoSupport, ICustomerDao
    {
        public CommonTResult<T_PL_Customers> GetCustomers(string appID, string CustId)
        {           
            CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(appID));
            if(String.IsNullOrEmpty(CustId))
                parameters.AddWithValue("CustId", "");
            else
                parameters.AddWithValue("CustId", new Guid(CustId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(
                CommandType.StoredProcedure, SPNames.PL_GetCustomers, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_Guarantors> GetGuarantorByAppId(string AppId)
        {
            CommonTResult<T_PL_Guarantors> result = new CommonTResult<T_PL_Guarantors>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(AppId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Guarantors>(CommandType.StoredProcedure, SPNames.PL_GetGuarantorByAppId, new T_PL_GuarantorsMapper<T_PL_Guarantors>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_FamilyMembers> GetFamilyMembersByCustId(string CustId)
        {
            CommonTResult<T_PL_FamilyMembers> result = new CommonTResult<T_PL_FamilyMembers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustId", new Guid(CustId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_FamilyMembers>(CommandType.StoredProcedure, SPNames.PL_GetFamilyMembersByCustId, new T_PL_FamilyMembersMapper<T_PL_FamilyMembers>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_Customers> GetMainAndJointCustomersListByAppId(string AppId)
        {
            CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(AppId));
            parameters.AddWithValue("Relations", Const.ESysParameter.OtherApplicationRelations.ToString("d"));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(CommandType.StoredProcedure, SPNames.PL_GetAppCheckerCustInfo, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            return result;
        }
        
        public CommonTResult<T_PL_CustomerContact> GetBorrowerContactByCustId(string CustId)
        {
            CommonTResult<T_PL_CustomerContact> result = new CommonTResult<T_PL_CustomerContact>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustId", new Guid(CustId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_CustomerContact>(CommandType.StoredProcedure, SPNames.PL_GetCustomerContactByCustId, new T_PL_CustomerContactMapper<T_PL_CustomerContact>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_SABudget> GetFinanceSalaryByCustId(string CustId, string stageId)
        {
            CommonTResult<T_PL_SABudget> result = new CommonTResult<T_PL_SABudget>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustId", new Guid(CustId));
            parameters.AddWithValue("StageId", stageId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_SABudget>(CommandType.StoredProcedure, SPNames.PL_GetFinanceSalaryByCustId, new T_PL_SABudgetMapper<T_PL_SABudget>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_SEBudget> GetFinanceSelfByCustId(string CustId, string stageId)
        {
            CommonTResult<T_PL_SEBudget> result = new CommonTResult<T_PL_SEBudget>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustId", new Guid(CustId));
            parameters.AddWithValue("StageId", stageId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_SEBudget>(CommandType.StoredProcedure, SPNames.PL_GetFinanceSelfByCustId, new T_PL_SEBudgetMapper<T_PL_SEBudget>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_Mortgagors> GetMortgagorListByAppId(string AppId, bool isChecker)
        {
            CommonTResult<T_PL_Mortgagors> result = new CommonTResult<T_PL_Mortgagors>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppId == "" ? new Guid("00000000-0000-0000-0000-000000000000") : new Guid(AppId));
            parameters.AddWithValue("IsChecker", isChecker==true?1:0);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Mortgagors>(CommandType.StoredProcedure, SPNames.PL_GetMortgagorListByAppId, new T_PL_MortgagorsMapper<T_PL_Mortgagors>(), parameters);
            return result;
        }

        public bool SaveCustomerContact(T_PL_CustomerContact Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("HouseProvince", Entity.HouseProvince);
            parameters.AddWithValue("HouseCity", Entity.HouseCity);
            parameters.AddWithValue("HouseDistrict", Entity.HouseDistrict);
            parameters.AddWithValue("HousePostCode", Entity.HousePostCode);
            parameters.AddWithValue("HouseStreet", Entity.HouseStreet);
            parameters.AddWithValue("HouseStatus", Entity.HouseStatus);
            parameters.AddWithValue("HouseTelAreaCode", Entity.HouseTelAreaCode);
            parameters.AddWithValue("HouseTelNumber", Entity.HouseTelNumber);
            parameters.AddWithValue("HouseSameAsResidence", Entity.HouseSameAsResidence);
            parameters.AddWithValue("ResidenceProvince", Entity.ResidenceProvince);
            parameters.AddWithValue("ResidenceCity", Entity.ResidenceCity);
            parameters.AddWithValue("ResidenceDistrict", Entity.ResidenceDistrict);
            parameters.AddWithValue("ResidenceStreet", Entity.ResidenceStreet);
            parameters.AddWithValue("ResidencePostCode", Entity.ResidencePostCode);
            parameters.AddWithValue("ResidenceTelAreaCode", Entity.ResidenceTelAreaCode);
            parameters.AddWithValue("ResidenceTelNumber", Entity.ResidenceTelNumber);
            parameters.AddWithValue("WorkingProvince", Entity.WorkingProvince);
            parameters.AddWithValue("WorkingCity", Entity.WorkingCity);
            parameters.AddWithValue("WorkingDistrict", Entity.WorkingDistrict);
            parameters.AddWithValue("WorkingStreet", Entity.WorkingStreet);
            parameters.AddWithValue("WorkingPostCode", Entity.WorkingPostCode);
            parameters.AddWithValue("WorkingTelAreaCode", Entity.WorkingTelAreaCode);
            parameters.AddWithValue("WorkingTelNumber", Entity.WorkingTelNumber);
            parameters.AddWithValue("WorkingTelExtNumber", Entity.WorkingTelExtNumber);
            parameters.AddWithValue("CommunicationAddressAs", Entity.CommunicationAddressAs);
            parameters.AddWithValue("MobileNumber", Entity.MobileNumber);
            parameters.AddWithValue("Email", Entity.Email);
            parameters.AddWithValue("IDIssueDate", Entity.IDIssueDate);
            parameters.AddWithValue("IDExpireDate", Entity.IDExpireDate);
            parameters.AddWithValue("IDIssuePlace", Entity.IDIssuePlace);
            parameters.AddWithValue("OtherContactName", Entity.OtherContactName);
            parameters.AddWithValue("OtherContactRelation", Entity.OtherContactRelation);
            parameters.AddWithValue("OtherContactTelAreaCode", Entity.OtherContactTelAreaCode);
            parameters.AddWithValue("OtherContactTelNumber", Entity.OtherContactTelNumber);
            parameters.AddWithValue("OtherContactCompany", Entity.OtherContactCompany);
            parameters.AddWithValue("OtherContactTelExtNumber", Entity.OtherContactTelExtNumber);
            parameters.AddWithValue("OtherContactMobile", Entity.OtherContactMobile);
            parameters.AddWithValue("RelativeName", Entity.RelativeName);
            parameters.AddWithValue("RelativeRelation", Entity.RelativeRelation);
            parameters.AddWithValue("RelativeCompany", Entity.RelativeCompany);
            parameters.AddWithValue("RelativeMobile", Entity.RelativeMobile);
            parameters.AddWithValue("RelativeTelAreaCode", Entity.RelativeTelAreaCode);
            parameters.AddWithValue("RelativeTelNumber", Entity.RelativeTelNumber);
            parameters.AddWithValue("RelativeTelExtNumber", Entity.RelativeTelExtNumber);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveBorrowerContact, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool SaveFinanceSalary(T_PL_SABudget Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("AfterTaxIncome", ConvertUtility.ConvertStringToDecimal(Entity.AfterTaxIncome));
            parameters.AddWithValue("RentalIncome",  ConvertUtility.ConvertStringToDecimal(Entity.RentalIncome));
            parameters.AddWithValue("OtherIncome", ConvertUtility.ConvertStringToDecimal( Entity.OtherIncome));
            parameters.AddWithValue("OtherFamilyIncome",  ConvertUtility.ConvertStringToDecimal(Entity.OtherFamilyIncome));
            parameters.AddWithValue("RentalExpenses",  ConvertUtility.ConvertStringToDecimal(Entity.RentalExpenses));
            parameters.AddWithValue("UtilitiesFee",  ConvertUtility.ConvertStringToDecimal(Entity.UtilitiesFee));
            parameters.AddWithValue("LivingExpenses", ConvertUtility.ConvertStringToDecimal( Entity.LivingExpenses));
            parameters.AddWithValue("EducationExpenses",  ConvertUtility.ConvertStringToDecimal(Entity.EducationExpenses));
            parameters.AddWithValue("TransportationExpenses",  ConvertUtility.ConvertStringToDecimal(Entity.TransportationExpenses));
            parameters.AddWithValue("OtherExpenses",  ConvertUtility.ConvertStringToDecimal(Entity.OtherExpenses));
            parameters.AddWithValue("MLRepayment", ConvertUtility.ConvertStringToDecimal( Entity.MLRepayment));
            parameters.AddWithValue("ULRepayment", ConvertUtility.ConvertStringToDecimal(Entity.ULRepayment));
            parameters.AddWithValue("StageID", Entity.StageID);
            parameters.AddWithValue("ProcessorID", Entity.ProcessorID);
            parameters.AddWithValue("ProceededDate", Entity.ProceededDate);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveFinanceSalaryByCustId, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool SaveFinanceSelf(T_PL_SEBudget Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("MonthlyTurnover", ConvertUtility.ConvertStringToDecimal(Entity.MonthlyTurnover));
            parameters.AddWithValue("PurchaseCost", ConvertUtility.ConvertStringToDecimal(Entity.PurchaseCost));
            parameters.AddWithValue("GrossMargins",ConvertUtility.ConvertStringToDecimal( Entity.GrossMargins));
            parameters.AddWithValue("StoreRents",ConvertUtility.ConvertStringToDecimal( Entity.StoreRents));
            parameters.AddWithValue("UtilitiesFee", ConvertUtility.ConvertStringToDecimal(Entity.UtilitiesFee));
            parameters.AddWithValue("EmployeeSalary", ConvertUtility.ConvertStringToDecimal(Entity.EmployeeSalary));
            parameters.AddWithValue("OtherExpenses",ConvertUtility.ConvertStringToDecimal( Entity.OtherExpenses));
            parameters.AddWithValue("Tax", ConvertUtility.ConvertStringToDecimal(Entity.Tax));
            parameters.AddWithValue("MLRepayment", ConvertUtility.ConvertStringToDecimal(Entity.MLRepayment));
            parameters.AddWithValue("ULRepayment",ConvertUtility.ConvertStringToDecimal( Entity.ULRepayment));
            parameters.AddWithValue("RentalIncome", ConvertUtility.ConvertStringToDecimal(Entity.RentalIncome));
            parameters.AddWithValue("StageID", Entity.StageID);
            parameters.AddWithValue("ProcessorID", Entity.ProcessorID);
            parameters.AddWithValue("ProceededDate", Entity.ProceededDate);
            parameters.AddWithValue("PaidInsurance", Entity.PaidInsurance);
            parameters.AddWithValue("OwnedEstate", Entity.OwnedEstate);
            parameters.AddWithValue("OwnedResidence", Entity.OwnedResidence);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveFinanceSelByCustId, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool SaveSalaryCust(T_PL_SalaryCust Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("EnterpriseLevel", Entity.EnterpriseLevel);
            parameters.AddWithValue("Department", Entity.Department);
            parameters.AddWithValue("Position", Entity.Position);
            parameters.AddWithValue("Job", Entity.Job);
            parameters.AddWithValue("EnterpriseName", Entity.EnterpriseName);
            parameters.AddWithValue("EnterpriseProperty", Entity.EnterpriseProperty);
            parameters.AddWithValue("EnterpriseScale", Entity.EnterpriseScale);
            parameters.AddWithValue("CurrentWorkingLife", Entity.CurrentWorkingLife);
            parameters.AddWithValue("PreWorkingLife", Entity.PreWorkingLife);
            parameters.AddWithValue("TotalWorkingLife", Entity.TotalWorkingLife);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveSalaryCust, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool SaveSelfEmployedCust(T_PL_SelfEmployedCust Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("CurrentIndustryTime", Entity.CurrentIndustryTime);
            parameters.AddWithValue("ShopName", Entity.ShopName);
            parameters.AddWithValue("RegistrationNumber", Entity.RegistrationNumber);
            parameters.AddWithValue("OperatorName", Entity.OperatorName);
            parameters.AddWithValue("OperationPlace", Entity.OperationPlace);
            parameters.AddWithValue("EmployeeNumber", Entity.EmployeeNumber);
            parameters.AddWithValue("Contact", Entity.Contact);
            parameters.AddWithValue("ContactPosition", Entity.ContactPosition);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveSelfEmployedCust, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool SaveCustomerInfo(T_PL_Customers Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("BorrowType", Entity.BorrowType);
            parameters.AddWithValue("FirstName", Entity.FirstName);
            parameters.AddWithValue("LastName", Entity.LastName);
            parameters.AddWithValue("FullName", Entity.FullName);
            parameters.AddWithValue("FormerName", Entity.FormerName);
            parameters.AddWithValue("PinyinName", Entity.PinyinName);
            parameters.AddWithValue("IDNo", Entity.IDNo);
            parameters.AddWithValue("Gender", Entity.Gender);
            parameters.AddWithValue("DOB", Entity.DOB==DateTime.MinValue?null:Entity.DOB.ToString());
            parameters.AddWithValue("MarriageStatus", Entity.MarriageStatus);
            parameters.AddWithValue("SpouseName", Entity.SpouseName);
            parameters.AddWithValue("SpouseIDNo", Entity.SpouseIDNo);
            parameters.AddWithValue("HasChildren", Entity.HasChildren);
            parameters.AddWithValue("Relation", Entity.Relation);
            parameters.AddWithValue("Education", Entity.Education);
            parameters.AddWithValue("ReportType", Entity.ReportType);
            parameters.AddWithValue("LivedYear", Entity.LivedYear==0?null:Entity.LivedYear.ToString());
            parameters.AddWithValue("EmploymentType", Entity.EmploymentType);
            parameters.AddWithValue("Industry", Entity.Industry);
            parameters.AddWithValue("Occupation", Entity.Occupation);
            parameters.AddWithValue("SharedFinancial", Entity.SharedFinancial);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveCustomerInfo, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }


        public bool DeleteCustomerByCustId(string custId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("custId", custId);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteCustomerByCustId, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }


        public bool SaveFamilyMember(T_PL_FamilyMembers Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("MemberID",Entity.MemberID.ToString()!="00000000-0000-0000-0000-000000000000"?Entity.MemberID: System.Guid.NewGuid());
            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("Gender", Entity.Gender);
            parameters.AddWithValue("Name", Entity.Name);
            parameters.AddWithValue("PinyinName", Entity.PinyinName);
            parameters.AddWithValue("IDNo", Entity.IDNo);
            parameters.AddWithValue("Relation", Entity.Relation);
            parameters.AddWithValue("QueriedBureau", Entity.QueriedBureau);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveFamilyMember, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;

        }

        public bool SaveGuarantors(T_PL_Guarantors Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("GuarantorID", System.Guid.NewGuid());
            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("Name", Entity.Name);
            parameters.AddWithValue("PinyinName", Entity.PinyinName);
            parameters.AddWithValue("IDNo", Entity.IDNo);
            parameters.AddWithValue("Telephone", Entity.Telephone);
            parameters.AddWithValue("MobileNumber", Entity.MobileNumber);
            parameters.AddWithValue("Relation", Entity.Relation);
            parameters.AddWithValue("HouseProvince", Entity.HouseProvince);
            parameters.AddWithValue("HouseCity", Entity.HouseCity);
            parameters.AddWithValue("HouseDistrict", Entity.HouseDistrict);
            parameters.AddWithValue("HouseStreet", Entity.HouseStreet);
            parameters.AddWithValue("HousePostCode", Entity.HousePostCode);
            parameters.AddWithValue("WorkingProvince", Entity.WorkingProvince);
            parameters.AddWithValue("WorkingCity", Entity.WorkingCity);
            parameters.AddWithValue("WorkingDistrict", Entity.WorkingDistrict);
            parameters.AddWithValue("WorkingStreet", Entity.WorkingStreet);
            parameters.AddWithValue("WorkingPostCode", Entity.WorkingPostCode);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveGuarantorByAppId, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool SaveBorrowerCustomers(BorrowerBasicView entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("CustID", entity.CustID);
            parameters.AddWithValue("FirstName", entity.FirstName);
            parameters.AddWithValue("LastName", entity.LastName);
            parameters.AddWithValue("FullName", entity.FullName);
            parameters.AddWithValue("FormerName", entity.FormerName);
            parameters.AddWithValue("PinyinName", entity.PinyinName);
            parameters.AddWithValue("IDNo", entity.IDNo);
            parameters.AddWithValue("Gender", entity.Gender);
            parameters.AddWithValue("DOB", entity.DOB);
            parameters.AddWithValue("MarriageStatus", entity.MarriageStatus);
            parameters.AddWithValue("SpouseName", entity.SpouseName);
            parameters.AddWithValue("SpouseIDNo", entity.SpouseIDNo);
            parameters.AddWithValue("HasChildren", entity.HasChildren);
            parameters.AddWithValue("Education", entity.Education);
            parameters.AddWithValue("LivedYear", entity.LivedYear);
            parameters.AddWithValue("EmploymentType", entity.EmploymentType);
            parameters.AddWithValue("Industry", entity.Industry);
            parameters.AddWithValue("Occupation", entity.Occupation);
            parameters.AddWithValue("Relation", entity.RelationShip);
            parameters.AddWithValue("SharedFinancial", entity.SharedFinancial);

            parameters.AddWithValue("IsTown", entity.IsTown == "on" ? 1 : 0);
            parameters.AddWithValue("IsSamePlace", entity.IsSamePlace == "on" ? 1 : 0);
            parameters.AddWithValue("IsEmployeeLoan", entity.IsEmployeeLoan == "on" ? 1 : 0);
            parameters.AddWithValue("EnterpriseLevel", entity.EnterpriseLevel);
            parameters.AddWithValue("Department", entity.Department);
            parameters.AddWithValue("Position", entity.Position);
            parameters.AddWithValue("Job", entity.Job);
            parameters.AddWithValue("EnterpriseProperty", entity.EnterpriseProperty);
            parameters.AddWithValue("EnterpriseName", entity.EnterpriseName);
            parameters.AddWithValue("EnterpriseScale", entity.EnterpriseScale);
            parameters.AddWithValue("CurrentWorkingLife", entity.CurrentWorkingLife);
            parameters.AddWithValue("PreWorkingLife", entity.PreWorkingLife);
            parameters.AddWithValue("TotalWorkingLife", entity.TotalWorkingLife);
            parameters.AddWithValue("ShopName", entity.ShopName);
            parameters.AddWithValue("RegistrationNumber", entity.RegistrationNumber);
            parameters.AddWithValue("CurrentIndustryTime", entity.CurrentIndustryTime);
            parameters.AddWithValue("OperationPlace", entity.OperationPlace);
            parameters.AddWithValue("OperatorName", entity.OperatorName);
            parameters.AddWithValue("EmployeeNumber", entity.EmployeeNumber);
            parameters.AddWithValue("Contact", entity.Contact);
            parameters.AddWithValue("ContactPosition", entity.ContactPosition);

            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveBorrowCustomer, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }


        public bool DeleteFamilyMembersByMemberId(string memberId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("MemberId", memberId);
            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteFamilyMemberByMemberId, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }

        public string GetFirstPercent(string MOCount, string OrgCode, string Collateralpe)
        {
            string result = "";
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("MOCount", int.Parse(MOCount));
            parameters.AddWithValue("OrgCode", OrgCode);
            parameters.AddWithValue("Collateralpe", Collateralpe);
            object o1 = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetFirstPercent, parameters);
            if (o1 != null)
            {
                result = o1.ToString();
            }
            else
            {
                result = "";
            }
            return result;
        }

        public List<string> GetBaseAndMaxLtv(string ProdID, string MOCount, string Collateralpe, string orgCode)
        {
            CommonTResult<T_PL_LTVValue> result = new CommonTResult<T_PL_LTVValue>();
            List<string> resultList = new List<string>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", ProdID);
            parameters.AddWithValue("MOCount", MOCount);
            parameters.AddWithValue("Collateralpe", Collateralpe);
            parameters.AddWithValue("OrgCode", orgCode);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_LTVValue>(CommandType.StoredProcedure, SPNames.PL_GetBaseAndMaxLtv, new T_PL_LTVValueMapper<T_PL_LTVValue>(), parameters);
            if (result.ResultList.Count > 0) {
                resultList.Add(result.ResultList.FirstOrDefault().BaseLTV.ToString());
                resultList.Add(result.ResultList.FirstOrDefault().MaxDelLTV.ToString());
            }
            return resultList;
        }

        public bool SaveMortgagor(T_PL_Mortgagors Entity, bool isChecker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", Entity.AppID);
            parameters.AddWithValue("HouseCity", Entity.HouseCity);
            parameters.AddWithValue("HouseDistrict", Entity.HouseDistrict);
            parameters.AddWithValue("HousePostCode", Entity.HousePostCode);
            parameters.AddWithValue("HouseProvince", Entity.HouseProvince);
            parameters.AddWithValue("HouseStreet", Entity.HouseStreet);
            parameters.AddWithValue("IDNo", Entity.IDNo);
            parameters.AddWithValue("MarriageStatus", Entity.MarriageStatus);
            parameters.AddWithValue("MobileNumber", Entity.MobileNumber);
            parameters.AddWithValue("MortID", Entity.MortID.ToString() == "00000000-0000-0000-0000-000000000000" ? System.Guid.NewGuid() : Entity.MortID);
            parameters.AddWithValue("Name", Entity.Name);
            parameters.AddWithValue("PinyinName", Entity.PinyinName);
            parameters.AddWithValue("Relation", Entity.Relation);
            parameters.AddWithValue("SpouseIDNo", Entity.SpouseIDNo);
            parameters.AddWithValue("SpouseMobile", Entity.SpouseMobile);
            parameters.AddWithValue("SpouseName", Entity.SpouseName);
            parameters.AddWithValue("SpousePinyinName", Entity.SpousePinyinName);
            parameters.AddWithValue("SpouseTelephone", Entity.SpouseTelephone);
            parameters.AddWithValue("Telephone", Entity.Telephone);
            parameters.AddWithValue("IsChecker", isChecker==true?1:0);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveMortgagor, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;

        }

        public bool RemoveMortgagor(string MortID, bool isChecker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("MortID", MortID);
            parameters.AddWithValue("IsChecker", isChecker==true?1:0);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RemoveMortgagor, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;

        }

        public string GetCustIDByBorrowType(string appID, string BorrowType)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("BorrowType", BorrowType);
            parameters.AddWithValue("appID", appID);
            parameters.AddOut("CustID", DbType.String, 50);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(
                CommandType.StoredProcedure, SPNames.PL_GetCustIDByBorrowType, parameters);
            string result = parameters["@CustID"].Value == System.DBNull.Value ? string.Empty : (string)parameters["@CustID"].Value;
            if (!string.IsNullOrEmpty(result))
                return result;
            else
                return "";
        }

        public string GetProdIDbyProdName(string prodName)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdName", prodName);
            object o1 = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetProdIDbyProdName, parameters);
            if (o1 != null)
            {
                return o1.ToString();
            }
            return "";
        }

        public bool SaveCustomers(T_PL_Customers entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("AppNo", entity.AppNo);
            parameters.AddWithValue("Soeid", entity.Soeid);
            parameters.AddWithValue("CustID", entity.CustID);
            parameters.AddWithValue("OrgApplicationNo", entity.OrgApplicationNo);
            parameters.AddWithValue("OrgLoanNumber", entity.OrgLoanNumber);
            parameters.AddWithValue("OrgSegment", entity.OrgCustType);
            parameters.AddWithValue("TopUpSegment", entity.TopUpCustType);
            parameters.AddWithValue("LastName", entity.LastName);
            parameters.AddWithValue("FirstName", entity.FirstName);
            parameters.AddWithValue("FullName", entity.FullName);
            parameters.AddWithValue("FormerName", entity.FormerName);
            parameters.AddWithValue("PinyinName", entity.PinyinName);
            parameters.AddWithValue("IDNo", entity.IDNo);
            parameters.AddWithValue("Gender", entity.Gender);
            parameters.AddWithValue("DOB", entity.DOB);
            parameters.AddWithValue("ReportType", entity.ReportType);
            parameters.AddWithValue("EmploymentType", entity.EmploymentType);
            parameters.AddWithValue("CollateralType", entity.CollateralType);
            parameters.AddWithValue("PropertyType", entity.PropertyType);
            parameters.AddWithValue("HasProperty", entity.PropertiesSituation);
            parameters.AddWithValue("Relation", entity.Relation);

            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveCustomer, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }

        public CommonTResult<BorrowerBasicView> GetBorrowerCustomers(string AppID, string CustId)
        {
            CommonTResult<BorrowerBasicView> result = new CommonTResult<BorrowerBasicView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(AppID));
            if (String.IsNullOrEmpty(CustId))
                parameters.AddWithValue("CustId", "");
            else
                parameters.AddWithValue("CustId", new Guid(CustId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<BorrowerBasicView>(
                CommandType.StoredProcedure, SPNames.PL_GetBorrowCustomer, new BorrowerBasicViewMapper<BorrowerBasicView>(), parameters);
            return result;
        }

        public bool SaveFinanceSalaryByCustId(T_PL_SABudget Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("AfterTaxIncome", ConvertUtility.ConvertStringToDecimal(Entity.AfterTaxIncome));
            parameters.AddWithValue("RentalIncome", ConvertUtility.ConvertStringToDecimal(Entity.RentalIncome));
            parameters.AddWithValue("OtherIncome", ConvertUtility.ConvertStringToDecimal( Entity.OtherIncome));
            parameters.AddWithValue("OtherFamilyIncome",  ConvertUtility.ConvertStringToDecimal(Entity.OtherFamilyIncome));
            parameters.AddWithValue("RentalExpenses",  ConvertUtility.ConvertStringToDecimal(Entity.RentalExpenses));
            parameters.AddWithValue("UtilitiesFee",  ConvertUtility.ConvertStringToDecimal(Entity.UtilitiesFee));
            parameters.AddWithValue("LivingExpenses", ConvertUtility.ConvertStringToDecimal( Entity.LivingExpenses));
            parameters.AddWithValue("EducationExpenses", ConvertUtility.ConvertStringToDecimal( Entity.EducationExpenses));
            parameters.AddWithValue("TransportationExpenses",  ConvertUtility.ConvertStringToDecimal(Entity.TransportationExpenses));
            parameters.AddWithValue("OtherExpenses",  ConvertUtility.ConvertStringToDecimal(Entity.OtherExpenses));
            parameters.AddWithValue("MLRepayment",  ConvertUtility.ConvertStringToDecimal(Entity.MLRepayment));
            parameters.AddWithValue("ULRepayment",  ConvertUtility.ConvertStringToDecimal(Entity.ULRepayment));
            parameters.AddWithValue("ProcessorID", Entity.ProcessorID);
            parameters.AddWithValue("ProceededDate", DateTime.Now.ToString());
            parameters.AddWithValue("StageID", Entity.StageID);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveFinanceSalaryByCustId, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool SaveFinanceSelByCustId(T_PL_SEBudget Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("MonthlyTurnover", Entity.MonthlyTurnover);
            parameters.AddWithValue("PurchaseCost", Entity.PurchaseCost);
            parameters.AddWithValue("GrossMargins", Entity.GrossMargins);
            parameters.AddWithValue("StoreRents", Entity.StoreRents);
            parameters.AddWithValue("UtilitiesFee", Entity.UtilitiesFee);
            parameters.AddWithValue("EmployeeSalary", Entity.EmployeeSalary);
            parameters.AddWithValue("OtherExpenses", Entity.OtherExpenses);
            parameters.AddWithValue("Tax", Entity.Tax);
            parameters.AddWithValue("ProcessorID", "kz17243");//todo
            parameters.AddWithValue("ProceededDate", DateTime.Now.ToString());
            parameters.AddWithValue("StageID", Entity.StageID);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveFinanceSelByCustId, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool InitNewProposal(string AppID, string SoeID,string orgCode)
        {
            CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", new Guid(AppID));
            parameters.AddWithValue("SoeID", SoeID);
            parameters.AddWithValue("OrgCode", orgCode);
            
            int iresult = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_InitNewProposal, parameters);
            if (iresult >= 0)
                return true;
            else
                return false;
        }

        public bool SaveGuarantorByAppId(T_PL_Guarantors entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("GuarantorID", entity.GuarantorID);
            parameters.AddWithValue("Name", entity.Name);
            parameters.AddWithValue("PinyinName", entity.PinyinName);
            parameters.AddWithValue("IDNo", entity.IDNo);
            parameters.AddWithValue("Telephone", entity.Telephone);
            parameters.AddWithValue("MobileNumber", entity.MobileNumber);
            parameters.AddWithValue("Relation", entity.Relation);
            parameters.AddWithValue("HouseProvince", entity.HouseProvince);
            parameters.AddWithValue("HouseCity", entity.HouseCity);
            parameters.AddWithValue("HouseDistrict", entity.HouseDistrict);
            parameters.AddWithValue("HouseStreet", entity.HouseStreet);
            parameters.AddWithValue("HousePostCode", entity.HousePostCode);
            parameters.AddWithValue("WorkingProvince", entity.WorkingProvince);
            parameters.AddWithValue("WorkingCity", entity.WorkingCity);
            parameters.AddWithValue("WorkingDistrict", entity.WorkingDistrict);
            parameters.AddWithValue("WorkingStreet", entity.WorkingStreet);
            parameters.AddWithValue("WorkingPostCode", entity.WorkingPostCode);


            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveGuarantorByAppId, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }


        public CommonTResult<FinanceSurveyView> GetFinanceSurvey(string appId)
        {
            CommonTResult<FinanceSurveyView> result = new CommonTResult<FinanceSurveyView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(appId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<FinanceSurveyView>(CommandType.StoredProcedure, SPNames.PL_GetFinanceSurvey, new FinanceSurveyViewMapper<FinanceSurveyView>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_CustIncome> GetIncomeDetails(string custId)
        {
            CommonTResult<T_PL_CustIncome> result = new CommonTResult<T_PL_CustIncome>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", new Guid(custId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_CustIncome>(CommandType.StoredProcedure, SPNames.PL_GetIncomeDetails, new T_PL_CustIncomeMapper<T_PL_CustIncome>(), parameters);
            return result;
        }


        public CommonTResult<T_PL_CustDebt> GetCutDebt(string custId)
        {
            CommonTResult<T_PL_CustDebt> result = new CommonTResult<T_PL_CustDebt>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", new Guid(custId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_CustDebt>(CommandType.StoredProcedure, SPNames.PL_GetCustDebt, new T_PL_CustDebtMapper<T_PL_CustDebt>(), parameters);
            return result;
        }


        public CommonTResult<LoanInfoView> GetLoanInfo(string appId)
        {
            CommonTResult<LoanInfoView> result = new CommonTResult<LoanInfoView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(appId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<LoanInfoView>(CommandType.StoredProcedure, SPNames.PL_GetApprovalLoanInfoByAppId, new LoanInfoViewMapper<LoanInfoView>(), parameters);
            return result;
        }


        public string GetCustIDByAppIdAndBorrowType(string appId, string borrowType)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("BorrowType", borrowType);
            object o1 = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetCustIDByAppIdAndBorrowType, parameters);
            if (o1 != null)
            {
                return o1.ToString();
            }
            return "";
        }

        public bool UpdateScoringCard(T_PL_SEBudget Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("OwnedEstate", Entity.OwnedEstate);
            parameters.AddWithValue("OwnedResidence", Entity.OwnedResidence);
            parameters.AddWithValue("PaidInsurance", Entity.PaidInsurance);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateScoringCard, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
           
        }

        public bool UpdateSalaryWorkInfo(T_PL_SalaryCust Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("EnterpriseLevel", Entity.EnterpriseLevel);
            parameters.AddWithValue("Department", Entity.Department);
            parameters.AddWithValue("Position", Entity.Position);
            parameters.AddWithValue("Job", Entity.Job);
            parameters.AddWithValue("EnterpriseName", Entity.EnterpriseName);
            parameters.AddWithValue("EnterpriseProperty", Entity.EnterpriseProperty);
            parameters.AddWithValue("EnterpriseScale", Entity.EnterpriseScale);
            parameters.AddWithValue("CurrentWorkingLife", Entity.CurrentWorkingLife);
            parameters.AddWithValue("PreWorkingLife", Entity.PreWorkingLife);
            parameters.AddWithValue("TotalWorkingLife", Entity.TotalWorkingLife);
            parameters.AddWithValue("Industry", Entity.Industry);
            parameters.AddWithValue("Occupation", Entity.Occupation);

            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateSalaryWorkInfo, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }

        public bool UpdateSelfEmploymentWorkInfo(T_PL_SelfEmployedCust Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("CurrentIndustryTime", Entity.CurrentIndustryTime);
            parameters.AddWithValue("ShopName", Entity.ShopName);
            parameters.AddWithValue("RegistrationNumber", Entity.RegistrationNumber);
            parameters.AddWithValue("OperatorName", Entity.OperatorName);
            parameters.AddWithValue("OperationPlace", Entity.OperationPlace);
            parameters.AddWithValue("EmployeeNumber", Entity.EmployeeNumber);
            parameters.AddWithValue("Contact", Entity.Contact);
            parameters.AddWithValue("ContactPosition", Entity.ContactPosition);
            parameters.AddWithValue("Industry", Entity.Industry);
            parameters.AddWithValue("Occupation", Entity.Occupation);

            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateSelfEmploymentWorkInfo, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }


        public bool SaveBorrowerDetailsInfoOfCreditApproval(T_PL_Customers Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("CustID", Entity.CustID);
            parameters.AddWithValue("FirstName", Entity.FirstName);
            parameters.AddWithValue("LastName", Entity.LastName);
            parameters.AddWithValue("PinyinName", Entity.PinyinName);
            parameters.AddWithValue("Gender", Entity.Gender);
            parameters.AddWithValue("IDNo", Entity.IDNo);
            parameters.AddWithValue("DOB", Entity.DOB);
            parameters.AddWithValue("MarriageStatus", Entity.MarriageStatus);
            parameters.AddWithValue("Education", Entity.Education);
            parameters.AddWithValue("HouseStatus", Entity.HouseStatus);
            parameters.AddWithValue("LivedYear", Entity.LivedYear);
            parameters.AddWithValue("HasChildren", Entity.HasChildren);
            parameters.AddWithValue("IsSamePlace", Entity.IsSamePlace==true?"1":"0");
            parameters.AddWithValue("IsTown", Entity.IsTown == true ? "1" : "0");
            parameters.AddWithValue("IsEmployeeLoan", Entity.IsEmployeeLoan == true ? "1" : "0");

            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveBorrowerDetailsInfoOfCreditApproval, parameters);
            if (i >= 0)
                return true;
            else
                return false;
           
        }

        public bool SaveFinanceSurveyOfCreditApproval(FinanceSurveyView Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("MBCustId", Entity.MBCustId);
            parameters.AddWithValue("CB1CustId", Entity.CB1CustId);
            parameters.AddWithValue("CB2CustId", Entity.CB2CustId);
            parameters.AddWithValue("MB_PaySlip", Entity.MB_PaySlip);
            parameters.AddWithValue("CB1_PaySlip", Entity.CB1_PaySlip);
            parameters.AddWithValue("CB2_PaySlip", Entity.CB2_PaySlip);
            parameters.AddWithValue("MB_CompanyLetter", Entity.MB_CompanyLetter);
            parameters.AddWithValue("CB1_CompanyLetter", Entity.CB1_CompanyLetter);
            parameters.AddWithValue("CB2_CompanyLetter", Entity.CB2_CompanyLetter);

            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveFinanceSurveyOfCreditApproval, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }

        public bool SaveIncomeDetailsOfCreditApproval(List<T_PL_CustIncome> List)
        {
            var isSuccess = false;
            foreach(var item in List){
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("CustID", item.CustID);
                parameters.AddWithValue("IncomeType", item.IncomeType);
                parameters.AddWithValue("VerifiedAmount", item.VerifiedAmount);
                parameters.AddWithValue("isSelected", item.isSelected);
                parameters.AddWithValue("ProvenIncome", item.ProvenIncome);

                isSuccess = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveIncomeDetailsOfCreditApproval, parameters) > 0 ? true : false;
                if(!isSuccess)
                    break;
            }
            return isSuccess;
        
        }

        public bool SaveCustDebtOfCreditApproval(T_PL_CustDebt Entity)
        {
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("CustID", Entity.CustID);
                parameters.AddWithValue("ModifiedDebt", Entity.ModifiedDebt);
                parameters.AddWithValue("ModifiedCollateralLoan", Entity.ModifiedCollateralLoan);
                parameters.AddWithValue("ModifiedUnsecuredLoan", Entity.ModifiedUnsecuredLoan);
                parameters.AddWithValue("ModifiedPropertyFee", Entity.ModifiedPropertyFee);
                parameters.AddWithValue("ModifiedCreditCard", Entity.ModifiedCreditCard);
                parameters.AddWithValue("ProcessorID", Entity.ProcessorID);
                parameters.AddWithValue("ProceededDate", Entity.ProceededDate);

                int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveCustDebtOfCreditApproval, parameters);
                if (i >= 0)
                    return true;
                else
                    return false;
        }

        public bool SaveLoanApprovaltOfCreditApproval(LoanInfoView Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", Entity.AppId);
            parameters.AddWithValue("ApprovedTenor", Entity.ApprovedTenor);
            parameters.AddWithValue("ApprovedLoanSize", Entity.ApprovedLoanSize);
            parameters.AddWithValue("InterestRate", Entity.InterestRate);
            parameters.AddWithValue("Installment", Entity.Installment);
            parameters.AddWithValue("LoanCategory", Entity.LoanCategory);
            parameters.AddWithValue("Purpose1", Entity.Purpose1);
            parameters.AddWithValue("Purpose2", Entity.Purpose2);
            parameters.AddWithValue("Purpose3", Entity.Purpose3);
            parameters.AddWithValue("LoanDirection", Entity.LoanDirection);
            parameters.AddWithValue("SubLoanDirection", Entity.SubLoanDirection);
            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveLoanApprovaltOfCreditApproval, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }


        public CommonTResult<T_PL_EntrusPay> GetEntrusPayListByAppId(string appId)
        {
            CommonTResult<T_PL_EntrusPay> result = new CommonTResult<T_PL_EntrusPay>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(appId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_EntrusPay>(CommandType.StoredProcedure, SPNames.PL_GetEntrusPayListByAppId, new T_PL_EntrusPayMapper<T_PL_EntrusPay>(), parameters);
            return result;
        }


        public bool DeleteEntrusPayById(string entrusPayId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("EntrusPayId", entrusPayId);
            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteEntrusPayByEntrusPayID, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }


        public bool SaveEntrusPay(T_PL_EntrusPay Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("EntrusPayID", Entity.EntrusPayID);
            parameters.AddWithValue("PayeeName", Entity.PayeeName);
            parameters.AddWithValue("PayeeBankName", Entity.PayeeBankName);
            parameters.AddWithValue("PayeeSubBankName", Entity.PayeeSubBankName);
            parameters.AddWithValue("PayeeAccount", Entity.PayeeAccount);
            parameters.AddWithValue("PaymentAmount", Entity.PaymentAmount);
            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveEntrusPay, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }

        public bool UpdateCustIncome(string custId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustId", custId);
            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateCustIncome, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }

        public List<string> GetCustIDListByAppID(string appId)
        {
            var result = new  List<string>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetCustIDListByAppID, parameters);
            if (dtResult.Rows.Count > 0) { 
                for(var i=0;i<dtResult.Rows.Count;i++){
                  result.Add(dtResult.Rows[i][0].ToString());
               }
            }
            return result;
        }

        public CommonTResult<T_PL_BranchCompany> GetCompanyList(string companyType, string enterpriseName, string orgCode)
        {
            CommonTResult<T_PL_BranchCompany> result = new CommonTResult<T_PL_BranchCompany>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CompanyType", companyType);
            parameters.AddWithValue("EnterpriseName", enterpriseName);
            parameters.AddWithValue("OrgCode", orgCode);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_BranchCompany>(CommandType.StoredProcedure, SPNames.PL_GetCompanyList, new T_PL_BranchCompanyMapper<T_PL_BranchCompany>(), parameters);
            return result;
        }
    }
}
