﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Mvc.Models.Mappers;

namespace Citibank.RFLFE.PL.Dal.application
{
    
    public class NewProposalDao : AdoDaoSupport, INewProposalDao
    {
        public CommonTResult<ProductListView> GetNPProductList(string AppId)
        {
            CommonTResult<ProductListView> result = new CommonTResult<ProductListView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppId);            
             result.ResultList = AdoTemplate.QueryWithRowMapper<ProductListView>(CommandType.StoredProcedure, SPNames.PL_GetNPProductList, new ProductListViewMapper<ProductListView>(), parameters);
            return result;
        }

        public bool UpdateMortgagorInfo(T_PL_Mortgagors entity)
        {            
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("MortID", entity.MortID);
            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("Name", entity.Name);
            parameters.AddWithValue("PinyinName", entity.PinyinName);
            parameters.AddWithValue("Relation", entity.Relation);
            parameters.AddWithValue("IDNo", entity.IDNo);
            parameters.AddWithValue("Telephone", entity.Telephone);
            parameters.AddWithValue("MobileNumber", entity.MobileNumber);
            parameters.AddWithValue("MarriageStatus", entity.MarriageStatus);
            parameters.AddWithValue("SpouseName", entity.SpouseName);
            parameters.AddWithValue("SpousePinyinName", entity.SpousePinyinName);
            parameters.AddWithValue("SpouseIDNo", entity.SpouseIDNo);
            parameters.AddWithValue("SpouseTelephone", entity.SpouseTelephone);
            parameters.AddWithValue("SpouseMobile", entity.SpouseMobile);
            parameters.AddWithValue("HouseProvince", entity.HouseProvince);
            parameters.AddWithValue("HouseCity", entity.HouseCity);
            parameters.AddWithValue("HouseDistrict", entity.HouseDistrict);
            parameters.AddWithValue("HouseStreet", entity.HouseStreet);
            parameters.AddWithValue("HousePostCode", entity.HousePostCode);

           // int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateMortgagorInfo,parameters);

            return true;
        }

        public CommonTResult<T_PL_LTVFactors> GetLTVFactors(string AppId)
        {
            CommonTResult<T_PL_LTVFactors> result = new CommonTResult<T_PL_LTVFactors>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_LTVFactors>(CommandType.StoredProcedure, SPNames.PL_GetLTVFactors, new T_PL_LTVFactorsMapper<T_PL_LTVFactors>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_Collateral> GetCustCollateralInfoByAppId(string AppId)
        {
            CommonTResult<T_PL_Collateral> result = new CommonTResult<T_PL_Collateral>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(AppId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Collateral>(CommandType.StoredProcedure, SPNames.PL_GetCollateralByAppId, new T_PL_CollateralMapper<T_PL_Collateral>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_Customers> GetCustBasicInfo(string AppId)
        {
            CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(AppId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(CommandType.StoredProcedure, SPNames.PL_GetCustomerByAppId, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            return result;
        }

        CommonTResult<T_PL_Customers> INewProposalDao.GetCustInfo(string AppId)
        {
            CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(AppId));
            parameters.AddWithValue("Relations", ESysParameter.OtherApplicationRelations.ToString("d"));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(CommandType.StoredProcedure, SPNames.PL_GetAppCheckerCustInfo, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            return result;
        }

        public bool IsSystemDecided(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("Count", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(
                CommandType.StoredProcedure, SPNames.PL_CheckIsDoNewProposalSystemDecided, parameters);
            return parameters["@Count"].Value.ToString() == "0" ? false : true;
        }

        public bool CheckSingleBo(string appId, string borrowType)
        {
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddWithValue("BorrowType", borrowType);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_SystemDecideVerifyInfo, parameters);
            if (ds.Tables[0].Rows.Count != 0)
            {
                for (var i = 0; i < ds.Tables[0].Rows[0].ItemArray.Length; i++)
                {
                    if (ds.Tables[0].Rows[0].ItemArray[i].Equals("") || ds.Tables[0].Rows[0].ItemArray[i] == null)
                    {
                        return false;
                    }
                }
                for (var i = 0; i < ds.Tables[1].Rows[0].ItemArray.Length; i++)
                {
                    if (i == 1 || i == 8 || i == 13)
                    {
                        if (ds.Tables[1].Rows[0].ItemArray[i - 1].Equals("BJ") || ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "TJ" || ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "CQ" || ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "SH" ||
                            ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "AMT" || ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "TW" || ds.Tables[1].Rows[0].ItemArray[i - 1].ToString() == "XGT")
                        {
                            if (ds.Tables[1].Rows[0].ItemArray[i].ToString() != "" && ds.Tables[1].Rows[0].ItemArray[i] != null)
                            {
                                return false;
                            }
                        }
                    }
                    else if (ds.Tables[1].Rows[0].ItemArray[i].ToString() == "" || ds.Tables[1].Rows[0].ItemArray[i] == null)
                    {
                        return false;
                    }
                }
                return true;
            }
            else
            {
                return false;
            }
        }

        public CommonTResult<DocumentItem> GetDocumentList(string strCustType, string strProdID, string custSegment)
        {
            CommonTResult<DocumentItem> result = new CommonTResult<DocumentItem>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustType", strCustType);
            parameters.AddWithValue("ProdID", strProdID);
            parameters.AddWithValue("CustSegment", custSegment);
            result.ResultList = AdoTemplate.QueryWithRowMapper<DocumentItem>(CommandType.StoredProcedure, SPNames.PL_GetDocumentList, new DocumentItemMapper<DocumentItem>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_Customers> GetPreviouseCasesByIDNo(string IdNo, string borrowType, string appNo)
        { 
            CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("IDNo", IdNo);
            parameters.AddWithValue("BorrowType",borrowType);
            parameters.AddWithValue("AppNo", appNo);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(
                CommandType.StoredProcedure, SPNames.PL_GetPreviouseCasesByIDNo, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            return result;
        }

        public bool CopyCoLoanerInfoByAppID(string oldAppId, string newAppId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("newAppID", newAppId);
            parameters.AddWithValue("oldAppID", oldAppId);
            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_CopyCoLoanerInfoByAppID, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }

        public DataSet GetMergerSourceData(Guid appID)
        {
            throw new NotImplementedException();
        }

        public DataTable GetPrintApplicationFormDataSource(string appId)
        {  
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            DataTable result = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetPrintApplicationFormDataSource, parameters);
            return result;
        }

        public bool CopyFinanceInfoToNextStage(string appId, string currentStage, string nextStage)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("CurrentStage", currentStage);
            parameters.AddWithValue("NextStage", nextStage);
            int i = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_CopyFinanceInfoToNextStage, parameters);
            if (i >= 0)
                return true;
            else
                return false;
        }
    }
}
