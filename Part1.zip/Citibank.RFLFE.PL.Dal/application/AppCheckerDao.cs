﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.application
{
    public class AppCheckerDao : AdoDaoSupport, IAppCheckerDao
    {
        public CommonTResult<T_PL_Customers> GetCustDetailInfoByCustId(string CustId)
        {
            CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustId", new Guid(CustId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(CommandType.StoredProcedure, SPNames.PL_GetCustDetailInfoByCustId, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            CommonTResult<T_PL_Customers> familyMembersResult = new CommonTResult<T_PL_Customers>();
            return result;
        }

        public CommonTResult<T_PL_Customers> GetDocListRoles(string appId)
        {
            CommonTResult<T_PL_Customers> result = new CommonTResult<T_PL_Customers>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appId", new Guid(appId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(CommandType.StoredProcedure, SPNames.PL_AppCheckerGetDocListRoles, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            CommonTResult<T_PL_Customers> familyMembersResult = new CommonTResult<T_PL_Customers>();
            return result;
        }

        public Boolean SaveReviewDocList(string insertStr, string updateStr)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("insertStr", insertStr);
            parameters.AddWithValue("updateStr", updateStr);
            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_SaveAppCheckerReviewDocList, parameters);
            return (int)parameters["@Result"].Value<=0?false:true;
        }
    }
}
