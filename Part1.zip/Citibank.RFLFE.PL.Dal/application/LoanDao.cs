﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Framework;
using System.Reflection;

namespace Citibank.RFLFE.PL.Dal.application
{
    public class LoanDao : AdoDaoSupport, ILoanDao
    {
        Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);

        public T_PL_Loan GetLoanByAppId(Guid appID) 
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appID);

            return AdoTemplate.QueryWithRowMapper<T_PL_Loan>(
                CommandType.StoredProcedure, SPNames.PL_GetLoanByAppId, new T_PL_LoanMapper<T_PL_Loan>(), parameters).FirstOrDefault();
        }

        public CommonTResult<T_PL_LTVFactors> GetLTVFactors(string AppId, string prodId)
        {
            CommonTResult<T_PL_LTVFactors> result = new CommonTResult<T_PL_LTVFactors>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppId);
            parameters.AddWithValue("ProdID", prodId);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_LTVFactors>(CommandType.StoredProcedure, SPNames.PL_GetLTVFactors, new T_PL_LTVFactorsMapper<T_PL_LTVFactors>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_LTVParam> GetLTVParams(int prodId, string orgCode, string appId)
        {
            CommonTResult<T_PL_LTVParam> result = new CommonTResult<T_PL_LTVParam>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", prodId);
            parameters.AddWithValue("OrgCode", orgCode);
            parameters.AddWithValue("AppID", appId);            
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_LTVParam>(CommandType.StoredProcedure, SPNames.PL_GetLTVParams, new T_PL_LTVParamMapper<T_PL_LTVParam>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_Collateral> GetCustCollateralInfoByAppId(string AppId)
        {
            CommonTResult<T_PL_Collateral> result = new CommonTResult<T_PL_Collateral>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(AppId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Collateral>(CommandType.StoredProcedure, SPNames.PL_GetCollateralByAppId, new T_PL_CollateralMapper<T_PL_Collateral>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_SellerInfo> GetVendorListByAppId(string AppId)
        {
            CommonTResult<T_PL_SellerInfo> result = new CommonTResult<T_PL_SellerInfo>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(AppId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_SellerInfo>(CommandType.StoredProcedure, SPNames.PL_GetVendorListByAppId, new T_PL_SellerInfoMapper<T_PL_SellerInfo>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_LoanIndustry> GetLoanPurposeByAppId(string AppId)
        {
            CommonTResult<T_PL_LoanIndustry> result = new CommonTResult<T_PL_LoanIndustry>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(AppId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_LoanIndustry>(CommandType.StoredProcedure, SPNames.PL_GetLoanPurpose, new T_PL_LoanIndustryMapper<T_PL_LoanIndustry>(), parameters);
            return result;
        }

        public int SaveLoanByAppId(T_PL_Loan entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", entity.AppID);
            parameters.AddWithValue("ProdID", entity.ProdID);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure,
                SPNames.PL_SaveLoanByAppId, parameters);
            return result;
        }

        public bool SaveVendor(T_PL_SellerInfo Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("Gender", Entity.Gender);
            parameters.AddWithValue("IDNo", Entity.IDNo);
            parameters.AddWithValue("Name", Entity.Name);
            parameters.AddWithValue("PinyinName", Entity.PinyinName);
            parameters.AddWithValue("SellerID", Entity.SellerID);

            int iresult = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveVendor, parameters);
            if (iresult >= 0)
                return true;
            else
                return false;
        }

        public bool RemoveVendor(string SellerID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("SellerID", SellerID);

            int iresult = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RemoveVendor, parameters);
            if (iresult >= 0)
                return true;
            else
                return false;
        }


        public bool SaveLTVFactors(string str,string appId)
        {
            CommonTResult<T_PL_LTVFactors> result = new CommonTResult<T_PL_LTVFactors>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DataList", str);
            parameters.AddWithValue("AppId", new Guid(appId));
            int iresult = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveLTVFactors2, parameters);
            if (iresult >= 0)
                return true;
            else
                return false; 
        }

        public List<string> GetHasPropertyandPropertyTypeByAppId(string appId)
        {
            List<string> list =new List<string>();
            CommonTResult<T_PL_Collateral> result = new CommonTResult<T_PL_Collateral>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Collateral>(CommandType.StoredProcedure, SPNames.PL_GetHasPropertyandPropertyTypeByAppId, new T_PL_CollateralMapper<T_PL_Collateral>(), parameters);
            if (result.ResultList.FirstOrDefault()!=null) {
                list.Add(result.ResultList.FirstOrDefault().HasProperty);
                list.Add(result.ResultList.FirstOrDefault().PropertyType);
            }
            return list;
        }

        public bool SaveLoanPurpose(T_PL_LoanIndustry Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("Category", Entity.Category);
            parameters.AddWithValue("Purpose1", Entity.Purpose1);
            parameters.AddWithValue("Purpose2", Entity.Purpose2);
            parameters.AddWithValue("Purpose3", Entity.Purpose3);
            parameters.AddWithValue("MainIndustry", Entity.MainIndustry);
            parameters.AddWithValue("SubIndustry", Entity.SubIndustry);
            parameters.AddWithValue("DecorationRelation", Entity.DecorationRelation);
            //parameters.AddWithValue("IsPropertySelf", Entity.IsPropertySelf=="是"? 1 : 0);
            parameters.AddWithValue("IsPropertySelf", Entity.IsPropertySelf);
            parameters.AddWithValue("DecorationAddress", Entity.DecorationAddress);
            parameters.AddWithValue("DecorationPropertyValue1", Entity.DecorationPropertyValue1);
            parameters.AddWithValue("DecorationPropertyValue2", Entity.DecorationPropertyValue2);
            parameters.AddWithValue("OtherPurpose", Entity.OtherPurpose);
            parameters.AddWithValue("SourceCode", Entity.SourceCode);
            parameters.AddWithValue("AgentCode", Entity.AgentCode);
            parameters.AddWithValue("WhereKnow", Entity.WhereKnow);
            parameters.AddWithValue("PayType", Entity.PayType);
            parameters.AddWithValue("PayeeName", Entity.PayeeName);
            parameters.AddWithValue("PayeeBankName", Entity.PayeeBankName);
            parameters.AddWithValue("PayeeSubBankName", Entity.PayeeSubBankName);
            parameters.AddWithValue("PayeeAccount", Entity.PayeeAccount);
            parameters.AddWithValue("DeditName", Entity.DebitName);
            parameters.AddWithValue("DeditRemarks", Entity.DeditRemarks);
            parameters.AddWithValue("PaymentAmount", Entity.PaymentAmount);
            parameters.AddWithValue("DeditBankName", Entity.DeditBankName);
            parameters.AddWithValue("DeditSubBankName", Entity.DeditSubBankName);
            parameters.AddWithValue("DeditAccount", Entity.DeditAccount);
            parameters.AddWithValue("DeditReason", Entity.DeditReason);
            parameters.AddWithValue("ServiceID", Entity.ServiceID);

            int iresult = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveLoanPurpose, parameters);
            if (iresult >= 0)
                return true;
            else
                return false;
        }

        public bool SaveSelfPay(T_PL_LoanIndustry Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("DeditName", Entity.DebitName);
            parameters.AddWithValue("DeditRemarks", Entity.DeditRemarks);
            parameters.AddWithValue("PaymentAmount", Entity.PaymentAmount);
            parameters.AddWithValue("DeditBankName", Entity.DeditBankName);
            parameters.AddWithValue("DeditSubBankName", Entity.DeditSubBankName);
            parameters.AddWithValue("DeditAccount", Entity.DeditAccount);
            parameters.AddWithValue("DeditReason", Entity.DeditReason);

            int iresult = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveSelfPay, parameters);
            if (iresult >= 0)
                return true;
            else
                return false;
        }

        public bool SaveCustCollateralInfo(T_PL_Collateral Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", Entity.AppID);
            parameters.AddWithValue("HasProperty", Entity.HasProperty);
            parameters.AddWithValue("CollateralType", Entity.CollateralType);
            parameters.AddWithValue("PropertyType", Entity.PropertyType);
            parameters.AddWithValue("HouseValue", Entity.HouseValue);
            parameters.AddWithValue("HouseAge", Entity.HouseAge);
            parameters.AddWithValue("BaseLTV", Entity.BaseLTV);
            parameters.AddWithValue("ReducedLTV", Entity.ReducedLTV);
            parameters.AddWithValue("MaxAllowedLTV", Entity.MaxAllowedLTV);
            parameters.AddWithValue("ResidentialType", Entity.ResidentialType);
            parameters.AddWithValue("Region", Entity.Region);
            parameters.AddWithValue("Address", Entity.Address);
            parameters.AddWithValue("CommunityName", Entity.CommunityName);
            parameters.AddWithValue("PropertyPermits", Entity.PropertyPermits);
            parameters.AddWithValue("LandArea", Entity.LandArea);
            parameters.AddWithValue("RightNoOfLand", Entity.RightNoOfLand);
            parameters.AddWithValue("FloorSpace", Entity.FloorSpace);
            parameters.AddWithValue("TotalPrice", Entity.TotalPrice);
            parameters.AddWithValue("RightTypeOfLand", Entity.RightTypeOfLand);
            parameters.AddWithValue("CompletedDate", Entity.CompletedDate.Trim());
            parameters.AddWithValue("LandUsingYear", Entity.LandUsingYear);
            parameters.AddWithValue("CurrentStatus", Entity.CurrentStatus);
            parameters.AddWithValue("RentRemainingDate", Entity.RentRemainingDate);
            parameters.AddWithValue("FirstHouseOp", Entity.FirstHouseOp);
            parameters.AddWithValue("HouseArea", Entity.HouseArea);
            parameters.AddWithValue("CarArea", Entity.CarArea);
            parameters.AddWithValue("GarageArea", Entity.GarageArea);
            parameters.AddWithValue("MorgageCount", Entity.MorgageCount);
            parameters.AddWithValue("IsPartialMortgage", Entity.IsImprovedHouse == "on" ? 1 : 0);
            parameters.AddWithValue("IsImprovedHouse", Entity.IsImprovedHouse == "on" ? 1 : 0);
            parameters.AddWithValue("FirstHouseArea", string.IsNullOrEmpty(Entity.FirstHouseArea) ? 0 : Decimal.Parse(Entity.FirstHouseArea));
            parameters.AddWithValue("FirstPayAmount", string.IsNullOrEmpty(Entity.FirstPayAmount) ? 0 : Int32.Parse(Entity.FirstPayAmount));
            parameters.AddWithValue("FirstPayPercent", string.IsNullOrEmpty(Entity.FirstPayPercent) ? 0 : Decimal.Parse(Entity.FirstPayPercent));

            int iresult = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveCustCollateralInfo, parameters);
            if (iresult >= 0)
                return true;
            else
                return false;
        }

        public List<String> GetBeforeAndCurrentRateByAppId(string appId)
        {
            var list = new List<String>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddOut("BeforeRateOut", DbType.String, 50);
            parameters.AddOut("CurrentRateOut", DbType.String, 50);
            AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetBeforeAndCurrentRateByAppId, parameters);
            list.Add(parameters["@BeforeRateOut"].Value.ToString());
            list.Add(parameters["@CurrentRateOut"].Value.ToString());
            return list;
        }

        public Boolean UpdateRateException(string appId, string result)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("Result", result);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateRateException, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public string GetSalesRate(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("appId", appId);
            parameters.AddOut("InterestRate", DbType.String, 50);
            AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetSalesRate, parameters);
            return parameters["@InterestRate"].Value.ToString();
        }

        public Boolean RefreshRate(string appId, string rate)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("Rate", rate);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RefreshRate, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool DeleteMortgatarbyAppID(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteMortgatarbyAppID, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool DeleteCollateralbyAppID(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteCollateralbyAppID, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public T_PL_Loan GetNewCurrLoanForCreditApproval(string appId)
        {
            T_PL_Loan loan = new T_PL_Loan();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetNewCurrLoanForPrescreen, parameters);
            loan.MaxLoanSize = dtResult.Rows[0][0].ToString() != "" ? Decimal.Parse(dtResult.Rows[0][0].ToString()) : 0;
            loan.ApprovedTenor = dtResult.Rows[0][1].ToString();
            var tenor = Convert.ToDecimal(dtResult.Rows[0][1].ToString());
            loan.InterestRate = (dtResult.Rows[0][2].ToString() != "" ? Decimal.Parse(dtResult.Rows[0][2].ToString()) : 0)/100;
            loan.AvailableUnsecuredSize = dtResult.Rows[0][3].ToString() != "" ? Decimal.Parse(dtResult.Rows[0][3].ToString()) : 0;
            loan.Installment = dtResult.Rows[0][4].ToString() != "" ? Decimal.Parse(dtResult.Rows[0][4].ToString()) : 0;
            decimal currentDebt = 0;
            if (loan.MaxLoanSize > 0 && tenor > 0 & loan.InterestRate > 0)
                log.DebugLog("begin print currentDebt: " + currentDebt, "GetNewCurrLoanForCreditApproval");
            currentDebt = loan.MaxLoanSize * (loan.InterestRate / 12 * DecimalPow((1 + loan.InterestRate / 12), tenor) / (DecimalPow((1 + loan.InterestRate / 12), tenor) - 1));
                log.DebugLog("begin print currentDebt:" + +currentDebt, "GetNewCurrLoanForCreditApproval");
            loan.CurrDebt = currentDebt;
            loan.ApprovedLoanSize = dtResult.Rows[0][5].ToString() != "" ? Decimal.Parse(dtResult.Rows[0][5].ToString()) : 0;
            return loan;
        }

        private decimal DecimalPow(decimal x, decimal y)
        {
            decimal result = 1.0M;

            for (int i = 0; i < y; i++)
            {
                result = decimal.Multiply(result, x);
            }

            return result;
        }

        public T_PL_Loan getLoanParametersByAppId(string AppId)
        {
            CommonTResult<T_PL_Loan> result = new CommonTResult<T_PL_Loan>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(AppId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_Loan>(CommandType.StoredProcedure, SPNames.PL_GetLoanParametersByAppId, new T_PL_LoanMapper<T_PL_Loan>(), parameters);
            if (result.ResultList != null) {
                return result.ResultList.FirstOrDefault();
            }
            else{
                return new T_PL_Loan();
            }
        }
        
        public bool SaveLoanParameters(string appId, string requestLoan, string monthlyMaxRefund, string tenor, string rate)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("RequestLoan", requestLoan);
            parameters.AddWithValue("MonthlyMaxRefund", monthlyMaxRefund);
            parameters.AddWithValue("Tenor", tenor);
            parameters.AddWithValue("Rate", rate==""?0:Decimal.Parse(rate));
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveLoanParameters, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public DataSet ExportDisbursementFileByAppId(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_ExportDisbursementFileByAppId, parameters);
            return ds;
        }

        public string GetCollateralTypeByAppId(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddOut("CollateralType", DbType.String, 50);
            AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetCollateralTypeByAppId, parameters);
            return parameters["@CollateralType"].Value.ToString();
        }

        public string GetMortgageCountByAppId(string appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddOut("MortgageCount", DbType.String, 50);
            AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetMortgageCountByAppId, parameters);
            return parameters["@MortgageCount"].Value.ToString();
        }

        public bool SaveLoanApproval(T_PL_LoanApproval Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", Entity.AppID);
            parameters.AddWithValue("StageID", Entity.StageID);
            parameters.AddWithValue("InterestRate", Entity.InterestRate);
            parameters.AddWithValue("ApprovedLoanSize", Entity.ApprovedLoanSize);
            parameters.AddWithValue("ApprovedLoanTenor", Entity.ApprovedLoanTenor);
            parameters.AddWithValue("RefreshedRate", Entity.RefreshedRate);
            parameters.AddWithValue("HomeOtherIncome", Entity.HomeOtherIncome);
            parameters.AddWithValue("HomeOtherDebt", Entity.HomeOtherDebt);
            parameters.AddWithValue("HomeMonthly", Entity.HomeMonthly);
            parameters.AddWithValue("ProcessorID", Entity.ProcessorID);
            parameters.AddWithValue("ProceededDate", Entity.ProceededDate);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveLoanApproval, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }


        public bool UpdateLoanInfoAndInsertRecordIntoLoanApproval(string appId,string processorId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);
            parameters.AddWithValue("ProcessorID", processorId);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateLoanInfoAndInsertRecordIntoLoanApproval, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool IsExistEntrusPay(string appId)
        {
            CommonTResult<T_PL_EntrusPay> result = new CommonTResult<T_PL_EntrusPay>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", new Guid(appId));
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_EntrusPay>(CommandType.StoredProcedure, SPNames.PL_GetEntrusPayListByAppId, new T_PL_EntrusPayMapper<T_PL_EntrusPay>(), parameters);
            if (result.ResultList.Count > 0) {
                return true; 
            }
            return false;
        }
    }
}
