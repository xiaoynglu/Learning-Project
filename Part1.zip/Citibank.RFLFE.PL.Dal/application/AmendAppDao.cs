﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.application
{
    public class AmendAppDao : AdoDaoSupport, IAmendAppDao
    {
        public Dictionary<string[], string> GetRACMapping(string collateralType)
        {
            var result = new Dictionary<string[], string>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CollateralType", collateralType);
            DataTable dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetAmendAppRACMapping, parameters);           
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow Dr in dt.Rows) {
                    result.Add(new string[] { Dr["RACPRODID"].ToString(), Dr["PRODRULECODE"].ToString() }, Convert.ToString(Dr["PRODNAME"]));
                }
            }
            return result;
        }
    }
}
