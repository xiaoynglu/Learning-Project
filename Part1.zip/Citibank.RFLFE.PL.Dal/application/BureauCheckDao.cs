﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.application
{
    public class BureauCheckDao : AdoDaoSupport, IBureauCheckDao
    {
        /// <summary>
        /// Get bureau personal info by id number and app id
        /// </summary>
        /// <param name="ID_NUMBER">id number</param>
        /// <param name="IMPORT_DATE">import date</param>
        /// <returns>T_PL_PBOC_LoanDetail entity</returns>
        public CommonTResult<T_PL_BureauInfo> QueryPersonalInfoByIdAndAppId(string AppId, string ID_NUMBER)
        {
            CommonTResult<T_PL_BureauInfo> result = new CommonTResult<T_PL_BureauInfo>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ID_NUMBER", ID_NUMBER);
            parameters.AddWithValue("AppID", AppId);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_BureauInfo>(
                CommandType.StoredProcedure, SPNames.PL_QueryPersonalInfoByIdAndAppId, new BaseMapper<T_PL_BureauInfo>(), parameters);
            result.ResultCount = result.ResultList.Count;
            result.IsSuccess = true;
            return result;
        }


        /// <summary>
        /// Get bureau loan details by id number and import date
        /// </summary>
        /// <param name="ID_NUMBER">id number</param>
        /// <param name="IMPORT_DATE">import date</param>
        /// <returns>T_PL_PBOC_LoanDetail entity</returns>
        public CommonTResult<T_PL_PBOC_LoanDetail> GetBureauLoanDetails(string ID_NUMBER, string IMPORT_DATE, int start, int limit)
        {
            CommonTResult<T_PL_PBOC_LoanDetail> result = new CommonTResult<T_PL_PBOC_LoanDetail>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ID_NUMBER", ID_NUMBER);
            parameters.AddWithValue("IMPORT_DATE", IMPORT_DATE);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_PBOC_LoanDetail>(
                CommandType.StoredProcedure, SPNames.PL_GetBureauLoanDetails, new BaseMapper<T_PL_PBOC_LoanDetail>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            result.IsSuccess = true;                            
            return result;
        }

        /// <summary>
        /// Get bureau card details by id number and import date
        /// </summary>
        /// <param name="ID_NUMBER">id number</param>
        /// <param name="IMPORT_DATE">import date</param>
        /// <returns>T_PL_PBOC_CreditCardDetail entity</returns>
        public CommonTResult<T_PL_PBOC_CreditCardDetail> GetBureauCardDetails(string ID_NUMBER, string IMPORT_DATE, int start, int limit)
        {
            CommonTResult<T_PL_PBOC_CreditCardDetail> result = new CommonTResult<T_PL_PBOC_CreditCardDetail>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ID_NUMBER", ID_NUMBER);
            parameters.AddWithValue("IMPORT_DATE", IMPORT_DATE);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_PBOC_CreditCardDetail>(
                CommandType.StoredProcedure, SPNames.PL_GetBureauCardDetails, new BaseMapper<T_PL_PBOC_CreditCardDetail>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            result.IsSuccess = true;
            return result;
        }

        /// <summary>
        /// Get cust info by app id
        /// </summary>
        /// <param name="AppID">AppID</param>
        /// <returns>T_PL_BureauCustInfo entity</returns>
        public CommonTResult<T_PL_BureauCustInfo> GetCustInfoByAppID(string AppID)
        {
            CommonTResult<T_PL_BureauCustInfo> result = new CommonTResult<T_PL_BureauCustInfo>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppID);
            parameters.AddOut("Count", DbType.Int32);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_BureauCustInfo>(
                CommandType.StoredProcedure, SPNames.PL_GetCustInfoByAppID, new BaseMapper<T_PL_BureauCustInfo>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            result.IsSuccess = true;
            return result;
        }

        /// <summary>
        /// Get HTML file name to downloader the html file: AppID + "_" + CertType + "_" + ID_NUMBER + ".htm"
        /// </summary>
        /// <param name="AppID">AppID</param>
        /// <returns>T_PL_PBOC_PersonalInfo entity</returns>
        public CommonTResult<T_PL_PBOC_PersonalInfo> GetBureauHTMLFileName(string AppID, string ID_NUMBER)
        {
            CommonTResult<T_PL_PBOC_PersonalInfo> result = new CommonTResult<T_PL_PBOC_PersonalInfo>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppID);
            parameters.AddWithValue("ID_NUMBER", ID_NUMBER);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_PBOC_PersonalInfo>(
                CommandType.StoredProcedure, SPNames.PL_GetBureauHTMLFileName, new BaseMapper<T_PL_PBOC_PersonalInfo>(), parameters);
            result.ResultCount = result.ResultList.Count;
            result.IsSuccess = true;
            return result;
        }

        /// <summary>
        /// Get lastest record from T_PL_PBOC_TotalInfo UNION PersonalInfo
        /// </summary>
        /// <param name="AppID">AppID</param>
        /// <returns>T_PL_BureauInfo entity</returns>
        public CommonTResult<T_PL_BureauInfo> RefreshBureauBasicInfo(string AppID, string ID_NUMBER)
        {
            CommonTResult<T_PL_BureauInfo> result = new CommonTResult<T_PL_BureauInfo>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", AppID);
            parameters.AddWithValue("ID_NUMBER", ID_NUMBER);
            parameters.AddOut("ret", DbType.Int32);
            parameters.AddOut("Message", DbType.String, 100);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_BureauInfo>(
                CommandType.StoredProcedure, SPNames.PL_RefreshBureauBasicInfo, new BaseMapper<T_PL_BureauInfo>(), parameters);
            result.ResultCount = result.ResultList.Count;
            result.IsSuccess = true;
            if ((int)parameters["@ret"].Value < 0)
            {
                result.IsSuccess = false;
                result.Message = parameters["@Message"].Value.ToString();
            }

            return result;
        }

        /// <summary>
        /// save updated bureau info
        /// </summary>
        /// <param name="T_PL_BureauInfo"></param>
        /// <returns>insert result</returns>
        public CommonResult SaveBureauBasicInfo(T_PL_BureauInfo info)
        {
            CommonResult result = new CommonResult();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", info.AppId);
            parameters.AddWithValue("ID_NUMBER", info.ID_NUMBER);
            parameters.AddWithValue("OLDEST_MOB", info.OLDEST_MOB_Edit);
            parameters.AddWithValue("TOTAL_CHARGE_OFF", info.TOTAL_CHARGE_OFF_Edit);
            parameters.AddWithValue("TOTAL_NUMBER_LOAN_UNSECURED", info.TOTAL_NUMBER_LOAN_UNSECURED_Edit);
            parameters.AddWithValue("COUNT_OUTSTANDING_MORTGAGES", info.COUNT_OUTSTANDING_MORTGAGES_Edit);
            parameters.AddWithValue("NUMBER_OF_M1_IN_LAST_6_MONTHS", info.NUMBER_OF_M1_IN_LAST_6_MONTHS_Edit);
            parameters.AddWithValue("NUMBER_CURRENT_M1", info.NUMBER_CURRENT_M1_Edit);
            parameters.AddWithValue("NUMBER_OF_M2_IN_LAST_6_MONTHS", info.NUMBER_OF_M2_IN_LAST_6_MONTHS_Edit);
            parameters.AddWithValue("NUMBER_CURRENT_M2", info.NUMBER_CURRENT_M2_Edit);
            parameters.AddWithValue("NUMBER_OF_M2_IN_LAST_12_MONTHS", info.NUMBER_OF_M2_IN_LAST_12_MONTHS_Edit);
            parameters.AddWithValue("NUMBER_OF_M3_IN_LAST_12_MONTHS", info.NUMBER_OF_M3_IN_LAST_12_MONTHS_Edit);
            parameters.AddWithValue("NUMBER_OF_M2_IN_LAST_24_MONTHS", info.NUMBER_OF_M2_IN_LAST_24_MONTHS_Edit);
            parameters.AddWithValue("NUMBER_OF_M3_IN_LAST_24_MONTHS", info.NUMBER_OF_M3_IN_LAST_24_MONTHS_Edit);
            parameters.AddWithValue("TOTAL_NUMBER_OF_ENQUIRY3", info.TOTAL_NUMBER_OF_ENQUIRY3_Edit);
            parameters.AddWithValue("BankCard_Credit_Utilization", info.BankCard_Credit_Utilization_Edit);
            parameters.AddWithValue("LitigationRecord", info.LitigationRecord);
            parameters.AddWithValue("LoanGrade", info.LoanGrade);
            parameters.AddWithValue("ModiBy", info.ModiBy);

            int Count = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveBureauBasicInfo, parameters);

            result.IsSuccess = Count > 0 ? true : false;
            result.Message = Count > 0 ? "保存成功！" : "保存失败！";

            return result;
        }

        public CommonResult UpdateBureauQueryStatus(List<T_PL_QueryList> custInfos)
        {
            CommonResult result = new CommonResult();            

            try
            {
                foreach (T_PL_QueryList list in custInfos)
                {
                    IDbParameters parameters = AdoTemplate.CreateDbParameters();
                    parameters.AddWithValue("AppID", list.AppID);
                    parameters.AddWithValue("IDNo", list.IDNo);
                    parameters.AddWithValue("FullName", list.FullName);
                    AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateBureauQueryStatus, parameters);
                }
                result.IsSuccess = true;
                result.Message = "更新成功！";
            }
            catch (Exception ex)
            {
                result.IsSuccess = false;
                result.Message = "更新失败！" + ex.Message;
            }
            return result;
        }
    }
}
