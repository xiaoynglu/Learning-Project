﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.application
{
    public class ExceptionApproveDao : AdoDaoSupport, IExceptionApproveDao
    {

        public bool UpdatePricingDeviatedAndRate(string appId, string pricingDeviated, string rate)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppId", appId);
            parameters.AddWithValue("PricingDeviated", pricingDeviated);
            parameters.AddWithValue("Rate", rate);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ExceptionApprove_UpdatePricingDeviatedAndRate, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }
    }
}
