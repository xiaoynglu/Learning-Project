﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.print
{
    public class PrintDao : AdoDaoSupport, IPrintDao
    {
        public CommonTResult<T_PL_MergeDefination> GetMergeDefinationByJobType(string FileType)
        {
            CommonTResult<T_PL_MergeDefination> fileDef = new CommonTResult<T_PL_MergeDefination>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("FileType", FileType);
            fileDef.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_MergeDefination>(CommandType.StoredProcedure, SPNames.PL_GetMergeDefinationByJobType, new BaseMapper<T_PL_MergeDefination>(), parameters);
            return fileDef;
        }

        public DataTable GetPrintCondtion(string FileType)
        {
            DataTable dt = new DataTable();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("FileType", FileType);
            dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetPrintCondtion, parameters);
            return dt;
        }

        public DataTable GetPrintCondtionsTable(string FileType)
        {
            DataTable dt = new DataTable();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("FileType", FileType);
            dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetPrintCondtions, parameters);
            return dt;
        }

        public void UpLoanMergeStatus(string FileType, string BranchCode, string ImportDate)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("FileType", FileType);
            parameters.AddWithValue("BranchCode", BranchCode);
            parameters.AddWithValue("ImportDate", ImportDate);
            AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpLoanMergeStatus, parameters);
        }

        public DataTable GetSourceDate(string FileType)
        {
            DataTable dt = new DataTable();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("FileType", FileType);
            dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetPrintSourceByFileType, parameters);
            return dt;
        }
    }
}
