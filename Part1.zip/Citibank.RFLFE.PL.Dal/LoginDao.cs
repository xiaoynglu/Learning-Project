﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using System.Configuration;
using System.DirectoryServices;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;


namespace Citibank.RFLFE.PL.Dal
{
    public class LoginDao : AdoDaoSupport, ILoginDao
    {
        public T_Sys_Users GetUserInfo(string soeID)
        {
            IList<T_Sys_Users>  Result2;
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("SoeID", soeID);
            parameters.AddWithValue("Type", 1);
            Result2 = AdoTemplate.QueryWithRowMapper<T_Sys_Users>(CommandType.StoredProcedure, SPNames.PL_GetUserRoleBySoeID, new T_Sys_UsersMapper<T_Sys_Users>(), parameters);
            if (Result2.Count > 0) {
             return   Result2.FirstOrDefault();
            }
            return null;
        }
        public int GetUserRole(string SoeID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("SoeID", SoeID);
            parameters.AddWithValue("Type", 2);
            object result = AdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetUserRoleBySoeID, parameters);
            return Convert.ToInt32(result);
        }

        public UserInfo GetUserInfoByEntity(UserInfo oUserInfo)
        {
            string Sql = @"sp_CitiSafeLogin";

            List<SqlParameter> Params = new List<SqlParameter>();

            Params.Add(new SqlParameter("@SoeId", oUserInfo.SoeId));
            Params.Add(new SqlParameter("@GEID", oUserInfo.GEID));
            Params.Add(new SqlParameter("@Agent", oUserInfo.AgentCode));
            Params.Add(new SqlParameter("@Branch", oUserInfo.BranchCode));
            Params.Add(new SqlParameter("@Phone", oUserInfo.Phone));
            Params.Add(new SqlParameter("@EnName", oUserInfo.EnName));
            Params.Add(new SqlParameter("@Role", oUserInfo.CitiSafeRole));

            DataTable dt = SqlHelper.ExecuteDatasetSpDefault(Sql, Params.ToArray()).Tables[0];

            if (dt != null && dt.Rows.Count > 0)
            {
                oUserInfo.CnName = dt.Rows[0]["CnName"].ToString();
                oUserInfo.OrgCode = dt.Rows[0]["OrgCode"].ToString();
                oUserInfo.RoleType = Convert.ToInt32(dt.Rows[0]["RoleType"]);
                oUserInfo.RoleName = Convert.ToString(dt.Rows[0]["RoleName"]);
                oUserInfo.Location = Convert.ToString(dt.Rows[0]["Location"]);
            }

            //根据用户的SoeId获取页面信息                                 
            //oUserInfo.UserPage = GetRolePage(oUserInfo.RoleType);

            return oUserInfo;
        }

        public IList<MenuTree> GetMenu(int RoleType)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RoleType", RoleType);
            return AdoTemplate.QueryWithRowMapper<MenuTree>(CommandType.StoredProcedure, SPNames.PL_GetMenuTree, new MenuTreeMapper<MenuTree>(), parameters);
        }

        public bool login(string soeid, string logonStatus, string password,string clientIPAddress, string hostName, ref string errMessage)
        {
            string Sql = "SELECT APPDESCRIPTION FROM TAPP WHERE APPID = 1";
            string ServerName = String.Empty;
            try
            {
                ServerName = Convert.ToString(SqlHelper.ExecuteScalarDefault(Sql));
            }
            catch (Exception ex)
            {
                errMessage = ex.Message;
                return false;
            }
            if (String.IsNullOrEmpty(ServerName))
            {
                errMessage = "登录失败";
                return false;
            }
            if (ServerName == "0")
            {
                return true;
            }
            else if (ServerName == "1")
            {
                //string sDirectoryEntry = "LDAP://Apacdchk014:636";//"Ldap://apac.nsroot.net:636";//"LDAP://apac.nsroot.net";//
                string sDirectoryEntry = Convert.ToString(ConfigurationManager.AppSettings["LDAP"]);

                using (DirectoryEntry deDirEntry = new DirectoryEntry(sDirectoryEntry, soeid, password))
                {
                    try
                    {
                        errMessage = deDirEntry.Name;
                        deDirEntry.Close();
                        return true;
                    }
                    catch (Exception exp)
                    {
                        errMessage = exp.Message;
                        return false;
                    }
                }
            }
            else
            {
                errMessage = "登录失败";
                return false;
            }
        }


        public Ent_TUser getAllUserInfo()
        {
            try
            {
                Ent_TUser ent_user;  //获取用户基本信息
                Ent_TUser ent_user1; //获取用户页面信息           
                UserInfo oUserInfo;  //返回的用户信息集合

                List<UserInfo> t = new List<UserInfo>();
               
                ///数据库引擎赋价值 
               

                //获取用户基本信息（role,soeid,name,branch,levelcode,deviation,maxloansize...）

                string SELECT_ALL_USERINFO = @"select a.SoeId,a.GEID,a.CnName,a.EnName,a.OrgCode,a.AgentCode,a.BranchCode,b.levelcode,isnull(b.LoanSize,0) as MaxLoanSize,
a.RoleType,c.RoleName,a.Status from T_Sys_Users a left join T_Sys_UserCreditLevel b on a.SoeID = b.SoeID left join 
(select RoleType,RoleName from T_Sys_Roles where [IsValid]=1) c on a.RoleType = c.RoleType where a.[status] = 1";

                ent_user = new Ent_TUser();
                ent_user.UserDataTable = AdoTemplate.ClassicAdoTemplate.DataTableCreate(CommandType.Text, SELECT_ALL_USERINFO);
                DataTable dt = ent_user.UserDataTable;

                //处理用户基本信息
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    oUserInfo = new UserInfo();
                    oUserInfo.SoeId = dt.Rows[i]["SoeId"].ToString();
                    oUserInfo.GEID = dt.Rows[i]["GEID"].ToString();
                    oUserInfo.CnName = dt.Rows[i]["CnName"].ToString();
                    oUserInfo.EnName = dt.Rows[i]["EnName"].ToString();
                    oUserInfo.OrgCode = dt.Rows[i]["OrgCode"].ToString();
                    oUserInfo.LevelCode = dt.Rows[i]["LevelCode"].ToString();
                    oUserInfo.AgentCode = dt.Rows[i]["AgentCode"].ToString();
                    oUserInfo.BranchCode = dt.Rows[i]["BranchCode"].ToString();
                    oUserInfo.MaxLoanSize = Convert.ToInt32(dt.Rows[i]["MaxLoanSize"]);
                    //oUserInfo.IsDeviation = Convert.ToInt32(dt.Rows[i]["IsDeviation"]);
                    oUserInfo.RoleType = Convert.ToInt32(dt.Rows[i]["RoleType"]);
                    oUserInfo.RoleName = Convert.ToString(dt.Rows[i]["RoleName"]);
                    oUserInfo.Status = Convert.ToInt32(dt.Rows[i]["Status"]);
                    //oUserInfo.ApprovalStatus = Convert.ToInt32(dt.Rows[i]["status"]);
                    ent_user1 = new Ent_TUser();
                    ent_user1.UserID = dt.Rows[i]["SoeId"].ToString();
                    //根据用户的SoeId获取页面信息                                 
                   // oUserInfo.UserPage = daUser.GetRolePage(oUserInfo.RoleType);

                    t.Add(oUserInfo);
                }
                ent_user.TUserInfo = t;
                return ent_user;
            }

            catch (Exception ISSE)
            {
                throw ISSE;
            }
           
        }

        public void InsertLogToDB(string soeID, string logon, string message, string ip, string hostName)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("IP", ip);
            parameters.AddWithValue("ComputerName", hostName);
            parameters.AddWithValue("LogDate", DateTime.Now.ToString("yyyy/MM/dd hh:mm:ss"));
            parameters.AddWithValue("SOEID", soeID);
            parameters.AddWithValue("LogStatus", logon);
            parameters.AddWithValue("Remark", message);  
            string sql = @"Insert into T_LOG (IP,ComputerName,LoginDate,SOEID,LogStatus,Remark) values (@IP,@ComputerName,@LogDate,@SOEID,@LogStatus,@Remark)";

            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.Text, sql, parameters);
        }



    }
}
