﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Mvc.Models.Mappers;

namespace Citibank.RFLFE.PL.Dal.userLevel
{
    public class CreditRatingCheckerDao : AdoDaoSupport, ICreditRatingCheckerDao
    {
        public CommonTResult<CreditRatingCheckerView> GetViewList(int start, int limit, CreditRatingCheckerView entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("BranchCode", entity.BranchCode);
            parameters.AddWithValue("ProductName", entity.ProductName);
            parameters.AddWithValue("SoeID", entity.SoeID);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<CreditRatingCheckerView> map = new CommonTResult<CreditRatingCheckerView>();
            map.ResultList = AdoTemplate.QueryWithRowMapper<CreditRatingCheckerView>(CommandType.StoredProcedure, SPNames.PL_GetCreditRatingCheckerViewList, new CreditRatingCheckerViewMapper<CreditRatingCheckerView>(), parameters);
            map.ResultCount = (int)parameters["@Count"].Value;
            return map;
        }

        public bool CheckerApproval(int TID, int ApprovalType, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
            parameters.AddWithValue("ApprovalType", ApprovalType);
            parameters.AddWithValue("checker", checker);           
            
            int i1 = AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_GetCreditRatingCheckerApproval, parameters);
            return true;            
        }
        
    }
}
