﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Mvc.Models.Mappers;

namespace Citibank.RFLFE.PL.Dal.userLevel
{
    public class CreditRatingDao : AdoDaoSupport, ICreditRatingDao
    {
        public CommonTResult<CreditRatingListView> QueryCreditLevel()
        {
            CommonTResult<CreditRatingListView> result = new CommonTResult<CreditRatingListView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ParamID", "76");
            parameters.AddWithValue("SubID", string.Empty);
            var dt1  = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_CreditRating_QueryCreditLevel, parameters);
            result.ResultList = new List<CreditRatingListView>();
            foreach (DataRow dr in dt1.Rows)
            {

                IDbParameters parameters1 = AdoTemplate.CreateDbParameters();
                parameters1.AddWithValue("DeviationLvl", dr["key"].ToString());
                var dt =  AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_CreditRating_QueryCreditLevel, parameters);
                List<CreditRatingListView> rlist = new List<CreditRatingListView>();
                string contentstring = "";
                for (var i = 0; i < dt.Rows.Count; i++)
                {
                    CreditRatingListView CreditRatingListView = new CreditRatingListView();
                    CreditRatingListView.ReasonCode = dt.Rows[i][0].ToString();
                    rlist.Add(CreditRatingListView);
                }
             
                foreach (CreditRatingListView one in rlist)
                {
                    contentstring += one.ReasonCode + ", ";
                }
                if (contentstring.Length > 0)
                {
                    contentstring = contentstring.Substring(0, contentstring.Length - 2);
                }
                CreditRatingListView c1=new CreditRatingListView();
                c1.LevelCode=dr["key"].ToString();
                c1.ReasonCode=contentstring;                
                result.ResultList.Add(c1);                
            }
            return result;
           
        }

        public CommonTResult<T_Sys_UsersSimple> QueryCreditOfficerUserInfo(string BranchCode, string SoeId, int limit, int start)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("SoeId", SoeId);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("BranchCode", BranchCode);
            parameters.AddOut("Count", DbType.Int32);

            CommonTResult<T_Sys_UsersSimple> result = new CommonTResult<T_Sys_UsersSimple>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_UsersSimple>(CommandType.StoredProcedure, SPNames.PL_QueryCreditOfficerUserInfo, new T_Sys_UsersSimpleMapper<T_Sys_UsersSimple>(),parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;           
            
        }

        public CommonTResult<OfficerUserLevelInfoView> QueryCreditOfficerUserLevelInfo(string soeid, int start, int limit)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            parameters.AddWithValue("soeid", soeid);
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddOut("Count", DbType.Int32);

            CommonTResult<OfficerUserLevelInfoView> result = new CommonTResult<OfficerUserLevelInfoView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<OfficerUserLevelInfoView>(CommandType.StoredProcedure, SPNames.PL_QueryCreditOfficerUserLevelInfo, new OfficerUserLevelInfoViewMapper<OfficerUserLevelInfoView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;   
        }
        public bool saveContent(OfficerUserLevelInfoView Entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", Entity.TID);
            parameters.AddWithValue("MAXLOANSIZE", Entity.MAXLOANSIZE);
            parameters.AddWithValue("LEVELCODE", Entity.LEVELCODE);
            parameters.AddWithValue("BranchCode", Entity.BranchCode);            
            parameters.AddWithValue("PRODID", Entity.PRODID);
            parameters.AddWithValue("SOEID", Entity.SOEID);
            parameters.AddWithValue("Maker", Entity.Maker);

            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveCreditOfficerUserLevelInfo, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

    }
}
