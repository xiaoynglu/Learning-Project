﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Mvc.Models.Mappers;

namespace Citibank.RFLFE.PL.Dal.userLevel
{
    public class SysRolesDao : AdoDaoSupport, ISysRolesDao
    {
        public CommonTResult<T_Sys_Roles> GetSysRoles()
        {
            string sql = "select RoleName, RoleID from T_Sys_Roles where  IsValid = 0";
            CommonTResult<T_Sys_Roles> result = new CommonTResult<T_Sys_Roles>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_Roles>(CommandType.Text, sql, new T_Sys_RolesMapper<T_Sys_Roles>());            
            return result;
        }

        public CommonTResult<T_SysRole_UserView> QueryUser(int limit, int start)
        {
            CommonTResult<T_SysRole_UserView> result = new CommonTResult<T_SysRole_UserView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddOut("Count", DbType.Int32);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_SysRole_UserView>(CommandType.StoredProcedure, SPNames.PL_UserLevelQueryUser, new T_SysRole_UserViewMapper<T_SysRole_UserView>(), parameters);
            return result;
        }

        public bool UpdateStatus(string soeid,string newstatus)
        {
            string sql = string.Format(@"update T_Sys_Users set Status='" + newstatus + @"' where soeid='" + soeid + @"'");
            CommonTResult<T_SysRole_UserView> result = new CommonTResult<T_SysRole_UserView>();
            int i1=AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.Text, sql);
            if (i1 > 0)
                return true;
            else
                return false;          
        }

        public CommonTResult<T_SysRole_UserView> QueryUserWithCondition(string soeid, string Location, string Status, int limit, int start)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("Location", Location);
            parameters.AddWithValue("Status", Status);
            parameters.AddWithValue("soeid", soeid);
            parameters.AddOut("Count", DbType.Int32);

            CommonTResult<T_SysRole_UserView> result = new CommonTResult<T_SysRole_UserView>();

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_SysRole_UserView>(CommandType.StoredProcedure, SPNames.PL_UserLevelQueryUserWithCondition, new T_SysRole_UserViewMapper<T_SysRole_UserView>(), parameters);
            return result;
        }

    }
}
