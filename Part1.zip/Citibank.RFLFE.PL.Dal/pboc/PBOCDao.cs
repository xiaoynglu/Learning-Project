﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Mvc.Models.Mappers;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using Citibank.RFLFE.PL.Framework;
using System.Reflection;

namespace Citibank.RFLFE.PL.Dal.pboc
{

    public class PBOCDao : AdoDaoSupport, IPBOCDao
    {
        Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);

        public void ImportRate()
        {

        }

        public Boolean DeleteExchRateByDataYM(string dataYM)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DataYM", dataYM);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_PBOC_DeleteExchRateByDataYM, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public void ExecuteNonQuery(string cmdText)
        {
            List<SqlParameter> Params = new List<SqlParameter>();
            Params.Add(new SqlParameter("", null));
            SqlHelper.ExecuteNonQueryDefault(cmdText, Params.ToArray());
        }

        public bool ClearImportData(string strData_YM)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DataYM", strData_YM);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_PBOC_DeletePRALSByDataYM, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public T_PL_ReportDefination GetReportDefinationByPreFileName(string strPreFileName)
        {
            CommonTResult<T_PL_ReportDefination> list = new CommonTResult<T_PL_ReportDefination>();
            T_PL_ReportDefination result = null;
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("PreFileName", strPreFileName);
            list.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_ReportDefination>(CommandType.StoredProcedure, SPNames.PL_PBOC_GetReportDefinationByPreFileName, new T_PL_ReportDefinationMapper<T_PL_ReportDefination>(), parameters);
            if (list.ResultList.Count > 0)
            {
                result = list.ResultList.FirstOrDefault();
            }
            return result;
        }

        public CommonTResult<T_PL_ReportDefinationDetail> GetReportDefinationDetail(string strPreFileName, int DataSource)
        {
            CommonTResult<T_PL_ReportDefinationDetail> result = new CommonTResult<T_PL_ReportDefinationDetail>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("PreFileName", strPreFileName);
            parameters.AddWithValue("DataSource", DataSource);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_ReportDefinationDetail>(CommandType.StoredProcedure, SPNames.PL_PBOC_GetReportDefinationDetails, new T_PL_ReportDefinationDetailMapper<T_PL_ReportDefinationDetail>(), parameters);
            return result;
        }

        public string GetHeaderDataByDataYM(string strData_YM)
        {
            var errorMessage = "";
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DataYM", strData_YM);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(CommandType.StoredProcedure, SPNames.PL_PBOC_GetHeaderDataByDataYM, parameters);
            if (ds == null)
            {
                errorMessage = "The table 'CNRFPR_Header' does not exist";
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
            if (ds.Tables[0].Rows.Count > 0)
            {
                return errorMessage;
            }
            else
            {
                errorMessage = "there is no data in table CNRFPR_Header";
                log.ErrorLog(errorMessage, MethodBase.GetCurrentMethod().Name);
                return errorMessage;
            }
        }

        public DataTable GetPBOCRecord(string strData_YM)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Data_YM", strData_YM);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_PBOC_GetPBOCRecordByDataYM, parameters);
            return dtResult;
        }

        public Boolean AddFileHeader(string formatNo, string finInsCode, string crtDate, string contributionRefNo, string resubmissionCode, string rptType,
                                  string iRecordCount, string eDueDate, string lDueDate, string contactPerson, string contactPhone, string fillers, string strData_YM)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("FormatNo", formatNo);
            parameters.AddWithValue("FinInsCode", finInsCode);
            parameters.AddWithValue("CrtDate", crtDate);
            parameters.AddWithValue("ContributionRefNo", contributionRefNo);
            parameters.AddWithValue("ResubmissionCode", resubmissionCode);
            parameters.AddWithValue("RptType", rptType);
            parameters.AddWithValue("IRecordCount", iRecordCount);
            parameters.AddWithValue("EDueDate", eDueDate);
            parameters.AddWithValue("LDueDate", lDueDate);
            parameters.AddWithValue("ContactPerson", contactPerson);
            parameters.AddWithValue("ContactPhone", contactPhone);
            parameters.AddWithValue("Fillers", fillers);
            parameters.AddWithValue("StrData_YM", strData_YM);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_PBOC_AddFileHeader, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public DataTable GetExchRateByDataYM(string Data_YM)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DataYM", Data_YM);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_PBOC_GetExchRateByDataYM, parameters);
            return dtResult;
        }

        public DataTable GetMatchWord()
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_PBOC_GetMatchWord, parameters);
            return dtResult;
        }

        public DataSet GetLastDeliHisStatus(string accountNo, string dataYM)
        {
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("BI_Acc_No", accountNo);
            parameters.AddWithValue("Data_YM", dataYM);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_PBOC_GetLastDeliHisStatus, parameters);
            return ds;
        }

        public DataSet SELECTPBOC(string accNo, string strDataYM)
        {
             ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("BI_Acc_No", accNo);
            parameters.AddWithValue("Data_YM", strDataYM);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_PBOC_SELECTPBOC, parameters);
            return ds;
        }

        public long getMAX_RT_ORIG_LOAN_AMT(string accountNo, string dataYM)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AccountNo", accountNo);
            parameters.AddWithValue("DataYM", dataYM);
            string strORIG_LOAN_AMT = "";
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
               CommandType.StoredProcedure, SPNames.PL_PBOC_SELECTPBOC, parameters);
            if (ds.Tables[0].Rows.Count > 1)
            {
                ds.Clear();
                throw new Exception("More than one DeliHisStatus record");
            }
            else if (ds.Tables[0].Rows.Count == 0)
            {
                return 0;
            }
            else
            {
                strORIG_LOAN_AMT = ds.Tables[0].Rows[0][0].ToString().Trim();
                if (SystemFrameworks.Util.ValidateCheck.chkNumber(strORIG_LOAN_AMT))
                {
                    return long.Parse(strORIG_LOAN_AMT);
                }
                else
                {
                    return 0;
                }

            }
        }

        public DataSet SelectReport(string strData_YM)
        {
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Data_YM", strData_YM);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_PBOC_SelectReportByDataYM, parameters);
            return ds;
        }

        public bool SaveChangeOffAmount(DataTable dt)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AccountNo", "");
            parameters.AddWithValue("Principal", "");
            parameters.AddWithValue("InterestFee", "");
            parameters.AddWithValue("TotalPI", "");
            parameters.AddWithValue("TotalRecoveryAmount", "");
            parameters.AddWithValue("CurrentOS", "");
            parameters.AddWithValue("ChargeOffDate", "");
            int i1 = 0;
            for (var i = 0; i < dt.Rows.Count; i++)
            {
                parameters.SetValue("AccountNo", dt.Rows[i][0].ToString());
                parameters.SetValue("CurrentOS", dt.Rows[i][1].ToString());
                parameters.SetValue("ChargeOffDate", dt.Rows[i][2].ToString());
                parameters.SetValue("Principal", dt.Rows[i][3].ToString());
                parameters.SetValue("InterestFee", dt.Rows[i][4].ToString());
                parameters.SetValue("TotalPI", dt.Rows[i][5].ToString());
                parameters.SetValue("TotalRecoveryAmount", dt.Rows[i][6].ToString());
                i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_PBOC_InsertChangeeOffAmount, parameters);
                if (i1 < 0)
                    return false;
            }
            return true;
        }

        public bool SaveRemainingMonth(DataTable dt)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CM_DIS_ACCTNUMB", "");
            parameters.AddWithValue("CM_DIS_RT_CURR_TERM", "");
            parameters.AddWithValue("CM_DIS_NO_INSTAL_PAID", "");
            parameters.AddWithValue("CM_DIS_RT_ACTL_PMTS_REM", "");
            int i1 = 0;
            for (var i = 0; i < dt.Rows.Count; i++)
            {
                parameters.SetValue("CM_DIS_ACCTNUMB", dt.Rows[i][0].ToString());
                parameters.SetValue("CM_DIS_RT_CURR_TERM", dt.Rows[i][1].ToString());
                parameters.SetValue("CM_DIS_NO_INSTAL_PAID", dt.Rows[i][2].ToString());
                parameters.SetValue("CM_DIS_RT_ACTL_PMTS_REM", dt.Rows[i][3].ToString());
                i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_PBOC_SaveRemainingMonth, parameters);
                if (i1 < 0)
                    return false;
            }
            return true;
        }


        public bool DeleteHeaderDataByDataYM(string data_YM)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DataYM", data_YM);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_PBOC_DeleteHeaderDataByDataYM, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }

        public bool DeleteBodyDataByDataYM(string data_YM)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DataYM", data_YM);
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_PBOC_DeleteBodyDataByDataYM, parameters);
            if (i1 >= 0)
                return true;
            else
                return false;
        }


        public DataSet GetBodyDataByDataYM(string data_YM)
        {
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Data_YM", data_YM);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_PBOC_GetBodyDataByDataYM, parameters);
            return ds;
        }

        public DataSet GetALSDataByDataYM(string data_YM, string accountNumberParam)
        {
            ApplicationDetail appInfo = new ApplicationDetail();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Data_YM", data_YM);
            parameters.AddWithValue("AccountNumberParam", accountNumberParam);            
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_PBOC_GetALSDataByDataYM, parameters);
            return ds;
        }

    }
}
