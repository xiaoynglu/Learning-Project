﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class RelatedPersonMakerDao : AdoDaoSupport, IRelatedPersonMakerDao
    {
        /// <summary>
        /// Get Related person maker data
        /// </summary>
        /// <returns></returns>
        public CommonTResult<T_RP_RelatedPersonMaker> GetRelatedPersonMaker(T_RP_RelatedPersonMaker entity, int limit, int start)
        {
            CommonTResult<T_RP_RelatedPersonMaker> result = new CommonTResult<T_RP_RelatedPersonMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("InsideName", entity.InsideName);
            parameters.AddWithValue("CertID", entity.CertID);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddWithValue("Checker", "");
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("Start", start);
            parameters.AddOut("Count", DbType.Int32);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_RelatedPersonMaker>(CommandType.StoredProcedure, SPNames.PL_GetRelatedPersonMaker, new T_RP_RelatedPersonMakerMapper<T_RP_RelatedPersonMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        /// <summary>
        /// Save Related person maker data
        /// </summary>
        /// <param name="entity">T_RP_RelatedPersonMaker entity</param>
        /// <returns>TID</returns>
        public int SaveRelatedPersonMaker(T_RP_RelatedPersonMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("CertID", entity.CertID);
            parameters.AddWithValue("InsideName", entity.InsideName);
            parameters.AddWithValue("CloseRelative1", entity.CloseRelative1);
            parameters.AddWithValue("CloseRelative2", entity.CloseRelative2);
            parameters.AddWithValue("CloseRelative3", entity.CloseRelative3);
            parameters.AddWithValue("CloseRelative4", entity.CloseRelative4);
            parameters.AddWithValue("CloseRelative5", entity.CloseRelative5);
            parameters.AddWithValue("CloseRelative6", entity.CloseRelative6);
            parameters.AddWithValue("CloseRelative7", entity.CloseRelative7);
            parameters.AddWithValue("CloseRelative8", entity.CloseRelative8);
            parameters.AddWithValue("CloseRelative9", entity.CloseRelative9);
            parameters.AddWithValue("CloseRelative10", entity.CloseRelative10);
            parameters.AddWithValue("CloseRelative11", entity.CloseRelative11);
            parameters.AddWithValue("CloseRelative12", entity.CloseRelative12);
            parameters.AddWithValue("CloseRelative13", entity.CloseRelative13);
            parameters.AddWithValue("CloseRelative14", entity.CloseRelative14);
            parameters.AddWithValue("CloseRelative15", entity.CloseRelative15);
            parameters.AddWithValue("CloseRelative16", entity.CloseRelative16);
            parameters.AddWithValue("CloseRelative17", entity.CloseRelative17);
            parameters.AddWithValue("CloseRelative18", entity.CloseRelative18);
            parameters.AddWithValue("CloseRelative19", entity.CloseRelative19);
            parameters.AddWithValue("CloseRelative20", entity.CloseRelative20);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddWithValue("CreateDate", entity.CreateDate);
            parameters.AddWithValue("Checker", entity.Checker);
            parameters.AddWithValue("ModifiedTime", entity.ModifiedTime);
            parameters.AddWithValue("OpType", entity.OpType);
            parameters.AddOut("NTID", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveRelatedPersonMaker, parameters);
            return (int)parameters["@NTID"].Value;
        }
        /// <summary>
        /// Delete existing related person maker data by tid
        /// </summary>
        /// <param name="tid">tid</param>
        /// <returns>succeed flag</returns>
        public bool DeleteRelatedPersonMaker(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteRelatedPersonMaker, parameters);
            return result > 0 ? true : false;
        }

        /// <summary>
        /// Update existing related person maker data with entity values
        /// </summary>
        /// <param name="entity">T_RP_RelatedPersonMaker entity</param>
        /// <returns>successed flag</returns>
        public int UpdateRelatedPersonMaker(T_RP_RelatedPersonMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("CertID", entity.CertID);
            parameters.AddWithValue("InsideName", entity.InsideName);
            parameters.AddWithValue("CloseRelative1", entity.CloseRelative1);
            parameters.AddWithValue("CloseRelative2", entity.CloseRelative2);
            parameters.AddWithValue("CloseRelative3", entity.CloseRelative3);
            parameters.AddWithValue("CloseRelative4", entity.CloseRelative4);
            parameters.AddWithValue("CloseRelative5", entity.CloseRelative5);
            parameters.AddWithValue("CloseRelative6", entity.CloseRelative6);
            parameters.AddWithValue("CloseRelative7", entity.CloseRelative7);
            parameters.AddWithValue("CloseRelative8", entity.CloseRelative8);
            parameters.AddWithValue("CloseRelative9", entity.CloseRelative9);
            parameters.AddWithValue("CloseRelative10", entity.CloseRelative10);
            parameters.AddWithValue("CloseRelative11", entity.CloseRelative11);
            parameters.AddWithValue("CloseRelative12", entity.CloseRelative12);
            parameters.AddWithValue("CloseRelative13", entity.CloseRelative13);
            parameters.AddWithValue("CloseRelative14", entity.CloseRelative14);
            parameters.AddWithValue("CloseRelative15", entity.CloseRelative15);
            parameters.AddWithValue("CloseRelative16", entity.CloseRelative16);
            parameters.AddWithValue("CloseRelative17", entity.CloseRelative17);
            parameters.AddWithValue("CloseRelative18", entity.CloseRelative18);
            parameters.AddWithValue("CloseRelative19", entity.CloseRelative19);
            parameters.AddWithValue("CloseRelative20", entity.CloseRelative20);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddWithValue("CreateDate", entity.CreateDate);
            parameters.AddWithValue("Checker", entity.Checker);
            parameters.AddWithValue("ModifiedTime", entity.ModifiedTime);
            parameters.AddWithValue("OpType", entity.OpType);

            parameters.AddOut("NTID", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateRelatedPersonMaker, parameters);
            return (int)parameters["@NTID"].Value;
        }

        /// <summary>
        /// Approve the related person maker requests
        /// </summary>
        /// <param name="ids">TIDs which need to approve</param>
        /// <param name="checker">current user</param>
        /// <returns>successed flag</returns>
        public bool ApproveRelatedPersonMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveRelatedPersonMaker, parameters);
            return result > 0 ? true : false;
        }

        /// <summary>
        /// Reject the related person maker request
        /// </summary>
        /// <param name="ids">TIDs which need to reject</param>
        /// <param name="checker">current user</param>
        /// <returns>successed flag</returns>
        public bool RejectRelatedPersonMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RejectRelatedPersonMaker, parameters);
            return result > 0 ? true : false;
        }
    }
}
