﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Dal.Mappers;
using System.IO;
using Citibank.RFLFE.PL.Mvc.Models;
using Citibank.RFLFE.PL.Framework;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class FileTemplateDao : AdoDaoSupport, IFileTemplateDao
    {
        public CommonTResult<T_PL_FileTemplateMaker> GetFileTemplateMakerList(int limit, int start, int? prodID, int? status)
        {
            CommonTResult<T_PL_FileTemplateMaker> result = new CommonTResult<T_PL_FileTemplateMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdId", prodID);
            parameters.AddWithValue("Status", status);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_FileTemplateMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_FILETEMPLATEMAKERLIST, new T_PL_FileTemplateMakerMapper<T_PL_FileTemplateMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<T_PL_ConfigConditionMaker> GetTemplateConditionMakerList(int limit, int start, int? prodID, int? status)
        {
            CommonTResult<T_PL_ConfigConditionMaker> result = new CommonTResult<T_PL_ConfigConditionMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdId", prodID);
            parameters.AddWithValue("Status", status);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_ConfigConditionMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_TEMPLATECONDITIONMAKERLIST, new T_PL_ConfigConditionMakerMapper<T_PL_ConfigConditionMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public IList<T_PL_ConditionColumns> GetConditionDisplayNames(string tableName)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TableName", tableName);

            IList<T_PL_ConditionColumns> list = AdoTemplate.QueryWithRowMapper<T_PL_ConditionColumns>(CommandType.StoredProcedure, SPNames.PL_GET_CONDITIONDISPLAYNAMES, new T_PL_ConditionColumnsMapper<T_PL_ConditionColumns>(), parameters);
            return list;
        }

        public IList<T_PL_ConfigConditionMaker> GetConditionGroupNames(int tid, int parentID, int prodID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            parameters.AddWithValue("ParentID", parentID);
            parameters.AddWithValue("ProdID", prodID);
            IList<T_PL_ConfigConditionMaker> list = AdoTemplate.QueryWithRowMapper<T_PL_ConfigConditionMaker>(CommandType.StoredProcedure, SPNames.PL_GET_CONDITIONGROUPNAMES, new ConditionGroupNamesMapper<T_PL_ConfigConditionMaker>(), parameters);
            return list;
        }

        public IList<T_PL_FileTemplateMaker> GetTemplateFileNames(int fileType)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("FileType", fileType);

            IList<T_PL_FileTemplateMaker> list = AdoTemplate.QueryWithRowMapper<T_PL_FileTemplateMaker>(CommandType.StoredProcedure, SPNames.PL_GET_TEMPLATEFILENAMES, new TemplateFileNamesMapper<T_PL_FileTemplateMaker>(), parameters);
            return list;
        }

        public T_PL_FileTemplateMaker GetTemplateFilePathByTID(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);

            return AdoTemplate.QueryForObject<T_PL_FileTemplateMaker>(CommandType.StoredProcedure, SPNames.PL_GET_TEMPLATEFILEPATH_BYTID, new TemplateFilePathMapper<T_PL_FileTemplateMaker>(), parameters);
        }

        public int ChangeTemplateName(int tid, string fileName)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            parameters.AddWithValue("FileName", fileName);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_TEMPLATENAME, parameters);
        }

        public int SaveTemplateConditionMaker(T_PL_ConfigConditionMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ConfigID", entity.ConfigID);
            parameters.AddWithValue("TemplateID", entity.TemplateID);
            parameters.AddWithValue("ParentID", entity.ParentID);
            parameters.AddWithValue("TabID", entity.TabID);
            parameters.AddWithValue("GroupName", entity.GroupName);
            parameters.AddWithValue("OP", entity.OP);
            parameters.AddWithValue("Value", entity.Value);
            parameters.AddWithValue("OpType", entity.OpType);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddOut("Result", DbType.Int32);     
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ADD_CONFIGCONDITIONMAKER, parameters);
            return (int)parameters["@Result"].Value;
        }

        public int SaveFileTemplateMaker(T_PL_FileTemplateMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", entity.ProdID);
            parameters.AddWithValue("FilePath", entity.FilePath);
            parameters.AddWithValue("FileName", entity.FileName);
            parameters.AddWithValue("FileType", entity.FileType);
            parameters.AddWithValue("ParentID", entity.ParentID);
            parameters.AddWithValue("BorrowerType", entity.BorrowerType);
            parameters.AddWithValue("OpType", entity.OpType);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ADD_FILETEMPLATEMAKER, parameters);
            return (int)parameters["@Result"].Value;
        }

        public int DeleteFileTemplateMaker(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            parameters.AddOut("Result", DbType.Int32);
            string path = "";
            T_PL_FileTemplateMaker entity = GetTemplateFilePathByTID(Convert.ToInt32(tid));
            if (String.IsNullOrEmpty(entity.FilePath))
            {
                entity.FilePath = "";
            }
            path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, entity.FilePath); 
            int i1= AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DEL_FILETEMPLATEMAKER, parameters);
            int rt=(int)parameters["@Result"].Value;
            if (rt == 1)
            {
                if (System.IO.File.Exists(path))
                {
                    try
                    {
                        System.IO.File.Delete(path);
                    }
                    catch
                    {

                    }
                }
            }
            return i1;

        }

        public int DeleteConfigConditionMaker(int cid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ConditionID", cid);
            return AdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DEL_CONFIGCONDITIONMAKER, parameters);
        }

        public bool ApproveFileTemplateMaker(string ids, string checker)
        {
            if (ids.IndexOf(',') == -1)
            {
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("TIDs", ids);
                parameters.AddWithValue("Checker", checker);
                parameters.AddOut("Result", DbType.Int32);
                string path = "";
                T_PL_FileTemplateMaker entity = GetTemplateFilePathByTID(Convert.ToInt32(ids));

                if (String.IsNullOrEmpty(entity.FilePath))
                {
                    entity.FilePath = "";
                }
                path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, entity.FilePath);
                int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_APPROVE_FILETEMPLATEMAKER, parameters);
                int iresult = parameters["@Result"].Value != System.DBNull.Value ? (int)parameters["@Result"].Value : -1;
                if (iresult != -1)
                {
                    if (System.IO.File.Exists(path))
                    {
                        try
                        {
                            System.IO.File.Delete(path);
                        }
                        catch
                        {

                        }
                    }
                }
                return result > 0 ? true : false;
            }
            else
            {
                foreach (string id in ids.Split(','))
                {
                    IDbParameters parameters = AdoTemplate.CreateDbParameters();
                    parameters.AddWithValue("TIDs", id);
                    parameters.AddWithValue("Checker", checker);
                    parameters.AddOut("Result", DbType.Int32);

                    string path = "";
                    T_PL_FileTemplateMaker entity = GetTemplateFilePathByTID(Convert.ToInt32(id));

                    if (String.IsNullOrEmpty(entity.FilePath))
                    {
                        entity.FilePath = "";
                    }
                    path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, entity.FilePath);
                    int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_APPROVE_FILETEMPLATEMAKER, parameters);
                    int iresult = (int)parameters["@Result"].Value;
                    if (iresult != -1)
                    {
                        if (System.IO.File.Exists(path))
                        {
                            try
                            {
                                System.IO.File.Delete(path);
                            }
                            catch
                            {

                            }
                        }
                    }
                }
                return true;
            }
            return false;
        }

        public bool RejectFileTemplateMaker(string ids, string checker)
        {
            if (ids.IndexOf(',') == -1)
            {
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("TIDs", ids);
                parameters.AddWithValue("Checker", checker);
                parameters.AddOut("Result", DbType.Int32);

                string path = "";
                T_PL_FileTemplateMaker entity = GetTemplateFilePathByTID(Convert.ToInt32(ids));

                if (String.IsNullOrEmpty(entity.FilePath))
                {
                    entity.FilePath = "";
                }
                path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, entity.FilePath);
                int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJECT_FILETEMPLATEMAKER, parameters);
                int iresult = (int)parameters["@Result"].Value;
                if (iresult != -1)
                {
                    if (System.IO.File.Exists(path))
                    {
                        try
                        {
                            System.IO.File.Delete(path);
                        }
                        catch
                        {

                        }
                    }
                }
                return result > 0 ? true : false;
            }
            else
            {
                foreach (string id in ids.Split(','))
                {
                    IDbParameters parameters = AdoTemplate.CreateDbParameters();
                    parameters.AddWithValue("TIDs", id);
                    parameters.AddWithValue("Checker", checker);
                    parameters.AddOut("Result", DbType.Int32);

                    string path = "";
                    T_PL_FileTemplateMaker entity = GetTemplateFilePathByTID(Convert.ToInt32(id));

                    if (String.IsNullOrEmpty(entity.FilePath))
                    {
                        entity.FilePath = "";
                    }
                    path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, entity.FilePath);
                    int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJECT_FILETEMPLATEMAKER, parameters);
                    int iresult = (int)parameters["@Result"].Value;
                    if (iresult != -1)
                    {
                        if (System.IO.File.Exists(path))
                        {
                            try
                            {
                                System.IO.File.Delete(path);
                            }
                            catch
                            {

                            }
                        }
                    }
                }
                return true;
            }
        }

        public bool ApproveConfigConditionMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_APPROVE_CONFIGCONDITIONMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectConfigConditionMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJECT_CONFIGCONDITIONMAKER, parameters);
            return result > 0 ? true : false;
        }

        public IList<Mvc.Models.ComboxDataView> GetUploadedProd()
        {
            var result = new List<Mvc.Models.ComboxDataView>();
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreate(
                CommandType.StoredProcedure, SPNames.PL_CTMaintainMaker_Get_UploadedProd);
            if (ds != null&& ds.Tables[0]!=null && ds.Tables[0].Rows.Count>0)
            {
                ComboxDataView itemNode = new ComboxDataView();
                itemNode.Code = "";
                itemNode.Description = StringResources.SELECTED_ITEM;
                result.Insert(0, itemNode);

                for (var i = 0; i < ds.Tables[0].Rows.Count;i++ )
                {
                    ComboxDataView itemNode2 = new ComboxDataView();
                    itemNode2.Code = ds.Tables[0].Rows[i][0].ToString();
                    itemNode2.Description = ds.Tables[0].Rows[i][1].ToString();
                    result.Insert(i+1, itemNode2);
                }
            }
            return result;
        }

        public Dictionary<object, object> GetUploadedFileNameAndAttachmentListByProdID(string prodId)
        {
            Dictionary<object, object> result = new Dictionary<object, object>();
            var attachmentList = new List<Mvc.Models.ComboxDataView>();
            var fileName = "";
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", prodId);
            DataSet ds = AdoTemplate.ClassicAdoTemplate.DataSetCreateWithParams(
                CommandType.StoredProcedure, SPNames.PL_GetUploadedFileNameAndAttachmentListByProdID, parameters);
            if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0 && ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
            {
                ComboxDataView itemNode = new ComboxDataView();
                itemNode.Code = "";
                itemNode.Description = StringResources.SELECTED_ITEM;
                attachmentList.Insert(0, itemNode);

                for (var i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    ComboxDataView itemNode2 = new ComboxDataView();
                    itemNode2.Code = ds.Tables[0].Rows[i][0].ToString();
                    itemNode2.Description = ds.Tables[0].Rows[i][1].ToString();
                    attachmentList.Insert(i + 1, itemNode2);
                }
                fileName = ds.Tables[1].Rows[0][0].ToString();

                result.Add("FileName", fileName);
                result.Add("AttachmentList", attachmentList);
            }
            return result;
        }
    }
}
