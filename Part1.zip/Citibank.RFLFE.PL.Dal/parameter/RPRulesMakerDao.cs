﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;
using Citibank.RFLFE.PL.Mvc.Models;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class RPRulesMakerDao : AdoDaoSupport, IRPRulesMakerDao
    {
        public CommonTResult<T_RP_RulesMaker> GetRPRulesChecker(string RuleID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleID", RuleID);
            CommonTResult<T_RP_RulesMaker> result = new CommonTResult<T_RP_RulesMaker>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_RulesMaker>(CommandType.StoredProcedure, SPNames.PL_GetRuleParamListCheckerByRuleID, new T_RP_RulesMakerMapper<T_RP_RulesMaker>(), parameters);
            return result;
        }

        public CommonTResult<T_RP_RulesMaker> GetRP_RulesMaker(T_RP_RulesMaker entity, int limit, int start)
        {
            CommonTResult<T_RP_RulesMaker> result = new CommonTResult<T_RP_RulesMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleID", entity.RuleID);
            parameters.AddWithValue("status", entity.Status);
            parameters.AddWithValue("statusParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.StatusParamID);
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("Start", start);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_RulesMaker>(CommandType.StoredProcedure, SPNames.PL_GetRPRulesMaker, new T_RP_RulesMakerMapper<T_RP_RulesMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public int UpdateRP_RulesMaker(T_RP_RulesMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleID", entity.RuleID);
            parameters.AddWithValue("RuleName", entity.RuleName);
            parameters.AddWithValue("ReasonID", entity.ReasonID);
            parameters.AddWithValue("HitType", entity.HitType);
            parameters.AddWithValue("DeviationLvl", entity.DeviationLvl);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddOut("NTID", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateRPRulesMaker, parameters);
            return (int)parameters["@NTID"].Value;  
        }

        public bool ApproveRP_RulesMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleID", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveRPRulesMaker, parameters);
            return result > 0 ? true : false;            
        }

        public bool RejectRP_RulesMaker(string ids, string checker)
        {
             IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleID", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RejectRPRulesMaker, parameters);
            return result > 0 ? true : false;            
        }

        public IList<T_RP_RulesMaker> GetRuleNamesMaker()
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            IList<T_RP_RulesMaker> list = AdoTemplate.QueryWithRowMapper<T_RP_RulesMaker>(CommandType.StoredProcedure, SPNames.PL_GetRuleNamesMaker, new T_RP_RulesMakerMapper<T_RP_RulesMaker>(), parameters);
            return list;
        }

        public IList<T_RP_Params> GetRuleParamListMaker(string RuleID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleID", RuleID);
            IList<T_RP_Params> list = AdoTemplate.QueryWithRowMapper<T_RP_Params>(CommandType.StoredProcedure, SPNames.PL_GetRuleParamListByRuleID, new T_RP_RuleParamMapper<T_RP_Params>(), parameters);
            return list;
        }

        public CommonTResult<T_RP_RuleParamValuePivot> GetRuleParamValuePivotListMaker(T_RP_RuleParamValuePivot entity, int limit, int start)
        {
            CommonTResult<T_RP_RuleParamValuePivot> result = new CommonTResult<T_RP_RuleParamValuePivot>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleID", entity.RuleID);
            parameters.AddWithValue("Paramid", entity.ParamID);
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("status", 0);
            parameters.AddWithValue("statusParamid", 0);
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("Start", start);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_RuleParamValuePivot>(CommandType.StoredProcedure, SPNames.PL_GetRPRuleParamValueMakerPivot, new T_RP_RuleParamValuePivotMaper<T_RP_RuleParamValuePivot>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;

            return result;
        }

        public CommonTResult<T_RP_RuleParamValuePivot> GetRuleParamValuePivotListChecker(T_RP_RuleParamValuePivot entity, int limit, int start)
        {
            CommonTResult<T_RP_RuleParamValuePivot> result = new CommonTResult<T_RP_RuleParamValuePivot>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleID", entity.RuleID);
            parameters.AddWithValue("Paramid", entity.ParamID);
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("status", 0);
            parameters.AddWithValue("statusParamid", 0);
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("Start", start);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_RuleParamValuePivot>(CommandType.StoredProcedure, SPNames.PL_GetRPRuleParamValueCheckerPivot, new T_RP_RuleParamValuePivotMaper<T_RP_RuleParamValuePivot>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;

            return result;
        }

        public bool SaveRPRuleParamValueMaker(string RuleIDs, string ParamIDs, string OrgCodes, string UPL_Gs, string UPL_Qs, string HE_Gs, string HE_Qs, string CRE_Gs, string CRE_Qs, string MO_Gs, string MO_Qs, string maker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleIDs", RuleIDs);
            parameters.AddWithValue("ParamIDs", ParamIDs);
            parameters.AddWithValue("OrgCodes", OrgCodes);
            parameters.AddWithValue("UPL_Gs", UPL_Gs);
            parameters.AddWithValue("UPL_Qs", UPL_Qs);
            parameters.AddWithValue("HE_Gs", HE_Gs);
            parameters.AddWithValue("HE_Qs", HE_Qs);
            parameters.AddWithValue("CRE_Gs", CRE_Gs);
            parameters.AddWithValue("CRE_Qs", CRE_Qs);
            parameters.AddWithValue("MO_Gs", MO_Gs);
            parameters.AddWithValue("MO_Qs", MO_Qs);
            parameters.AddWithValue("Maker", maker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveRPRuleParamValueMaker, parameters);
            return result > 0 ? true : false;
        }

        public bool ApproveLTVParamMaker(string ProdIds, string OrgCodes, string Factors, string checker, int approvetype)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdIds", ProdIds);
            parameters.AddWithValue("OrgCodes", OrgCodes);
            parameters.AddWithValue("Factors", Factors);
            parameters.AddWithValue("approvetype", approvetype);
            
            parameters.AddWithValue("checker", checker);

            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveLTVParamMaker, parameters);
            return result > 0 ? true : false;   
        }

        public bool ApproveLTVValueMaker(string ProdIDs, string OrgCodes, string CollateralTypes, string checker, int approvetype)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdIDs", ProdIDs);
            parameters.AddWithValue("OrgCodes", OrgCodes);
            parameters.AddWithValue("CollateralTypes", CollateralTypes);
            parameters.AddWithValue("approvetype", approvetype);
            parameters.AddWithValue("checker", checker);

            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveLTVValueMaker, parameters);
            return result > 0 ? true : false;
        }

        public bool ApproveRPRuleParamValueMaker(string RuleIDs, string ParamIDs, string OrgCodes, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleIDs", RuleIDs);
            parameters.AddWithValue("ParamIDs", ParamIDs);
            parameters.AddWithValue("OrgCodes", OrgCodes);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveRPRuleParamValueMaker, parameters);
            return result > 0 ? true : false;
        }

        public CommonTResult<T_PL_AppExpireDateMaker> GetExpireDateList()
        {
            CommonTResult<T_PL_AppExpireDateMaker> result = new CommonTResult<T_PL_AppExpireDateMaker>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_AppExpireDateMaker>(CommandType.StoredProcedure, SPNames.PL_GetRuleParamAlistMaker, new T_PL_AppExpireDateMakerMapper<T_PL_AppExpireDateMaker>());
            return result;
        }

        public bool UpdateExpireDay(string ids, string expiredays, string maker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ids", ids);
            parameters.AddWithValue("expiredays", expiredays);
            parameters.AddWithValue("maker", maker);

            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateExpireDay, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectRPRuleParamValueMaker(string RuleIDs, string ParamIDs, string OrgCodes, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RuleIDs", RuleIDs);
            parameters.AddWithValue("ParamIDs", ParamIDs);
            parameters.AddWithValue("OrgCodes", OrgCodes);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RejectRPRuleParamValueMaker, parameters);
            return result > 0 ? true : false;
        }

        public bool ApproveExpireDay(string ids, int approveType, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ids", ids);
            parameters.AddWithValue("approveType", approveType);
            parameters.AddWithValue("checker", checker);
            int result= AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveExpireDay, parameters);
            return result > 0 ? true : false;
        }

        public CommonTResult<RuleParamAlistView> GetRuleParamAlistMaker(int start, int limit, string orgcode, string Status)
        {

            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("orgcode", orgcode);
            parameters.AddWithValue("Status", Status);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<RuleParamAlistView> result = new CommonTResult<RuleParamAlistView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<RuleParamAlistView>(CommandType.StoredProcedure, SPNames.PL_GetRuleParamAlistMaker, new RuleParamAlistViewMapper<RuleParamAlistView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }
        public CommonTResult<RuleParamBlistView> GetRuleParamBlistMaker(int start, int limit, string orgcode, string Status)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("orgcode", orgcode);
            parameters.AddWithValue("Status", Status);
            parameters.AddOut("Count", DbType.Int32);
            CommonTResult<RuleParamBlistView> result = new CommonTResult<RuleParamBlistView>();
            result.ResultList = AdoTemplate.QueryWithRowMapper<RuleParamBlistView>(CommandType.StoredProcedure, SPNames.PL_GetRuleParamBlistMaker, new RuleParamBlistViewMapper<RuleParamBlistView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public bool SaveLTVValueMaker(string ProdIds, string OrgCodes, string CollateralTypes, string BaseLTVs, string MaxDelLTVs, string maker)
        {
            if (ProdIds == "") return false;
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdIds", ProdIds);
            parameters.AddWithValue("OrgCodes", OrgCodes);
            parameters.AddWithValue("CollateralTypes", CollateralTypes);
            parameters.AddWithValue("BaseLTVs", BaseLTVs);
            parameters.AddWithValue("MaxDelLTVs", MaxDelLTVs);
            parameters.AddWithValue("maker", maker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveLTVValueMaker, parameters);
            return result > 0 ? true : false;
        }

        public bool SaveLTVParamMaker(string ProdIds, string OrgCodes, string Factors, string Values,  string maker)
        {
            if (ProdIds == "") return false;
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdIds", ProdIds);
            parameters.AddWithValue("OrgCodes", OrgCodes);
            parameters.AddWithValue("Factors", Factors);
            parameters.AddWithValue("Values", Values);            
            parameters.AddWithValue("maker", maker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveLTVParamMaker, parameters);
            return result > 0 ? true : false;
        }

    }
}
