﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class FraudDataMakerDao : AdoDaoSupport, IFraudDataMakerDao
    {
        /// <summary>
        /// Get Fraud data
        /// </summary>
        /// <returns></returns>
        public CommonTResult<T_RP_FraudDataMaker> GetFraudDataMaker(T_RP_FraudDataMaker entity, int limit, int start)
        {
            CommonTResult<T_RP_FraudDataMaker> result = new CommonTResult<T_RP_FraudDataMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("id", entity.CertID);
            parameters.AddWithValue("custName", entity.CustName);
            parameters.AddWithValue("mobile", entity.MobilePhone);
            parameters.AddWithValue("companyName", entity.CompanyName);
            parameters.AddWithValue("companyAddr", entity.CompanyAddress);
            parameters.AddWithValue("HPAC", entity.HomePhoneAreaCode);
            parameters.AddWithValue("companyPhone", entity.CompanyPhone);
            parameters.AddWithValue("CPAC", entity.CompanyPhoneAreaCode);
            parameters.AddWithValue("homePhone", entity.HomePhone);
            parameters.AddWithValue("CPExt", entity.CompanyPhoneExt);
            parameters.AddWithValue("referrerName", entity.ReferrerName);
            parameters.AddWithValue("homeAddr", entity.HomeAddress);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("maker", entity.Maker);
            parameters.AddWithValue("checker", entity.Checker);
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("Start", start);
            parameters.AddOut("Count", DbType.Int32);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_FraudDataMaker>(CommandType.StoredProcedure, SPNames.PL_GetFraudDataMaker, new T_RP_FraudDataMakerMapper<T_RP_FraudDataMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        /// <summary>
        /// Save Fraud maker data
        /// </summary>
        /// <param name="entity">T_RP_FraudDataMaker entity</param>
        /// <returns>TID</returns>
        public int SaveFraudDataMaker(T_RP_FraudDataMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("id", entity.CertID);
            parameters.AddWithValue("companyAddr", entity.CompanyAddress);
            parameters.AddWithValue("companyName", entity.CompanyName);
            parameters.AddWithValue("companyPhone", entity.CompanyPhone);
            parameters.AddWithValue("CPAC", entity.CompanyPhoneAreaCode);
            parameters.AddWithValue("CPExt", entity.CompanyPhoneExt);
            parameters.AddWithValue("custName", entity.CustName);
            parameters.AddWithValue("ExpireDate", entity.ExpireDate);
            parameters.AddWithValue("homeAddr", entity.HomeAddress);
            parameters.AddWithValue("homePhone", entity.HomePhone);
            parameters.AddWithValue("HPAC", entity.HomePhoneAreaCode);
            parameters.AddWithValue("InfoSource", entity.InfoSource);
            parameters.AddWithValue("mobile", entity.MobilePhone);
            parameters.AddWithValue("referrerName", entity.ReferrerName);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddWithValue("CreateDate", entity.CreateDate);
            parameters.AddWithValue("Checker", entity.Checker);
            parameters.AddWithValue("ModifiedTime", entity.ModifiedTime);
            parameters.AddWithValue("OpType", entity.OpType);
            
            parameters.AddOut("NTID", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_SaveFraudDataMaker, parameters);
            return (int)parameters["@NTID"].Value;
        }
        /// <summary>
        /// Delete existing Fraud maker data by tid
        /// </summary>
        /// <param name="tid">tid</param>
        /// <returns>succeed flag</returns>
        public bool DeleteFraudDataMaker(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteFraudDataMaker, parameters);
            return result > 0 ? true : false;
        }

        /// <summary>
        /// Update existing fraud maker data with entity values
        /// </summary>
        /// <param name="entity">T_RP_FraudDataMaker entity</param>
        /// <returns>successed flag</returns>
        public int UpdateFraudDataMaker(T_RP_FraudDataMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("CertID", entity.CertID);
            parameters.AddWithValue("CompanyAddrress", entity.CompanyAddress);
            parameters.AddWithValue("CompanyName", entity.CompanyName);
            parameters.AddWithValue("CompanyPhone", entity.CompanyPhone);
            parameters.AddWithValue("CompanyPhoneAreaCode", entity.CompanyPhoneAreaCode);
            parameters.AddWithValue("CompanyPhoneExt", entity.CompanyPhoneExt);
            parameters.AddWithValue("CustName", entity.CustName);
            parameters.AddWithValue("ExpireDate", entity.ExpireDate);
            parameters.AddWithValue("HomeAddrress", entity.HomeAddress);
            parameters.AddWithValue("HomePhone", entity.HomePhone);
            parameters.AddWithValue("HomePhoneAreaCode", entity.HomePhoneAreaCode);
            parameters.AddWithValue("InfoSource", entity.InfoSource);
            parameters.AddWithValue("MobilePhone", entity.MobilePhone);
            parameters.AddWithValue("ReferrerName", entity.ReferrerName);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddWithValue("CreateDate", entity.CreateDate);
            parameters.AddWithValue("Checker", entity.Checker);
            parameters.AddWithValue("ModifiedTime", entity.ModifiedTime);

            parameters.AddOut("NTID", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateFraudDataMaker, parameters);
            return (int)parameters["@NTID"].Value;
        }

        /// <summary>
        /// Approve the fraud data maker requests
        /// </summary>
        /// <param name="ids">TIDs which need to approve</param>
        /// <param name="checker">current user</param>
        /// <returns>successed flag</returns>
        public bool ApproveFraudDataMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveFraudDataMaker, parameters);
            return result > 0 ? true : false;
        }

        /// <summary>
        /// Reject the fraud data maker request
        /// </summary>
        /// <param name="ids">TIDs which need to reject</param>
        /// <param name="checker">current user</param>
        /// <returns>successed flag</returns>
        public bool RejectFraudDataMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RejectFraudDataMaker, parameters);
            return result > 0 ? true : false;
        }
    }
}