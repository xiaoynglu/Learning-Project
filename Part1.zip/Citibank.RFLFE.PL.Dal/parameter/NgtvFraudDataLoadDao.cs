﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class NgtvFraudDataLoadDao : AdoDaoSupport, INgtvFraudDataLoadDao
    {
        public CommonTResult<T_RP_NegativeDataMaker> GetNgtvData()
        {
            CommonTResult<T_RP_NegativeDataMaker> result = new CommonTResult<T_RP_NegativeDataMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_NegativeDataMaker>(CommandType.StoredProcedure, SPNames.PL_GetNgtvDataForDownload, new T_RP_NgtvDataMapper<T_RP_NegativeDataMaker>(), parameters);

            return result;
        }

        public CommonTResult<T_RP_FraudDataMaker> GetFraudData()
        {
            CommonTResult<T_RP_FraudDataMaker> result = new CommonTResult<T_RP_FraudDataMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();


            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_FraudDataMaker>(CommandType.StoredProcedure, SPNames.PL_GetFraudDataForDownload, new T_RP_FraudDataMakerMapper<T_RP_FraudDataMaker>(), parameters);

            return result;
        }
    }
}
