﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class NgtvDataDao : AdoDaoSupport, INgtvDataDao
    {
        /// <summary>
        /// Get Fraud data
        /// </summary>
        /// <returns></returns>
        public CommonTResult<T_RP_NegativeDataMaker> GetNgtvData(int start, int limit, string CustName, string CompanyName, string AgentName, string IDNo, string DOB, string SalesName, string OtherCertID, string Reason, string Status)
        {
            CommonTResult<T_RP_NegativeDataMaker> result = new CommonTResult<T_RP_NegativeDataMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("CustName", CustName);
            parameters.AddWithValue("CompanyName", CompanyName);
            parameters.AddWithValue("AgentName", AgentName);
            parameters.AddWithValue("IDNo", IDNo);
            parameters.AddWithValue("DOB", DOB);
            parameters.AddWithValue("SalesName", SalesName);
            parameters.AddWithValue("OtherCertID", OtherCertID);
            parameters.AddWithValue("Reason", Reason);
            parameters.AddWithValue("Status", Status);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_NegativeDataMaker>(CommandType.StoredProcedure, SPNames.PL_GetNgtvMakerData, new T_RP_NgtvDataMapper<T_RP_NegativeDataMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<T_RP_NegativeDataCheckerView> GetNgtvDataByID(int TID)
        {
            CommonTResult<T_RP_NegativeDataCheckerView> result = new CommonTResult<T_RP_NegativeDataCheckerView>();
            string sql = "select * from T_RP_NegativeData where TID=@TID";
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_NegativeDataCheckerView>(CommandType.Text, sql, new T_RP_NgtvDataCheckerMapper<T_RP_NegativeDataCheckerView>(), parameters);
            return result;
        }

        public CommonTResult<T_RP_NegativeDataMaker> AddDoc(T_RP_NegativeDataMaker entity, string soeID)
        {
            CommonTResult<T_RP_NegativeDataMaker> result = new CommonTResult<T_RP_NegativeDataMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustName", entity.CustName == null ? "" : entity.CustName);
            parameters.AddWithValue("CompanyName", entity.CompanyName== null ? "" : entity.CompanyName);
            parameters.AddWithValue("AgentName", entity.AgentName== null ? "" : entity.AgentName);
            parameters.AddWithValue("IDNo", entity.IDNo== null ? "" : entity.IDNo);
            parameters.AddWithValue("DOB", entity.DOB < DateTime.Parse("1900/01/01") ? DateTime.Parse("1900/01/01") : entity.DOB);
            parameters.AddWithValue("SalesName", entity.SalesName== null ? "" : entity.SalesName);
            parameters.AddWithValue("OtherCertID", entity.OtherCertID== null ? "" : entity.OtherCertID);
            parameters.AddWithValue("Reason", entity.Reason == null ? "" : entity.Reason);
            parameters.AddWithValue("Status", "1");
            parameters.AddWithValue("Optype", "1");
            parameters.AddWithValue("Maker", soeID);            
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_NegativeDataMaker>(CommandType.StoredProcedure, SPNames.PL_AddNgtvMakerData, new T_RP_NgtvDataMapper<T_RP_NegativeDataMaker>(), parameters);

            return result;
        }

        public CommonTResult<T_RP_NegativeDataMaker> UpdateDoc(T_RP_NegativeDataMaker entity, string soeID)
        {
            CommonTResult<T_RP_NegativeDataMaker> result = new CommonTResult<T_RP_NegativeDataMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CustName", entity.CustName == null ? "" : entity.CustName);
            parameters.AddWithValue("CompanyName", entity.CompanyName == null ? "" : entity.CompanyName);
            parameters.AddWithValue("AgentName", entity.AgentName == null ? "" : entity.AgentName);
            parameters.AddWithValue("IDNo", entity.IDNo == null ? "" : entity.IDNo);
            parameters.AddWithValue("DOB", entity.DOB < DateTime.Parse("1900/01/01") ? DateTime.Parse("1900/01/01") : entity.DOB);
            parameters.AddWithValue("SalesName", entity.SalesName == null ? "" : entity.SalesName);
            parameters.AddWithValue("OtherCertID", entity.OtherCertID == null ? "" : entity.OtherCertID);
            parameters.AddWithValue("Reason", entity.Reason == null ? "" : entity.Reason);            
            parameters.AddWithValue("Optype", "2");
            parameters.AddWithValue("Maker", soeID);
            
            parameters.AddWithValue("TID", entity.TID);
            
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_NegativeDataMaker>(CommandType.StoredProcedure, SPNames.PL_UptNgtvMakerData, new T_RP_NgtvDataMapper<T_RP_NegativeDataMaker>(), parameters);

            return result;
        }

        public CommonTResult<T_RP_NegativeDataMaker> DeleteDoc(string TID, string soeID)
        {
            CommonTResult<T_RP_NegativeDataMaker> result = new CommonTResult<T_RP_NegativeDataMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
            parameters.AddWithValue("Maker", soeID);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_NegativeDataMaker>(CommandType.StoredProcedure, SPNames.PL_DelNgtvMakerData, new T_RP_NgtvDataMapper<T_RP_NegativeDataMaker>(), parameters);

            return result;
        }

      
        

    }
}
