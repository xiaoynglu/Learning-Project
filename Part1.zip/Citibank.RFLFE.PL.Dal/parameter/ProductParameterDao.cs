﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Dal.Mappers;


namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class ProductParameterDao : AdoDaoSupport, IProductParameterDao
    {
        public CommonTResult<T_PL_BaseRateMaker> GetBaseRateByProdID(int? prodID)
        {
            CommonTResult<T_PL_BaseRateMaker> result = new CommonTResult<T_PL_BaseRateMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", prodID);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_BaseRateMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_BASERATEBYPRODID, new T_PL_BaseRateMakerMapper<T_PL_BaseRateMaker>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_BaseRateMaker> GetBaseRate(int prodID, string orgCode)
        {
            CommonTResult<T_PL_BaseRateMaker> result = new CommonTResult<T_PL_BaseRateMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", prodID);
            parameters.AddWithValue("OrgCode", orgCode);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_BaseRateMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_BASERATE, new T_PL_BaseRateMakerMapper<T_PL_BaseRateMaker>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_BaseRateMaker> GetBaseRateMOByOrgCode(string orgCode)
        {
            CommonTResult<T_PL_BaseRateMaker> result = new CommonTResult<T_PL_BaseRateMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", orgCode);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_BaseRateMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_BASERATEMOBYORGCODE, new T_PL_BaseRateMakerMapper<T_PL_BaseRateMaker>(), parameters);
            return result;
        }

        public int MakeProdBaseRate(T_PL_BaseRateMaker baseRate)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", baseRate.ProdID);
            parameters.AddWithValue("OrgCode", baseRate.OrgCode);
            parameters.AddWithValue("BaseRate", baseRate.Value);
            parameters.AddWithValue("BaseRateOver5", baseRate.ValueOverFive);
            parameters.AddWithValue("FirstPayRate", baseRate.FirstPayRate);
            parameters.AddWithValue("SecondPayRate", baseRate.SecondPayRate);
            parameters.AddWithValue("Maker", baseRate.Maker);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_MAKEPRODBASERATE, parameters);
        }

        public CommonTResult<T_PL_FeeMaker> GetFeeMakerByTID(int TID)
        {
            CommonTResult<T_PL_FeeMaker> result = new CommonTResult<T_PL_FeeMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_FeeMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_FEEMAKERBYTID, new T_PL_FeeMakerMapper<T_PL_FeeMaker>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_RateMaker> GetRateMakerByTID(int TID)
        {
            CommonTResult<T_PL_RateMaker> result = new CommonTResult<T_PL_RateMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_RateMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_RATEMAKERBYTID, new T_PL_RateMakerMapper<T_PL_RateMaker>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_FeeMaker> GetFees(T_PL_FeeMaker fee)
        {
            CommonTResult<T_PL_FeeMaker> result = new CommonTResult<T_PL_FeeMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", fee.ProdID);
            parameters.AddWithValue("FeeType", fee.FeeType);
            parameters.AddWithValue("CollateralType", fee.CollateralType);
            parameters.AddWithValue("OrgCode", fee.OrgCode);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_FeeMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_FEEMAKERS, new T_PL_FeeMakerMapper<T_PL_FeeMaker>(), parameters);
            return result;
        }

        public CommonTResult<T_PL_RateMaker> GetRates(T_PL_RateMaker rate)
        {
            CommonTResult<T_PL_RateMaker> result = new CommonTResult<T_PL_RateMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", rate.ProdID);
            parameters.AddWithValue("CollateralType", rate.CollateralType);
            parameters.AddWithValue("OrgCode", rate.OrgCode);
            parameters.AddWithValue("IsSecond", rate.IsSecond);
            parameters.AddWithValue("IsOverFive", rate.IsOverFive);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_RateMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_RATEMAKERS, new T_PL_RateMakerMapper<T_PL_RateMaker>(), parameters);
            return result;
        }

        public int SaveFeeMaker(T_PL_FeeMaker fee)
        {
            int typeint = IsSameFee(fee);
             if (typeint != 0)
             {
                 IDbParameters parameters = AdoTemplate.CreateDbParameters();                 
                 parameters.AddWithValue("TID", fee.TID);
                 parameters.AddWithValue("Value", fee.Value);
                 parameters.AddWithValue("Maker", fee.Maker);
                 parameters.AddWithValue("ProdID", fee.ProdID);
                 parameters.AddWithValue("CollateralType", fee.CollateralType);
                 parameters.AddWithValue("OrgCode", fee.OrgCode);
                 parameters.AddWithValue("FeeType", fee.FeeType);
                 parameters.AddWithValue("EmploymentType", fee.EmploymentType);
                 parameters.AddWithValue("Segment", fee.Segment);                 

                 return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_SAVEFEEMAKER, parameters);
             }
             else
             {
                 return 0;
             }

        }

        public int SaveRateMaker(T_PL_RateMaker rate)
        {
            int typeint= IsSameRate(rate);
            if (typeint != 0)
            {
                IDbParameters parameters = AdoTemplate.CreateDbParameters();

                parameters.AddWithValue("typeint", typeint);
                parameters.AddWithValue("TID", rate.TID);
                parameters.AddWithValue("Value", rate.Value);
                parameters.AddWithValue("Spread", rate.Spread);
                parameters.AddWithValue("Maker", rate.Maker);

                parameters.AddWithValue("ProdID", rate.ProdID);
                parameters.AddWithValue("OrgCode", rate.OrgCode);
                parameters.AddWithValue("CollateralType", rate.CollateralType);
                parameters.AddWithValue("EmploymentType", rate.EmploymentType);
                parameters.AddWithValue("Segment", rate.Segment);

                parameters.AddWithValue("IsSecond", rate.IsSecond);
                parameters.AddWithValue("IsOverFive", rate.IsOverFive);


                return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_SAVERATEMAKER, parameters);
            }
            else
            {
                return 0;
            }
        }

        private int IsSameRate(T_PL_RateMaker newRate)
        {
            CommonTResult<T_PL_RateMaker> oldRate = null;
            decimal oldValue, oldSpread;

            oldRate = GetRateMakerByTID(newRate.TID);
            if (oldRate.ResultList.Count != 0)
            {
                oldValue = oldRate.ResultList[0].Value;
                oldSpread = oldRate.ResultList[0].Spread;
                return newRate.Value == oldValue &&
                       newRate.Spread == oldSpread ? 0 : 1;
            }
            else
            {
                return 2;
            }
        }

        private int IsSameFee(T_PL_FeeMaker newFee)
        {
            CommonTResult<T_PL_FeeMaker> oldFee = null;
            decimal oldValue;

            oldFee = GetFeeMakerByTID(newFee.TID);
            if (oldFee.ResultList.Count != 0)
            {
                oldValue = oldFee.ResultList[0].Value;
                return newFee.Value == oldValue ? 0 : 1;
            }
            else
            {
                return 2;
            }
        }

        public IList<T_Sys_Parameters> GetCustSegments(string employType)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("Key", employType);

            IList<T_Sys_Parameters> list = AdoTemplate.QueryWithRowMapper<T_Sys_Parameters>(CommandType.StoredProcedure, SPNames.PL_GET_CUSTSEGMENTS, new T_Sys_ParametersMapper<T_Sys_Parameters>(), parameters);
            return list;
        }

        public CommonTResult<T_PL_DocListMaker> GetDocListMaker(int limit, int start,T_PL_DocListMaker docList)
        {
            CommonTResult<T_PL_DocListMaker> result = new CommonTResult<T_PL_DocListMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdId", docList.ProdID);
            parameters.AddWithValue("DocType", docList.DocType);
            parameters.AddWithValue("CustType", docList.CustType);
            parameters.AddWithValue("CustSegment", docList.CustSegment);
            parameters.AddWithValue("Status", docList.Status);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_DocListMaker>(CommandType.StoredProcedure,
                SPNames.PL_GET_DOCLISTMAKER, new T_PL_DocListMakerMapper<T_PL_DocListMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public int AddDocListMaker(T_PL_DocListMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            if (entity.DocType == 1) {
                parameters.AddWithValue("CustType", entity.CustType);
                parameters.AddWithValue("CustSegment", entity.CustSegment);
            }
            if (entity.DocType == 2)
            {
                parameters.AddWithValue("CustType", String.Empty);
                parameters.AddWithValue("CustSegment", String.Empty);
            }
            parameters.AddWithValue("DocName", entity.DocName);
            parameters.AddWithValue("DocType", entity.DocType);
            parameters.AddWithValue("ProdID", entity.ProdID);
            parameters.AddWithValue("GroupNo", entity.GroupNo);
            parameters.AddWithValue("IsRequired", entity.IsRequired);
            parameters.AddWithValue("Remarks", entity.Remarks);
            parameters.AddWithValue("OpType", entity.OpType);
            parameters.AddWithValue("Status", entity.Status);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddOut("Result", DbType.Int32);
            DataTable dtResult = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_ADD_DOCLISTMAKER, parameters);
            return (int)parameters["@Result"].Value;
        }

        public int SaveDocListMaker(T_PL_DocListMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DocID", entity.DocID);
            parameters.AddWithValue("DocName", entity.DocName);
            parameters.AddWithValue("GroupNo", entity.GroupNo);
            parameters.AddWithValue("IsRequired", entity.IsRequired);
            parameters.AddWithValue("Remarks", entity.Remarks);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ALT_DOCLISTMAKER, parameters);
        }

        public bool DelDocListMaker(string ids, string maker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DocIDs", ids);
            parameters.AddWithValue("Maker", maker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DEL_DOCLISTMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool ApproveBaseRateMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ARE_BASERATEMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectBaseRateMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJ_BASERATEMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool ApproveRateMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ARE_RATEMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectRateMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJ_RATEMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool ApproveFeeMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ARE_FEEMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectFeeMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJ_FEEMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool ApproveDocListMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DocIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ARE_DOCLISTMAKER, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectDocListMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("DocIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_REJ_DOCLISTMAKER, parameters);
            return result > 0 ? true : false;
        }

        public string GetOrgCodeByBranchCode(string branchcode)
        {
            string sql = "select OrgCode from T_Sys_Branch where BranchCode='" + branchcode + "' and BranchName is not null";
            object obj = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.Text, sql);
            string result = "";
            if (obj != null)
                result = obj.ToString().Trim();
            return result;
        }
    }
}
