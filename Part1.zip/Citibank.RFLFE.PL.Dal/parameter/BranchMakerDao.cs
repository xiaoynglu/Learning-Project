﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Data.Generic;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class BranchMakerDao : AdoDaoSupport, IBranchMakerDao
    {

        public Entities.CommonTResult<Entities.T_Sys_BranchMaker> GetBranchDataMaker(Entities.T_Sys_BranchMaker entity, int limit, int start)
        {
            CommonTResult<T_Sys_BranchMaker> result = new CommonTResult<T_Sys_BranchMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("BranchName", entity.BranchName);
            parameters.AddWithValue("status", entity.Status);
            parameters.AddWithValue("statusParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.StatusParamID);
            parameters.AddWithValue("optypeParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.OpTypeParamID); 
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("Start", start);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_BranchMaker>(CommandType.StoredProcedure, SPNames.PL_GetSysBranchMaker, new T_Sys_BranchDataMakerMapper<T_Sys_BranchMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public Entities.CommonTResult<Entities.T_Sys_Branch> GetBranchDataByOrgcode(string orgcode)
        {
            string sql = "select * from [T_Sys_Branch] where orgcode=@orgcode";
            CommonTResult<T_Sys_Branch> result = new CommonTResult<T_Sys_Branch>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("orgcode", orgcode);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_Branch>(CommandType.StoredProcedure, SPNames.PL_GetSysBranchMaker, new T_Sys_BranchMapper<T_Sys_Branch>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<T_Sys_BranchMaker> GetSysBranchPendingChecker(T_Sys_BranchMaker entity, int limit, int start)
        {
            CommonTResult<T_Sys_BranchMaker> result = new CommonTResult<T_Sys_BranchMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("BranchName", entity.BranchName);
            parameters.AddWithValue("status", entity.Status);
            parameters.AddWithValue("statusParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.StatusParamID);
            parameters.AddWithValue("optypeParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.OpTypeParamID);
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("Start", start);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_BranchMaker>(CommandType.StoredProcedure, SPNames.PL_GetSysBranchPendingChecker, new T_Sys_BranchDataMakerMapper<T_Sys_BranchMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public Entities.CommonTResult<Entities.T_Sys_BranchMaker> GetBranchDataPendingChecker(Entities.T_Sys_BranchMaker entity, int limit, int start)
        {
            CommonTResult<T_Sys_BranchMaker> result = new CommonTResult<T_Sys_BranchMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("BranchName", entity.BranchName);
            parameters.AddWithValue("status", entity.Status);
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("Start", start);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_BranchMaker>(CommandType.StoredProcedure, SPNames.PL_GetSysBranchMaker, new T_Sys_BranchDataMakerMapper<T_Sys_BranchMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }


        public int UpdateBranchDataMaker(T_Sys_BranchMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("BranchName", entity.BranchName);
            parameters.AddWithValue("BranchAddress", entity.BranchAddress);
            parameters.AddWithValue("PostCode", entity.PostCode);
            parameters.AddWithValue("Fax", entity.Fax);
            parameters.AddWithValue("Phone", entity.Phone);
            parameters.AddWithValue("RCCode", entity.RCCode);
            parameters.AddWithValue("CityCode", entity.CityCode);
            parameters.AddOut("NTID", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateBranchMaker, parameters);
            return (int)parameters["@NTID"].Value;
        }

        public bool ApproveBranchDataMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveBranchDataMaker, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectBranchDataMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RejectBranchDataMaker, parameters);
            return result > 0 ? true : false;
        }


        public CommonTResult<T_PL_BranchCompanyMaker> GetBranchCompanyMaker(T_PL_BranchCompanyMaker entity, int limit, int start)
        {
            CommonTResult<T_PL_BranchCompanyMaker> result = new CommonTResult<T_PL_BranchCompanyMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("CompanyName", entity.CompanyName);
            parameters.AddWithValue("status", entity.Status);
            parameters.AddWithValue("statusParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.StatusParamID);
            parameters.AddWithValue("optypeParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.OpTypeParamID);
            parameters.AddWithValue("companyTypeParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.CompanyTypeParamID);
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("Start", start);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_BranchCompanyMaker>(CommandType.StoredProcedure, SPNames.PL_GetBranchCompanyMaker, new T_Sys_BranchCompanyMakerMapper<T_PL_BranchCompanyMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }


        public int MergeBranchCompanyMaker(T_PL_BranchCompanyMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("CompanyName", entity.CompanyName);
            parameters.AddWithValue("CompanyType", entity.CompanyType);
            parameters.AddWithValue("OpType", entity.OpType);            
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddOut("NTID", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_MergeBranchCompanyMaker, parameters);
            return (int)parameters["@NTID"].Value;
        }

        public bool ApproveBranchCompanyMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveBranchCompanyMaker, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectBranchCompanyMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RejectBranchCompanyMaker, parameters);
            return result > 0 ? true : false;
        }


        public bool DeleteBranchCompanyMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteBranchCompanyMaker, parameters);
            return result > 0 ? true : false;
        }


        public CommonTResult<T_PL_EvaluationCompanyMaker> GetEvaluationCompanyMaker(T_PL_EvaluationCompanyMaker entity, int limit, int start)
        {
            CommonTResult<T_PL_EvaluationCompanyMaker> result = new CommonTResult<T_PL_EvaluationCompanyMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("CompanyName", entity.CompanyName);
            parameters.AddWithValue("status", entity.Status);
            parameters.AddWithValue("statusParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.StatusParamID);
            parameters.AddWithValue("optypeParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.OpTypeParamID);
            parameters.AddWithValue("evaluationCompanyTypeParamid", Citibank.RFLFE.PL.Dal.Const.ESysParameter.EvaluationCompanyTypeParamid);
            parameters.AddWithValue("Limit", limit);
            parameters.AddWithValue("Start", start);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_EvaluationCompanyMaker>(CommandType.StoredProcedure, SPNames.PL_GetEvaluationCompanyMaker, new T_PL_EvaluationCompanyMakerMapper<T_PL_EvaluationCompanyMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }


        public int MergeBranchEvaluationCompanyMaker(T_PL_EvaluationCompanyMaker entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("OrgCode", entity.OrgCode);
            parameters.AddWithValue("CompanyName", entity.CompanyName);
            parameters.AddWithValue("CompanyType", entity.CompanyType);
            parameters.AddWithValue("Phone", entity.Phone);
            parameters.AddWithValue("ContactName", entity.ContactName);
            parameters.AddWithValue("OpType", entity.OpType);
            parameters.AddWithValue("Maker", entity.Maker);
            parameters.AddOut("NTID", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_MergeBranchEvaluationCompanyMaker, parameters);
            return (int)parameters["@NTID"].Value;
        }

        public bool ApproveBranchEvaluationCompanyMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveBranchEvaluationCompanyMaker, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectBranchEvaluationCompanyMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RejectBranchEvaluationCompanyMaker, parameters);
            return result > 0 ? true : false;
        }

        public bool DeleteBranchEvaluationCompanyMaker(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TIDs", ids);
            parameters.AddWithValue("Checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteBranchEvaluationCompanyMaker, parameters);
            return result > 0 ? true : false;
        }

        public IList<T_Sys_Branch> GetBranchNamesMaker()
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            IList<T_Sys_Branch> list = AdoTemplate.QueryWithRowMapper<T_Sys_Branch>(CommandType.StoredProcedure, SPNames.PL_GetSysBranchNamesMaker, new SysBranchNamesMapper<T_Sys_Branch>(), parameters);
            return list;
        }
    }
}
