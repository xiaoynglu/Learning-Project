﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class RelatedPersonDao : AdoDaoSupport, IRelatedPersonDao
    {
        /// <summary>
        /// Get all related person data
        /// </summary>
        /// <returns>T_RP_RelatedPerson list</returns>
        public CommonTResult<T_RP_RelatedPerson> GetRelatedPersonByID(int tid)
        {
            CommonTResult<T_RP_RelatedPerson> result = new CommonTResult<T_RP_RelatedPerson>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            parameters.AddOut("Count", DbType.Int32);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_RelatedPerson>(CommandType.StoredProcedure, SPNames.PL_GetRelatedPersonByID, new T_RP_RelatedPersonMapper<T_RP_RelatedPerson>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<T_RP_RelatedPerson> GetRelatedPersonChecker(string TID)
        {
            CommonTResult<T_RP_RelatedPerson> result = new CommonTResult<T_RP_RelatedPerson>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
            parameters.AddOut("Count", DbType.Int32);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_RelatedPerson>(CommandType.StoredProcedure, SPNames.PL_GetRelatedPersonByID, new T_RP_RelatedPersonMapper<T_RP_RelatedPerson>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }
    }
}
