﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class NgtvDataCheckerDao : AdoDaoSupport, INgtvDataCheckerDao
    {
        /// <summary>
        /// Get Fraud data
        /// </summary>
        /// <returns></returns>
        public CommonTResult<T_RP_NegativeDataCheckerView> GetNgtvData(int start, int limit, string CustName, string CompanyName, string AgentName, string IDNo, string DOB, string SalesName, string OtherCertID, string Reason, string Status, string Maker, string Checker, string ModifiedTime)
        {
            CommonTResult<T_RP_NegativeDataCheckerView> result = new CommonTResult<T_RP_NegativeDataCheckerView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("CustName", CustName);
            parameters.AddWithValue("CompanyName", CompanyName);
            parameters.AddWithValue("AgentName", AgentName);
            parameters.AddWithValue("IDNo", IDNo);
            parameters.AddWithValue("DOB", DOB);
            parameters.AddWithValue("SalesName", SalesName);
            parameters.AddWithValue("OtherCertID", OtherCertID);
            parameters.AddWithValue("Reason", Reason);
            parameters.AddWithValue("Status", Status);
            parameters.AddWithValue("Maker", Maker);
            parameters.AddWithValue("Checker", Checker);
            parameters.AddWithValue("ModifiedTime", ModifiedTime==""?"": DateTime.Parse(ModifiedTime).Date.ToString("yyyyMMdd"));
            parameters.AddWithValue("ModifiedTimeEnd", ModifiedTime == "" ? "" : DateTime.Parse(ModifiedTime).Date.AddDays(1).ToString("yyyyMMdd"));
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_NegativeDataCheckerView>(CommandType.StoredProcedure, SPNames.PL_GetNgtvCheckerData, new T_RP_NgtvDataCheckerMapper<T_RP_NegativeDataCheckerView>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<T_RP_NegativeDataCheckerView> GetNgtvDataByID(int TID)
        {
            CommonTResult<T_RP_NegativeDataCheckerView> result = new CommonTResult<T_RP_NegativeDataCheckerView>();
            string sql = "select * from T_RP_NegativeData where TID=@TID";
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_NegativeDataCheckerView>(CommandType.Text, sql, new T_RP_NgtvDataCheckerMapper<T_RP_NegativeDataCheckerView>(), parameters);
            return result;
        }

        public bool RejectData(string TID, string approveresult, string soeID)
        {
            CommonTResult<T_RP_NegativeDataCheckerView> result = new CommonTResult<T_RP_NegativeDataCheckerView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
            parameters.AddWithValue("Status", approveresult);
            parameters.AddWithValue("Checker", soeID);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_NegativeDataCheckerView>(CommandType.StoredProcedure, SPNames.PL_RejectNgtvData, new T_RP_NgtvDataCheckerMapper<T_RP_NegativeDataCheckerView>(), parameters);
            

            return result.IsSuccess;
        }

        public bool ApproveNgtvData(string TID, string approveresult, string soeID)
        {
            CommonTResult<T_RP_NegativeDataCheckerView> result = new CommonTResult<T_RP_NegativeDataCheckerView>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", TID);
            parameters.AddWithValue("Status", approveresult);
            parameters.AddWithValue("Checker", soeID);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_NegativeDataCheckerView>(CommandType.StoredProcedure, SPNames.PL_ApproveNgtvData, new T_RP_NgtvDataCheckerMapper<T_RP_NegativeDataCheckerView>(), parameters);           
            return result.IsSuccess;
        }

       
        
    }
}
