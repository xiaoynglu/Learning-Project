﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class FraudDataDao : AdoDaoSupport, IFraudDataDao
    {
        /// <summary>
        /// Get all Fraud data
        /// </summary>
        /// <returns></returns>
        public CommonTResult<T_RP_FraudData> GetFraudDataByID(int tid) 
        {
            CommonTResult<T_RP_FraudData> result = new CommonTResult<T_RP_FraudData>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            parameters.AddOut("Count", DbType.Int32);

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_RP_FraudData>(CommandType.StoredProcedure, SPNames.PL_GetFraudDataByID, new T_RP_FraudDataMapper<T_RP_FraudData>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        /// <summary>
        /// Insert new Fraud data
        /// </summary>
        /// <param name="entity">T_RP_FraudDataMaker entity</param>
        /// <returns>TID</returns>
       public int InsertFraudData(T_RP_FraudData entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("CertID", entity.CertID);
            parameters.AddWithValue("CompanyAddrress", entity.CompanyAddress);
            parameters.AddWithValue("CompanyName", entity.CompanyName);
            parameters.AddWithValue("CompanyPhone", entity.CompanyPhone);
            parameters.AddWithValue("CompanyPhoneAreaCode", entity.CompanyPhoneAreaCode);
            parameters.AddWithValue("CompanyPhoneExt", entity.CompanyPhoneExt);
            parameters.AddWithValue("CustName", entity.CustName);
            parameters.AddWithValue("ExpireDate", entity.ExpireDate);
            parameters.AddWithValue("HomeAddrress", entity.HomeAddress);
            parameters.AddWithValue("HomePhone", entity.HomePhone);
            parameters.AddWithValue("HomePhoneAreaCode", entity.HomePhoneAreaCode);
            parameters.AddWithValue("InfoSource", entity.InfoSource);
            parameters.AddWithValue("MobilePhone", entity.MobilePhone);
            parameters.AddWithValue("ReferrerName", entity.ReferrerName);

            parameters.AddOut("NTID", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_InsertFraudData, parameters);
            return (int)parameters["@NTID"].Value;
        }

        /// <summary>
        /// Delete existing Fraud maker data by tid
        /// </summary>
        /// <param name="tid">tid</param>
        /// <returns>succeed flag</returns>
        public int DeleteFraudData(int tid)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", tid);
            return AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_DeleteFraudData, parameters);
        }

        /// <summary>
        /// Update existing fraud maker data with entity values
        /// </summary>
        /// <param name="entity">T_RP_FraudDataMaker entity</param>
        /// <returns>successed flag</returns>
       public int UpdateFraudData(T_RP_FraudData entity)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("TID", entity.TID);
            parameters.AddWithValue("CertID", entity.CertID);
            parameters.AddWithValue("CompanyAddrress", entity.CompanyAddress);
            parameters.AddWithValue("CompanyName", entity.CompanyName);
            parameters.AddWithValue("CompanyPhone", entity.CompanyPhone);
            parameters.AddWithValue("CompanyPhoneAreaCode", entity.CompanyPhoneAreaCode);
            parameters.AddWithValue("CompanyPhoneExt", entity.CompanyPhoneExt);
            parameters.AddWithValue("CustName", entity.CustName);
            parameters.AddWithValue("ExpireDate", entity.ExpireDate);
            parameters.AddWithValue("HomeAddrress", entity.HomeAddress);
            parameters.AddWithValue("HomePhone", entity.HomePhone);
            parameters.AddWithValue("HomePhoneAreaCode", entity.HomePhoneAreaCode);
            parameters.AddWithValue("InfoSource", entity.InfoSource);
            parameters.AddWithValue("MobilePhone", entity.MobilePhone);
            parameters.AddWithValue("ReferrerName", entity.ReferrerName);

            parameters.AddOut("NTID", DbType.Int32);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_UpdateFraudData, parameters);
            return (int)parameters["@NTID"].Value;
        }
    }
}
