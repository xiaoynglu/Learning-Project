﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class BranchCreationDao : AdoDaoSupport, IBranchCreationDao
    {
        public bool AddBranch(T_Sys_BranchMaker branchentity,string soeID)
        {
            string orgcode = GenerateOrgCode(branchentity.CityCode, branchentity.BranchCode);
            CommonTResult<T_Sys_BranchMaker> result = new CommonTResult<T_Sys_BranchMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", orgcode);
            parameters.AddWithValue("Location", branchentity.Location == null ? "" : branchentity.Location);
            parameters.AddWithValue("BranchCode", branchentity.BranchCode == null ? "" : branchentity.BranchCode);
            parameters.AddWithValue("BranchSimpleCode", branchentity.BranchCode == null ? "" : branchentity.BranchSimpleCode);                
            parameters.AddWithValue("BranchName", branchentity.BranchName == null ? "" : branchentity.BranchName);
            parameters.AddWithValue("BranchAddress", branchentity.BranchAddress == null ? "" : branchentity.BranchAddress);
            parameters.AddWithValue("PostCode", branchentity.PostCode == null ? "" : branchentity.PostCode);
            parameters.AddWithValue("Fax", branchentity.Fax == null ? "" : branchentity.Fax);
            parameters.AddWithValue("Phone", branchentity.Phone == null ? "" : branchentity.Phone);
            parameters.AddWithValue("RCCode", branchentity.RCCode == null ? "" : branchentity.RCCode);
            parameters.AddWithValue("ALSCode", branchentity.ALSCode == null ? "" : branchentity.ALSCode);
            parameters.AddWithValue("CityCode", branchentity.CityCode == null ? "" : branchentity.CityCode);
            parameters.AddWithValue("BM", branchentity.BM == null ? "" : branchentity.BM);
            parameters.AddWithValue("BranchType", branchentity.BranchType);
            parameters.AddWithValue("Status", "1");
            parameters.AddWithValue("Maker", soeID);            

            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_BranchMaker>(CommandType.StoredProcedure, SPNames.PL_AddNewBranch, new T_RP_BranchMapper<T_Sys_BranchMaker>(), parameters);

            return true;
        }

        private string GenerateOrgCode(string CityCode, string BranchCode)
        {
            List<T_Sys_BranchMaker> result = new List<T_Sys_BranchMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("CityCode", CityCode);
            parameters.AddWithValue("BranchCode", BranchCode);
            parameters.AddOut("Result", DbType.String,20);
            AdoTemplate.QueryWithRowMapper<T_Sys_BranchMaker>(CommandType.StoredProcedure, SPNames.PL_GetBranchOrgcode, new T_RP_BranchMapper<T_Sys_BranchMaker>(), parameters);
            return parameters["@Result"].Value.ToString();                        
        }

        public CommonTResult<ComboboxEntity> GetBranchType()
        {
            CommonTResult<ComboboxEntity> result = new CommonTResult<ComboboxEntity>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            result.ResultList = AdoTemplate.QueryWithRowMapper<ComboboxEntity>(CommandType.StoredProcedure, SPNames.PL_GetBranchType, new ComboxMapper<ComboboxEntity>(), parameters);

            return result;
        }
    }
}
