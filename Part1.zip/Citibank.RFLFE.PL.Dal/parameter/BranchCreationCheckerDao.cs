﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IDal;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using System.Data;
using Citibank.RFLFE.PL.Dal.Mappers;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class BranchCreationCheckerDao : AdoDaoSupport, IBranchCreationCheckerDao
    {
        public CommonTResult<T_Sys_BranchMaker> GetBranch(int start,int limit,string BranchCode, string BranchName, string Status, string SoeID)
        {
            CommonTResult<T_Sys_BranchMaker> result = new CommonTResult<T_Sys_BranchMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("start", start);
            parameters.AddWithValue("limit", limit);
            parameters.AddWithValue("BranchCode", BranchCode);
            parameters.AddWithValue("BranchName", BranchName);
            parameters.AddWithValue("Status", Status);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_Sys_BranchMaker>(CommandType.StoredProcedure, SPNames.PL_GetBrahchCheckerData, new T_RP_BranchCheckerMapper<T_Sys_BranchMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public CommonTResult<ComboboxEntity> GetBranchName()
        {
            CommonTResult<ComboboxEntity> result = new CommonTResult<ComboboxEntity>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            result.ResultList = AdoTemplate.QueryWithRowMapper<ComboboxEntity>(CommandType.StoredProcedure, SPNames.PL_GetBranchName, new ComboxMapper<ComboboxEntity>(), parameters);
            return result;
        }

        public bool RejectData(string TID, string approveresult, string SoeID)
        {
             try
            {
                CommonTResult<ComboboxEntity> result = new CommonTResult<ComboboxEntity>();               
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("TID", TID);
                parameters.AddWithValue("Checker", SoeID);
                result.ResultList = AdoTemplate.QueryWithRowMapper<ComboboxEntity>(CommandType.StoredProcedure, SPNames.PL_RejectBranch, new ComboxMapper<ComboboxEntity>(), parameters);
                return true;
               
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool ApproveData(string TID, string approveresult, string SoeID)
        {
            try
            {
                CommonTResult<ComboboxEntity> result = new CommonTResult<ComboboxEntity>();                
                IDbParameters parameters = AdoTemplate.CreateDbParameters();
                parameters.AddWithValue("TID", TID);
                parameters.AddWithValue("Checker", SoeID);
                result.ResultList = AdoTemplate.QueryWithRowMapper<ComboboxEntity>(CommandType.StoredProcedure, SPNames.PL_InsertNewBranchToChecker, new ComboxMapper<ComboboxEntity>(), parameters);
                return true;                
            }
            catch (Exception ex)
            {
                return false;
            }
        }

      


    }
}
