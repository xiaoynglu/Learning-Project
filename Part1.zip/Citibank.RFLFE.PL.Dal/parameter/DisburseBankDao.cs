﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Dal.Mappers;
using System.IO;

namespace Citibank.RFLFE.PL.Dal.parameter
{
    public class DisburseBankDao : AdoDaoSupport, IDisburseBankDao
    {
        public CommonTResult<T_PL_DisburseBankMaker> GetDisburseBankList(int limit, int start, string name, string alias, string status)
        {
            CommonTResult<T_PL_DisburseBankMaker> result = new CommonTResult<T_PL_DisburseBankMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("name", name);
            parameters.AddWithValue("status", status);
            parameters.AddWithValue("alias", alias);
            parameters.AddWithValue("Start", start);
            parameters.AddWithValue("Limit", limit);
            parameters.AddOut("Count", DbType.Int32);
            result.ResultList = AdoTemplate.QueryWithRowMapper<T_PL_DisburseBankMaker>(CommandType.StoredProcedure,
                SPNames.PL_GetDisburseBankList, new T_PL_DisburseBankMakerMapper<T_PL_DisburseBankMaker>(), parameters);
            result.ResultCount = (int)parameters["@Count"].Value;
            return result;
        }

        public bool ApproveItem(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ids", ids);
            parameters.AddWithValue("checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_ApproveDisburseBankMaker, parameters);
            return result > 0 ? true : false;
        }

        public bool RejectItem(string ids, string checker)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ids", ids);
            parameters.AddWithValue("checker", checker);
            int result = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure, SPNames.PL_RejectDisburseBankMaker, parameters);
            return result > 0 ? true : false;
        }

        public int AddOrUpdateDisburseBank(string name, string alias, string id, int optype, string soeid)
        {   
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("name", name);
            parameters.AddWithValue("optype", optype);
            parameters.AddWithValue("alias", alias);
            parameters.AddWithValue("soeid", soeid);
            parameters.AddWithValue("id", id);
            parameters.AddOut("result", DbType.Int32);       
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure,
                SPNames.PL_AddOrUpdateDisburseBank,  parameters);
            var result = 0;
            if (parameters["@result"].Value != System.DBNull.Value)
            {
                result = (int)parameters["@result"].Value;
            }
            return result;
        }

        public bool DeleteDisburseBank(string id)
        {
            CommonTResult<T_PL_DisburseBankMaker> result = new CommonTResult<T_PL_DisburseBankMaker>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("id", id);           
            int i1 = AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(CommandType.StoredProcedure,
                SPNames.PL_DeleteDisburseBank, parameters);
            if (i1 > 0)
                return true;
            else
                return false;
        }
    }
}
