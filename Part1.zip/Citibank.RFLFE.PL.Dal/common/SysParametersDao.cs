﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using Spring.Data.Generic;
using Spring.Data.Common;
using Citibank.RFLFE.PL.Entities;
using Citibank.RFLFE.PL.IDal;
using Citibank.RFLFE.PL.Dal.Mappers;



namespace Citibank.RFLFE.PL.Dal.common
{
    public class SysParametersDao : AdoDaoSupport, ISysParametersDao
    {
        public IList<T_Sys_Parameters> GetSysParamListByID(string paramID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ParamID", paramID);
            parameters.AddWithValue("SubID", string.Empty);
            IList<T_Sys_Parameters> list = AdoTemplate.QueryWithRowMapper<T_Sys_Parameters>(CommandType.StoredProcedure, SPNames.PL_GET_SYSPARAMLISTBYID, new T_Sys_ParametersMapper<T_Sys_Parameters>(), parameters);
            return list;
        }
        public IList<T_Sys_Parameters> GetSysParamListByIDKey(string paramID, string key)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ParamID", paramID);
            parameters.AddWithValue("SubID", key);
            IList<T_Sys_Parameters> list = AdoTemplate.QueryWithRowMapper<T_Sys_Parameters>(CommandType.StoredProcedure, SPNames.PL_GET_SYSPARAMLISTBYID, new T_Sys_ParametersMapper<T_Sys_Parameters>(), parameters);
            return list;
        }
        public IList<T_Sys_Products> GetSysProdNames(int? prodID)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ProdID", prodID);

            IList<T_Sys_Products> list = AdoTemplate.QueryWithRowMapper<T_Sys_Products>(CommandType.StoredProcedure, SPNames.PL_GET_SYSPRODNAMES, new T_Sys_ProductsMapper<T_Sys_Products>(), parameters);
            return list;
        }
       
        public IList<T_Sys_Branch> GetSysBranchNames(string orgCode)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("OrgCode", orgCode);

            IList<T_Sys_Branch> list = AdoTemplate.QueryWithRowMapper<T_Sys_Branch>(CommandType.StoredProcedure, SPNames.PL_GET_SYSBRANCHNAMES, new SysBranchNamesMapper<T_Sys_Branch>(), parameters);
            return list;
        }

        public IList<T_Sys_Region> GetCities(string parentCode)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("parentCode", parentCode);

            IList<T_Sys_Region> list = AdoTemplate.QueryWithRowMapper<T_Sys_Region>(CommandType.StoredProcedure, SPNames.PL_GetCities, new T_Sys_RegionMapper<T_Sys_Region>(), parameters);
            return list;
        }

        public IList<T_Sys_Region> GetProvinces()
        {
            IList<T_Sys_Region> list = AdoTemplate.QueryWithRowMapper<T_Sys_Region>(CommandType.StoredProcedure, SPNames.PL_GetProvinces, new T_Sys_RegionMapper<T_Sys_Region>());
            return list;
        }


        public string GetParamKeyByIDAndValue(string paramId,string paramValue)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("ParamId", paramId);
            parameters.AddWithValue("ParamValue", paramValue);
            parameters.AddOut("Result", DbType.String, 200);
            AdoTemplate.ClassicAdoTemplate.ExecuteNonQuery(
                CommandType.StoredProcedure, SPNames.PL_GetParamKeyByIDAndValue, parameters);
            return parameters["@Result"].Value == System.DBNull.Value ? string.Empty : (string)parameters["@Result"].Value.ToString();
        }

        public string GetRegionCode(string regionName,string parentCode)
        {
            string result = "";
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("RegionName", regionName);
            parameters.AddWithValue("ParentCode", parentCode);
            object o1 = AdoTemplate.ClassicAdoTemplate.ExecuteScalar(CommandType.StoredProcedure, SPNames.PL_GetRegionCode, parameters);
            if (o1 != null)
            {
                result = o1.ToString();
            }
            else
            {
                result = "";
            }
            return result;
        }

        public IList<T_PL_Customers> GetBorrowerNames(Guid appId)
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            parameters.AddWithValue("AppID", appId);

            IList<T_PL_Customers> list = AdoTemplate.QueryWithRowMapper<T_PL_Customers>(CommandType.StoredProcedure, SPNames.PL_GET_BORROWERNAMES, new T_PL_CustomersMapper<T_PL_Customers>(), parameters);
            return list;
        }

        public IList<T_PL_EvaluationCompany> GetEvaluationCompanys()
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();

            IList<T_PL_EvaluationCompany> list = AdoTemplate.QueryWithRowMapper<T_PL_EvaluationCompany>(CommandType.Text, "select * from T_PL_EvaluationCompany", new T_PL_EvaluationCompanyMapper<T_PL_EvaluationCompany>(), parameters);
            return list;
        }

        //获取T_SYS_Parameters 表中所有的参数
        public IList<T_Sys_Parameters> GetAllParamters()
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            IList<T_Sys_Parameters> list = AdoTemplate.QueryWithRowMapper<T_Sys_Parameters>(CommandType.StoredProcedure, SPNames.PL_GetAllParameters, new T_Sys_ParametersMapper<T_Sys_Parameters>(), parameters);
            return list;
        }

        public IList<T_Sys_Region> GetAllRegionInfo()
        {
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            IList<T_Sys_Region> list = AdoTemplate.QueryWithRowMapper<T_Sys_Region>(CommandType.StoredProcedure, SPNames.PL_GetAllRegionInfo, new T_Sys_RegionMapper<T_Sys_Region>(), parameters);
            return list;
        }

        public IDictionary<string, IList<MenuTree>> GetAllMenuTree()
        {
            var returnResult = new Dictionary<string, IList<MenuTree>>();
            IDbParameters parameters = AdoTemplate.CreateDbParameters();
            DataTable dt = AdoTemplate.ClassicAdoTemplate.DataTableCreateWithParams(CommandType.StoredProcedure, SPNames.PL_GetAllSysRoles, parameters);
            parameters.AddWithValue("RoleType", 0);
            if (dt.Rows.Count > 0)
            {
                for (var i = 0; i < dt.Rows.Count; i++)
                {
                    parameters.SetValue("RoleType",Int32.Parse(dt.Rows[i][1].ToString()));
                    
                    var result = AdoTemplate.QueryWithRowMapper<MenuTree>(CommandType.StoredProcedure, SPNames.PL_GetMenuTree, new MenuTreeMapper<MenuTree>(), parameters);
                    returnResult.Add(dt.Rows[i][1].ToString(), result);
                }
            }
            return returnResult;
            
        }
    }
}
