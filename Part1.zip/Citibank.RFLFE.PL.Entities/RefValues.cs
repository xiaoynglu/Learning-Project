﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class RefValues
    {
        public String FileName { get; set; }
        
        public byte[] Bytes { get; set; }
        
        public byte[][] BytesArray { get; set; }

        public string[] Keys { get; set; }
        
        public string[] ReportName { get; set; }

        public string ErrMessage { get; set; }

        
    }
}
