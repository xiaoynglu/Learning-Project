using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_RulesMaker
   {
       public Int32 RuleID
       {
           get;
           set;
       }

       public String RuleName
       {
           get;
           set;
       }

       public String ClassName
       {
           get;
           set;
       }

       public String ReasonID
       {
           get;
           set;
       }

       public String ReferMessage
       {
           get;
           set;
       }

       public String ActualMessage
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }

       public Int32 Status
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime CreateTime
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime ModifiedTime
       {
           get;
           set;
       }

       public String HitType { get;set; }

       public String DeviationLvl { get;set; }

       public String StatusName { get; set; }

   }
}

