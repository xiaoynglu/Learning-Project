﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_DisburseBankMaker
    {
        public String Id { get; set; }
        public String FullName { get; set; }
        public String Alias { get; set; }
        public String Maker { get; set; }
        public String MakeDate { get; set; }
        public String Checker { get; set; }
        public String CheckDate { get; set; }
        public String Operation { get; set; }
        public String OpName { get; set; }        
        public String Status { get; set; }
        public String statusname { get; set; }   
    }
}
