using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_Elements
   {
       public Int32 EleID
       {
           get;
           set;
       }

       public String EleText
       {
           get;
           set;
       }

       public String EleName
       {
           get;
           set;
       }

       public Int32 ParentID
       {
           get;
           set;
       }

       public String Url
       {
           get;
           set;
       }

       public Int32 OrderBy
       {
           get;
           set;
       }

       public String IsValid
       {
           get;
           set;
       }

   }
}

