using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_Params
   {
       public Int32 ParamID
       {
           get;
           set;
       }

       public Int32 RuleID
       {
           get;
           set;
       }

       public String ParamName
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }

       public Int32 OrderBy
       {
           get;
           set;
       }

       public Int32 IsValid
       {
           get;
           set;
       }

   }
}

