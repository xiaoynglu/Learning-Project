using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_ParamValue
   {
       public Int32 RuleID
       {
           get;
           set;
       }

       public Int32 ParamID
       {
           get;
           set;
       }

       public Int32 ProdID
       {
           get;
           set;
       }

       public String OP
       {
           get;
           set;
       }

       public String Value
       {
           get;
           set;
       }

       public String OrgCode
       {
           get;
           set;
       }

       public String CustType
       {
           get;
           set;
       }

       public Int32 OrderBy
       {
           get;
           set;
       }

   }
}

