﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_ReportDefinationDetail  
    {

        public string PreFilename
        {
            get;
            set;
        }

        public int ColNo
        {
            get;
            set;
        }

        public int Required
        {
            get;
            set;
        }

        public int StartPostion
        {
            get;
            set;
        }

        public int EndPostion
        {
            get;
            set;
        }
        
        public int MinLength
        {
            get;
            set;
        }

        public int MaxLength
        {
            get;
            set;
        }

        public int DataType
        {
            get;
            set;
        }

        public String DataFormat
        {
            get;
            set;
        }

        public string ColName
        {
            get;
            set;
        }

        public int DataSource
        {
            get;
            set;
        }

        public int RowNo
        {
            get;
            set;
        }
    }
}
