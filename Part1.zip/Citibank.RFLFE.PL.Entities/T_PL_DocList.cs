using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_DocList
   {
       public Int32 DocID
       {
           get;
           set;
       }

       public Int32 DocType
       {
           get;
           set;
       }

       public String DocName
       {
           get;
           set;
       }

       public Int32 ProdID
       {
           get;
           set;
       }

       public String CustType
       {
           get;
           set;
       }

       public String CustSegment
       {
           get;
           set;
       }

       public String IsRequired
       {
           get;
           set;
       }

       public String GroupNo
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }

   }
}

