﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_ReportDefination
    {

        public int UID
        {
            get;
            set;
        }

        public string PreFilename
        {
            get;
            set;
        }

        public string ReportHDStartTag
        {
            get;
            set;
        }

        public int ReportHDTagStartPos
        {
            get;
            set;
        }

        public int ReportHDTagEndTPos
        {
            get;
            set;
        }

        public int ReportHDRows
        {
            get;
            set;
        }

        public int AvailbleDataRows
        {
            get;
            set;
        }

        public string FooterTag
        {
            get;
            set;
        }

        public int FooterTagStartPos
        {
            get;
            set;
        }

        public int FooterTagEndPos
        {
            get;
            set;
        }

        public int FooterRows
        {
            get;
            set;
        }

        public string SourcePath
        {
            get;
            set;
        }

        public string DestPath
        {
            get;
            set;
        }

        public string SaveFileName
        {
            get;
            set;
        }

        public string DTSName
        {
            get;
            set;
        }

        public string BackUpPath
        {
            get;
            set;
        }

        public string Description
        {
            get;
            set;
        }

        public int FileType
        {
            get;
            set;
        }

        public int SaveDays
        {
            get;
            set;
        }

        public int ReportType
        {
            get;
            set;
        }

        public string TableName
        {
            get;
            set;
        }

        public int DeleteFlag
        {
            get;
            set;
        }

        public string HistoryTable
        {
            get;
            set;
        }

    }
}
