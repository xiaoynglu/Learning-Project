using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_MortgageCognizance
   {
       public Int64 TID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public Int32 CustDeclare
       {
           get;
           set;
       }

       public Int32 ConfirmCustDeclare
       {
           get;
           set;
       }

       public Int32 HouseBureau
       {
           get;
           set;
       }

       public Int32 ConfirmHouseBureau
       {
           get;
           set;
       }

       public Boolean HouseBureauChecked
       {
           get;
           set;
       }

       public Int32 PBOC
       {
           get;
           set;
       }

       public Int32 ConfirmPBOC
       {
           get;
           set;
       }

       public bool PBOCChecked
       {
           get;
           set;
       }

       public Int32 TotalMoCount
       {
           get;
           set;
       }

       public Int32 ConfirmTotalMoCount
       {
           get;
           set;
       }

       public String CreatedId
       {
           get;
           set;
       }

       public DateTime CreatedTime
       {
           get;
           set;
       }

       public String UpdatedId
       {
           get;
           set;
       }

       public DateTime UpdatedTime
       {
           get;
           set;
       }

       public Int32 PBOC_Unliquidated
       {
           get;
           set;
       }

       public Int32 ConfirmPBOC_Unliquidated
       {
           get;
           set;
       }

       public Int32 PBOC_UnliquidatedMatch
       {
           get;
           set;
       }

       public Int32 ConfirmPBOC_UnliquidatedMatch
       {
           get;
           set;
       }

       public Int32 PBOC_SettlementMatch
       {
           get;
           set;
       }

       public Int32 ConfirmPBOC_SettlementMatch
       {
           get;
           set;
       }

       public Int32 TotalMoCount_Orgin
       {
           get;
           set;
       }

       public Int32 ConfirmTotalMoCount_Orgin
       {
           get;
           set;
       }

   }
}

