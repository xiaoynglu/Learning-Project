using System;
using System.Collections;
using System.Text;
using System.Data;
using System.Collections.Generic;

namespace Citibank.RFLFE.PL.Entities
{
    public class ApplyInfoDetail
   {
       public ApplyInfoDetail()
       {
           T_PL_Application = new T_PL_Application();
           T_PL_LoanIndustryMaker = new T_PL_LoanIndustryMaker();
           T_PL_CollateralMaker = new T_PL_CollateralMaker();
           T_PL_LoanIndustry = new T_PL_LoanIndustry();
           T_PL_Collateral = new T_PL_Collateral();
       }

       public T_PL_Application T_PL_Application
       {
           get;
           set;
       }
       public T_PL_LoanIndustryMaker T_PL_LoanIndustryMaker
       {
           get;
           set;
       }
       public T_PL_CollateralMaker T_PL_CollateralMaker
       {
           get;
           set;
       }
       public T_PL_LoanIndustry T_PL_LoanIndustry
       {
           get;
           set;
       }
       public T_PL_Collateral T_PL_Collateral
       {
           get;
           set;
       }
   }
}

