using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_EntrusPay
   {
       public Guid AppID
       {
           get;
           set;
       }

       public String EntrusPayID
       {
           get;
           set;

       }

       public String PayeeName
       {
           get;
           set;
       }

       public String PayeeBankName
       {
           get;
           set;
       }

       public String PayeeBankNameDesc
       {
           get;
           set;
       }

       public String PayeeBankFullName
       {
           get;
           set;
       }

       public String PayeeSubBankName
       {
           get;
           set;
       }

       public String PayeeAccount
       {
           get;
           set;
       }
       public String PaymentAmount
       {
           get;
           set;
       }
   }
}

