﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_Sys_BranchView
    {
        public String OrgCode
        {
            get;
            set;
        }

        public String Location
        {
            get;
            set;
        }

        public String BranchCode
        {
            get;
            set;
        }

        public String BranchName
        {
            get;
            set;
        }

        public String BranchAddress
        {
            get;
            set;
        }

        public String PostCode
        {
            get;
            set;
        }

        public String Fax
        {
            get;
            set;
        }

        public String Phone
        {
            get;
            set;
        }

        public String RCCode
        {
            get;
            set;
        }

        public String CityCode
        {
            get;
            set;
        }

        public String ALSCode
        {
            get;
            set;
        }

        public String BM
        {
            get;
            set;
        }

        public Int32 BranchType
        {
            get;
            set;
        }
        public String Status
        {
            get;
            set;
        }
        public String OpType
        {
            get;
            set;
        }
    }
}
