using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_ADR
   {
       public Guid AppID
       {
           get;
           set;
       }

       public Int32 ProdID
       {
           get;
           set;
       }

       public string ProdName { get; set; }

       public string Result
       {
           get;
           set;
       }

       public String Deviated
       {
           get;
           set;
       }

       public String DeviationLevel
       {
           get;
           set;
       }

       public String ProposalDeviated
       {
           get;
           set;
       }

       public String BMDeviated
       {
           get;
           set;
       }

       public Decimal LoanAmount
       {
           get;
           set;
       }

       public String LoanTenor
       {
           get;
           set;
       }

       public Decimal Installment
       {
           get;
           set;
       }

       public Decimal BaseRate
       {
           get;
           set;
       }

       public Decimal InterestRate
       {
           get;
           set;
       }

       public Decimal CurrDBR
       {
           get;
           set;
       }

       public Decimal TotalDBR
       {
           get;
           set;
       }

       public Decimal AvaliableLTV
       {
           get;
           set;
       }

       public Decimal MaxLTV
       {
           get;
           set;
       }

       public String CustSegment
       {
           get;
           set;
       }

       public String RiskSegment
       {
           get;
           set;
       }

       public Decimal DSCR
       {
           get;
           set;
       }

       public String PolicyDeviated
       {
           get;
           set;
       }

       public String PolicyDeviationReason
       {
           get;
           set;
       }

       public String PriceDeviated
       {
           get;
           set;
       }

       public String PriceDeviationReason
       {
           get;
           set;
       }

       public String ProcessDeviated
       {
           get;
           set;
       }

       public String ProcessDeviationReason
       {
           get;
           set;
       }

       public String DeviationRemarks
       {
           get;
           set;
       }

       public String RateException
       {
           get;
           set;
       }

       public String RefreshDate
       {
           get;
           set;
       }

       public String ProcID
       {
           get;
           set;
       }

   }
}

