using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_ParamValueMaker
   {
       public Int32 TID
       {
           get;
           set;
       }

       public Int32 RuleID
       {
           get;
           set;
       }

       public Int32 ParamID
       {
           get;
           set;
       }

       public Int32 ProdID
       {
           get;
           set;
       }

       public String OP
       {
           get;
           set;
       }

       public String Value
       {
           get;
           set;
       }

       public String OrgCode
       {
           get;
           set;
       }

       public Int32 OrderBy
       {
           get;
           set;
       }

       public Int32 Status
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime CreateTime
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime ModifiedTime
       {
           get;
           set;
       }

   }
}

