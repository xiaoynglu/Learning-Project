﻿using System;
using System.Collections;
using System.Text;
using System.Data;
using System.Collections.Generic;

namespace Citibank.RFLFE.PL.Entities
{
    public class ApplicationDetail
    {
        public T_PL_Application Application { get; set; }
        public T_PL_Loan Loan { get; set; }
        public List<T_PL_Customers> Borrowers { get; set; }
        public List<T_PL_Mortgagors> Mortgagtors { get; set; }
        public List<T_PL_Guarantors> Guarantors { get; set; }
        public List<T_PL_LoanIndustry> LoanIndustry { get; set; }
        public List<T_PL_LTVFactors> LTVFactors { get; set; }
        public T_PL_Collateral Collateral { get; set; }
        public List<T_PL_AcceptService> AcceptServices { get; set; }
        public T_PL_EntrusPay EntrustPay { get; set; }
        public T_PL_SelfPay SelfPay { get; set; }
        public List<T_PL_SalaryCust> SalaryCust { get; set; }
        public List<T_PL_SelfEmployedCust> SelfEmployedCust { get; set; }
        public List<T_PL_CustomerContact> CustomerContacts { get; set; }
        public List<T_PL_SABudget> SABudget { get; set; }
        public List<T_PL_SEBudget> SEBudget { get; set; }
        public List<T_PL_CustDebt> CustIncomeDebt { get; set; }
        public List<T_PL_OralAppraisal> OralAppraisal { get; set; }
        public T_PL_LoanApproval LoanApproval { get; set; }
        public List<T_PL_FamilyMembers> FamilyMembers { get; set; }
        public T_PL_SellerInfo SellerInfo { get; set; }
        public List<T_PL_VerificationRecord> VerificationRecords { get; set; }
    }
}
