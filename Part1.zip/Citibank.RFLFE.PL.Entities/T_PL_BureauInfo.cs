﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_BureauInfo
    {
        public String AppId
        {
            get;
            set;
        }

        public String TODAY
        {
            get;
            set;
        }

        public String CERT_TYPE
        {
            get;
            set;
        }

        public String CERT_ID
        {
            get;
            set;
        }

        public String FULLNAME
        {
            get;
            set;
        }

        public String FoundBureauFile
        {
            get;
            set;
        }

        public String INQUIRY_NAME
        {
            get;
            set;
        }

        public String ID_TYPE
        {
            get;
            set;
        }

        public String ID_NUMBER
        {
            get;
            set;
        }

        public String INQUIRER
        {
            get;
            set;
        }

        public String Inquiryreason
        {
            get;
            set;
        }

        public String NAME
        {
            get;
            set;
        }

        public String SEX
        {
            get;
            set;
        }

        public String BIRTHDAY
        {
            get;
            set;
        }

        public String HIGHEST_EDUCATION
        {
            get;
            set;
        }

        public String CONTACT_ADDRESS
        {
            get;
            set;
        }

        public String ZIP_CODE
        {
            get;
            set;
        }

        public String HOME_ADDRESS
        {
            get;
            set;
        }

        public String HOUSE_PHONE_NUMBER
        {
            get;
            set;
        }

        public String EMPLOYER_UNIT_PHONE
        {
            get;
            set;
        }

        public String MOBILE_PHONE
        {
            get;
            set;
        }

        public String EMAIL
        {
            get;
            set;
        }

        public String MARRIAGE_STATUS
        {
            get;
            set;
        }

        public String SPOUSE_NAME
        {
            get;
            set;
        }

        public String SPOUSE_ID_TYPE
        {
            get;
            set;
        }

        public String SPOUSE_ID_NUMBER
        {
            get;
            set;
        }

        public String SPOUSE_EMPLOYER_UNIT
        {
            get;
            set;
        }

        public String SPOUSE_CONTACT_NUMBER
        {
            get;
            set;
        }

        public String INF_CAPTURE_TIME
        {
            get;
            set;
        }

        public String WORKING_YEAR_IN_CURRENT_INDUSTRY
        {
            get;
            set;
        }

        public String TOTAL_WORKING_YEAR
        {
            get;
            set;
        }

        public String UTI
        {
            get;
            set;
        }

        public String ExposureIncome
        {
            get;
            set;
        }

        public String TURT
        {
            get;
            set;
        }

        public String OLDEST_MOB
        {
            get;
            set;
        }

        public String LATEST_MOB
        {
            get;
            set;
        }

        public String TOTAL_INSTALLMENT_OF_TOTAL_LOANS
        {
            get;
            set;
        }

        public String TOTAL_INSTALLMENT_OF_UNSECURED_LOANS
        {
            get;
            set;
        }

        public String NUMBER_OF_M1_IN_LAST_24_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M1_IN_LAST_12_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M1_IN_LAST_6_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M2_IN_LAST_24_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M2_IN_LAST_12_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M2_IN_LAST_6_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M3_IN_LAST_24_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M3_IN_LAST_12_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M3_IN_LAST_6_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M4_IN_LAST_24_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M4_IN_LAST_12_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_OF_M4_IN_LAST_6_MONTHS
        {
            get;
            set;
        }

        public String NUMBER_CURRENT_M1
        {
            get;
            set;
        }

        public String NUMBER_CURRENT_M2
        {
            get;
            set;
        }

        public String NUMBER_CURRENT_M3
        {
            get;
            set;
        }

        public String NUMBER_CURRENT_M4
        {
            get;
            set;
        }

        public String TOTAL_NUM_OF_ENQUIRY
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_ENQUIRY12
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_ENQUIRY6
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_ENQUIRY3
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_NEW_ENQUIRY12
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_NEW_ENQUIRY6
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_NEW_ENQUIRY3
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_NEW_ENQUIRY
        {
            get;
            set;
        }

        public String TOTAL_CURRENT_PAST_DUE_AMOUNT
        {
            get;
            set;
        }

        public String NUMBER_OF_ACCOUT_NOT_NORMAL_CLOSED24
        {
            get;
            set;
        }

        public String HIGHEST_DELINQUENT_24
        {
            get;
            set;
        }

        public String HIGHEST_DELINQUENT_12
        {
            get;
            set;
        }

        public String CURRENT_WORST_DELINQUENT
        {
            get;
            set;
        }

        public Decimal Bureau_Monthly_Income
        {
            get;
            set;
        }

        public String Satisfactory_Trades
        {
            get;
            set;
        }

        public Decimal bankcard_trades_Larger_75_Per
        {
            get;
            set;
        }

        public String BankCard_Credit_Utilization
        {
            get;
            set;
        }

        public Decimal trades_never_delinquent
        {
            get;
            set;
        }

        public String Smaller_month
        {
            get;
            set;
        }

        public String Inquiry_Count
        {
            get;
            set;
        }

        public String delq_month_in_24_month
        {
            get;
            set;
        }

        public String External_DBR_Percent
        {
            get;
            set;
        }

        public String TOTAL_OF_CREDIT_CARD
        {
            get;
            set;
        }

        public String TOTAL_OF_LOAN
        {
            get;
            set;
        }

        public String TOTAL_OF_LOAN_UNSECURED
        {
            get;
            set;
        }

        public String TOTAL_OUTSTANDING_BALANCE
        {
            get;
            set;
        }

        public String TOTAL_OUTSTANDING_BALANCE_CREDIT_CARD
        {
            get;
            set;
        }

        public String TOTAL_CREDIT_LIMIT
        {
            get;
            set;
        }

        public String TOTAL_OVERDRAFT_180
        {
            get;
            set;
        }

        public Decimal CREDIT_LIMIT_C_D
        {
            get;
            set;
        }

        public String OVERDRAFT
        {
            get;
            set;
        }

        public String OVERDRAFT_LINE_OUTSTANDING_180
        {
            get;
            set;
        }

        public String ACCOUNT_NUMBER
        {
            get;
            set;
        }

        public String CREDIT_LIMIT_C
        {
            get;
            set;
        }

        public String USED_CREDIT_LINE
        {
            get;
            set;
        }

        public String COMPANY_NAME
        {
            get;
            set;
        }

        public String RESIDE_ADDRESS_FIRST
        {
            get;
            set;
        }

        public String RESIDE_STATUS_FIRST
        {
            get;
            set;
        }

        public String RESIDE_ADDRESS_SECOND
        {
            get;
            set;
        }

        public String RESIDE_STATUS_SECOND
        {
            get;
            set;
        }

        public String EMPLOYER_UNIT_NAME_FIRST
        {
            get;
            set;
        }

        public String EMPLOYER_UNIT_ADDRESS_FIRST
        {
            get;
            set;
        }

        public String CAREER_FIRST
        {
            get;
            set;
        }

        public String POSITION_FIRST
        {
            get;
            set;
        }

        public String ANNUAL_INCOME_FIRST
        {
            get;
            set;
        }

        public String EMPLOYER_UNIT_NAME_SECOND
        {
            get;
            set;
        }

        public String EMPLOYER_UNIT_ADDRESS_SECOND
        {
            get;
            set;
        }

        public String CAREER_SECOND
        {
            get;
            set;
        }

        public String POSITION_SECOND
        {
            get;
            set;
        }

        public String ANNUAL_INCOME_SECOND
        {
            get;
            set;
        }

        public String TOTAL_CHARGE_OFF
        {
            get;
            set;
        }

        public String SUM_OF_CERTAIN_LOAN_CARD_OVERDRAW_BALANCE
        {
            get;
            set;
        }

        public String SUM_OF_LOAN_CARD_OVERDRAW_BALANCE
        {
            get;
            set;
        }

        public String SUM_OF_LOAN_CARD_MONTH_OUGHT_PAY
        {
            get;
            set;
        }

        public String SUM_OF_LOAN_CARD_MONTH_PRACTICAL_PAY
        {
            get;
            set;
        }

        public String COUNT_OF_LOAN_CARD_NOT_FULL_PAY
        {
            get;
            set;
        }

        public String SUM_OF_LOANS_BALANCE
        {
            get;
            set;
        }

        public String SUM_OF_LOANS_MONTH_OUGHT_PAY
        {
            get;
            set;
        }

        public String COUNT_OUTSTANDING_MORTGAGES
        {
            get;
            set;
        }

        public String COUNT_OF_GRZFDK
        {
            get;
            set;
        }

        public String COUNT_OF_ZFGJJ
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_CardQ
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_CardQ3
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_CardQ6
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_CardQ12
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_LOAN_UNSECURED
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OTHERLOAN_SECURED
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OS_CREDIT
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_UNSECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_SECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_OTHERLOAN_SECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_OUGHT_PAY_UNSECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_OUGHT_PAY_SECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_OTHERLOAN_OUGHT_PAY_SECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_PRACTICAL_PAY_UNSECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_PRACTICAL_PAY_SECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_OTHERLOAN_PRACTICAL_PAY_SECURED
        {
            get;
            set;
        }

        public String COUNT_Previous_Write_Off
        {
            get;
            set;
        }

        public String Count_Current_M1_Accounts
        {
            get;
            set;
        }

        public String Count_Current_M2_Accounts
        {
            get;
            set;
        }

        public String Count_Open_Unsecured_Loan
        {
            get;
            set;
        }

        public string ImportDate
        {
            get;
            set;
        }

        public string SERIAL_NO2
        {
            get;
            set;
        }

        public DateTime? ModiDate
        {
            get;
            set;
        }

        public string LitigationRecord
        {
            get;
            set;
        }

        public string LoanGrade
        {
            get;
            set;
        }

        public String OLDEST_MOB_Edit
        {
            get;
            set;
        }

        public String TOTAL_CHARGE_OFF_Edit
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_LOAN_UNSECURED_Edit
        {
            get;
            set;
        }

        public String COUNT_OUTSTANDING_MORTGAGES_Edit
        {
            get;
            set;
        }

        public String NUMBER_OF_M1_IN_LAST_6_MONTHS_Edit
        {
            get;
            set;
        }

        public String NUMBER_CURRENT_M1_Edit
        {
            get;
            set;
        }

        public String NUMBER_OF_M2_IN_LAST_6_MONTHS_Edit
        {
            get;
            set;
        }

        public String NUMBER_CURRENT_M2_Edit
        {
            get;
            set;
        }

        public String NUMBER_OF_M2_IN_LAST_12_MONTHS_Edit
        {
            get;
            set;
        }

        public String NUMBER_OF_M3_IN_LAST_24_MONTHS_Edit
        {
            get;
            set;
        }

        public String NUMBER_OF_M2_IN_LAST_24_MONTHS_Edit
        {
            get;
            set;
        }

        public String NUMBER_OF_M3_IN_LAST_12_MONTHS_Edit
        {
            get;
            set;
        }

        public String TOTAL_NUMBER_OF_ENQUIRY3_Edit
        {
            get;
            set;
        }

        public String BankCard_Credit_Utilization_Edit
        {
            get;
            set;
        }

        public String ModiBy
        {
            get;
            set;
        }
    }
}
