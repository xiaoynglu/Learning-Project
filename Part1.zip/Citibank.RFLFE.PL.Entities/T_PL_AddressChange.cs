using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_AddressChange
   {
       public Int32 TID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public Guid CustID
       {
           get;
           set;
       }

       public String Province
       {
           get;
           set;
       }

       public String City
       {
           get;
           set;
       }

       public String District
       {
           get;
           set;
       }

       public String Street
       {
           get;
           set;
       }

       public String MobilePhone
       {
           get;
           set;
       }

       public String AreaCode
       {
           get;
           set;
       }

       public String PhoneNumber
       {
           get;
           set;
       }

       public String PhoneExt
       {
           get;
           set;
       }

       public DateTime ImportDate
       {
           get;
           set;
       }

       public String ProcID
       {
           get;
           set;
       }

   }
}

