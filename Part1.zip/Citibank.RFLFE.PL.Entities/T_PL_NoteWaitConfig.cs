﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public  class T_PL_NoteWaitConfig
    {
        public int TID { get; set; }
        public int StageID { get; set; }
        public string PanelID { get; set; }
        public string PanelType { get; set; }
        public string PanelTitle { get; set; }
        public string appid { get; set; }
        public string StageName { get; set; }
        public string AppNo { get; set; }
        public string Controller { get; set; }
        public string EleName { get; set; }
        public string status { get; set; }
        public string procdate { get; set; }
        public string CustomerName { get; set; }
        public string ProdName { get; set; }
        public string isnew { get; set; }  
                  
        
    }
}
