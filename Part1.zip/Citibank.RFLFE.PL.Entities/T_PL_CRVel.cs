using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_CRVel
   {
       public String T_VelCR
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public String MatchCode
       {
           get;
           set;
       }

       public String AppNo
       {
           get;
           set;
       }

       public String CustName
       {
           get;
           set;
       }

       public String ReferName
       {
           get;
           set;
       }

       public String CompanyName
       {
           get;
           set;
       }

       public String Hphone
       {
           get;
           set;
       }

       public String Mphone
       {
           get;
           set;
       }

       public String Ophone
       {
           get;
           set;
       }

       public String Haddr
       {
           get;
           set;
       }

       public String Oaddr
       {
           get;
           set;
       }

       public String Vel_PersonID
       {
           get;
           set;
       }

       public String ParaName
       {
           get;
           set;
       }

       public String ParaPhone
       {
           get;
           set;
       }

       public String ParaMbile
       {
           get;
           set;
       }

       public String OthName
       {
           get;
           set;
       }

       public String OthPhone
       {
           get;
           set;
       }

       public String OthMBile
       {
           get;
           set;
       }

       public String SpouseName
       {
           get;
           set;
       }

   }
}

