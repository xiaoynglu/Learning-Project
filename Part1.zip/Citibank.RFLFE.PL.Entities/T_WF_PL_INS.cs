using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_WF_PL_INS
   {
       public Guid AppID
       {
           get;
           set;
       }
       public String AppNo
       {
           set;
           get;
       }
       public String IDNo
       {
           set;
           get;
       }
       public Int32 StageID
       {
           get;
           set;
       }
       public String StageName
       {
           set;
           get;
       }
       public String SoeID
       {
           set;
           get;
       }
       public String Status
       {
           get;
           set;
       }
       public String StatusDesc
       {
           get;
           set;
       }

       public String CurrentProcessor
       {
           get;
           set;
       }

       public String ExecID
       {
           get;
           set;
       }

       public String SalesID
       {
           get;
           set;
       }
       public String CreateDate
       {
           get;
           set;
       }

       public String ProcDate
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }
       public String Action
       {
           set;
           get;
       }


       public Guid CustID
       {
           set;
           get;
       }

       public String FirstName
       {
           get;
           set;
       }

       public String LastName
       {
           get;
           set;
       }

       public String CustomerName
       {
           set;
           get;
       }

       public int ProdID
       {
           set;
           get;
       }

       public String ProdName
       {
           set;
           get;
       }


       public String DateBegin
       {
           set;
           get;
       }

       public String DateEnd
       {
           set;
           get;
       }
       public String PickupTime
       {
           set;
           get;
       }

       public int StepID
       {
           get;
           set;
       }
       public string StepName
       {
           get;
           set;
       }

       public Boolean IsLocked
       {
           get;
           set;
       }
       public String PendingReason
       {
           get;
           set;
       }
   }
}

