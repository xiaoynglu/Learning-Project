using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_VerificationRecord
   {
       public Guid CustID
       {
           get;
           set;
       }

       public String CustType
       {
           get;
           set;
       }

       public String BorrowType
       {
           get;
           set;
       }

       public Boolean VerifiedPhone
       {
           get;
           set;
       }

       public Boolean VerifiedInternet
       {
           get;
           set;
       }

       public Boolean Verified114
       {
           get;
           set;
       }

       public Boolean VerifiedOther
       {
           get;
           set;
       }

       public String VerifiedOtherRemark
       {
           get;
           set;
       }

       public String PhoneReason
       {
           get;
           set;
       }

       public String PhoneResult
       {
           get;
           set;
       }

       public Boolean VerifiedSite
       {
           get;
           set;
       }

       public String SiteReason
       {
           get;
           set;
       }

       public String SiteResult
       {
           get;
           set;
       }

       public Boolean VerifiedHouse
       {
           get;
           set;
       }

       public String HouseReason
       {
           get;
           set;
       }

       public String HouseResult
       {
           get;
           set;
       }

       public Boolean VerifiedExternal
       {
           get;
           set;
       }

       public String ExternalReason
       {
           get;
           set;
       }

       public String ExternalResult
       {
           get;
           set;
       }

       public Boolean VerifiedWorking
       {
           get;
           set;
       }

       public String WorkingReason
       {
           get;
           set;
       }

       public String WorkingResult
       {
           get;
           set;
       }

   }
}

