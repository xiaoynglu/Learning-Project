using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_CustomerContact
   {
       public Guid CustID
       {
           get;
           set;
       }

       public String HouseProvince
       {
           get;
           set;
       }

       public String HouseCity
       {
           get;
           set;
       }

       public String HouseDistrict
       {
           get;
           set;
       }

       public String HouseStreet
       {
           get;
           set;
       }

       public String HousePostCode
       {
           get;
           set;
       }

       public String HouseStatus
       {
           get;
           set;
       }

       public String HouseTelAreaCode
       {
           get;
           set;
       }

       public String HouseTelNumber
       {
           get;
           set;
       }

       public String HouseSameAsResidence
       {
           get;
           set;
       }

       public String ResidenceProvince
       {
           get;
           set;
       }

       public String ResidenceCity
       {
           get;
           set;
       }

       public String ResidenceDistrict
       {
           get;
           set;
       }

       public String ResidenceStreet
       {
           get;
           set;
       }

       public String ResidencePostCode
       {
           get;
           set;
       }

       public String ResidenceTelAreaCode
       {
           get;
           set;
       }

       public String ResidenceTelNumber
       {
           get;
           set;
       }

       public String WorkingProvince
       {
           get;
           set;
       }

       public String WorkingCity
       {
           get;
           set;
       }

       public String WorkingDistrict
       {
           get;
           set;
       }

       public String WorkingStreet
       {
           get;
           set;
       }

       public String WorkingPostCode
       {
           get;
           set;
       }

       public String WorkingTelAreaCode
       {
           get;
           set;
       }

       public String WorkingTelNumber
       {
           get;
           set;
       }

       public String WorkingTelExtNumber
       {
           get;
           set;
       }

       public String CommunicationAddressAs
       {
           get;
           set;
       }

       public String MobileNumber
       {
           get;
           set;
       }

       public String Email
       {
           get;
           set;
       }

       public DateTime IDIssueDate
       {
           get;
           set;
       }

       public DateTime IDExpireDate
       {
           get;
           set;
       }

       public String IDIssuePlace
       {
           get;
           set;
       }

       public String OtherContactName
       {
           get;
           set;
       }

       public String OtherContactRelation
       {
           get;
           set;
       }

       public String OtherContactTelAreaCode
       {
           get;
           set;
       }

       public String OtherContactTelNumber
       {
           get;
           set;
       }

       public String OtherContactTelExtNumber
       {
           get;
           set;
       }

       public String OtherContactMobile
       {
           get;
           set;
       }

       public String OtherContactCompany
       {
           get;
           set;
       }

       public String RelativeName
       {
           get;
           set;
       }

       public String RelativeRelation
       {
           get;
           set;
       }

       public String RelativeCompany
       {
           get;
           set;
       }

       public String RelativeTelAreaCode
       {
           get;
           set;
       }

       public String RelativeTelNumber
       {
           get;
           set;
       }

       public String RelativeTelExtNumber
       {
           get;
           set;
       }

       public String RelativeMobile
       {
           get;
           set;
       }

   }
}

