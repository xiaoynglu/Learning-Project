using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_FraudData
   {
       public Int32 TID
       {
           get;
           set;
       }

       public String CustName
       {
           get;
           set;
       }

       public String CompanyName
       {
           get;
           set;
       }

       public String HomeAddress
       {
           get;
           set;
       }

       public String CompanyAddress
       {
           get;
           set;
       }

       public String HomePhoneAreaCode
       {
           get;
           set;
       }

       public String HomePhone
       {
           get;
           set;
       }

       public String MobilePhone
       {
           get;
           set;
       }

       public String CompanyPhoneAreaCode
       {
           get;
           set;
       }

       public String CompanyPhone
       {
           get;
           set;
       }

       public String CompanyPhoneExt
       {
           get;
           set;
       }

       public String ReferrerName
       {
           get;
           set;
       }

       public String InfoSource
       {
           get;
           set;
       }

       public String CertID
       {
           get;
           set;
       }

       public String ExpireDate
       {
           get;
           set;
       }

      

         

   }
}

