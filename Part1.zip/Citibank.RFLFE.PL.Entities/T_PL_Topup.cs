using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_Topup
   {
       public Guid TopupID
       {
           get;
           set;
       }

       public String OrgLoanNumber
       {
           get;
           set;
       }

       public String OrgApplicationNo
       {
           get;
           set;
       }

       public String OrgSegment
       {
           get;
           set;
       }

       public String TopUpSegment
       {
           get;
           set;
       }

       public String CurrentAppNo
       {
           get;
           set;
       }

       public Guid CurrentAppID
       {
           get;
           set;
       }

       public String CreatorID
       {
           get;
           set;
       }

       public DateTime CreateDate
       {
           get;
           set;
       }

   }
}

