﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_AppAuditLog
    {
        public int TID { get; set; }
        public String AppID { get; set; }
        public String AppNO { get; set; }
        public String StageID { get; set; }
        public String RequestType { get; set; }
        public String RequestTypeShow { get; set; }
        public String StageName { get; set; }
        public String LogType { get; set; }
        public String TableName { get; set; }
        public String GroupNumber { get; set; }
        public String LogContent { get; set; }
        public String OperationLog { get; set; }
        public String Operator { get; set; }
        public String OperateTime { get; set; }
    }
}
