﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_DWH
    {
        public String FileType
        {
            get;
            set;
        }

        public String FileName
        {
            get;
            set;
        }

        public String DateBegin
        {
            get;
            set;
        }

        public String DateEnd
        {
            get;
            set;
        }
    }
}
