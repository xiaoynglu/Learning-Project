﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_MISReportTemplate
    {
        public Int32 Id
        {
            get;
            set;
        }

        public String Name
        {
            get;
            set;
        }

        public String SoeId
        {
            get;
            set;
        }

        public String RepNo
        {
            get;
            set;
        }

        public String CreateDate
        {
            get;
            set;
        }
    }
}
