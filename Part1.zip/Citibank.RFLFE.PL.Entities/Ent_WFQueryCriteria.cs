using System;
using System.Collections.Generic;
using System.Text;


namespace Citibank.RFLFE.PL.Entities
{
    [Serializable]
    public class Ent_WFQueryCriteria 
    {
        /*
        private Map_WFQueryGriteria mapWFQueryCriteria;
        public Map_WFQueryGriteria MapWFQueryGriteria
        {
            get {return mapWFQueryCriteria;}
            set {mapWFQueryCriteria=valus;}
        }
        */
        private string  appNo;
        public string AppNo
        {
            get { return appNo; }
            set {appNo = value; }
        }

        //�ͻ�������֤����
        private string customerID;
        public string CustomerID
        {
            get { return customerID; }
            set { customerID = value; }
        }
        //�ͻ���CN����ȫƴ
        private string customerName;
        public string CustomerName
        {
            get { return customerName; }
            set { customerName = value; }
        }

        //��Ʒ�����֣�HE,UPL��
        private int  product;
        public int Product
        {
            get { return product; }
            set { product = value; }
        }

        //��ʼ�Ĳ�ѯʱ�䣬��ʽΪ��yyyy/MM/dd
        private DateTime  dateEnd;
        public DateTime DateEnd
        {
            get { return dateEnd; }
            set { dateEnd = value; }
        }

        //�����Ĳ�ѯʱ�䣬��ʽΪ��yyyy/MM/dd
        private DateTime  dateBegin;
        public DateTime DateBegin
        {
            get { return dateBegin; }
            set { dateBegin = value; }
        }

        //��ǰ�Ĵ�����
        private string processor;
        public string Processor
        {
            get { return processor; }
            set { processor = value; }
        }

        //��ǰ��״̬
        private string status;
        public string Status
        {
            get { return status; }
            set { status = value; }
        }

        //��ǰ�Ľڵ�ID
        private int stageID;
        public int StageID
        {
            get { return stageID; }
            set { stageID = value; }
        }

        //��֯����
        private string orgCode;
        public string OrgCode
        {
            get { return orgCode; }
            set { orgCode = value; }
        }

        //userid
        private string soeid;
        public string Soeid
        {
            get { return soeid; }
            set { soeid = value; }
        }

        //role type
        private int roleType;
        public int RoleType
        {
            get { return roleType; }
            set { roleType = value; }
        }


    }
}
