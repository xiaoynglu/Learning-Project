using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_Rules
   {
       public Int32 RuleID
       {
           get;
           set;
       }

       public String RuleName
       {
           get;
           set;
       }

       public String ClassName
       {
           get;
           set;
       }

       public Int32 ReasonID
       {
           get;
           set;
       }

       public String ReferMessage
       {
           get;
           set;
       }

       public String ActualMessage
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }

   }
}

