using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_Users
   {
       public Int64 TID
       {
           get;
           set;
       }

       public String SoeID
       {
           get;
           set;
       }

       public String GEID
       {
           get;
           set;
       }

       public String CNName
       {
           get;
           set;
       }

       public String ENName
       {
           get;
           set;
       }

       public Int32 RoleType
       {
           get;
           set;
       }
       public String RoleName
       {
           get;
           set;
       }

       public String Phone
       {
           get;
           set;
       }

       public String OrgCode
       {
           get;
           set;
       }

       public String GOCCode
       {
           get;
           set;
       }

       public String AgentCode
       {
           get;
           set;
       }

       public String BranchCode
       {
           get;
           set;
       }

       public String Location
       {
           get;
           set;
       }

       public Int32 Status
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public String CreateTime
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public String ModifiedTime
       {
           get;
           set;
       }

   }
}

