﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_AppraisalFee
    {
        public string ApplicationNo
        {
            get;
            set;
        }

        public string FullName
        {
            get;
            set;
        }

        public string ProdName
        {
            get;
            set;
        }

        public string Price
        {
            get;
            set;
        }

        public string LandValue
        {
            get;
            set;
        }

        public string BuildingValue
        {
            get;
            set;
        }

        public string Fee
        {
            get;
            set;
        }

        public string InsuranceFee
        {
            get;
            set;
        }

        public string RegisterFee
        {
            get;
            set;
        }

        public string ApprovedLoanSize
        {
            get;
            set;
        }

        public string ApprovedTenor
        {
            get;
            set;
        }

        public string InterestRate
        {
            get;
            set;
        }

        public string Installment
        {
            get;
            set;
        }
    }
}
