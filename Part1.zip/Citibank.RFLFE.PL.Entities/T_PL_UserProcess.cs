﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_UserProcess
    {
        public String ApplicationNo
        {
            get;
            set;
        }

        public String FullName
        {
            get;
            set;
        }

        public String IDIssueDate
        {
            get;
            set;
        }

        public String DebitAccount
        {
            get;
            set;
        }

        public String ProdName
        {
            get;
            set;
        }

        public String HouseTel
        {
            get;
            set;
        }

        public String MobileNumber
        {
            get;
            set;
        }

        public String FirstDueDate
        {
            get;
            set;
        }

        public String MaturityDate
        {
            get;
            set;
        }

        public String ContractDate
        {
            get;
            set;
        }

        public String CustSegment
        {
            get;
            set;
        }

        public String Installment
        {
            get;
            set;
        }

        public String ApprovedLoanSize
        {
            get;
            set;
        }
    }
}
