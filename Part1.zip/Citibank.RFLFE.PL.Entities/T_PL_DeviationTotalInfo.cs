﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_DeviationTotalInfo
    {
        public String Title
        {
            get;
            set;
        }

        public String Deviation
        {
            get;
            set;
        }

        public String Normal
        {
            get;
            set;
        }

        public String Percent
        {
            get;
            set;
        }
    }
}
