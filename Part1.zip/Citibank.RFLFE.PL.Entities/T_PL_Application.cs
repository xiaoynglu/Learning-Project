using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_Application
   {
       public string AppID
       {
           get;
           set;
       }

       public String ApplicationNo
       {
           get;
           set;
       }

       public Int32 ProdID
       {
           get;
           set;
       }

       public String PayType
       {
           get;
           set;
       }

       public String SourceCode
       {
           get;
           set;
       }

       public String AgentCode
       {
           get;
           set;
       }

       public String BranchCode
       {
           get;
           set;
       }


       public String WhereKnow
       {
           get;
           set;
       }

       public String OrgCode
       {
           get;
           set;
       }

       public String CreatorID
       {
           get;
           set;
       }

       public DateTime? CreateDate
       {
           get;
           set;
       }

       public String IsLackDoc
       {
           get;
           set;
       }

       public String IsSubmitted
       {
           get;
           set;
       }

       public String IsEmployeeLoan
       {
           get;
           set;
       }

       public String RelationNumber
       {
           get;
           set;
       }

       public String IsPBOCChecked
       {
           get;
           set;
       }

       public String IsALSChecked
       {
           get;
           set;
       }

       public String UserDefined1
       {
           get;
           set;
       }

       public String UserDefined2
       {
           get;
           set;
       }

       public String UserDefined3
       {
           get;
           set;
       }

       public String UserDefined4
       {
           get;
           set;
       }

       public String UserDefined5
       {
           get;
           set;
       }

       public String IsTown
       {
           get;
           set;
       }

       public String IsSamePlace
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }

       public string CustomerID
       {
           get;
           set;
       }

       public string CustomerName
       {
           get;
           set;
       }

       public string ProdName
       {
           get;
           set;
       }

       public string DateOfApplication
       {
           get;
           set;
       }

       public string StageID
       {
           get;
           set;
       }

       public string CurrentStage
       {
           get;
           set;
       }

       public string Status
       {
           get;
           set;
       }

       public string CNName
       {
           get;
           set;
       }

       public string CurrentProcessor
       {
           get;
           set;
       }

       public Boolean IsLocked
       {
           get;
           set;
       }

       public string IDNo
       {
           get;
           set;
       }

       public DateTime DateBegin
       {
           get;
           set;
       }

       public DateTime DateEnd
       {
           get;
           set;
       }


   }
}

