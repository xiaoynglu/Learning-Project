using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_IDChange
   {
       public Int32 TID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public Guid CustID
       {
           get;
           set;
       }

       public String IDNo
       {
           get;
           set;
       }

       public DateTime ImportDate
       {
           get;
           set;
       }

       public String ProcID
       {
           get;
           set;
       }

   }
}

