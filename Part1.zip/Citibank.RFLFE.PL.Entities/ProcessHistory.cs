﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
   public class ProcessHistory
    {
        public String ProcID
        {
            get;
            set;
        }

        public String BeginDate
        {
            get;
            set;
        }
        public String BeginStage
        {
            get;
            set;
        }
        public String EndDate
        {
            get;
            set;
        }
        public String EndStage
        {
            get;
            set;
        }
        public String Action
        {
            get;
            set;
        }
        public String Remarks
        {
            get;
            set;
        }
    }
}
