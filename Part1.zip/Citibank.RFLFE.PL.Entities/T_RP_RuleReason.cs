using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_RuleReason
   {
       public Int32 TID
       {
           get;
           set;
       }

       public Int32 RuleID
       {
           get;
           set;
       }

       public Int32 ReasonID
       {
           get;
           set;
       }

   }
}

