﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_TempDefination
    {
        public Int32 ID
        {
            get;
            set;
        }

        public String ColumnName
        {
            get;
            set;
        }

        public String CN_Name
        {
            get;
            set;
        }

        public String EN_Name
        {
            get;
            set;
        }

        public String ViewName
        {
            get;
            set;
        }

        public String Disable
        {
            get;
            set;
        }

        public String HQ_Visible
        {
            get;
            set;
        }
    }
}
