using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_Engine
   {
       public Int32 StageID
       {
           get;
           set;
       }

       public Int32 RuleID
       {
           get;
           set;
       }

       public Int32 ProdID
       {
           get;
           set;
       }

       public Int32 OrderBy
       {
           get;
           set;
       }

   }
}

