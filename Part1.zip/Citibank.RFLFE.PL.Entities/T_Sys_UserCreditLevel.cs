using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_UserCreditLevel
   {
       public Int32 TID
       {
           get;
           set;
       }

       public String SoeID
       {
           get;
           set;
       }

       public String LevelCode
       {
           get;
           set;
       }

       public Int32 LoanSize
       {
           get;
           set;
       }

       public Int32 ProdID
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime CreateTime
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime ModifiedTime
       {
           get;
           set;
       }

   }
}

