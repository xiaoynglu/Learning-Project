using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_OralAppraisal
   {
       public Int32 TID
       {
           get;
           set;
       }
       public Guid AppID
       {
           get;
           set;
       }

       public Int32 CompanyID
       {
           get;
           set;
       }

       public String CompanyName
       {
           get;
           set;
       }

       public String RequestDate
       {
           get;
           set;
       }

       public String AcceptDate
       {
           get;
           set;
       }

       public Decimal Price
       {
           get;
           set;
       }

       public Decimal Fee
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }
       public String CreateID
       {
           get;
           set;
       }
       public String CreateDate
       {
           get;
           set;
       }
   }
}

