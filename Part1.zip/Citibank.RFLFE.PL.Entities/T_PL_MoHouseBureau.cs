using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_MoHouseBureau
   {
        public Int32 TID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public Guid CustID
       {
           get;
           set;
       }

       public String FullName
       {
           get;
           set;
       }

       public String PropertyValue
       {
           get;
           set;
       }

       public String TotalPropertyValue
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }

       public String CreateID
       {
           get;
           set;
       }

       public String CreatedTime
       {
           get;
           set;
       }

       public String UpdateID
       {
           get;
           set;
       }

       public String UpdatedTime
       {
           get;
           set;
       }

   }
}

