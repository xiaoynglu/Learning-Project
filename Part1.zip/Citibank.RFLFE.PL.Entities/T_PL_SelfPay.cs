using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_SelfPay
   {
       public Guid AppID
       {
           get;
           set;
       }

       public String DebitName
       {
           get;
           set;
       }

       public String DebitBankName
       {
           get;
           set;
       }

       public String DebitSubBankName
       {
           get;
           set;
       }

       public String DebitAccount
       {
           get;
           set;
       }

       public String DebitReason
       {
           get;
           set;
       }

       public String DebitRemarks
       {
           get;
           set;
       }
       public Decimal PaymentAmount
       {
           get;
           set;
       }

       public string  PayeeBankFullName {
           get;
           set;
       }
   }
}

