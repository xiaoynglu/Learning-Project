using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_SalaryCust
   {
       public Guid CustID
       {
           get;
           set;
       }

       public String EnterpriseLevel
       {
           get;
           set;
       }

       public String Department
       {
           get;
           set;
       }

       public String Position
       {
           get;
           set;
       }

       public String Job
       {
           get;
           set;
       }

       public String EnterpriseName
       {
           get;
           set;
       }

       public String EnterpriseProperty
       {
           get;
           set;
       }

       public String EnterpriseScale
       {
           get;
           set;
       }

       public Int32 CurrentWorkingLife
       {
           get;
           set;
       }

       public Int32 PreWorkingLife
       {
           get;
           set;
       }

       public Int32 TotalWorkingLife
       {
           get;
           set;
       }
       public String Segment
       {
           get;
           set;
       }

       public string Industry
       {
           get;
           set;
       }

       public string Occupation
       {
           get;
           set;
       }
   }
}

