using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_ProductMaker
   {
       public Int32 ProdID
       {
           get;
           set;
       }

       public String ProdName
       {
           get;
           set;
       }

       public String Descriptions
       {
           get;
           set;
       }

       public String ProdType
       {
           get;
           set;
       }

       public String ProdCode
       {
           get;
           set;
       }

       public String ProdRCCode
       {
           get;
           set;
       }

       public String CreditAcc
       {
           get;
           set;
       }

       public String DebitAcc
       {
           get;
           set;
       }

       public Int32 Status
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime CreateTime
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime ModifiedTime
       {
           get;
           set;
       }

   }
}

