﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class ComboboxEntity
    {
        public String Description
        {
            get;
            set;
        }
        public String Code
        {
            get;
            set;
        }
            
    }
}
