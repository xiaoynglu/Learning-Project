﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_BureauCustInfo
    {
        public String AppID
        {
            get;
            set;
        }

        public String IDNo
        {
            get;
            set;
        }

        public String BorrowType
        {
            get;
            set;
        }

        public String ProvenIncome
        {
            get;
            set;
        }

        public String FormerName
        {
            get;
            set;
        }        

        public String FullName
        {
            get;
            set;
        }

        public String CustID
        {
            get;
            set;
        }

        public String RelatedCustID
        {
            get;
            set;
        }
    }
}
