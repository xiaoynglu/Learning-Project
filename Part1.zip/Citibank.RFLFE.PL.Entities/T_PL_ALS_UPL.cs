﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_ALS_UPL
    {
        public Guid AppID { get; set; }
        public String AccountNumber { get; set; }
        public String ProductCode { get; set; }
        public String LoanAmount { get; set; }
        public String LoanProceeds { get; set; }
        public String InterestRate { get; set; }
        public String CustomerNumber { get; set; }
        public String RelationshipNumber { get; set; }
        public String RCNumber { get; set; }
        public String ContractDate { get; set; }
        public String FirstDueDate { get; set; }
        public String Term { get; set; }
        public String MaturityDate { get; set; }
        public String PrimBranch { get; set; }
        public String IndustryCode { get; set; }
        public String CACSCity { get; set; }
        public String CACSLoc { get; set; }
        public String CityCode { get; set; }
        public String ACF { get; set; }
        public String RateIndex { get; set; }
        public String Purpose { get; set; }
        public String AgentCode { get; set; }
        public String SourceCode { get; set; }
        public String IncomeType { get; set; }
        public String EmployerCD { get; set; }
        public String SegmentID { get; set; }
        public Int64 OriginalAccNo { get; set; }
        public Int64 OriginalSegmentId { get; set; }
        public int LoanDirection { get; set; }
        public String DisbursementMethod { get; set; }
        public String LineID { get; set; }
        public String CollateralID { get; set; }

    }
}
