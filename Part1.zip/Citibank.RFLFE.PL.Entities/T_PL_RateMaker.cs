using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_RateMaker
   {
       public Int32 TID
       {
           get;
           set;
       }

       public Int32 ProdID
       {
           get;
           set;
       }

       public String OrgCode
       {
           get;
           set;
       }

       public String CollateralType
       {
           get;
           set;
       }

       public String EmploymentType
       {
           get;
           set;
       }

       public String Segment
       {
           get;
           set;
       }

       public Decimal Value
       {
           get;
           set;
       }

       public Decimal BaseValue
       {
           get;
           set;
       }

       public Decimal Spread
       {
           get;
           set;
       }

       public bool IsSecond
       {
           get;
           set;
       }

       public bool IsOverFive
       {
           get;
           set;
       }

       public Int32 OpType
       {
           get;
           set;
       }

       public Int32 Status
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime MakeDate
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime CheckDate
       {
           get;
           set;
       }
       public String StatusDesc
       {
           get;
           set;
       }
   }
}

