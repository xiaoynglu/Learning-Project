﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_IDChangeLog
    {
        public int TID
        {
            get;
            set;
        }
        public Guid CustID
        {
            get;
            set;
        }
        public string IDNo
        {
            get;
            set;
        }
        public string IDIssueDate
        {
            get;
            set;
        }
        
        public string IDExpireDate
        {
            get;
            set;
        }
        public string IDIssuePlace
        {
            get;
            set;
        }
        public string ModiID
        {
            get;
            set;
        }
        public string ModiDate
        {
            get;
            set;
        }


    }
}
