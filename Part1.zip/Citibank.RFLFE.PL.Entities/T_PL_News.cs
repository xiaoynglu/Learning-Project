﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_News
    {
        public int TID { get; set; }
        public string title { get; set; }
        public string newscontent { get; set; }
        public bool istop { get; set; }
        public string maker { get; set; }
        public DateTime maketime { get; set; }
        

        
    }
}
