using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_LoanApproval
   {
       public Guid AppID
       {
           get;
           set;
       }

       public Int32 StageID
       {
           get;
           set;
       }

       public Decimal InterestRate
       {
           get;
           set;
       }

       public Decimal ApprovedLoanSize
       {
           get;
           set;
       }

       public String ApprovedLoanTenor
       {
           get;
           set;
       }

       public String RefreshedRate
       {
           get;
           set;
       }

       public Decimal HomeOtherIncome
       {
           get;
           set;
       }

       public Decimal HomeOtherDebt
       {
           get;
           set;
       }

       public Decimal HomeMonthly
       {
           get;
           set;
       }

       public String ProcessorID
       {
           get;
           set;
       }

       public DateTime ProceededDate
       {
           get;
           set;
       }

   }
}

