﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class CommonResult
    {
        public bool IsSuccess { get; set; }

        public string Message { get; set; }
    }
}
