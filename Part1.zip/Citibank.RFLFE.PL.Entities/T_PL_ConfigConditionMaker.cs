using System;
using System.Collections;
using System.Text;
using System.Data;
/****************************
 * ģ����������Makerʵ����
 * LiYong,2015-09-14,created
 * LiYong,2015-09-14,updated
 ***************************/
namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_ConfigConditionMaker
   {
       #region Basic Entity Properties

       public Int32 ConditionID
       {
           get;
           set;
       }

       public Guid ConfigID
       {
           get;
           set;
       }

       public String TabID
       {
           set;
           get;
       }

       public String OP
       {
           get;
           set;
       }

       public String Value
       {
           get;
           set;
       }

       public Int32 GroupID
       {
           get;
           set;
       }

       public String GroupName
       {
           get;
           set;
       }

       public Int32 OpType
       {
           get;
           set;
       }

       public Int32 Status
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime MakeDate
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime CheckDate
       {
           get;
           set;
       }

       #endregion

       #region Extended Entity Properties

       public Int32 TID
       {
           get;
           set;
       }

       public Int32 TemplateID
       {
           get;
           set;
       }

       public Int32 ProdID
       {
           get;
           set;
       }

       public String ProdName
       {
           set;
           get;
       }

       public Int32 ParentID
       {
           get;
           set;
       }

       public String FileName
       {
           get;
           set;
       }

       public String AttachName
       {
           get;
           set;
       }

       public String BorrowerType
       {
           get;
           set;
       }

       public Int32 FileType
       {
           set;
           get;
       }

       public String OrderBy
       {
           get;
           set;
       }

       public String StatusName
       {
           set;
           get;
       }

       public String OpTypeName
       {
           set;
           get;
       }

       public String TableName
       {
           get;
           set;
       }

       public String ColumnName
       {
           get;
           set;
       }

       public String DisplayName
       {
           set;
           get;
       }

       #endregion
   }
}

