using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_SellerInfo
   {
       public Guid SellerID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public String Gender
       {
           get;
           set;
       }

       public String Name
       {
           get;
           set;
       }

       public String PinyinName
       {
           get;
           set;
       }

       public String IDNo
       {
           get;
           set;
       }

   }
}

