﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_MessageAndNotice
    {
        public int TID { get; set; }

        public int typevalue { get; set; }

        public string contentvalue { get; set; }

        public string starttime { get; set; }

        public string endtime { get; set; }

        public string orgcode { get; set; }
        public string roletype { get; set; }
    }
}
