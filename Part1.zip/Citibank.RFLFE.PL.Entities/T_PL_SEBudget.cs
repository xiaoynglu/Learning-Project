using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_SEBudget
   {
       public Guid CustID
       {
           get;
           set;
       }

       public Int32 StageID
       {
           get;
           set;
       }

       public String MonthlyTurnover
       {
           get;
           set;
       }

       public String PurchaseCost
       {
           get;
           set;
       }

       public String GrossMargins
       {
           get;
           set;
       }

       public String StoreRents
       {
           get;
           set;
       }

       public String UtilitiesFee
       {
           get;
           set;
       }

       public String EmployeeSalary
       {
           get;
           set;
       }

       public String OtherExpenses
       {
           get;
           set;
       }

       public String Tax
       {
           get;
           set;
       }

       public String MonthlyIncome
       {
           get;
           set;
       }

       public String MonthlyDebt
       {
           get;
           set;
       }

       //ë��
       public String GrossProfit
       {
           get;
           set;
       }

       //��֧��
       public String TotalExpenses
       {
           get;
           set;
       }

       //������
       public String NetIncome
       {
           get;
           set;
       }

       //��������
       public String NetProfitMargin
       {
           get;
           set;
       }

       public String MLRepayment
       {
           get;
           set;
       }

       public String ULRepayment
       {
           get;
           set;
       }

       public String RentalIncome
       {
           get;
           set;
       }
       //����������żסլ����ӵ�����
       public String OwnedResidence
       {
           get;
           set;
       }


       //����������ż��ҵ����ӵ�����
       public String OwnedEstate
       {
            get;
            set;
       }

       //�����˹�ȥ���걣��
       public String PaidInsurance
       {
            get;
            set;
       }

       public String ProcessorID
       {
           get;
           set;
       }

       public DateTime ProceededDate
       {
           get;
           set;
       }

   }
}

