using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_DetailReasons
   {
       public Int32 ReasonID
       {
           get;
           set;
       }

       public String ReasonCode
       {
           get;
           set;
       }

       public String HitType
       {
           get;
           set;
       }

       public String Descriptions
       {
           get;
           set;
       }

       public Int32 ParentReasonID
       {
           get;
           set;
       }

       public String DeviationLevel
       {
           get;
           set;
       }

       public String IsValid
       {
           get;
           set;
       }

   }
}

