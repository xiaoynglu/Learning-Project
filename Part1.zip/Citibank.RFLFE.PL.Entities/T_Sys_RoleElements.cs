using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_RoleElements
   {
       public Int32 TID
       {
           get;
           set;
       }

       public Int32 RoleType
       {
           get;
           set;
       }

       public Int32 EleID
       {
           get;
           set;
       }

   }
}

