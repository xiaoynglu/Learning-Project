﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_RP_RuleParamValuePivot
    {
        public int RuleID { get; set; }

        public int ParamID { get; set; }

        public string OrgCode { get; set; }

        public string ParamName { get; set; }

        public string CustType { get; set; }

        public string UPL_Q { get; set; }

        public string UPL_G { get; set; }

        public string HE_Q { get; set; }

        public string HE_G { get; set; }

        public string CRE_Q { get; set; }

        public string CRE_G { get; set; }

        public string MO_Q { get; set; }

        public string MO_G { get; set; }

        public string Rownumber { get; set; }

        public string BranchName { get; set; }
    }
}
