using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_Information
   {
       public Int32 TID
       {
           get;
           set;
       }

       public String Environment
       {
           get;
           set;
       }

       public String SysURL
       {
           get;
           set;
       }

       public String SysDefine
       {
           get;
           set;
       }

       public String SysName
       {
           get;
           set;
       }

   }
}

