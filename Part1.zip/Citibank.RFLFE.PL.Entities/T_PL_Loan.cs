using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_Loan
   {
       public Guid AppID
       {
           get;
           set;
       }
       public String AppNO
       {
           get;
           set;
       }
       public Int32 ProdID
       {
           get;
           set;
       }
       public String ProdName
       {
           get;
           set;
       }
       public Decimal RequestLoanSize
       {
           get;
           set;
       }

       public Decimal ApprovedLoanSize
       {
           get;
           set;
       }

       public Decimal ProposalLoanSize
       {
           get;
           set;
       }

       public Decimal MaxLoanSize
       {
           get;
           set;
       }

       public Decimal AvailableUnsecuredSize
       {
           get;
           set;
       }

       public String RequestTenor
       {
           get;
           set;
       }

       public String ApprovedTenor
       {
           get;
           set;
       }

       public String ProposalTenor
       {
           get;
           set;
       }

       public Decimal Installment
       {
           get;
           set;
       }

       public Decimal InterestRate
       {
           get;
           set;
       }

       public Decimal BaseRate
       {
           get;
           set;
       }

       public Decimal BaseLTV
       {
           get;
           set;
       }

       public Decimal MaxAllowedLTV
       {
           get;
           set;
       }

       public Decimal ReducedLTV
       {
           get;
           set;
       }

       public String HasProperty
       {
           get;
           set;
       }

       public String OwnHouse
       {
           get;
           set;
       }

       public String AccOpenDate
       {
           get;
           set;
       }

       public String DisbursedDate
       {
           get;
           set;
       }

       public Int32 MorgageCount
       {
           get;
           set;
       }

       public Decimal TailAmount
       {
           get;
           set;
       }

       public String FirstHouseOp
       {
           get;
           set;
       }

       public Decimal FirstHouseArea
       {
           get;
           set;
       }

       public Decimal FirstPayAmount
       {
           get;
           set;
       }

       public Decimal FirstPayPercent
       {
           get;
           set;
       }

       public String IsImprovedHouse
       {
           get;
           set;
       }

       public String IsPartialMortgage
       {
           get;
           set;
       }

       public Decimal Fee
       {
           get;
           set;
       }
       public Decimal InsuranceFee
       {
           get;
           set;
       }
       public Decimal ActualLTV
       {
           get;
           set;
       }
       public String Remarks
       {
           get;
           set;
       }

       public decimal CurrDebt
       {
           get;
           set;
       }

       public String CustSegment
       {
           get;
           set;
       }

       public Boolean Deviated
       {
           get;
           set;
       }
   }
}

