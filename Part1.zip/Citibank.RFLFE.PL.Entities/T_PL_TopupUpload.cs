using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_TopupUpload
   {
       public Guid TopupID
       {
           get;
           set;
       }

       public String OrgLoanNumber
       {
           get;
           set;
       }

       public String OrgApplicationNo
       {
           get;
           set;
       }

       public String OrgSegment
       {
           get;
           set;
       }

       public String TopUpSegment
       {
           get;
           set;
       }

       public String RelationNo
       {
           get;
           set;
       }

       public Int32 TopUpApprovedTenor
       {
           get;
           set;
       }

       public Decimal TopUpApprovedLoanSize
       {
           get;
           set;
       }

       public Decimal TopUpRate
       {
           get;
           set;
       }

       public Decimal OrgLoanSize
       {
           get;
           set;
       }

       public Decimal LoanBalance
       {
           get;
           set;
       }

       public Decimal INC_FACE
       {
           get;
           set;
       }

       public Decimal INC_ENR
       {
           get;
           set;
       }

       public String AgentCode
       {
           get;
           set;
       }

       public String MainBorrower
       {
           get;
           set;
       }

       public String ID_No
       {
           get;
           set;
       }

       public String Coborrower
       {
           get;
           set;
       }

       public String CoborrowerID
       {
           get;
           set;
       }

       public String CoborrowerAddress
       {
           get;
           set;
       }

       public String MainBorrowerSpouse
       {
           get;
           set;
       }

       public String CoborrowerSpouse
       {
           get;
           set;
       }

       public String ReportType
       {
           get;
           set;
       }

       public Decimal TotalIncome
       {
           get;
           set;
       }

       public String AddressType
       {
           get;
           set;
       }

       public String ZipCode
       {
           get;
           set;
       }

       public DateTime CM_DIS_BOOKDATE
       {
           get;
           set;
       }

       public DateTime CM_DIS_MATDATE
       {
           get;
           set;
       }

       public Decimal OrgRate
       {
           get;
           set;
       }

       public String CM_DIS_PRODTYPE
       {
           get;
           set;
       }

       public String MainBorrowerSpouseID
       {
           get;
           set;
       }

       public String AddProvince
       {
           get;
           set;
       }

       public String AddCity
       {
           get;
           set;
       }

       public String AddArea
       {
           get;
           set;
       }

       public String AddStreet
       {
           get;
           set;
       }

       public String Loan_Category
       {
           get;
           set;
       }

       public String LoanPrupose
       {
           get;
           set;
       }

       public String LoanIndustry
       {
           get;
           set;
       }

       public String Paytype
       {
           get;
           set;
       }

       public String PayeeBenefic
       {
           get;
           set;
       }

       public String PayeeBank
       {
           get;
           set;
       }

       public String PayeeAccount
       {
           get;
           set;
       }

       public Decimal PaymentAmount
       {
           get;
           set;
       }

       public String DebitBank
       {
           get;
           set;
       }

       public String DebitAccount
       {
           get;
           set;
       }

       public Decimal EntrustPayamount
       {
           get;
           set;
       }

       public String ReasonList
       {
           get;
           set;
       }

       public String OtherRea
       {
           get;
           set;
       }

   }
}

