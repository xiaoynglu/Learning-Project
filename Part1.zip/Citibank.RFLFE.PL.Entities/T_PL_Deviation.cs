﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{    
    public class T_PL_Deviation
    {
        public String AppID
        {
            get;
            set;
        }

        public String ApplicationNo
        {
            get;
            set;
        }

        public String FullName
        {
            get;
            set;
        }

        public String IDNo
        {
            get;
            set;
        }

        public String ProdName
        {
            get;
            set;
        }

        public String ProdID
        {
            get;
            set;
        }

        public String ApplyDate
        {
            get;
            set;
        }

        public String CurrentStage
        {
            get;
            set;
        }

        public String StageID
        {
            get;
            set;
        }

        public String CurrentStatus
        {
            get;
            set;
        }

        public String SalesName
        {
            get;
            set;
        }

        public String SalesId
        {
            get;
            set;
        }

        public String SApproverId
        {
            get;
            set;
        }

        public String CurrentProcesserId
        {
            get;
            set;
        }

        public String CurrentProcesserName
        {
            get;
            set;
        }

        public String ApprovedDate
        {
            get;
            set;
        }

        public String IsDeviationed
        {
            get;
            set;
        }

        public String DeviationCode
        {
            get;
            set;
        }
    }
}
