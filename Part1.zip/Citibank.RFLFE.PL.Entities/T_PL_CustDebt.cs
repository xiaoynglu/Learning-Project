using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_CustDebt
   {
       public String CustID
       {
           get;
           set;
       }

       public Decimal CurrDebt
       {
           get;
           set;
       }

       public Decimal CurrCollateralLoan
       {
           get;
           set;
       }


       public Decimal CurrUnsecuredLoan
       {
           get;
           set;
       }


       public Decimal CurrCreditCard
       {
           get;
           set;
       }

          public Decimal CurrPropertyFee
       {
           get;
           set;
       }

        public Decimal CurrTotalDebt
        {
            get;
            set;
        }

       public Decimal ModifiedDebt
       {
           get;
           set;
       }

       public Decimal ModifiedCollateralLoan
       {
           get;
           set;
       }

       public Decimal ModifiedUnsecuredLoan
       {
           get;
           set;
       }

       public Decimal ModifiedPropertyFee
       {
           get;
           set;
       }
       public Decimal ModifiedCreditCard
       {
           get;
           set;
       }
       public Decimal ModifiedTotalDebt
       {
           get;
           set;
       }

       public String ProcessorID
       {
           get;
           set;
       }

       public DateTime ProceededDate
       {
           get;
           set;
       }

   }
}

