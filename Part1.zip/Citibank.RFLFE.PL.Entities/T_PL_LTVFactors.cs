using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_LTVFactors
   {

       public String TID
       {
           get;
           set;
       }


       public Guid AppID
       {
           get;
           set;
       }

       public String Factor
       {
           get;
           set;
       }

       public String FactorValue
       {
           get;
           set;
       }

   }
}

