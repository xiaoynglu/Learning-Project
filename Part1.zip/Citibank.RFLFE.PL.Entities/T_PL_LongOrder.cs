﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_LongOrder
    {
        public String AppID
        {
            get;
            set;
        }

        public String OwnerName
        {
            get;
            set;
        }

        public String ProcId
        {
            get;
            set;
        }

        public String ApplicationNo
        {
            get;
            set;
        }

        public String IDNo
        {
            get;
            set;
        }

        public String FullName
        {
            get;
            set;
        }

        public String ProdName
        {
            get;
            set;
        }

        public String ProdID
        {
            get;
            set;
        }

        public String StageName
        {
            get;
            set;
        }

        public String StageID
        {
            get;
            set;
        }

        public String ApprovedLoanSize
        {
            get;
            set;
        }

        public String CreateDate
        {
            get;
            set;
        }

        public String Status
        {
            get;
            set;
        }
    }
}
