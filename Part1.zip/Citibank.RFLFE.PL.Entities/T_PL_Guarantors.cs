using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_Guarantors
   {
       public String GuarantorID
       {
           get;
           set;
       }

       public String AppID
       {
           get;
           set;
       }

       public String Name
       {
           get;
           set;
       }

       public String PinyinName
       {
           get;
           set;
       }

       public String IDNo
       {
           get;
           set;
       }

       public String Telephone
       {
           get;
           set;
       }

       public String MobileNumber
       {
           get;
           set;
       }

       public String Relation
       {
           get;
           set;
       }

       public String HouseProvince
       {
           get;
           set;
       }

       public String HouseCity
       {
           get;
           set;
       }

       public String HouseDistrict
       {
           get;
           set;
       }

       public String HouseStreet
       {
           get;
           set;
       }

       public String HousePostCode
       {
           get;
           set;
       }

       public String WorkingProvince
       {
           get;
           set;
       }

       public String WorkingCity
       {
           get;
           set;
       }

       public String WorkingDistrict
       {
           get;
           set;
       }

       public String WorkingStreet
       {
           get;
           set;
       }

       public String WorkingPostCode
       {
           get;
           set;
       }
       public string CustNO
       {
           get;
           set;
       }

   }
}

