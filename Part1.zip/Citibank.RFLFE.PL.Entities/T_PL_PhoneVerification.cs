using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_PhoneVerification
   {
       public Int64 TID
       {
           get;
           set;
       }

       public Guid CustID
       {
           get;
           set;
       }

       public String ContactNumber
       {
           get;
           set;
       }

       public String ContactName
       {
           get;
           set;
       }

       public String Gender
       {
           get;
           set;
       }

       public String GenderDesc
       {
           get;
           set;
       }

       public String Position
       {
           get;
           set;
       }

       public String Relation
       {
           get;
           set;
       }

       public String RelationDesc
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }
       public String CheckerID
       {
           get;
           set;
       }
       public String CheckDate
       {
           get;
           set;
       }
   }
}

