using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_ExternalVerification
   {
       public Int64 TID
       {
           get;
           set;
       }

       public Guid CustID
       {
           get;
           set;
       }

       public Int32 HasSocialSecurity
       {
           get;
           set;
       }

       public Int32 PensionStatus
       {
           get;
           set;
       }

       public Decimal PensionAmount
       {
           get;
           set;
       }

       public String PensionNumber
       {
           get;
           set;
       }

       public Int32 TaxesStatus
       {
           get;
           set;
       }

       public Int32 CreditStatus
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }
       public String CheckerID
       {
           get;
           set;
       }
       public String CheckDate
       {
           get;
           set;
       }
   }
}

