using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_LoanIndustry
   {
       public Guid AppID
       {
           get;
           set;
       }

       public String Purpose1
       {
           get;
           set;
       }
      
       public String Purpose2
       {
           get;
           set;
       }

       public String Purpose3
       {
           get;
           set;
       }

      
       public String OtherPurpose
       {
           get;
           set;
       }

       public String Category
       {
           get;
           set;
       }

       public String CommericialFitment
       {
           get;
           set;
       }

       public String MainIndustry
       {
           get;
           set;
       }


       public String SubIndustry
       {
           get;
           set;
       }

       public String DecorationProvince
       {
           get;
           set;
       }

       public String DecorationCity
       {
           get;
           set;
       }


       public String DecorationRegion
       {
           get;
           set;
       }

       public String DecorationAddress
       {
           get;
           set;
       }

       public String IsPropertySelf
       {
           get;
           set;
       }

       public String DecorationRelation
       {
           get;
           set;
       }

       public Decimal DecorationPropertyValue1
       {
           get;
           set;
       }

       public Decimal DecorationPropertyValue2
       {
           get;
           set;
       }

       public String SourceCode
       {
           get;
           set;
       }

       public String AgentCode
       {
           get;
           set;
       }

       public String WhereKnow
       {
           get;
           set;
       }

       public String PayType
       {
           get;
           set;
       }

       public String  ServiceID
       {
           get;
           set;
       }

       public String DeditBankName
       {
           get;
           set;
       }

       public String DeditSubBankName
       {
           get;
           set;
       }
    
       public String DeditAccount
       {
           get;
           set;
       }

       public String DeditReason
       {
           get;
           set;
       }

       public String DeditRemarks
       {
           get;
           set;
       }

       public String PayeeName
       {
           get;
           set;
       }

       public String PayeeBankName
       {
           get;
           set;
       }

       public String PayeeSubBankName
       {
           get;
           set;
       }

       public String PayeeAccount
       {
           get;
           set;
       }

       public String DebitName
       {
           get;
           set;
       }

       public String PaymentAmount
       {
           get;
           set;
       }
   }
}

