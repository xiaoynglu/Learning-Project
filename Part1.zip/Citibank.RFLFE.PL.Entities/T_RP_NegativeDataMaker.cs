using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_NegativeDataMaker
   {
       public Int32 TID
       {
           get;
           set;
       }

       public String CustName
       {
           get;
           set;
       }

       public String IDNo
       {
           get;
           set;
       }

       public String CompanyName
       {
           get;
           set;
       }

       public DateTime DOB
       {
           get;
           set;
       }

       public String AgentName
       {
           get;
           set;
       }

       public String SalesName
       {
           get;
           set;
       }

       public String Reason
       {
           get;
           set;
       }

       public String OtherCertID
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime CreateDate
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime ModifiedTime
       {
           get;
           set;
       }

       public String Status
       {
           get;
           set;
       }

       public Int32 OpType
       {
           get;
           set;
       }

   }
}

