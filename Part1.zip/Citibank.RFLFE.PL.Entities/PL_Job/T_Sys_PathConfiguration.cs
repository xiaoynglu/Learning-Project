using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_PathConfiguration
   {
       public Int32 TID
       {
           get;
           set;
       }

       public String ISActive
       {
           get;
           set;
       }

       public String Description
       {
           get;
           set;
       }

       public String Type
       {
           get;
           set;
       }

       public String ImpOrGenerateFilePath
       {
           get;
           set;
       }

       public String FileNameKeyword
       {
           get;
           set;
       }

       public String ShareFilePath
       {
           get;
           set;
       }

       public String FileFormat
       {
           get;
           set;
       }

       public String FileAccessFunctionID
       {
           get;
           set;
       }

       public String FileAccessFunctionPWD
       {
           get;
           set;
       }

       public String BackUpFilePath
       {
           get;
           set;
       }

       public String DataFromOrIntoTable
       {
           get;
           set;
       }

       public String ImportOrGenerateFunction
       {
           get;
           set;
       }

       public String EmailTo
       {
           get;
           set;
       }
   }
}

