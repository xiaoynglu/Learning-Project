using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FileHelpers;

namespace Citibank.RFLFE.PL.Entities
{
    [DelimitedRecord("|")]
   public class T_PL_PBOC_IndividualOldInsurance
   {
       public String ID_NUMBER
       {
           get;
           set;
       }

       public String SERIAL_NUMBER
       {
           get;
           set;
       }

       public String OPERATION_UNIT_PLACE
       {
           get;
           set;
       }

       public String SEX
       {
           get;
           set;
       }

       public String BIRTHDAY
       {
           get;
           set;
       }

       public String WORK_DATE
       {
           get;
           set;
       }

       public String EMPLOYER_NAME
       {
           get;
           set;
       }

       public String EMPLOYER_TYPE
       {
           get;
           set;
       }

       public String EMPLOYER_ECONOMIC_TYPE
       {
           get;
           set;
       }

       public String EMPLOYER_INDUSTRY
       {
           get;
           set;
       }

       public String ACCOUNT_SETUP_DATE
       {
           get;
           set;
       }

       public String PERSONAL_BASE
       {
           get;
           set;
       }

       public String MONTH_PRACTICAL_HANDIN
       {
           get;
           set;
       }

       public String TOTAL_MONTH
       {
           get;
           set;
       }

       public String HANDIN_STATUS
       {
           get;
           set;
       }

       public String SUSPEND_REASON
       {
           get;
           set;
       }

       public String OCCUR_DATE
       {
           get;
           set;
       }

       public String The24
       {
           get;
           set;
       }

       public String The23
       {
           get;
           set;
       }

       public String The22
       {
           get;
           set;
       }

       public String The21
       {
           get;
           set;
       }

       public String The20
       {
           get;
           set;
       }

       public String The19
       {
           get;
           set;
       }

       public String The18
       {
           get;
           set;
       }

       public String The17
       {
           get;
           set;
       }

       public String The16
       {
           get;
           set;
       }

       public String The15
       {
           get;
           set;
       }

       public String The14
       {
           get;
           set;
       }

       public String The13
       {
           get;
           set;
       }

       public String The12
       {
           get;
           set;
       }

       public String The11
       {
           get;
           set;
       }

       public String The10
       {
           get;
           set;
       }

       public String The9
       {
           get;
           set;
       }

       public String The8
       {
           get;
           set;
       }

       public String The7
       {
           get;
           set;
       }

       public String The6
       {
           get;
           set;
       }

       public String The5
       {
           get;
           set;
       }

       public String The4
       {
           get;
           set;
       }

       public String The3
       {
           get;
           set;
       }

       public String The2
       {
           get;
           set;
       }

       public String The1
       {
           get;
           set;
       }

       public String INF_CAPTURE_TIME
       {
           get;
           set;
       }

       public String IMPORT_DATE
       {
           get;
           set;
       }

   }
}

