﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_PBOC_ALS
    {
        public String RT_ACCT_NUM
        {
            get;
            set;
        }

        public String RT_ACCT_EFF_DATE
        {
            get;
            set;
        }

        public String RT_CURR_MATUR_DATE
        {
            get;
            set;
        }

        public String CTL2
        {
            get;
            set;
        }
    
        public String RT_ORIG_LOAN_AMT
        {
            get;
            set;
        }

        public String RT_TOT_CM_BAL
        {
            get;
            set;
        }
    
        public String HIGHEST_LOAN_AMT
        {
            get;
            set;
        }

        public String RT_REPAY_FREQ
        {
            get;
            set;
        }
    
        public String RT_CURR_TERM
        {
            get;
            set;
        }

        public String RT_NUM_PMTS_REM
        {
            get;
            set;
        }
    
        public String BD_PREV_DUE_DATE
        {
            get;
            set;
        }

        public String RT_LST_PMT_DATE
        {
            get;
            set;
        }

        public String RT_CURR_DUE_AMT
        {
            get;
            set;
        }
    
        public String RT_LST_PMT_AMT
        {
            get;
            set;
        }

        public String RT_TOT_PRIN
        {
            get;
            set;
        }
    
        public String DQ_NUM_PMTS_PDUE
        {
            get;
            set;
        }

        public String DQ_TOT_AMT_PDUE
        {
            get;
            set;
        }
    
        public String PRIN_PDUE31_60
        {
            get;
            set;
        }

        public String PRIN_PDUE61_90
        {
            get;
            set;
        }
    
        public String PRIN_PDUE91_180
        {
            get;
            set;
        }

        public String PRIN_PDUE180_OVR
        {
            get;
            set;
        }

        public String DQ_NO_OF_TIMES_DLQ
        {
            get;
            set;
        }
    
        public String DQ_HIGH_MONTH_DLQ
        {
            get;
            set;
        }

        public String CLASS_LOAN_TYPE
        {
            get;
            set;
        }
    
        public String DQ_MONTH_ST
        {
            get;
            set;
        }

        public String CURR_MONTH_DLQ_ST
        {
            get;
            set;
        }
    
        public String ID_TYPE
        {
            get;
            set;
        }

        public String ID_NUM
        {
            get;
            set;
        }
    
        public String BD_NXT_DUE_DATE
        {
            get;
            set;
        }

        public String DQ_HIST_DAY_CTR
        {
            get;
            set;
        }

        public String RT_POFF_AMT
        {
            get;
            set;
        }
    
        public String PRIN_1ST_DUE
        {
            get;
            set;
        }

        public String INT_1ST_DUE
        {
            get;
            set;
        }
    
        public String FEES_1ST_DUE
        {
            get;
            set;
        }

        public String INT_2ND_DUE
        {
            get;
            set;
        }
    
        public String INS_2ND_DUE
        {
            get;
            set;
        }

        public String PRIN_3RD_DUE
        {
            get;
            set;
        }
    
        public String FEES_3RD_DUE
        {
            get;
            set;
        }

        public String INS_3RD_DUE
        {
            get;
            set;
        }

        public String INT_4TH_DUE
        {
            get;
            set;
        }
    
        public String FEES_4TH_DUE
        {
            get;
            set;
        }

        public String INS_4TH_DUE
        {
            get;
            set;
        }
    
        public String PRIN_5TH_DUE
        {
            get;
            set;
        }

        public String INT_5TH_DUE
        {
            get;
            set;
        }
    
        public String FEES_5TH_DUE
        {
            get;
            set;
        }

        public String INS_5TH_DUE
        {
            get;
            set;
        }
    
        public String PRIN_6TH_DUE
        {
            get;
            set;
        }

        public String INT_6TH_DUE
        {
            get;
            set;
        }

        public String FEES_6TH_DUE
        {
            get;
            set;
        }
    
        public String INS_6TH_DUE
        {
            get;
            set;
        }

        public String PRIN_TOT_DUE
        {
            get;
            set;
        }
    
        public String INT_TOT_DUE
        {
            get;
            set;
        }

        public String FEES_TOT_DUE
        {
            get;
            set;
        }
    
        public String INS_TOT_DUE
        {
            get;
            set;
        }

        public String CF_CUST_NUM
        {
            get;
            set;
        }
    
        public String RT_ACCT_PROD
        {
            get;
            set;
        }

        public String RT_ORIG_PROCD_AMT
        {
            get;
            set;
        }

        public String RT_DURATION_CD
        {
            get;
            set;
        }
    
        public String RT_INT_TYPE
        {
            get;
            set;
        }

        public String RT_TERM_FREQ
        {
            get;
            set;
        }
    
        public String CF_PRIM_BR
        {
            get;
            set;
        }

        public String RT_CNTRY_CD
        {
            get;
            set;
        }
    
        public String RT_ACCT_TYPE
        {
            get;
            set;
        }

        public String RT_APR
        {
            get;
            set;
        }
    
        public String RT_MAX_LOAN_RATE
        {
            get;
            set;
        }

        public String RC_BASE
        {
            get;
            set;
        }

        public String ACCT_STATUS
        {
            get;
            set;
        }
    
        public String INS_1ST_DUE
        {
            get;
            set;
        }

        public String PRIN_2ND_DUE
        {
            get;
            set;
        }
    
        public String FEES_2ND_DUE
        {
            get;
            set;
        }

        public String INT_3RD_DUE
        {
            get;
            set;
        }
    
        public String PRIN_4TH_DUE
        {
            get;
            set;
        }

        public String RT_TERM_INCR
        {
            get;
            set;
        }
    
        public String RT_EXT_USER_FLD
        {
            get;
            set;
        }

        public String RT_CACS_LOC
        {
            get;
            set;
        }
    
        public String CF_LIABILITY_TYPE
        {
            get;
            set;
        }

        public String CF_PRIM_OFFICER
        {
            get;
            set;
        }
    
        public String RT_STATE_CD
        {
            get;
            set;
        }

        public String RT_GL_STATUS
        {
            get;
            set;
        }

        public String RT_INTERFACE_CD
        {
            get;
            set;
        }
    
        public String RT_ORIG_LINE_AMT
        {
            get;
            set;
        }

        public String ORIG_SL_APPROV_AMT
        {
            get;
            set;
        }
    
        public String RT_FRST_DUE_DATE
        {
            get;
            set;
        }

        public String TOT_LATE_CHRG_DUE
        {
            get;
            set;
        }
    
        public String TOT_FEES_DUE
        {
            get;
            set;
        }

        public String RT_CURR_INT
        {
            get;
            set;
        }
    
        public String REG_PYMT_AMT
        {
            get;
            set;
        }

        public String RT_CURR_RATE
        {
            get;
            set;
        }
    
        public String AC_ORIG_RATE
        {
            get;
            set;
        }

        public String RT_POFF_DLY_AMT
        {
            get;
            set;
        }
    
        public String RT_OLDST_DUE_DATE
        {
            get;
            set;
        }

        public String RT_DATE_LST_MAINT
        {
            get;
            set;
        }

        public String RT_LST_BAL_CHG_DT
        {
            get;
            set;
        }
    
        public String AUTO_DR
        {
            get;
            set;
        }

        public String RT_CCI_IND
        {
            get;
            set;
        }
    
        public String RT_NUM_PMTS_MADE
        {
            get;
            set;
        }

        public String RT_MONTHS_EXTD
        {
            get;
            set;
        }
    
        public String YTD_INT_COLL
        {
            get;
            set;
        }

        public String YTD_COLL_PREV
        {
            get;
            set;
        }
    
        public String RT_COLL_CD
        {
            get;
            set;
        }

        public String CO_UC01
        {
            get;
            set;
        }
    
        public String CO_UC02
        {
            get;
            set;
        }

        public String CO_UC03
        {
            get;
            set;
        }
    
        public String CO_UC04
        {
            get;
            set;
        }

        public String CO_UC05
        {
            get;
            set;
        }

        public String CO_UC06
        {
            get;
            set;
        }
    
        public String CO_UC07
        {
            get;
            set;
        }

        public String CO_UC08
        {
            get;
            set;
        }
    
        public String CO_UC09
        {
            get;
            set;
        }

        public String CO_UC10
        {
            get;
            set;
        }
    
        public String CO_UC11
        {
            get;
            set;
        }

        public String CO_UC12
        {
            get;
            set;
        }
    
        public String CO_UC13
        {
            get;
            set;
        }

        public String CO_UC14
        {
            get;
            set;
        }
    
        public String CO_UC15
        {
            get;
            set;
        }

        public String CO_UD01
        {
            get;
            set;
        }
    
        public String CO_UD02
        {
            get;
            set;
        }

        public String CO_UD03
        {
            get;
            set;
        }

        public String CO_ADDR_LINE1
        {
            get;
            set;
        }
    
        public String CO_ADDR_LINE2
        {
            get;
            set;
        }

        public String CO_ADDR_LINE3
        {
            get;
            set;
        }
    
        public String CO_ADDR_LINE4
        {
            get;
            set;
        }

        public String CO_HOUSE_NUM
        {
            get;
            set;
        }
    
        public String CO_AGE
        {
            get;
            set;
        }

        public String CO_SURVEY_NUM
        {
            get;
            set;
        }
    
        public String CO_ZIP_CODE
        {
            get;
            set;
        }

        public String CO_AREA
        {
            get;
            set;
        }
    
        public String CO_BLDG_SIZE
        {
            get;
            set;
        }

        public String DUE_AMOUNT
        {
            get;
            set;
        }

        public String ACTUAL_PAYMENT_AMOUNT
        {
            get;
            set;
        }
    }
}
