using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_DWHMortInfo
   {
       public String ApplicationNO
       {
           get;
           set;
       }

       public Int32 MortID
       {
           get;
           set;
       }

       public Guid CustID
       {
           get;
           set;
       }

       public String CustName
       {
           get;
           set;
       }

       public String CustPName
       {
           get;
           set;
       }

       public String Relation
       {
           get;
           set;
       }

       public String ID_No
       {
           get;
           set;
       }

       public String Phone
       {
           get;
           set;
       }

       public String Mphone
       {
           get;
           set;
       }

       public String SName
       {
           get;
           set;
       }

       public String SPName
       {
           get;
           set;
       }

       public String SID_No
       {
           get;
           set;
       }

       public String SPhone
       {
           get;
           set;
       }

       public String SMPhone
       {
           get;
           set;
       }

       public String House_P
       {
           get;
           set;
       }

       public String House_C
       {
           get;
           set;
       }

       public String House_B
       {
           get;
           set;
       }

       public String House_A
       {
           get;
           set;
       }

       public String House_Code
       {
           get;
           set;
       }

       public String CreatID
       {
           get;
           set;
       }

       public DateTime CreatDate
       {
           get;
           set;
       }

       public String ModiID
       {
           get;
           set;
       }

       public DateTime ModiDate
       {
           get;
           set;
       }

   }
}

