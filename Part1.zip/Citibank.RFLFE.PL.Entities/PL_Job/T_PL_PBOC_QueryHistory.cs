using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FileHelpers;

namespace Citibank.RFLFE.PL.Entities
{
    [DelimitedRecord("|")]
   public class T_PL_PBOC_QueryHistory
   {
       public String ID_NUMBER
       {
           get;
           set;
       }

       public String SERIAL_NUMBER
       {
           get;
           set;
       }

       public String INQUIRE_DATE
       {
           get;
           set;
       }

       public String INQUIRER
       {
           get;
           set;
       }

       public String INQUIRE_REASON
       {
           get;
           set;
       }

       public String IMPORT_DATE
       {
           get;
           set;
       }

   }
}

