﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_DWHApplicationInfo
    {
        public String ApplicationNo
        {
            get;
            set;
        }

        public String ProposalNo
        {
            get;
            set;
        }

        public String LoanNumber
        {
            get;
            set;
        }

        public Guid MBID
        {
            get;
            set;
        }

        public String CustType
        {
            get;
            set;
        }

        public String ProdName
        {
            get;
            set;
        }

        public Int64 RequestedLoanSize
        {
            get;
            set;
        }

        public String Tenor
        {
            get;
            set;
        }

        public Decimal AcceptedInstallment
        {
            get;
            set;
        }

        public String LoanPurpose
        {
            get;
            set;
        }

        public String LPRemarks
        {
            get;
            set;
        }

        public Decimal ProposalRate
        {
            get;
            set;
        }

        public String SourceCode
        {
            get;
            set;
        }

        public String AgentCode
        {
            get;
            set;
        }

        public String WhereKnow
        {
            get;
            set;
        }

        public String DebitBank
        {
            get;
            set;
        }

        public String DebitAccount
        {
            get;
            set;
        }

        public String OrgCode
        {
            get;
            set;
        }

        public String BranchCode
        {
            get;
            set;
        }

        public String Status
        {
            get;
            set;
        }

        public String CustConfirm
        {
            get;
            set;
        }

        public String SigningDate
        {
            get;
            set;
        }

        public String ConfirmDate
        {
            get;
            set;
        }

        public Decimal ProcFee
        {
            get;
            set;
        }

        public Decimal ValFee
        {
            get;
            set;
        }

        public Decimal InsuranceFee
        {
            get;
            set;
        }

        public Decimal LegalFee
        {
            get;
            set;
        }

        public String CustNo
        {
            get;
            set;
        }

        public String RelnNo
        {
            get;
            set;
        }

        public String AccOpenDate
        {
            get;
            set;
        }

        public String PricingDeviationed
        {
            get;
            set;
        }

        public String ApprovedDate
        {
            get;
            set;
        }

        public String ApprovedTime
        {
            get;
            set;
        }

        public String RejectedDate
        {
            get;
            set;
        }

        public String RejectedTime
        {
            get;
            set;
        }

        public String CancelledDate
        {
            get;
            set;
        }

        public String CancelledTime
        {
            get;
            set;
        }

        public String Deviationed
        {
            get;
            set;
        }

        public String RejectOrPendingReason
        {
            get;
            set;
        }

        public String PendReasonCode
        {
            get;
            set;
        }

        public String IsLackDoc
        {
            get;
            set;
        }

        public String IsMoreServer
        {
            get;
            set;
        }

        public String DelegationLvl
        {
            get;
            set;
        }

        public String MaxDeviationLvl
        {
            get;
            set;
        }

        public Decimal LoanAmt
        {
            get;
            set;
        }

        public Decimal LoanTenor
        {
            get;
            set;
        }

        public Decimal DecisionedInstallment
        {
            get;
            set;
        }

        public Decimal BaseRate
        {
            get;
            set;
        }

        public Decimal DecisionedRate
        {
            get;
            set;
        }

        public Decimal CurrDBR
        {
            get;
            set;
        }

        public Decimal TotalDBR
        {
            get;
            set;
        }

        public Decimal DSCR
        {
            get;
            set;
        }

        public String LTV
        {
            get;
            set;
        }

        public Decimal MaxLTV
        {
            get;
            set;
        }

        public String CollType
        {
            get;
            set;
        }

        public String HouseType
        {
            get;
            set;
        }

        public String Title_No
        {
            get;
            set;
        }

        public Decimal Soil_Area
        {
            get;
            set;
        }

        public String Soil_TitleNo
        {
            get;
            set;
        }

        public String CollStatus
        {
            get;
            set;
        }

        public String Region
        {
            get;
            set;
        }

        public String Address
        {
            get;
            set;
        }

        public String ComName
        {
            get;
            set;
        }

        public Decimal Area
        {
            get;
            set;
        }

        public Int64 TotalPrice
        {
            get;
            set;
        }

        public String CompletedYear
        {
            get;
            set;
        }

        public Int32 UsingYear
        {
            get;
            set;
        }

        public String FixRelation
        {
            get;
            set;
        }

        public String FixIsSame
        {
            get;
            set;
        }

        public String FixAddress
        {
            get;
            set;
        }

        public Int64 FixValue1
        {
            get;
            set;
        }

        public Int64 FixValue2
        {
            get;
            set;
        }

        public Decimal InsurFee
        {
            get;
            set;
        }

        public Decimal EvalFee
        {
            get;
            set;
        }

        public String SameWithHouse
        {
            get;
            set;
        }

        public String Coll_P
        {
            get;
            set;
        }

        public String Coll_C
        {
            get;
            set;
        }

        public String Coll_B
        {
            get;
            set;
        }

        public String Coll_A
        {
            get;
            set;
        }

        public String Coll_Code
        {
            get;
            set;
        }

        public String SoilUsingYear
        {
            get;
            set;
        }

        public Int32 HouseAge
        {
            get;
            set;
        }

        public Int64 FixEval
        {
            get;
            set;
        }

        public String Fix_P
        {
            get;
            set;
        }

        public String Fix_C
        {
            get;
            set;
        }

        public String Fix_B
        {
            get;
            set;
        }

        public String Fac1
        {
            get;
            set;
        }

        public Int32 Fac1Value
        {
            get;
            set;
        }

        public String Fac2
        {
            get;
            set;
        }

        public Int32 Fac2Value
        {
            get;
            set;
        }

        public String Fac3
        {
            get;
            set;
        }

        public Int32 Fac3Value
        {
            get;
            set;
        }

        public String Fac4
        {
            get;
            set;
        }

        public Int32 Fac4Value
        {
            get;
            set;
        }

        public String Fac5
        {
            get;
            set;
        }

        public Int32 Fac5Value
        {
            get;
            set;
        }

        public Int64 HouseValue
        {
            get;
            set;
        }

        public Int32 LtvHouseAge
        {
            get;
            set;
        }

        public Decimal BaseLtv
        {
            get;
            set;
        }

        public Decimal LowerLtvTotal
        {
            get;
            set;
        }

        public Decimal AllowedMaxLtv
        {
            get;
            set;
        }

        public Int64 MaxLoanSize
        {
            get;
            set;
        }

        public Int64 FreeULoan
        {
            get;
            set;
        }

        public String ATenor
        {
            get;
            set;
        }

        public Decimal RateForYear
        {
            get;
            set;
        }

        public Int64 NewALoanSize
        {
            get;
            set;
        }

        public Decimal FInstallment
        {
            get;
            set;
        }

        public Int64 MBIncom
        {
            get;
            set;
        }

        public Int64 MBDebt
        {
            get;
            set;
        }

        public Int64 CB1Incom
        {
            get;
            set;
        }

        public Int64 CB1Debt
        {
            get;
            set;
        }

        public Int64 CB2Incom
        {
            get;
            set;
        }

        public Int64 CB2Debt
        {
            get;
            set;
        }

        public Int64 HomeIncom
        {
            get;
            set;
        }

        public Int64 HomeDebt
        {
            get;
            set;
        }

        public Int64 HomeOutgoing
        {
            get;
            set;
        }

        public Int64 MonthIncomeTotal
        {
            get;
            set;
        }

        public String PBoC
        {
            get;
            set;
        }

        public String ALS
        {
            get;
            set;
        }

        public String NgtvFile
        {
            get;
            set;
        }

        public String DupCheck
        {
            get;
            set;
        }

        public String RltdPt
        {
            get;
            set;
        }

        public String ItnFraud
        {
            get;
            set;
        }

        public String Velocity
        {
            get;
            set;
        }

        public String Verf
        {
            get;
            set;
        }

        public String RacStatus
        {
            get;
            set;
        }

        public String Devationed
        {
            get;
            set;
        }

        public String MUE
        {
            get;
            set;
        }

        public String SDBR
        {
            get;
            set;
        }

        public String UDBR
        {
            get;
            set;
        }

        public String CDBR
        {
            get;
            set;
        }

        public String TDBR
        {
            get;
            set;
        }

        public String CStage
        {
            get;
            set;
        }

        public String PBOCIqrDate
        {
            get;
            set;
        }

        public String Prescreener
        {
            get;
            set;
        }

        public String Verifier
        {
            get;
            set;
        }

        public String CrdtSn
        {
            get;
            set;
        }

        public String FApprover
        {
            get;
            set;
        }

        public String SApprover
        {
            get;
            set;
        }

        public String MDBR
        {
            get;
            set;
        }

        public String CompanyName
        {
            get;
            set;
        }

        public String RequestDate
        {
            get;
            set;
        }

        public String AcceptDate
        {
            get;
            set;
        }

        public Int64 Value
        {
            get;
            set;
        }

        public Decimal Fee
        {
            get;
            set;
        }

        public String IsSelected
        {
            get;
            set;
        }

        public String CreatID
        {
            get;
            set;
        }

        public DateTime CreatDate
        {
            get;
            set;
        }

        public String ModiID
        {
            get;
            set;
        }

        public DateTime ModiDate
        {
            get;
            set;
        }

        public Int32 ApproveCount
        {
            get;
            set;
        }

        public Int32 RejectCount
        {
            get;
            set;
        }

        public Int32 CancelCount
        {
            get;
            set;
        }

        public String SoilType
        {
            get;
            set;
        }

        public String User_Defined1
        {
            get;
            set;
        }

        public String User_Defined2
        {
            get;
            set;
        }

        public String User_Defined3
        {
            get;
            set;
        }

        public String User_Defined4
        {
            get;
            set;
        }

        public String User_Defined5
        {
            get;
            set;
        }

        public String OriginalAppNo
        {
            get;
            set;
        }

        public Int64 OriginalAccNo
        {
            get;
            set;
        }

        public Int64 OriginalSegmentId
        {
            get;
            set;
        }

        public Int64 TopUpSegmentId
        {
            get;
            set;
        }

        public String PolicyDeviation
        {
            get;
            set;
        }

        public String PriceDeviation
        {
            get;
            set;
        }

        public String ProcessDeviation
        {
            get;
            set;
        }

        public String PolicyDeviationReason
        {
            get;
            set;
        }

        public String PriceDeviationReason
        {
            get;
            set;
        }

        public String ProcessDeviationReason
        {
            get;
            set;
        }

        public String DeviationRemarks
        {
            get;
            set;
        }

        public String NotSamePlace
        {
            get;
            set;
        }

        public String GuarantorCnName
        {
            get;
            set;
        }

        public String GuarantorEnName
        {
            get;
            set;
        }

        public String Guarantor_ID
        {
            get;
            set;
        }

        public String GuarantorTel
        {
            get;
            set;
        }

        public String GuarantorMob
        {
            get;
            set;
        }

        public String GuarantorRelation
        {
            get;
            set;
        }

        public String Guarantor_House_P
        {
            get;
            set;
        }

        public String Guarantor_House_C
        {
            get;
            set;
        }

        public String Guarantor_House_B
        {
            get;
            set;
        }

        public String Guarantor_House_A
        {
            get;
            set;
        }

        public String Guarantor_House_PostCode
        {
            get;
            set;
        }

        public String Guarantor_Work_P
        {
            get;
            set;
        }

        public String Guarantor_Work_C
        {
            get;
            set;
        }

        public String Guarantor_Work_B
        {
            get;
            set;
        }

        public String Guarantor_Work_A
        {
            get;
            set;
        }

        public String Guarantor_Work_PostCode
        {
            get;
            set;
        }

        public Decimal FMV
        {
            get;
            set;
        }

        public Decimal LandValue
        {
            get;
            set;
        }

        public Decimal BuildingValue
        {
            get;
            set;
        }

        public Decimal AssessmentFee
        {
            get;
            set;
        }

        public Decimal InsureFee
        {
            get;
            set;
        }

        public Decimal RegisterFee
        {
            get;
            set;
        }

        public String IsWorkerLoan
        {
            get;
            set;
        }

        public Int32 ConfirmTotalMoCount
        {
            get;
            set;
        }

        public Int32 ConfirmTotalMoCount_Orgin
        {
            get;
            set;
        }

    }
}
