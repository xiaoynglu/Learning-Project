using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FileHelpers;

namespace Citibank.RFLFE.PL.Entities
{
    [DelimitedRecord("|")]
   public class T_PL_PBOC_IndividualHouseFund
   {
       public String ID_NUMBER
       {
           get;
           set;
       }

       public String SERIAL_NUMBER
       {
           get;
           set;
       }

       public String PERSONAL_ACCOUNT
       {
           get;
           set;
       }

       public String UNIT_NAME
       {
           get;
           set;
       }

       public String OPEN_ACCOUNT_DATE
       {
           get;
           set;
       }

       public String FIRST_HANDIN_DATE
       {
           get;
           set;
       }

       public String LATEST_HANDIN_DATE
       {
           get;
           set;
       }

       public String UNIT_PAY_RATIO
       {
           get;
           set;
       }

       public String PERSON_PAY_RATIO
       {
           get;
           set;
       }

       public String MONTH_HANDIN_BALANCE
       {
           get;
           set;
       }

       public String HANDIN_END_DATE
       {
           get;
           set;
       }

       public String The24
       {
           get;
           set;
       }

       public String The23
       {
           get;
           set;
       }

       public String The22
       {
           get;
           set;
       }

       public String The21
       {
           get;
           set;
       }

       public String The20
       {
           get;
           set;
       }

       public String The19
       {
           get;
           set;
       }

       public String The18
       {
           get;
           set;
       }

       public String The17
       {
           get;
           set;
       }

       public String The16
       {
           get;
           set;
       }

       public String The15
       {
           get;
           set;
       }

       public String The14
       {
           get;
           set;
       }

       public String The13
       {
           get;
           set;
       }

       public String The12
       {
           get;
           set;
       }

       public String The11
       {
           get;
           set;
       }

       public String The10
       {
           get;
           set;
       }

       public String The9
       {
           get;
           set;
       }

       public String The8
       {
           get;
           set;
       }

       public String The7
       {
           get;
           set;
       }

       public String The6
       {
           get;
           set;
       }

       public String The5
       {
           get;
           set;
       }

       public String The4
       {
           get;
           set;
       }

       public String The3
       {
           get;
           set;
       }

       public String The2
       {
           get;
           set;
       }

       public String The1
       {
           get;
           set;
       }

       public String INF_CAPTURE_TIME
       {
           get;
           set;
       }

       public String IMPORT_DATE
       {
           get;
           set;
       }

   }
}

