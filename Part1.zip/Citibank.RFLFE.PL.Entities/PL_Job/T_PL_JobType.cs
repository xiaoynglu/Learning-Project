﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public enum JobType
    {
        DWH = 0,
        Advice = 1,
        RiskData = 2,
        RM = 3,
        Annual = 4,
        Bureau = 5,  //PBOC
        CNRFALS = 6
    }

    public enum FileType
    {
        DWHAppInfo = 0,
        DWHCustInfo = 1,
        DWHMortInfo = 2,
        DWHAppHis = 3,
        RiskData = 4,
        CNRFALS = 5
    }

    public enum AlignEnum
    {
        Left = 0,
        Right = 1
    }
}
