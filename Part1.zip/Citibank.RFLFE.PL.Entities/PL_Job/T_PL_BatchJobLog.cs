﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_BatchJobLog
    {
        public String JobName
        {
            get;
            set;
        }

        public DateTime RunDate
        {
            get;
            set;
        }

        public int RunStatus
        {
            get;
            set;
        }

        public String RunMachine
        {
            get;
            set;
        }

        public String Remark
        {
            get;
            set;
        }

        public String FileName
        {
            get;
            set;
        }

        public DateTime? FileWriteDate
        {
            get;
            set;
        }
    }
}
