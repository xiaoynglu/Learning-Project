using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FileHelpers;

namespace Citibank.RFLFE.PL.Entities
{
    [DelimitedRecord("|")]
   public class T_PL_PBOC_ResideAddress
   {
       public String ID_NUMBER
       {
           get;
           set;
       }

       public String SERIAL_NUMBER
       {
           get;
           set;
       }

       public String RESIDE_ADDRESS
       {
           get;
           set;
       }

       public String RESIDE_ADDRESS_MAILNUMBER
       {
           get;
           set;
       }

       public String RESIDE_STATUS
       {
           get;
           set;
       }

       public String INF_CAPTURE_TIME
       {
           get;
           set;
       }

       public String IMPORT_DATE
       {
           get;
           set;
       }

   }
}

