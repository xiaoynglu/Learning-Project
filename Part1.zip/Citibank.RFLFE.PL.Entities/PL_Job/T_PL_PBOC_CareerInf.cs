using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FileHelpers;

namespace Citibank.RFLFE.PL.Entities
{
   [DelimitedRecord("|")]
   public class T_PL_PBOC_CareerInf
   {
       public String ID_NUMBER
       {
           get;
           set;
       }

       public String SERIAL_NUMBER
       {
           get;
           set;
       }

       public String EMPLOYER_UNIT_NAME
       {
           get;
           set;
       }

       public String EMPLOYER_UNIT_ADDRESS
       {
           get;
           set;
       }

       public String EMPLOYER_UNIT_MAILNUMBER
       {
           get;
           set;
       }

       public String EMPLOYER_INDUSTRY
       {
           get;
           set;
       }

       public String CAREER
       {
           get;
           set;
       }

       public String POSITION
       {
           get;
           set;
       }

       public String TITLE
       {
           get;
           set;
       }

       public String ANNUAL_INCOME
       {
           get;
           set;
       }

       public String CURRENT_EMPLOYER_START_YEAR
       {
           get;
           set;
       }

       public String INF_CAPTURE_TIME
       {
           get;
           set;
       }

       public String IMPORT_DATE
       {
           get;
           set;
       }

   }
}

