﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_RunResult
    {
        public Guid AppID {  get;  set; }

        public string ProdID { get; set; }

        public string StageID { get; set; }

        //无担保额度
        public string MUE { get; set; }

        //有担保DBR
        public string SDBR { get; set; }

        //无担保DBR
        public string UDBR { get; set; }

        //当前DBR
        public string CDBR { get; set; }

        //总DBR
        public string TDBR { get; set; }

        //贷款成数
        public string LTV { get; set; }
        
        public string SDNAndPF { get; set; }

        public string MonthlyInstallment { get; set; }

        //征信查询
        public string PBoC { get; set; }

        //内部信用记录
        public string ALS { get; set; }

        //内部负面信息检查
        public string NgtvFile { get; set; }

        //重复贷款建议检查
        public string DupCheck { get; set; }

        //关联人物检查
        public string RltdPt { get; set; }

        //内部欺诈名单检查
        public string ItnFraud { get; set; }

        //可疑欺诈名单检查
        public string Velocity { get; set; }

        public string Verf { get; set; }

        //系统决策详情
        public string RacStatus { get; set; }

        //异常
        public string Devationed { get; set; }

        //最高贷款额度
        public string MaxLoanSize { get; set; }

        //当前流程
        public string CStage { get; set; }

        //PBOC查询日期
        public string PBOCIqrDate { get; set; }

        //预批
        public string Prescreener { get; set; }

        //核实
        public string Verifier { get; set; }

        //信贷签署
        public string CrdtSn { get; set; }

        //第一审批
        public string FApprover { get; set; }

        //第二审批
        public string SApprover { get; set; }

        //住房贷款月收入比
        public string MDBR { get; set; }

        //利率特批
        public string RateException { get; set; }

        //产调核实
        public string HouseBureauCheck { get; set; }
    }
}
