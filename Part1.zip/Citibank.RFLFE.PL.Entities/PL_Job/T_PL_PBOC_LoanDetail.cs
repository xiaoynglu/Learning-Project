using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FileHelpers;

namespace Citibank.RFLFE.PL.Entities
{
    [DelimitedRecord("|")]
   public class T_PL_PBOC_LoanDetail
   {
       public String ID_NUMBER
       {
           get;
           set;
       }

       public String SERIAL_NUMBER
       {
           get;
           set;
       }

       public String LOAN_TYPE
       {
           get;
           set;
       }

       public String OPERATION_NUM
       {
           get;
           set;
       }

       public String LOAN_UNIT_NAME
       {
           get;
           set;
       }

       public String AVOUCH_TYPE
       {
           get;
           set;
       }

       public String CURRENCY
       {
           get;
           set;
       }

       public String ACCOUNT_STATUS
       {
           get;
           set;
       }

       public String PAYBACK_SPEED
       {
           get;
           set;
       }

       public String PAYBACK_MONTH
       {
           get;
           set;
       }

       public String LOAN_PROVIDE_DATE
       {
           get;
           set;
       }

       public String LOAN_DEADLINE
       {
           get;
           set;
       }

       public String LOAN_TOTOAL
       {
           get;
           set;
       }

       public String LOAN_BALANCE
       {
           get;
           set;
       }

       public String LEFT_PAYBACK_MONTH
       {
           get;
           set;
       }

       public String LATEST_PAY_DATE
       {
           get;
           set;
       }

       public String MONTH_OUGHT_PAY
       {
           get;
           set;
       }

       public String MONTH_PRACTICAL_PAY
       {
           get;
           set;
       }

       public String DELINQUENT_NUM
       {
           get;
           set;
       }

       public String ALL_DELINQUENT_TIMES
       {
           get;
           set;
       }

       public String HIGHEST_DELINQUENT_NUM
       {
           get;
           set;
       }

       public String EXCEED_31_60
       {
           get;
           set;
       }

       public String EXCEED_61_90
       {
           get;
           set;
       }

       public String EXCEED_91_180
       {
           get;
           set;
       }

       public String EXCEED_181
       {
           get;
           set;
       }

       public String The24
       {
           get;
           set;
       }

       public String The23
       {
           get;
           set;
       }

       public String The22
       {
           get;
           set;
       }

       public String The21
       {
           get;
           set;
       }

       public String The20
       {
           get;
           set;
       }

       public String The19
       {
           get;
           set;
       }

       public String The18
       {
           get;
           set;
       }

       public String The17
       {
           get;
           set;
       }

       public String The16
       {
           get;
           set;
       }

       public String The15
       {
           get;
           set;
       }

       public String The14
       {
           get;
           set;
       }

       public String The13
       {
           get;
           set;
       }

       public String The12
       {
           get;
           set;
       }

       public String The11
       {
           get;
           set;
       }

       public String The10
       {
           get;
           set;
       }

       public String The9
       {
           get;
           set;
       }

       public String The8
       {
           get;
           set;
       }

       public String The7
       {
           get;
           set;
       }

       public String The6
       {
           get;
           set;
       }

       public String The5
       {
           get;
           set;
       }

       public String The4
       {
           get;
           set;
       }

       public String The3
       {
           get;
           set;
       }

       public String The2
       {
           get;
           set;
       }

       public String The1
       {
           get;
           set;
       }

       public String INF_CAPTURE_TIME
       {
           get;
           set;
       }

       public String IMPORT_DATE
       {
           get;
           set;
       }

       public String CALCULATE_YEAR_MONTH
       {
           get;
           set;
       }

       public String DQYQZE
       {
           get;
           set;
       }

   }
}

