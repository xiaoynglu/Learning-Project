using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_DWHApplicationHis
   {
       public String ApplicationNo
       {
           get;
           set;
       }

       public String PRO_ID
       {
           get;
           set;
       }

       public String BEGINDATE
       {
           get;
           set;
       }

       public String BEGINSTAGE
       {
           get;
           set;
       }

       public String ENDDATE
       {
           get;
           set;
       }

       public String ENDSTAGE
       {
           get;
           set;
       }

       public String ACTION
       {
           get;
           set;
       }

       public String REMARK1
       {
           get;
           set;
       }

   }
}

