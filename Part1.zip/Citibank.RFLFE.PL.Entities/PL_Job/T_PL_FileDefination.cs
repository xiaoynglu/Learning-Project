﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_FileDefination
    {
        public string ColumnName { get; set; }

        public int RecordType { get; set; }

        public string DataType { get; set; }

        public int Length { get; set; }

        public int StartPosition { get; set; }

        public int EndPosition { get; set; }

        public string ReportType { get; set; }

        public string Format { get; set; }

        public int SortIndex { get; set; }
    }

    //public class DWH_FileDefination
    //{
    //    public string ColumnName { get; set; }

    //    public string RecordType { get; set; }

    //    public string DataType { get; set; }

    //    public string Length { get; set; }

    //    public string StartPosition { get; set; }

    //    public string EndPosition { get; set; }

    //    public string ReportType { get; set; }
    //}
}
