﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_RiskData
    {
        public String Loan_nbr
        {
            get;
            set;
        }

        public String Marrital
        {
            get;
            set;
        }

        public String Education
        {
            get;
            set;
        }

        public String CompanyName
        {
            get;
            set;
        }

        public String Industry
        {
            get;
            set;
        }

        public String Designation
        {
            get;
            set;
        }

        public String DomicAdd
        {
            get;
            set;
        }

        public String SpouseName
        {
            get;
            set;
        }

        public String SpouseIDType
        {
            get;
            set;
        }

        public String SpouseID
        {
            get;
            set;
        }

        public String SpouseEmployerName
        {
            get;
            set;
        }

        public String SpouseContactPhone
        {
            get;
            set;
        }

        public String OfficeAdd
        {
            get;
            set;
        }

        public String OfficeZIPCode
        {
            get;
            set;
        }

        public String WorkingYear
        {
            get;
            set;
        }

        public String ProvenIncome
        {
            get;
            set;
        }

        public String ResidentType
        {
            get;
            set;
        }
    }
}
