using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FileHelpers;

namespace Citibank.RFLFE.PL.Entities
{
    [DelimitedRecord("|")]
   public class T_PL_PBOC_PersonalInfo
   {
       public String InquiryName
       {
           get;
           set;
       }

       public String Inquirer
       {
           get;
           set;
       }

       public String Inquiryreason
       {
           get;
           set;
       }

       public String NAME
       {
           get;
           set;
       }

       public String ID_TYPE
       {
           get;
           set;
       }

       public String ID_NUMBER
       {
           get;
           set;
       }

       public String SEX
       {
           get;
           set;
       }

       public String BIRTHDAY
       {
           get;
           set;
       }

       public String HIGHEST_EDUCATION
       {
           get;
           set;
       }

       public String HIGHEST_DIPLOMA
       {
           get;
           set;
       }

       public String CONTACT_ADDRESS
       {
           get;
           set;
       }

       public String CONTACT_ADDRESS_MAILNUMBER
       {
           get;
           set;
       }

       public String CENSUS_REGISTER_ADDRESS
       {
           get;
           set;
       }

       public String HOUSE_PHONE_NUMBER
       {
           get;
           set;
       }

       public String EMPLOYER_UNIT_PHONE
       {
           get;
           set;
       }

       public String MOBILE_PHONE
       {
           get;
           set;
       }

       public String EMAIL
       {
           get;
           set;
       }

       public String MARRIAGE_STATUS
       {
           get;
           set;
       }

       public String SPOUSE_NAME
       {
           get;
           set;
       }

       public String SPOUSE_ID_TYPE
       {
           get;
           set;
       }

       public String SPOUSE_ID_NUMBER
       {
           get;
           set;
       }

       public String SPOUSE_EMPLOYER_UNIT
       {
           get;
           set;
       }

       public String SPOUSE_CONTACT_NUMBER
       {
           get;
           set;
       }

       public String INF_CAPTURE_TIME
       {
           get;
           set;
       }

       public String IMPORTDATE
       {
           get;
           set;
       }

       public String AppID
       {
           get;
           set;
       }

       public String FoundBureauFile
       {
           get;
           set;
       }

       public String CertType
       {
           get;
           set;
       }

       public Int32? Status
       {
           get;
           set;
       }

       public String AppGuid
       {
           get;
           set;
       }

   }
}

