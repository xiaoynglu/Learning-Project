﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_DWHCustInfo
    {
        public Guid CustID
        {
            get;
            set;
        }

        public String ApplicationNo
        {
            get;
            set;
        }

        public String CustSegm
        {
            get;
            set;
        }

        public String RiskSegm
        {
            get;
            set;
        }

        public String BorrowType
        {
            get;
            set;
        }

        public String CustFName
        {
            get;
            set;
        }

        public String CustLName
        {
            get;
            set;
        }

        public String CustName
        {
            get;
            set;
        }

        public String CustPName
        {
            get;
            set;
        }

        public String CoBorrow
        {
            get;
            set;
        }

        public String Gender
        {
            get;
            set;
        }

        public String BirthDate
        {
            get;
            set;
        }

        public String ID_No
        {
            get;
            set;
        }

        public String WorkType
        {
            get;
            set;
        }

        public String JobProperty
        {
            get;
            set;
        }

        public String Job
        {
            get;
            set;
        }

        public String Ent_Level
        {
            get;
            set;
        }

        public String Ent_Scale
        {
            get;
            set;
        }

        public String HasHouse
        {
            get;
            set;
        }

        public String Marriage
        {
            get;
            set;
        }

        public String SpouseName
        {
            get;
            set;
        }

        public String SpouseID
        {
            get;
            set;
        }

        public Decimal CurrHouse
        {
            get;
            set;
        }

        public String Edu
        {
            get;
            set;
        }

        public String CurrDep
        {
            get;
            set;
        }

        public String CurrTitle
        {
            get;
            set;
        }

        public String CTRemarks
        {
            get;
            set;
        }

        public String Position
        {
            get;
            set;
        }

        public String CompName
        {
            get;
            set;
        }

        public String CompType
        {
            get;
            set;
        }

        public String CPRemarks
        {
            get;
            set;
        }

        public Decimal CurrentWorkingYear
        {
            get;
            set;
        }

        public Decimal LastWorkingYear
        {
            get;
            set;
        }

        public Decimal ProWorkingYear
        {
            get;
            set;
        }

        public Decimal TotalWorkingYear
        {
            get;
            set;
        }

        public String NoName
        {
            get;
            set;
        }

        public String Licence
        {
            get;
            set;
        }

        public String Operator
        {
            get;
            set;
        }

        public String Operate_Place
        {
            get;
            set;
        }

        public Decimal Operate_Year
        {
            get;
            set;
        }

        public Int32 EmpCount
        {
            get;
            set;
        }

        public String Contact
        {
            get;
            set;
        }

        public String ContactTitle
        {
            get;
            set;
        }

        public String Prequalified
        {
            get;
            set;
        }

        public String PremiseOwner
        {
            get;
            set;
        }

        public String CarOwner
        {
            get;
            set;
        }

        public Decimal MonthlyBalance
        {
            get;
            set;
        }

        public String HasSSC
        {
            get;
            set;
        }

        public Decimal MonthlySSC
        {
            get;
            set;
        }

        public String HasLifeInsure
        {
            get;
            set;
        }

        public Decimal LifeInsure
        {
            get;
            set;
        }

        public Decimal MonthlyTax
        {
            get;
            set;
        }

        public String BusinessScale
        {
            get;
            set;
        }

        public String PBOCDownloaded
        {
            get;
            set;
        }

        public String EmployerCD
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_Salary
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_House_Salary
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_Other_Salary
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_P_Salary
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_Loan_Fee
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_Public_Fee
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_Live_Fee
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_Edu_Fee
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_Tra_Fee
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_Other_Fee
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_SL_Fee
        {
            get;
            set;
        }

        public Int64 SA_SelfDeclared_UL_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_M_Turnover
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Cost
        {
            get;
            set;
        }

        public Decimal SE_SelfDeclared_Gross
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Rent
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Pub_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Emp_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Other_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Tax
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_P_Salary
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_House_Salary
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_O_Salary
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Loan_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Public_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Live_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Edu_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_Tra_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_OF_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_SL_Fee
        {
            get;
            set;
        }

        public Int64 SE_SelfDeclared_UL_Fee
        {
            get;
            set;
        }

        public String Operator_Type
        {
            get;
            set;
        }

        public String CAR
        {
            get;
            set;
        }

        public Int32 Cards
        {
            get;
            set;
        }

        public Int64 Cards_Tot
        {
            get;
            set;
        }

        public String Fund
        {
            get;
            set;
        }

        public Decimal Fund_Rate
        {
            get;
            set;
        }

        public Int32 Fund_Year
        {
            get;
            set;
        }

        public String Fund_No
        {
            get;
            set;
        }

        public String Insure
        {
            get;
            set;
        }

        public Decimal Insur_Rate
        {
            get;
            set;
        }

        public Int32 Insur_Year
        {
            get;
            set;
        }

        public Decimal S_TAX
        {
            get;
            set;
        }

        public Decimal Y_TAX
        {
            get;
            set;
        }

        public String House_P
        {
            get;
            set;
        }

        public String House_C
        {
            get;
            set;
        }

        public String House_B
        {
            get;
            set;
        }

        public String House_A
        {
            get;
            set;
        }

        public String House_Code
        {
            get;
            set;
        }

        public String House_Status
        {
            get;
            set;
        }

        public String HSRemarks
        {
            get;
            set;
        }

        public String House_Tel_No
        {
            get;
            set;
        }

        public String House_Tel
        {
            get;
            set;
        }

        public String Domic_Addr
        {
            get;
            set;
        }

        public String Domic_P
        {
            get;
            set;
        }

        public String Domic_C
        {
            get;
            set;
        }

        public String Domic_B
        {
            get;
            set;
        }

        public String Domic_A
        {
            get;
            set;
        }

        public String Domic_Code
        {
            get;
            set;
        }

        public String Co_P
        {
            get;
            set;
        }

        public String Co_C
        {
            get;
            set;
        }

        public String Co_B
        {
            get;
            set;
        }

        public String Co_A
        {
            get;
            set;
        }

        public String Co_Code
        {
            get;
            set;
        }

        public String Co_Tel_No
        {
            get;
            set;
        }

        public String Co_Tel
        {
            get;
            set;
        }

        public String Co_S_Tel
        {
            get;
            set;
        }

        public String Address
        {
            get;
            set;
        }

        public String Tel
        {
            get;
            set;
        }

        public String Mail
        {
            get;
            set;
        }

        public String ID_Date
        {
            get;
            set;
        }

        public String Pare_Name
        {
            get;
            set;
        }

        public String Pare_R
        {
            get;
            set;
        }

        public String PRRemarks
        {
            get;
            set;
        }

        public String Pare_Co
        {
            get;
            set;
        }

        public String Pare_Tel_No
        {
            get;
            set;
        }

        public String Pare_Tel
        {
            get;
            set;
        }

        public String Pare_S_Tel
        {
            get;
            set;
        }

        public String Pare_Mob
        {
            get;
            set;
        }

        public String Oth_Name
        {
            get;
            set;
        }

        public String Oth_R
        {
            get;
            set;
        }

        public String ORRemarks
        {
            get;
            set;
        }

        public String Oth_Co
        {
            get;
            set;
        }

        public String Oth_Tel_No
        {
            get;
            set;
        }

        public String Oth_Tel
        {
            get;
            set;
        }

        public String Oth_S_Tel
        {
            get;
            set;
        }

        public String Oth_Mob
        {
            get;
            set;
        }

        public String ISType1
        {
            get;
            set;
        }

        public Decimal Declare1
        {
            get;
            set;
        }

        public Decimal Confirm1
        {
            get;
            set;
        }

        public Decimal ProIncome1
        {
            get;
            set;
        }

        public String selected1
        {
            get;
            set;
        }

        public String ISType2
        {
            get;
            set;
        }

        public Decimal Declare2
        {
            get;
            set;
        }

        public Decimal Confirm2
        {
            get;
            set;
        }

        public Decimal ProIncome2
        {
            get;
            set;
        }

        public String selected2
        {
            get;
            set;
        }

        public String ISType3
        {
            get;
            set;
        }

        public Decimal Declare3
        {
            get;
            set;
        }

        public Decimal Confirm3
        {
            get;
            set;
        }

        public Decimal ProIncome3
        {
            get;
            set;
        }

        public String selected3
        {
            get;
            set;
        }

        public String ISType4
        {
            get;
            set;
        }

        public Decimal Declare4
        {
            get;
            set;
        }

        public Decimal Confirm4
        {
            get;
            set;
        }

        public Decimal ProIncome4
        {
            get;
            set;
        }

        public String selected4
        {
            get;
            set;
        }

        public String ISType5
        {
            get;
            set;
        }

        public Decimal Declare5
        {
            get;
            set;
        }

        public Decimal Confirm5
        {
            get;
            set;
        }

        public Decimal ProIncome5
        {
            get;
            set;
        }

        public String selected5
        {
            get;
            set;
        }

        public String IncomeType1
        {
            get;
            set;
        }

        public Decimal IncomeDeclare1
        {
            get;
            set;
        }

        public Decimal ConfirmIn1
        {
            get;
            set;
        }

        public String SelectedIn1
        {
            get;
            set;
        }

        public String IncomeType2
        {
            get;
            set;
        }

        public Decimal IncomeDeclare2
        {
            get;
            set;
        }

        public Decimal ConfirmIn2
        {
            get;
            set;
        }

        public String SelectedIn2
        {
            get;
            set;
        }

        public String IncomeType3
        {
            get;
            set;
        }

        public Decimal IncomeDeclare3
        {
            get;
            set;
        }

        public Decimal ConfirmIn3
        {
            get;
            set;
        }

        public String SelectedIn3
        {
            get;
            set;
        }

        public String IncomeType4
        {
            get;
            set;
        }

        public Decimal IncomeDeclare4
        {
            get;
            set;
        }

        public Decimal ConfirmIn4
        {
            get;
            set;
        }

        public String SelectedIn4
        {
            get;
            set;
        }

        public String IncomeType5
        {
            get;
            set;
        }

        public Decimal IncomeDeclare5
        {
            get;
            set;
        }

        public Decimal ConfirmIn5
        {
            get;
            set;
        }

        public String SelectedIn5
        {
            get;
            set;
        }

        public Decimal ProvenIncome
        {
            get;
            set;
        }

        public Decimal CurrLoan
        {
            get;
            set;
        }

        public Decimal ConfirmCurrLoan
        {
            get;
            set;
        }

        public Decimal PBOCSL
        {
            get;
            set;
        }

        public Decimal ConfirmPBOCSL
        {
            get;
            set;
        }

        public Decimal PBOCUL
        {
            get;
            set;
        }

        public Decimal ConfirmPBOCUL
        {
            get;
            set;
        }

        public Decimal PBOCCCard
        {
            get;
            set;
        }

        public Decimal ConfirmPBOCCCard
        {
            get;
            set;
        }

        public Decimal CitiSL
        {
            get;
            set;
        }

        public Decimal ConfirmCitiSL
        {
            get;
            set;
        }

        public Decimal CitiUL
        {
            get;
            set;
        }

        public Decimal ConfirmCitiUL
        {
            get;
            set;
        }

        public Decimal OSL
        {
            get;
            set;
        }

        public Decimal ConfirmOSL
        {
            get;
            set;
        }

        public Decimal OUL
        {
            get;
            set;
        }

        public Decimal ConfirmOUL
        {
            get;
            set;
        }

        public Decimal TotalDebt
        {
            get;
            set;
        }

        public Decimal ConfirmedTotalDebt
        {
            get;
            set;
        }

        public Int64 SA_Proven_Salary
        {
            get;
            set;
        }

        public Int64 SA_Proven_House_Salary
        {
            get;
            set;
        }

        public Int64 SA_Proven_Other_Salary
        {
            get;
            set;
        }

        public Int64 SA_Proven_P_Salary
        {
            get;
            set;
        }

        public Int64 SA_Proven_Loan_Fee
        {
            get;
            set;
        }

        public Int64 SA_Proven_Public_Fee
        {
            get;
            set;
        }

        public Int64 SA_Proven_Live_Fee
        {
            get;
            set;
        }

        public Int64 SA_Proven_Edu_Fee
        {
            get;
            set;
        }

        public Int64 SA_Proven_Tra_Fee
        {
            get;
            set;
        }

        public Int64 SA_Proven_Other_Fee
        {
            get;
            set;
        }

        public Int64 SA_Proven_SL_Fee
        {
            get;
            set;
        }

        public Int64 SA_Proven_UL_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_M_Turnover
        {
            get;
            set;
        }

        public Int64 SE_Proven_Cost
        {
            get;
            set;
        }

        public Decimal SE_Proven_Gross
        {
            get;
            set;
        }

        public Int64 SE_Proven_Rent
        {
            get;
            set;
        }

        public Int64 SE_Proven_Pub_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_Emp_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_Other_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_Tax
        {
            get;
            set;
        }

        public Int64 SE_Proven_P_Salary
        {
            get;
            set;
        }

        public Int64 SE_Proven_House_Salary
        {
            get;
            set;
        }

        public Int64 SE_Proven_O_Salary
        {
            get;
            set;
        }

        public Int64 SE_Proven_Loan_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_Public_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_Live_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_Edu_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_Tra_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_OF_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_SL_Fee
        {
            get;
            set;
        }

        public Int64 SE_Proven_UL_Fee
        {
            get;
            set;
        }

        public String TODAY
        {
            get;
            set;
        }

        public String CERT_TYPE
        {
            get;
            set;
        }

        public String CERT_ID
        {
            get;
            set;
        }

        public String FULLNAME
        {
            get;
            set;
        }

        public String FoundBureauFile
        {
            get;
            set;
        }

        public String INQUIRY_NAME
        {
            get;
            set;
        }

        public String ID_TYPE
        {
            get;
            set;
        }

        public String ID_NUMBER
        {
            get;
            set;
        }

        public String INQUIRER
        {
            get;
            set;
        }

        public String Inquiryreason
        {
            get;
            set;
        }

        public String NAME
        {
            get;
            set;
        }

        public String SEX
        {
            get;
            set;
        }

        public String BIRTHDAY
        {
            get;
            set;
        }

        public String HIGHEST_EDUCATION
        {
            get;
            set;
        }

        public String CONTACT_ADDRESS
        {
            get;
            set;
        }

        public String ZIP_CODE
        {
            get;
            set;
        }

        public String HOME_ADDRESS
        {
            get;
            set;
        }

        public String HOUSE_PHONE_NUMBER
        {
            get;
            set;
        }

        public String EMPLOYER_UNIT_PHONE
        {
            get;
            set;
        }

        public String MOBILE_PHONE
        {
            get;
            set;
        }

        public String EMAIL
        {
            get;
            set;
        }

        public String MARRIAGE_STATUS
        {
            get;
            set;
        }

        public String SPOUSE_NAME
        {
            get;
            set;
        }

        public String SPOUSE_ID_TYPE
        {
            get;
            set;
        }

        public String SPOUSE_ID_NUMBER
        {
            get;
            set;
        }

        public String SPOUSE_EMPLOYER_UNIT
        {
            get;
            set;
        }

        public String SPOUSE_CONTACT_NUMBER
        {
            get;
            set;
        }

        public String INF_CAPTURE_TIME
        {
            get;
            set;
        }

        public Int32 WORKING_YEAR_IN_CURRENT_INDUSTRY
        {
            get;
            set;
        }

        public Int32 TOTAL_WORKING_YEAR
        {
            get;
            set;
        }

        public Int32 UTI
        {
            get;
            set;
        }

        public Int32 ExposureIncome
        {
            get;
            set;
        }

        public Decimal TURT
        {
            get;
            set;
        }

        public Int32 OLDEST_MOB
        {
            get;
            set;
        }

        public Int32 LATEST_MOB
        {
            get;
            set;
        }

        public Decimal TOTAL_INSTALLMENT_OF_TOTAL_LOANS
        {
            get;
            set;
        }

        public Decimal TOTAL_INSTALLMENT_OF_UNSECURED_LOANS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M1_IN_LAST_24_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M1_IN_LAST_12_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M1_IN_LAST_6_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M2_IN_LAST_24_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M2_IN_LAST_12_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M2_IN_LAST_6_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M3_IN_LAST_24_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M3_IN_LAST_12_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M3_IN_LAST_6_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M4_IN_LAST_24_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M4_IN_LAST_12_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_M4_IN_LAST_6_MONTHS
        {
            get;
            set;
        }

        public Int32 NUMBER_CURRENT_M1
        {
            get;
            set;
        }

        public Int32 NUMBER_CURRENT_M2
        {
            get;
            set;
        }

        public Int32 NUMBER_CURRENT_M3
        {
            get;
            set;
        }

        public Int32 NUMBER_CURRENT_M4
        {
            get;
            set;
        }

        public Int32 TOTAL_NUM_OF_ENQUIRY
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_ENQUIRY12
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_ENQUIRY6
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_ENQUIRY3
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_NEW_ENQUIRY12
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_NEW_ENQUIRY6
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_NEW_ENQUIRY3
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_NEW_ENQUIRY
        {
            get;
            set;
        }

        public Int32 TOTAL_CURRENT_PAST_DUE_AMOUNT
        {
            get;
            set;
        }

        public Int32 NUMBER_OF_ACCOUT_NOT_NORMAL_CLOSED24
        {
            get;
            set;
        }

        public Int32 HIGHEST_DELINQUENT_24
        {
            get;
            set;
        }

        public Int32 HIGHEST_DELINQUENT_12
        {
            get;
            set;
        }

        public Int32 CURRENT_WORST_DELINQUENT
        {
            get;
            set;
        }

        public Decimal Bureau_Monthly_Income
        {
            get;
            set;
        }

        public Int32 Satisfactory_Trades
        {
            get;
            set;
        }

        public Decimal bankcard_trades_Larger_75_Per
        {
            get;
            set;
        }

        public String BankCard_Credit_Utilization
        {
            get;
            set;
        }

        public Decimal trades_never_delinquent
        {
            get;
            set;
        }

        public Int32 Smaller_month
        {
            get;
            set;
        }

        public Int32 Inquiry_Count
        {
            get;
            set;
        }

        public String delq_month_in_24_month
        {
            get;
            set;
        }

        public String External_DBR_Percent
        {
            get;
            set;
        }

        public Int32 TOTAL_OF_CREDIT_CARD
        {
            get;
            set;
        }

        public Int32 TOTAL_OF_LOAN
        {
            get;
            set;
        }

        public Int32 TOTAL_OF_LOAN_UNSECURED
        {
            get;
            set;
        }

        public Int32 TOTAL_OUTSTANDING_BALANCE
        {
            get;
            set;
        }

        public Int32 TOTAL_OUTSTANDING_BALANCE_CREDIT_CARD
        {
            get;
            set;
        }

        public Int32 TOTAL_CREDIT_LIMIT
        {
            get;
            set;
        }

        public Int32 TOTAL_OVERDRAFT_180
        {
            get;
            set;
        }

        public Int32 CREDIT_LIMIT_C_D
        {
            get;
            set;
        }

        public Int32 OVERDRAFT
        {
            get;
            set;
        }

        public Int32 OVERDRAFT_LINE_OUTSTANDING_180
        {
            get;
            set;
        }

        public Int32 ACCOUNT_NUMBER
        {
            get;
            set;
        }

        public Int32 CREDIT_LIMIT_C
        {
            get;
            set;
        }

        public Int32 USED_CREDIT_LINE
        {
            get;
            set;
        }

        public String COMPANY_NAME
        {
            get;
            set;
        }

        public String RESIDE_ADDRESS_FIRST
        {
            get;
            set;
        }

        public String RESIDE_STATUS_FIRST
        {
            get;
            set;
        }

        public String RESIDE_ADDRESS_SECOND
        {
            get;
            set;
        }

        public String RESIDE_STATUS_SECOND
        {
            get;
            set;
        }

        public String EMPLOYER_UNIT_NAME_FIRST
        {
            get;
            set;
        }

        public String EMPLOYER_UNIT_ADDRESS_FIRST
        {
            get;
            set;
        }

        public String CAREER_FIRST
        {
            get;
            set;
        }

        public String POSITION_FIRST
        {
            get;
            set;
        }

        public String ANNUAL_INCOME_FIRST
        {
            get;
            set;
        }

        public String EMPLOYER_UNIT_NAME_SECOND
        {
            get;
            set;
        }

        public String EMPLOYER_UNIT_ADDRESS_SECOND
        {
            get;
            set;
        }

        public String CAREER_SECOND
        {
            get;
            set;
        }

        public String POSITION_SECOND
        {
            get;
            set;
        }

        public String ANNUAL_INCOME_SECOND
        {
            get;
            set;
        }

        public Int32 TOTAL_CHARGE_OFF
        {
            get;
            set;
        }

        public Int32 SUM_OF_CERTAIN_LOAN_CARD_OVERDRAW_BALANCE
        {
            get;
            set;
        }

        public Int32 SUM_OF_LOAN_CARD_OVERDRAW_BALANCE
        {
            get;
            set;
        }

        public Int32 SUM_OF_LOAN_CARD_MONTH_OUGHT_PAY
        {
            get;
            set;
        }

        public Int32 SUM_OF_LOAN_CARD_MONTH_PRACTICAL_PAY
        {
            get;
            set;
        }

        public Int32 COUNT_OF_LOAN_CARD_NOT_FULL_PAY
        {
            get;
            set;
        }

        public Int32 SUM_OF_LOANS_BALANCE
        {
            get;
            set;
        }

        public Int32 SUM_OF_LOANS_MONTH_OUGHT_PAY
        {
            get;
            set;
        }

        public Int32 COUNT_OUTSTANDING_MORTGAGES
        {
            get;
            set;
        }

        public Int32 COUNT_OF_GRZFDK
        {
            get;
            set;
        }

        public Int32 COUNT_OF_ZFGJJ
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_CardQ
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_CardQ3
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_CardQ6
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OF_CardQ12
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_LOAN_UNSECURED
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OTHERLOAN_SECURED
        {
            get;
            set;
        }

        public Int32 TOTAL_NUMBER_OS_CREDIT
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_UNSECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_SECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_OTHERLOAN_SECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_OUGHT_PAY_UNSECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_OUGHT_PAY_SECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_OTHERLOAN_OUGHT_PAY_SECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_PRACTICAL_PAY_UNSECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_LOAN_PRACTICAL_PAY_SECURED
        {
            get;
            set;
        }

        public Decimal TOTAL_SUM_OTHERLOAN_PRACTICAL_PAY_SECURED
        {
            get;
            set;
        }

        public Int32 COUNT_Previous_Write_Off
        {
            get;
            set;
        }

        public Int32 Count_Current_M1_Accounts
        {
            get;
            set;
        }

        public Int32 Count_Current_M2_Accounts
        {
            get;
            set;
        }

        public Int32 Count_Open_Unsecured_Loan
        {
            get;
            set;
        }

        public String ImportDate
        {
            get;
            set;
        }

        public Int32 LitigationRecord
        {
            get;
            set;
        }

        public Int32 LoanGrade
        {
            get;
            set;
        }

        public String CreatID
        {
            get;
            set;
        }

        public DateTime CreatDate
        {
            get;
            set;
        }

        public String ModiID
        {
            get;
            set;
        }

        public DateTime ModiDate
        {
            get;
            set;
        }

    }

}
