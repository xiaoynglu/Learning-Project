using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_SelfEmployedCust
   {
       public Guid CustID
       {
           get;
           set;
       }

       public Double CurrentIndustryTime
       {
           get;
           set;
       }

       public String ShopName
       {
           get;
           set;
       }

       public String RegistrationNumber
       {
           get;
           set;
       }

       public String OperatorName
       {
           get;
           set;
       }

       public String OperationPlace
       {
           get;
           set;
       }

       public Int32 EmployeeNumber
       {
           get;
           set;
       }

       public String Contact
       {
           get;
           set;
       }

       public String ContactPosition
       {
           get;
           set;
       }
       public String OwnedEstate
       {
           get;
           set;
       }
       public String PaidInsurance
       {
           get;
           set;
       }
       public String Segment
       {
           get;
           set;
       }

       public string Industry
       {
           get;
           set;
       }

       public string Occupation
       {
           get;
           set;
       }
   }
}

