using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_BaseRateMaker
    {
        #region Basic Entity Properties
        public Int32 TID
        {
            get;
            set;
        }
        public Int32 ProdID
        {
            get;
            set;
        }
        public String OrgCode
        {
            get;
            set;
        }
        public Decimal Value
        {
            get;
            set;
        }
        public Decimal ValueOverFive
        {
            get;
            set;
        }
        public Decimal FirstPayRate
        {
            get;
            set;
        }
        public Decimal SecondPayRate
        {
            get;
            set;
        }
        public int OpType
        {
            get;
            set;
        }
        public int Status
        {
            get;
            set;
        }
        public String Maker
        {
            get;
            set;
        }
        public DateTime MakeDate
        {
            get;
            set;
        }
        public String Checker
        {
            get;
            set;
        }
        public DateTime CheckDate
        {
            get;
            set;
        }
        #endregion

        #region Extended Entity Properties
        public String ProdName
        {
            get;
            set;
        }
        public String BranchName
        {
            get;
            set;
        }
        public String StatusDesc
        {
            get;
            set;
        }
        #endregion


   }
}

