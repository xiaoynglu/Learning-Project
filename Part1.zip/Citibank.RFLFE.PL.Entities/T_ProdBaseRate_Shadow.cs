using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_ProdBaseRate_Shadow
    {
        #region Basic Entity Properties
        public Int32 ID
        {
            get;
            set;
        }
        public Int32 ProdID
        {
            get;
            set;
        }
        public String OrgCode
        {
            get;
            set;
        }
        public Decimal BaseRate
        {
            get;
            set;
        }
        public Decimal BaseRateOver5
        {
            get;
            set;
        }
        public Decimal FirstPayRate
        {
            get;
            set;
        }
        public Decimal SecondPayRate
        {
            get;
            set;
        }
        public Char Status
        {
            get;
            set;
        }
        public String Maker
        {
            get;
            set;
        }
        #endregion

        #region Extended Entity Properties
        public String ProdName
        {
            get;
            set;
        }
        public String BranchName
        {
            get;
            set;
        }
        #endregion


   }
}

