using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_Mortgagors
   {
       public Guid MortID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public String Name
       {
           get;
           set;
       }

       public String PinyinName
       {
           get;
           set;
       }

       public String Relation
       {
           get;
           set;
       }

       public String IDNo
       {
           get;
           set;
       }

       public String Telephone
       {
           get;
           set;
       }

       public String MobileNumber
       {
           get;
           set;
       }

       public String MarriageStatus
       {
           get;
           set;
       }

       public String SpouseName
       {
           get;
           set;
       }

       public String SpousePinyinName
       {
           get;
           set;
       }

       public String SpouseIDNo
       {
           get;
           set;
       }

       public String SpouseTelephone
       {
           get;
           set;
       }

       public String SpouseMobile
       {
           get;
           set;
       }

       public String HouseProvince
       {
           get;
           set;
       }

       public String HouseCity
       {
           get;
           set;
       }

       public String HouseDistrict
       {
           get;
           set;
       }

       public String HouseStreet
       {
           get;
           set;
       }

       public String HousePostCode
       {
           get;
           set;
       }

       public String RelationDesc
       {
           get;
           set;
       }

       //��ǰ��Ѻ�˶�Ӧ��AppId ���������˺͹����˵ĸ���
       public int RelatedCustomersCount
       {
           get;
           set;
       }
       public string CustNO
       {
           get;
           set;
       }

       public String MBCustID
       {
           get;
           set;
       }

       public String CB1CustID
       {
           get;
           set;
       }

       public String CB2CustID
       {
           get;
           set;
       }
   }
}

