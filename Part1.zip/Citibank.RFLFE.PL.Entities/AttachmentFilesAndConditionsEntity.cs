﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class AttachmentFilesAndConditionsEntity
    {
        public String TID
        {
            get;
            set;
        }

        public String ProdID
        {
            get;
            set;
        }

        public String FilePath
        {
            get;
            set;
        }

        public String FileType
        {
            get;
            set;
        }

        public String FileName
        {
            get;
            set;
        }

        public String TemplateID
        {
            get;
            set;
        }

        public String ConfigID
        {
            get;
            set;
        }

        public String ParentID
        {
            get;
            set;
        }

        public String BorrowerType
        {
            get;
            set;
        }

        public String QueryBy
        {
            get;
            set;
        }

        public String OrderBy
        {
            get;
            set;
        }

        public String ConditionID
        {
            get;
            set;
        }

        public String TabID
        {
            get;
            set;
        }


        public String GroupID
        {
            get;
            set;
        }


        public String GroupName
        {
            get;
            set;
        }

        public String OP
        {
            get;
            set;
        }

        public String Value
        {
            get;
            set;
        }

    }
}
