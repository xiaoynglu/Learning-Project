﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_CLMSHandover
    {
        public Guid AppID { get; set; }
        public  String  CollateralType { get; set; }
        public  String  CollateralSubType { get; set; }
        public  String  CollateralDescription { get; set; }
        public  String  Scope { get; set; }
        public  String  RegisteredAt { get; set; }
        public  String  Currency { get; set; }
        public  String  FMV { get; set; }
        public  String  Restricted { get; set; }
        public  String  ExpiryDate { get; set; }
        public  String  ApplicableLVS { get; set; }
        public  String  Owner { get; set; }
        public  String  Address { get; set; }
        public  String  District { get; set; }
        public  String  TowCity { get; set; }
        public  String  Country { get; set; }
        public  String  CurrencyRestriction { get; set; }
        public  String  CurrencyCode { get; set; }
        public  String  SanctionDate { get; set; }
        public  String  SanctionExpiryDate { get; set; }
        public  String  StartDate { get; set; }
        public  String  DrawdownExpireDate { get; set; }
        public  String  MaturityDate { get; set; }
        public  String  NextReviewDate { get; set; }
        public  String  ApprovedLimit { get; set; }
        public  String  AvailedLimit { get; set; }
        public  String  Revolving { get; set; }
        public  String  RiskRating { get; set; }
        public  String  Tolerance { get; set; }
        public  String  RiskCategory { get; set; }
        public  String  ConditionalApproveFlag { get; set; }
        public  String  LineID { get; set; }
        public  String  CollateralID { get; set; }

    }
}
