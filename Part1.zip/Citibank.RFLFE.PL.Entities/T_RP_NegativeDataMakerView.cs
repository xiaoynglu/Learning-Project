﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_RP_NegativeDataMakerView
    {
        public Int32 TID
        {
            get;
            set;
        }

        public String CustName
        {
            get;
            set;
        }

        public String IDNo
        {
            get;
            set;
        }

        public String CompanyName
        {
            get;
            set;
        }

        public String DOB
        {
            get;
            set;
        }

        public String AgentName
        {
            get;
            set;
        }

        public String SalesName
        {
            get;
            set;
        }

        public String Reason
        {
            get;
            set;
        }

        public String OtherCertID
        {
            get;
            set;
        }

        public String Maker
        {
            get;
            set;
        }

        public String CreateDate
        {
            get;
            set;
        }

        public String Checker
        {
            get;
            set;
        }

        public String ModifiedTime
        {
            get;
            set;
        }

        public String Status
        {
            get;
            set;
        }
        public String OpType
        {
            get;
            set;
        }
    }
}

