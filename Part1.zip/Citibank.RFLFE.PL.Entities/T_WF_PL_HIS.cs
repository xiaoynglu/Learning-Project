using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_WF_PL_HIS
   {
       public Guid AppID
       {
           get;
           set;
       }

       public String ProcID
       {
           get;
           set;
       }

       public String ExecID
       {
           get;
           set;
       }

       public String SalesID
       {
           get;
           set;
       }

       public Int32 StageID
       {
           get;
           set;
       }

       public String Status
       {
           get;
           set;
       }

       public String CreateDate
       {
           get;
           set;
       }

       public String ProcDate
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }
       public String PickupTime
       {
           set;
           get;
       }
   }
}

