using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_DocStage
   {
       public Int32 TID
       {
           get;
           set;
       }

       public Int32 DocID
       {
           get;
           set;
       }

       public Int32 StageID
       {
           get;
           set;
       }

   }
}

