using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_RuleResult
   {
       public Int32 ResultID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public Int32 StageID
       {
           get;
           set;
       }

       public String ProcID
       {
           get;
           set;
       }

       public DateTime ProcDate
       {
           get;
           set;
       }

       public String Result
       {
           get;
           set;
       }

       public string MType { get; set; }

       public int ProdID { get; set; }

       public string ProdName { get; set; }

   }
}

