﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_LTVParam
    {
        public Int32 TID
        {
            get;
            set;
        }
        public Int32 ProdID
        {
            get;
            set;
        }

        public string OrgCode
        {
            get;
            set;
        }
        public string Factor
        {
            get;
            set;
        }
        public string FactorName
        {
            get;
            set;
        }
        public Int32 Value
        {
            get;
            set;
        }
        public string IsValid
        {
            get;
            set;
        }
    }
}
