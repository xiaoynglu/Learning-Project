﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_BureauQueryResult
    {
        public String AppID
        {
            get;
            set;
        }

        public String IDNo
        {
            get;
            set;
        }

        public String AppNo
        {
            get;
            set;
        }

        public String CustName
        {
            get;
            set;
        }

        public String FormerName
        {
            get;
            set;
        }        

        public String ProdName
        {
            get;
            set;
        }

        public String StageName
        {
            get;
            set;
        }

        public String Status
        {
            get;
            set;
        }

        public String BorrowType
        {
            get;
            set;
        }
    }
}
