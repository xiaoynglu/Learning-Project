﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_AppExpireDateMaker
    {
        public string ProdID { get; set; }
        public string ProdName { get; set; }
        public string ExpireDate { get; set; }
        public string Status { get; set; }
        public string statusname { get; set; }
        public string Maker { get; set; }
        public string CreateDate { get; set; }
        public string Checker { get; set; }
        public string ModifiedTime { get; set; }
        public string OpType { get; set; }
        public string OpName { get; set; }
        
    }
}
