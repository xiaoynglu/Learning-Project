﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_QueryList
    {
        public String AppID
        {
            get;
            set;
        }

        public String QueryDate
        {
            get;
            set;
        }

        public String QueryPurpose
        {
            get;
            set;
        }

        public String IDNo
        {
            get;
            set;
        }

        public String FullName
        {
            get;
            set;
        }
    }
}
