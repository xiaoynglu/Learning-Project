using System;
using System.Collections;
using System.Text;
using System.Data;
using System.Collections.Generic;

namespace Citibank.RFLFE.PL.Entities
{
   public class BorrowerVerificationDetail
   {
       public BorrowerVerificationDetail()
       {
           T_PL_Customers = new T_PL_Customers();
           T_PL_CustomerContact = new T_PL_CustomerContact();
           T_PL_VerificationRecord = new T_PL_VerificationRecord();
       }

       public T_PL_Customers T_PL_Customers
       {
           get;
           set;
       }

       
       public T_PL_CustomerContact T_PL_CustomerContact
       {
           get;
           set;
       }
       public T_PL_VerificationRecord T_PL_VerificationRecord
       {
           get;
           set;
       }

   }
}

