using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_AcceptService
   {
       public Guid AppID
       {
           get;
           set;
       }

       public Int32 ServiceID
       {
           get;
           set;
       }

   }
}

