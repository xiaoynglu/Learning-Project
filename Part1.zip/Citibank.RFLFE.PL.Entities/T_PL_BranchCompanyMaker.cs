using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_BranchCompanyMaker
   {
       public Int32 TID
       {
           get;
           set;
       }

       public String OrgCode
       {
           get;
           set;
       }

       public String CompanyName
       {
           get;
           set;
       }

       public String CompanyType
       {
           get;
           set;
       }

       public Int32 Status
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime CreateTime
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime ModifiedTime
       {
           get;
           set;
       }

       public Int32 OpType { get; set; }
       public string StatusName { get; set; }
       public string CompanyTypeName { get; set; }
       public string OpTypeName { get; set; }

   }
}

