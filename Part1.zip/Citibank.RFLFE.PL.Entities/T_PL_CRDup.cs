using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_CRDup
   {
       public String DupCRID
       {
           get;
           set;
       }

       public String AppID
       {
           get;
           set;
       }

       public String CustID 
       {
           get;
           set;
       }

       public String Name
       {
           get;
           set;
       }

       public String MatchResult
       {
           get;
           set;
       }

       public String AppNo
       {
           get;
           set;
       }

       public String MatchName
       {
           get;
           set;
       }

       public String MatchIDNo
       {
           get;
           set;
       }

       public String AppDate
       {
           get;
           set;
       }

       public String AppCurrStage
       {
           get;
           set;
       }
   }
}

