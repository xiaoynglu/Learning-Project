using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_WF_PL_Stage
   {
       public Int32 StageID
       {
           get;
           set;
       }

       public String StageName
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }

       public Int32 OrderBy
       {
           get;
           set;
       }

       public String IsValid
       {
           get;
           set;
       }

   }
}

