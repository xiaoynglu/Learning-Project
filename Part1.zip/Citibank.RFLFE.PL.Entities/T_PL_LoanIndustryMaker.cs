using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_LoanIndustryMaker
   {
       public Guid AppID
       {
           get;
           set;
       }

       public String Category
       {
           get;
           set;
       }

       public String Purpose1
       {
           get;
           set;
       }

       public String Purpose2
       {
           get;
           set;
       }

       public String Purpose3
       {
           get;
           set;
       }

       public String OtherPurpose
       {
           get;
           set;
       }

       public String CommericialFitment
       {
           get;
           set;
       }

       public String MainIndustry
       {
           get;
           set;
       }

       public String SubIndustry
       {
           get;
           set;
       }

       public String DecorationProvince
       {
           get;
           set;
       }

       public String DecorationCity
       {
           get;
           set;
       }

       public String DecorationRegion
       {
           get;
           set;
       }

       public String DecorationAddress
       {
           get;
           set;
       }

       public Boolean IsPropertySelf
       {
           get;
           set;
       }

       public String DecorationRelation
       {
           get;
           set;
       }

       public Decimal DecorationPropertyValue1
       {
           get;
           set;
       }

       public Decimal DecorationPropertyValue2
       {
           get;
           set;
       }

       public Int32 Status
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime CreateDate
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime UpdateDate
       {
           get;
           set;
       }
       public Boolean IsChecker
       {
           get;
           set;
       }
   }
}

