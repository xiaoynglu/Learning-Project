using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_CRPersonVel
   {
       public Int32 ID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public Guid CustID
       {
           get;
           set;
       }

       public String PersonType
       {
           get;
           set;
       }

       public String Name
       {
           get;
           set;
       }

       public String HomePhone
       {
           get;
           set;
       }

       public String MobilePhone
       {
           get;
           set;
       }

       public String OfficePhone
       {
           get;
           set;
       }

       public String HomeAddress
       {
           get;
           set;
       }

       public String CompanyAddress
       {
           get;
           set;
       }

       public String CompanyName
       {
           get;
           set;
       }

       public String ReferenceName
       {
           get;
           set;
       }

       public String SpouseName
       {
           get;
           set;
       }

   }
}

