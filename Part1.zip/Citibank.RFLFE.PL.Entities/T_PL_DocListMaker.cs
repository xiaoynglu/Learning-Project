using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_DocListMaker
   {
       #region Basic Entity Properties
       public Int32 DocID
       {
           get;
           set;
       }

       public Int32 DocType
       {
           get;
           set;
       }

       public String DocName
       {
           get;
           set;
       }

       public String CustType
       {
           get;
           set;
       }

       public String CustSegment
       {
           get;
           set;
       }

       public Int32 ProdID
       {
           get;
           set;
       }

       public String IsRequired
       {
           get;
           set;
       }

       public String GroupNo
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }

       public Int32 Status
       {
           get;
           set;
       }

       public Int32 OpType
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime CreateTime
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime ModifiedTime
       {
           get;
           set;
       }
       #endregion

       #region Extended Entity Properties
       public String ProdName
       {
           set;
           get;
       }
       public String CustTypeDesc
       {
           set;
           get;
       }
       public String CustSegmentDesc
       {
           set;
           get;
       }
       public String StatusDesc
       {
           set;
           get;
       }
       public String OpTypeDesc
       {
           set;
           get;
       }
       #endregion
   }
}

