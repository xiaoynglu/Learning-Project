using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_Collateral
   {
       public Guid AppID
       {
           get;
           set;
       }

       public String HasProperty
       {
           get;
           set;
       }

       public String  OwnHouse
       {
           get;
           set;
       }

       public String CollateralType
       {
           get;
           set;
       }

       public Decimal HouseValue
       {
           get;
           set;
       }

       public Int32 HouseAge
       {
           get;
           set;
       }

       public Decimal HouseArea
       {
           get;
           set;
       }

       public Decimal CarArea
       {
           get;
           set;
       }

       public Decimal GarageArea
       {
           get;
           set;
       }

       public String PropertyType
       {
           get;
           set;
       }

       public String ResidencialType
       {
           get;
           set;
       }

       public String Province
       {
           get;
           set;
       }

       public String City
       {
           get;
           set;
       }

       public String Region
       {
           get;
           set;
       }

       public String PostCode
       {
           get;
           set;
       }

       public String Address
       {
           get;
           set;
       }

       public String CommunityName
       {
           get;
           set;
       }

       public String CurrentStatus
       {
           get;
           set;
       }

       public string ResidentialType
       {
           get;
           set;
       }

       public String PropertyPermits
       {
           get;
           set;
       }

       public Decimal LandArea
       {
           get;
           set;
       }

       public String RightNoOfLand
       {
           get;
           set;
       }

       public String RightTypeOfLand
       {
           get;
           set;
       }

       public Decimal FloorSpace
       {
           get;
           set;
       }

       public Decimal TotalPrice
       {
           get;
           set;
       }

       public String CompletedDate
       {
           get;
           set;
       }

       public Int32 LandUsingYear
       {
           get;
           set;
       }

       public Int32 SoilUsingYear
       {
           get;
           set;
       }

       public Int32 RentRemainingDate
       {
           get;
           set;
       }

       public Decimal BaseLTV
       {
           get;
           set;
       }

       public Decimal MaxAllowedLTV
       {
           get;
           set;
       }

       public Decimal ReducedLTV
       {
           get;
           set;
       }

       public String MorgageCount
       {
           get;
           set;
       }

       public String FactorsList
       {
           get;
           set;
       }
       public String FirstHouseOp
       {
           get;
           set;
       }
       public String FirstHouseArea
       {
           get;
           set;
       }
       public String FirstPayAmount
       {
           get;
           set;
       }
       public String FirstPayPercent
       {
           get;
           set;
       }
       public String IsImprovedHouse
       {
           get;
           set;
       }
       public String IsPartialMortgage
       {
           get;
           set;
       }

       public Boolean NeedCheckHouseBureau
       {
           get;
           set;
       }

       public String HouseBureauRemarks
       {
           get;
           set;
       }

       public decimal HighPropertyFactorActualValue
       {
           get;
           set;
       }

       public Boolean IsSelectHighProperty
       {
           get;
           set;
       }    

       
   }
}

