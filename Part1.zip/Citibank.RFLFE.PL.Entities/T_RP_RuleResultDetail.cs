using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_RP_RuleResultDetail
    {
        public Int32 ResultID
        {
            get;
            set;
        }
        public Guid AppID
        {
            get;
            set;
        }
        public Int32 ProdID
        {
            get;
            set;
        }

        public string ProdName { get; set; }


        public String Result
        {
            get;
            set;
        }
        public Int32 DetailID
        {
            get;
            set;
        }
        public Int32 ReasonID
        {
            get;
            set;
        }
        public String ReasonCode
        {
            get;
            set;
        }
        public String Descriptions
        {
            get;
            set;
        }
        public String ReferMessage
        {
            get;
            set;
        }

        public String ActualMessage
        {
            get;
            set;
        }
        public Int32 MajorReasonID
        {
            get;
            set;
        }
        public String MajorReasonDesc
        {
            get;
            set;
        }
        public Int32 RuleID
        {
            get;
            set;
        }
        public String RuleName
        {
            get;
            set;
        }

        public string ClassName { get; set; }


        public String Remarks
        {
            get;
            set;
        }
        public String HitType
        {
            get;
            set;
        }
        public String DeviationLvl
        {
            get;
            set;
        }

        public String CurrentRate
        {
            get;
            set;
        }
        public string MajorDescriptions { get; set; }
    }
}

