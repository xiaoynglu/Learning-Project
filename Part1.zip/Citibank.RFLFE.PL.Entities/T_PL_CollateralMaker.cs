using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_CollateralMaker
   {
       public Guid AppID
       {
           get;
           set;
       }

       public String CollateralType
       {
           get;
           set;
       }

       public Decimal HouseValue
       {
           get;
           set;
       }

       public Int32 HouseAge
       {
           get;
           set;
       }

       public Decimal HouseArea
       {
           get;
           set;
       }

       public Decimal CarArea
       {
           get;
           set;
       }

       public Decimal GarageArea
       {
           get;
           set;
       }

       public String PropertyType
       {
           get;
           set;
       }

       public String Province
       {
           get;
           set;
       }

       public String City
       {
           get;
           set;
       }

       public String Region
       {
           get;
           set;
       }

       public String Address
       {
           get;
           set;
       }

       public String CommunityName
       {
           get;
           set;
       }

       public Int32 CurrentStatus
       {
           get;
           set;
       }

       public String PropertyPermits
       {
           get;
           set;
       }

       public Decimal LandArea
       {
           get;
           set;
       }

       public String RightNoOfLand
       {
           get;
           set;
       }

       public String RightTypeOfLand
       {
           get;
           set;
       }

       public Decimal FloorSpace
       {
           get;
           set;
       }

       public Decimal TotalPrice
       {
           get;
           set;
       }

       public String CompletedDate
       {
           get;
           set;
       }

       public Int32 LandUsingYear
       {
           get;
           set;
       }

       public Int32 RentRemainingDate
       {
           get;
           set;
       }

       public Int32 Status
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime CreateDate
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime UpdateDate
       {
           get;
           set;
       }

   }
}

