using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_Parameters
   {
       public String ParamID
       {
           get;
           set;
       }

       public String ParentID
       {
           get;
           set;
       }

       public String Key
       {
           get;
           set;
       }

       public String Value
       {
           get;
           set;
       }

       public Int32 OrderBy
       {
           get;
           set;
       }

       public String IsValid
       {
           get;
           set;
       }

   }
}

