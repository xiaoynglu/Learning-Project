using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_Roles
   {
       public Int32 RoleID
       {
           get;
           set;
       }

       public String RoleName
       {
           get;
           set;
       }

       public String CitiSafeRole
       {
           get;
           set;
       }

       public String IsValid
       {
           get;
           set;
       }

   }
}

