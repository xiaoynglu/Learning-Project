using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_WF_PL_TRACE
   {
       public Int64 TraceID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public String ProcID
       {
           get;
           set;
       }

       public DateTime OPDate
       {
           get;
           set;
       }

       public Int32 StepID
       {
           get;
           set;
       }

       public String Action
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }

       public String PendingReason
       {
           get;
           set;
       }

   }
}

