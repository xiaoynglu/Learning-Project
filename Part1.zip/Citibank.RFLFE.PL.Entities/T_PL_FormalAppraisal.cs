using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_FormalAppraisal
   {
       public Int32 TID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public Int32 CompanyID
       {
           get;
           set;
       }

       public DateTime RequestDate
       {
           get;
           set;
       }

       public DateTime AcceptDate
       {
           get;
           set;
       }

       public Decimal Price
       {
           get;
           set;
       }

       public Decimal Fee
       {
           get;
           set;
       }

       public String IsApplied
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }

   }
}

