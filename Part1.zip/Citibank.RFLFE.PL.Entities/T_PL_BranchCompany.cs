using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_BranchCompany
   {
       public Int32 TID
       {
           get;
           set;
       }

       public String OrgCode
       {
           get;
           set;
       }

       public String CompanyName
       {
           get;
           set;
       }

       public String CompanyType
       {
           get;
           set;
       }

   }
}

