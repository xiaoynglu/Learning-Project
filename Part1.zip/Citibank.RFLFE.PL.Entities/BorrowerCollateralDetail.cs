using System;
using System.Collections;
using System.Text;
using System.Data;
using System.Collections.Generic;

namespace Citibank.RFLFE.PL.Entities
{
   public class BorrowerCollateralDetail
   {
       public BorrowerCollateralDetail()
       {
           T_PL_Collateral = new T_PL_Collateral();
           T_PL_Loan = new T_PL_Loan();
           T_PL_MortgageCognizance = new T_PL_MortgageCognizance();
           T_PL_OralAppraisal = new T_PL_OralAppraisal();
           T_PL_FormalAppraisal = new T_PL_FormalAppraisal();
       }

       public T_PL_Collateral T_PL_Collateral
       {
           get;
           set;
       }
       public T_PL_Loan T_PL_Loan
       {
           get;
           set;
       }
       public T_PL_MortgageCognizance T_PL_MortgageCognizance
       {
           get;
           set;
       }
       public T_PL_OralAppraisal T_PL_OralAppraisal
       {
           get;
           set;
       }
       public T_PL_FormalAppraisal T_PL_FormalAppraisal
       {
           get;
           set;
       }
   }
}

