using System;
using System.Collections;
using System.Text;
using System.Data;
using System.Collections.Generic;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_Customers
   {
       public String CustID
       {
           get;
           set;
       }

       public String  AppID
       {
           get;
           set;
       }

       public String AppNo
       {
           get;
           set;
       }

       public String Soeid
       {
           get;
           set;
       }

       public String BorrowType
       {
           get;
           set;
       }

       public string CoBorrow
       {
           get;
           set;
       }

       public String FirstName
       {
           get;
           set;
       }

       public String LastName
       {
           get;
           set;
       }
       public String FullName
       {
           get;
           set;
       }

       public String FormerName
       {
           get;
           set;
       }

       	



       public String PinyinName
       {
           get;
           set;
       }

       public String CustomerRole
       {
           get;
           set;
       }

       public String IDNo
       {
           get;
           set;
       }

       public String Gender
       {
           get;
           set;
       }

       public DateTime DOB
       {
           get;
           set;
       }

       public String MarriageStatus
       {
           get;
           set;
       }

       public String SpouseName
       {
           get;
           set;
       }

       public String SpouseIDNo
       {
           get;
           set;
       }

       public String HasChildren
       {
           get;
           set;
       }

       public String Relation
       {
           get;
           set;
       }
       public String RelationShip
       {
           get;
           set;
       }
       public String Education
       {
           get;
           set;
       }

       public String ReportType
       {
           get;
           set;
       }

       public Int32 LivedYear
       {
           get;
           set;
       }

       public String EmploymentType
       {
           get;
           set;
       }

       public String Industry
       {
           get;
           set;
       }

       public String Occupation
       {
           get;
           set;
       }

       public String SharedFinancial
       {
           get;
           set;
       }

       public String OrgApplicationNo
       {
           get;
           set;
       }

       public String OrgLoanNumber
       {
           get;
           set;
       }

       public String OrgCustType
       {
           get;
           set;
       }

       public String TopUpCustType
       {
           get;
           set;
       }

       public String PropertiesSituation
       {
           get;
           set;
       }

       public String CollateralType
       {
           get;
           set;
       }

       public String PropertyType
       {
           get;
           set;
       }

       public T_PL_SalaryCust T_PL_SalaryCust
       {
           get;
           set;
       }

       public T_PL_SelfEmployedCust T_PL_SelfEmployedCust
       {
           get;
           set;
       }

       public String ProdId
       {
           get;
           set;
       }

       public String ProdName
       {
           get;
           set;
       }

       public Boolean IsTown
       {
           get;
           set;
       }

       public Boolean IsSamePlace
       {
           get;
           set;
       }

       public Boolean IsEmployeeLoan
       {
           get;
           set;
       }

       //customer contact

       public String HouseProvince
       {
           get;
           set;
       }

       public String HouseCity
       {
           get;
           set;
       }

       public String HouseDistrict
       {
           get;
           set;
       }

       public String HouseStreet
       {
           get;
           set;
       }

       public String HousePostCode
       {
           get;
           set;
       }

       public String CommunicationAddressAs
       {
           get;
           set;
       }

       public String HouseTelAreaCode
       {
           get;
           set;
       }

       public String HouseTelNumber
       {
           get;
           set;
       }

       public String ResidenceTelAreaCode
       {
           get;
           set;
       }

        public String ResidenceTelNumber
       {
           get;
           set;
       }

        public String WorkingTelAreaCode
       {
           get;
           set;
       }

        public String WorkingTelNumber
       {
           get;
           set;
       }

        public String WorkingTelExtNumber
        {
            get;
            set;
        }

       public int MorgageAmount
       {
           get;
           set;
       }
       public string CustNO
       {
           get;
           set;
       }

       public String HouseStatus
       {
           get;
           set;
       }

       public String MobileNumber
       {
           get;
           set;
       }

       public Decimal RequestLoanSize
       {
           get;
           set;
       }

       public String RequestTenor 
       {
           get;
           set;
       }

       public String InterestRate 
       {
           get;
           set;
       }

       public String MortgageCount
       {
           get;
           set;
       }

       public T_PL_Customers() 
       {
           T_PL_SalaryCust = new T_PL_SalaryCust();
           T_PL_SelfEmployedCust = new T_PL_SelfEmployedCust();
       }
   }
}

