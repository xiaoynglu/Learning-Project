using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_CustIncome
   {
       public string  CustID
       {
           get;
           set;
       }

       public String IncomeType
       {
           get;
           set;
       }

       public Decimal DeclareAmount
       {
           get;
           set;
       }

       public Decimal VerifiedAmount
       {
           get;
           set;
       }

       public String isSelected
       {
           get;
           set;
       }

       public Decimal ProvenIncome
       {
           get;
           set;
       }

   }
}

