﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_EvaluationCompanyMaker
    {
        public Int32 TID
        {
            get;
            set;
        }

        public String OrgCode
        {
            get;
            set;
        }

        public String CompanyName
        {
            get;
            set;
        }

        public String CompanyType
        {
            get;
            set;
        }

        public String Phone
        {
            get;
            set;
        }

        public String ContactName
        {
            get;
            set;
        }

        public int OpType { get; set; }

        public int Status { get; set; }

        public string Maker { get; set; }

        public DateTime CreateTime { get; set; }

        public string Checker { get; set; }

        public DateTime ModifiedTime { get; set; }

        public string StatusName { get; set; }

        public string CompanyTypeName { get; set; }

        public string OpTypeName { get; set; }


    }
}
