﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class ProposalListEntity
    {
        public String App_ID
        {
            get;
            set;
        }

        public String AppNo
        {
            get;
            set;
        }

        public String CustomerID
        {
            get;
            set;
        }

        public String CustomerName
        {
            get;
            set;
        }

        public String Product
        {
            get;
            set;
        }

        public String ProductName
        {
            get;
            set;
        }

        public String DateOfApplication
        {
            get;
            set;
        }

        public String CurrentStage
        {
            get;
            set;
        }

        public String status
        {
            get;
            set;
        }

        public String CurrentProcessor
        {
            get;
            set;
        }

        public String IsLocked
        {
            get;
            set;
        }

        
    }
}
