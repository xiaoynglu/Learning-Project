using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_RP_RelatedPerson
   {
       public Int32 TID
       {
           get;
           set;
       }

       public String InsideName
       {
           get;
           set;
       }

       public String CertID
       {
           get;
           set;
       }

       public String CloseRelative1
       {
           get;
           set;
       }

       public String CloseRelative2
       {
           get;
           set;
       }

       public String CloseRelative3
       {
           get;
           set;
       }

       public String CloseRelative4
       {
           get;
           set;
       }

       public String CloseRelative5
       {
           get;
           set;
       }

       public String CloseRelative6
       {
           get;
           set;
       }

       public String CloseRelative7
       {
           get;
           set;
       }

       public String CloseRelative8
       {
           get;
           set;
       }

       public String CloseRelative9
       {
           get;
           set;
       }

       public String CloseRelative10
       {
           get;
           set;
       }

       public String CloseRelative11
       {
           get;
           set;
       }

       public String CloseRelative12
       {
           get;
           set;
       }

       public String CloseRelative13
       {
           get;
           set;
       }

       public String CloseRelative14
       {
           get;
           set;
       }

       public String CloseRelative15
       {
           get;
           set;
       }

       public String CloseRelative16
       {
           get;
           set;
       }

       public String CloseRelative17
       {
           get;
           set;
       }

       public String CloseRelative18
       {
           get;
           set;
       }

       public String CloseRelative19
       {
           get;
           set;
       }

       public String CloseRelative20
       {
           get;
           set;
       }

   }
}

