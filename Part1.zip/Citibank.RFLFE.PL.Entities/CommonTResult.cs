﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class CommonTResult<T>
    {
        public IList<T> ResultList { get; set; }

        public int ResultCount { get; set; }

        public T ResultT { get; set; }

        public bool IsSuccess { get; set; }

        public string Message { get; set; }
    }
}
