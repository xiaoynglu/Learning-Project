using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_BatchConfig
   {
       public Int32 BatchID
       {
           get;
           set;
       }

       public String BatchName
       {
           get;
           set;
       }

       public DateTime RunTime
       {
           get;
           set;
       }

       public String IsMonthly
       {
           get;
           set;
       }

       public String IsDaily
       {
           get;
           set;
       }

       public String SkipHoliday
       {
           get;
           set;
       }

       public String IsValid
       {
           get;
           set;
       }

   }
}

