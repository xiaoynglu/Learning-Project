﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class PBOCData
    {
        public String Delinq_History
        {
            get;
            set;
        }

        public String Id
        {
            get;
            set;
        }

        public String ValidData
        {
            get;
            set;
        }

        public String AccountNo
        {
            get;
            set;
        }

        public String Name
        {
            get;
            set;
        }

        public String Id_Type
        {
            get;
            set;
        }
    }
}
