using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_Sys_BranchMaker
   {
       public Int32 TID
       {
           get;
           set;
       }

       public String OrgCode
       {
           get;
           set;
       }

       public String Location
       {
           get;
           set;
       }

       public String BranchCode
       {
           get;
           set;
       }

       public String BranchName
       {
           get;
           set;
       }

       public String BranchAddress
       {
           get;
           set;
       }

       public String PostCode
       {
           get;
           set;
       }

       public String Fax
       {
           get;
           set;
       }

       public String Phone
       {
           get;
           set;
       }

       public String RCCode
       {
           get;
           set;
       }

       public String CityCode
       {
           get;
           set;
       }

       public String ALSCode
       {
           get;
           set;
       }

       public String BM
       {
           get;
           set;
       }

       public Int32 BranchType
       {
           get;
           set;
       }

       public string BranchTypeDesc
       {
           get;
           set;
       }

       public String Status
       {
           get;
           set;
       }

       public String Maker
       {
           get;
           set;
       }

       public DateTime CreateTime
       {
           get;
           set;
       }

       public String Checker
       {
           get;
           set;
       }

       public DateTime ModifiedTime
       {
           get;
           set;
       }

       public String OpType
       {
           get;
           set;
       }

       public string OpTypeName
       {
           get;
           set;
       }

       public string StatusName
       {
           get;
           set;
       }

       public string BranchSimpleCode
       {
           get;
           set;
       }

   }
}

