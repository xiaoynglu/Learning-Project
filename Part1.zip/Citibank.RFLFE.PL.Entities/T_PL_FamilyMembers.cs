using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_FamilyMembers
   {
       public Guid MemberID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public Guid CustID
       {
           get;
           set;
       }

       public String Gender
       {
           get;
           set;
       }

       public String Name
       {
           get;
           set;
       }

       public String PinyinName
       {
           get;
           set;
       }

       public String IDNo
       {
           get;
           set;
       }

       public String Relation
       {
           get;
           set;
       }

       public String RelationShip
       {
           get;
           set;
       }

       public String QueriedBureau
       {
           get;
           set;
       }

   }
}

