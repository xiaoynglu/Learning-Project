using System;
using System.Collections;
using System.Text;
using System.Data;
using System.Collections.Generic;

namespace Citibank.RFLFE.PL.Entities
{
    public class CreditPaymentDetail
   {
       public CreditPaymentDetail()
       {
           T_PL_Application = new T_PL_Application();
           T_PL_SelfPay = new T_PL_SelfPay();
           T_PL_EntrusPay = new T_PL_EntrusPay();
       }

       public string PayType { get; set; }
       public T_PL_Application T_PL_Application
       {
           get;
           set;
       }
       public T_PL_SelfPay T_PL_SelfPay
       {
           get;
           set;
       }
       public T_PL_EntrusPay T_PL_EntrusPay
       {
           get;
           set;
       }
   }
}

