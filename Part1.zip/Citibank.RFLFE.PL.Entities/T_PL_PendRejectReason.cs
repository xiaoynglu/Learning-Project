using System;
using System.Collections;
using System.Text;
using System.Data;
using System.Collections.Generic;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_PendRejectReason
   {
        public int ID
        {
            get;
            set;
        }

        public String ReasonCode
        {
            get;
            set;
        }

        public String Description
        {
            get;
            set;
        }

        public String ParentReasonCode
        {
            get;
            set;
        }
   }
}

