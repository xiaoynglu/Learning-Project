using System;
using System.Collections;
using System.Text;
using System.Data;
using System.Collections.Generic;

namespace Citibank.RFLFE.PL.Entities
{
   public class GuarantorPhoneVerification
   {
       public GuarantorPhoneVerification()
       {
           T_PL_Guarantors = new T_PL_Guarantors();
           T_PL_PhoneVerification = new T_PL_PhoneVerification();
           T_PL_VerificationRecord = new T_PL_VerificationRecord();
       }
       public T_PL_Guarantors T_PL_Guarantors
       {
           get;
           set;
       }
       public T_PL_PhoneVerification T_PL_PhoneVerification
       {
           get;
           set;
       }
       public T_PL_VerificationRecord T_PL_VerificationRecord
       {
           get;
           set;
       }
   }
}

