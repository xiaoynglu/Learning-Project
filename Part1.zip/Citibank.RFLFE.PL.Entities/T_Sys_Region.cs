﻿using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_Sys_Region
    {
        public Int32 TID
        {
            get;
            set;
        }

        public String RegionCode
        {
            get;
            set;
        }

        public String RegionName
        {
            get;
            set;
        }


        public String ParentCode
        {
            get;
            set;
        }
    }
}

