using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_DocSumitted
   {
       public Int64 TID
       {
           get;
           set;
       }

       public Guid AppID
       {
           get;
           set;
       }

       public Guid CustID
       {
           get;
           set;
       }

       public bool uploaded 
       {
           get;
           set;
       }
       public String IsRequired
       {
           get;
           set;
       }

       public Int32 DocID
       {
           get;
           set;
       }

       public String DocName
       {
           get;
           set;
       }

       public String GroupNo
       {
           get;
           set;
       }

       public Int32 StageID
       {
           get;
           set;
       }

       public String ProcID
       {
           get;
           set;
       }

       public String SubmittedTime
       {
           get;
           set;
       }

       public String Submitted
       {
           get;
           set;
       }

       public String Remarks
       {
           get;
           set;
       }
   }
}

