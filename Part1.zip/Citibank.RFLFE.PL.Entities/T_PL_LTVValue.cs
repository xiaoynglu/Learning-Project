using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_LTVValue
   {
       public int ProdId
       {
           get;
           set;
       }


       public String OrgCode
       {
           get;
           set;
       }

       public String CollateralType
       {
           get;
           set;
       }

       public Decimal BaseLTV
       {
           get;
           set;
       }
       public Decimal MaxDelLTV 
       {
           get;
           set;
       
       }

       public int MoCount
       {
           get;
           set;

       }

       public String CreatorId
       {
           get;
           set;

       }

       public DateTime CreatedDate 
       {
           get;
           set;

       }

       public String UpdatorId
       {
           get;
           set;

       }

       public DateTime UpdatedDate
       {
           get;
           set;

       }
   }
}

