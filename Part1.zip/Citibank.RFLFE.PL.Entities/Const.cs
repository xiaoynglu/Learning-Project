﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    /// <summary>
    /// The status of Application
    /// </summary>
    public enum EApplicationStatus
    {
        /// <summary>
        /// created
        /// </summary>
        CR = 1,
        /// <summary>
        /// Approved
        /// </summary>
        AP = 2,
        /// <summary>
        /// Rejected
        /// </summary>
        RE = 3,
        /// <summary>
        /// Canceled
        /// </summary>
        CA = 4
    }

    public enum EProductName
    {
        UPL = 1,
        HE = 2,
        CRE = 3,
        MO = 5,
        ML = 2, //used for all mortgage product
        TOPUP = 4
    }

    public enum InternalType
    {
        Ngtv = 1,
        Fraud = 2,
        RP = 3
    }

    /// <summary>
    /// 个体户和工薪
    /// </summary>
    public enum BAType
    {
        /// <summary>
        /// 工薪
        /// </summary>
        G,
        /// <summary>
        /// 个体户
        /// </summary>
        Q
    }
    public enum EResult
    {
        /// <summary>
        /// 通过
        /// </summary>
        Pass,
        /// <summary>
        /// 失败
        /// </summary>
        Fail
    }

    /// <summary>
    /// Borrow Type
    /// </summary>
    public enum EBorrowType
    {
        /// <summary>
        /// Main Borrower
        /// </summary>
        MB = 1,
        /// <summary>
        /// CoBorrower 1
        /// </summary>
        CB1 = 2,
        /// <summary>
        /// CoBorrower 2
        /// </summary>
        CB2 = 3
    }

    public enum EYesNo
    {
        Y,
        N
    }

    /// <summary>
    /// Sys_Parameter 
    /// </summary>
    public enum ESysParameter
    {
        /// <summary>
        /// 收入代理种类1 
        /// </summary>
        IncomeSurrogate1 = 1,
        /// <summary>
        /// 收入代理种类2
        /// </summary>
        IncomeSurrogate2 = 2,
        /// <summary>
        /// 收入代理种类3
        /// </summary>
        IncomeSurrogate3 = 3,
        /// <summary>
        /// 收入代理种类4
        /// </summary>
        IncomeSurrogate4 = 4,
        /// <summary>
        /// UPL借款期限
        /// </summary>
        BorrowingPeriod = 51,
        /// <summary>
        /// HE借款期限
        /// </summary>
        HEBorrowingPeriod = 52,
        /// <summary>
        /// 借款用途
        /// </summary>
        borroweruses = 6,
        /// <summary>
        /// 住宅状况
        /// </summary>
        ResidentialStatus = 7,
        /// <summary>
        /// 通讯地址
        /// </summary>
        address = 8,   
         /// <summary>
        /// 房屋种类
        /// </summary>
        HousingTypes = 13,
        /// <summary>
        /// 抵押房产类型
        /// </summary>
        Deduction = 14,
        /// <summary>
        /// 抵押房地产目前状态
        /// </summary>
        Mortgage = 15,
        /// <summary>
        /// 装修房屋所有人与申请人关系
        /// </summary>
        OtherApplicationRelations = 16,
        /// <summary>
        /// SourceCode
        /// </summary>
        SourceCode = 17,
        /// <summary>
        /// 从何处获知本行个贷业务
        /// </summary>
        WhereBankLoanBusiness = 18,
        /// <summary>
        /// SDN Check
        /// </summary>
        SDN = 19,
        /// <summary>
        /// Public Figure Check
        /// </summary>
        PFC = 20,
        /// <summary>
        /// 教育程度
        /// </summary>
        EducationLevel = 21,
        /// <summary>
        /// 婚姻状况
        /// </summary>
        MaritalStatus = 22,
        /// <summary>
        /// 与申请人的关系
        /// </summary>
        RelationBetweenApplicant = 23,
        /// <summary>
        /// 现任职位
        /// </summary>
        CurrentPosition = 24,
        /// <summary>
        /// 工作单位企业性质
        /// </summary>
        NatureEnterprise = 25,
        /// <summary>
        /// 营业场所租赁或购买
        /// </summary>
        Business = 26,
        /// <summary>
        /// 行业性质
        /// </summary>
        NatureIndustry = 27,
        /// <summary>
        /// 成数扣减因素
        /// </summary>
        ToReduceFactors = 28,
        /// <summary>
        /// 职业领域
        /// </summary>
        FieldOccupational = 10014,
        /// <summary>
        /// 企业级别
        /// </summary>
        EnterpriseLevel = 30,
        /// <summary>
        /// 职业种类
        /// </summary>
        OccupationalCategories = 31,
        /// <summary>
        /// 工作单位企业规模
        /// </summary>
        ScaleEnterprises = 32,
        /// <summary>
        /// 随访结果
        /// </summary>
        FollowUpResults = 33,
        /// <summary>
        /// 就业类型
        /// </summary>
        EmployType = 34,
        /// <summary>
        /// 非收入代理类型
        /// </summary>
        NIs = 37,
        /// <summary>
        /// OSCAR职业代码
        /// </summary>
        OscarOccupationCode = 49,
        /// <summary>
        /// 借款用途类比
        /// </summary>
        LoanPurposeType = 59,
        /// <summary>
        /// 装修房产使用类别
        /// </summary>
        EstateDecorationPurpose = 60
    }

    public enum EStageName
    {
        Prescreen = 0,
        Verfication = 1,
        CreditSigner = 2,
        FirstAppoval = 3,
        SecondAppoval = 4,
        FullCallVal = 5
    }

    public class Stage
    {
        public static readonly string PROPOSAL = "PROPOSAL";

        public static readonly string INTERNALFILEMATCHING = "Internal File Matching";

        public static readonly string FIRSTRAC = "1ST RAC";

        public static readonly string SECONDRAC = "2ND RAC";

        public static readonly string THIRDRAC = "3RD RAC";
    }

    public class ResultType
    {
        public static readonly string PASS = "pass";

        public static readonly string FAIL = "fail";

        public static readonly string NA = "N/A";
    }

    /// <summary>
    /// 性别
    /// </summary>
    public enum Sex
    {
        /// <summary>
        /// 男
        /// </summary>
        man = 0,
        /// <summary>
        /// 女
        /// </summary>
        woman = 1
    }

    /// <summary>
    /// 系统枚举是否通过
    /// </summary>
    public enum PASSORFAIL
    {
        /// <summary>
        /// 未完成
        /// </summary>
        NoComplete = 0,

        /// <summary>
        /// 通过
        /// </summary>
        Pass = 1,

        /// <summary>
        /// 失败
        /// </summary>
        Fail = 2

    }

    public enum RoleType
    {
        //DBM or BM
        BMOrDBM = 5,
        //HQ CreditOfficer
        HQCreditOfficer = 9
    }

    /// <summary>
    /// Sys_Parameter 
    /// </summary>
    public enum ESysParameterForPrint
    {
        /// <summary>
        /// 收入代理种类1 
        /// </summary>
        IncomeSurrogate1 = 1,
        /// <summary>
        /// 收入代理种类2
        /// </summary>
        IncomeSurrogate2 = 2,
        /// <summary>
        /// 收入代理种类3
        /// </summary>
        IncomeSurrogate3 = 3,
        /// <summary>
        /// 收入代理种类4
        /// </summary>
        IncomeSurrogate4 = 4,
        /// <summary>
        /// 借款期限
        /// </summary>
        BorrowingPeriod = 5,
        /// <summary>
        /// 借款用途
        /// </summary>
        borroweruses = 6,
        /// <summary>
        /// 住宅状况
        /// </summary>
        ResidentialStatus = 7,
        /// <summary>
        /// 通讯地址
        /// </summary>
        address = 8,
        /// <summary>
        /// 直系亲属关系
        /// </summary>
        ImmediateFamilyRelations = 9,
        /// <summary>
        /// 住宅所在地省－－－－－－－－－－改动
        /// </summary>
        Provice = 10,
        /// <summary>
        /// 紧急联系人关系
        /// </summary>
        contactsbetweenemergency = 11,
        /// <summary>
        /// 抵押人与申请人关系
        /// </summary>
        MortgagorRelationshipApplicant = 12,
        /// <summary>
        /// 房屋种类
        /// </summary>
        HousingTypes = 13,
        /// <summary>
        /// 抵押房产类型
        /// </summary>
        Deduction = 14,
        /// <summary>
        /// 抵押房地产目前状态
        /// </summary>
        Mortgage = 15,
        /// <summary>
        /// 装修房屋所有人与申请人关系
        /// </summary>
        HousingRenovationApplicantsRelations = 16,
        /// <summary>
        /// SourceCode
        /// </summary>
        SourceCode = 17,
        /// <summary>
        /// 从何处获知本行个贷业务
        /// </summary>
        WhereBankLoanBusiness = 18,
        /// <summary>
        /// SDN Check
        /// </summary>
        SDN = 19,
        /// <summary>
        /// Public Figure Check
        /// </summary>
        PFC = 20,
        /// <summary>
        /// 教育程度
        /// </summary>
        EducationLevel = 21,
        /// <summary>
        /// 婚姻状况
        /// </summary>
        MaritalStatus = 22,
        /// <summary>
        /// 与申请人的关系
        /// </summary>
        RelationBetweenApplicant = 23,
        /// <summary>
        /// 现任职位
        /// </summary>
        CurrentPosition = 24,
        /// <summary>
        /// 工作单位企业性质
        /// </summary>
        NatureEnterprise = 25,
        /// <summary>
        /// 营业场所租赁或购买
        /// </summary>
        Business = 26,
        /// <summary>
        /// 行业性质
        /// </summary>
        NatureIndustry = 27,
        /// <summary>
        /// 成数扣减因素
        /// </summary>
        ToReduceFactors = 28,
        /// <summary>
        /// 职业领域
        /// </summary>
        FieldOccupational = 10014,
        /// <summary>
        /// 企业级别
        /// </summary>
        EnterpriseLevel = 30,
        /// <summary>
        /// 职业种类
        /// </summary>
        OccupationalCategories = 31,
        /// <summary>
        /// 工作单位企业规模
        /// </summary>
        ScaleEnterprises = 32,
        /// <summary>
        /// 随访结果
        /// </summary>
        FollowUpResults = 33,
        /// <summary>
        /// 产品类型
        /// </summary>
        ProducType = 34,
        /// <summary>
        /// 征信社保相关状态
        /// </summary>
        VerStatus = 38,
        /// <summary>
        /// 非收入代理
        /// </summary>
        IncomeType = 35,
        /// <summary>
        /// 亲属关系
        /// </summary>
        Relatives = 39,

        /// <summary>
        /// "行业性质" for Salaried
        /// </summary>
        JobPropertyForSal = 40,

        /// <summary>
        /// "行业性质" for Employed
        /// </summary>
        JobPropertyForEmp = 41,

        /// <summary>
        /// 房产拥有情况
        /// </summary>
        HasHouse = 42,
        /// <summary>
        /// 营业场所拥有状况
        /// </summary>
        PremiseOwnerType = 43,
        /// <summary>
        /// 汽车拥有状况
        /// </summary>
        CarOwnerType = 44,
        /// <summary>
        /// 户籍所在地省
        /// </summary>
        DomicProvice = 48
    }

    /// <summary>
    /// 银行类型
    /// </summary>
    public enum BranchType
    {
        /// <summary>
        /// 分行
        /// </summary>
        Branch = 4
    }

    /// <summary>
    /// Deviation for Approval(Second Approval, Call Full Valuation)
    /// </summary>
    public enum EDeviationApproval
    {
        Deviationed = 0,
        NoDeviation = 1
    }

    public enum CollaterialType
    {
        H = 0,
        C = 1,
        M = 2
    }

    /// <summary>
    /// 贷款投向，SysParameters单独映射
    /// </summary>
    public enum LoanIndustry
    {
        LoanPurposeCategory = 2,  //贷款用途类别
        PER = 3,　//个人消费
        PRO = 4,  //生产经营
        PERM = 6,  //生产经营
        CommercialFitment = 9,    //经营性装修
        LoanMainIndustry = 11,    //贷款主要投向
        //二级投向通过页面上的规则进行绑定
    }
}
