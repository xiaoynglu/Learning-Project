﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class MenuTree
    {
        public Int32 ID
        {
            get;
            set;
        }

        public string EleText
        {
            get;
            set;
        }

        public string EleId
        {
            get;
            set;
        }

        public Int32 ParentId
        {
            get;
            set;
        }

        public Int32 SortBy
        {
            get;
            set;
        }

        public string Url
        {
            get;
            set;
        }
        public bool disabled
        {
            get;
            set;
        }
    }
}
