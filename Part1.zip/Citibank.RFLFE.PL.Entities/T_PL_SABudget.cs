using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_SABudget
   {
       public Guid CustID
       {
           get;
           set;
       }

       public Int32 StageID
       {
           get;
           set;
       }

       public String AfterTaxIncome
       {
           get;
           set;
       }

       public String RentalIncome
       {
           get;
           set;
       }

       public String OtherIncome
       {
           get;
           set;
       }

       public String OtherFamilyIncome
       {
           get;
           set;
       }

       public String RentalExpenses
       {
           get;
           set;
       }

       public String UtilitiesFee
       {
           get;
           set;
       }

       public String LivingExpenses
       {
           get;
           set;
       }

       public String EducationExpenses
       {
           get;
           set;
       }

       public String TransportationExpenses
       {
           get;
           set;
       }

       public String OtherExpenses
       {
           get;
           set;
       }

       public String MLRepayment
       {
           get;
           set;
       }

       public String ULRepayment
       {
           get;
           set;
       }

       public String MonthlyIncome
       {
           get;
           set;
       }

       public String MonthlyDebt
       {
           get;
           set;
       }

       //����/��ͥ����С��
       public String PersonalFamilyIncomeSubtotal
       {
           get;
           set;
       }

       //ÿ�¿�֧С��
       public String FamilyExpenseSubtotal
       {
           get;
           set;
       }

       //��ͥ���ÿ����С��
       public String MonthlyRepaymentSubTotal
       {
           get;
           set;
       }

       //ÿ��֧�ܼ�
       public String MonthlyTotalExpenses
       {
           get;
           set;
       }

       //ÿ�¿�֧������
       public String MonthlyDisposableIncome
       {
           get;
           set;
       }

       //��ͥ��֧ռ��ͥ�������
       public String ExpenditureAccountingForIncome
       {
           get;
           set;
       }

       //��ͥ�����ռ��ͥ�����
       public String RepaymentAccountingForIncome
       {
           get;
           set;
       }

       public String ProcessorID
       {
           get;
           set;
       }

       public DateTime ProceededDate
       {
           get;
           set;
       }

   }
}

