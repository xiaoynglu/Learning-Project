﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_AfterLoanChangeLog
    {
        public int TID
        {
            get;
            set;
        }
        public Guid CustID
        {
            get;
            set;
        }
        public string CommunicationAddressAs
        {
            get;
            set;
        }
        public string Province
        {
            get;
            set;
        }

        public string City
        {
            get;
            set;
        }
        public string District
        {
            get;
            set;
        }
        public string Street
        {
            get;
            set;
        }
        public string TelAreaCode
        {
            get;
            set;
        }

        public string TelNumber
        {
            get;
            set;
        }
        public string ModiID
        {
            get;
            set;
        }
        public string ModiDate
        {
            get;
            set;
        }
       
    }
}
