﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Entities
{
    public class T_PL_ApprovalInfo
    {
        public string AppId
        {
            get;
            set;
        }

        public string RequestLoanSize
        {
            get;
            set;
        }

        public string RequestTenor
        {
            get;
            set;
        }

        public string InterestRate
        {
            get;
            set;
        }

        public string CustSegment
        {
            get;
            set;
        }

        public string ReconfirmResult
        {
            get;
            set;
        }

        public string RejectReason
        {
            get;
            set;
        }

        public string ApprovedLoanSize
        {
            get;
            set;
        }

        public string ApprovedTenor
        {
            get;
            set;
        }

        public string Installment
        {
            get;
            set;
        }

        public string ContractConfirmed
        {
            get;
            set;
        }

        public string ContractSignDate
        {
            get;
            set;
        }

        public string ContractConfirmDate
        {
            get;
            set;
        }

        public string CustomerNumber
        {
            get;
            set;
        }

        public string RelationshipNumber
        {
            get;
            set;
        }

        public string DebitBank
        {
            get;
            set;
        }

        public string DebitAccount
        {
            get;
            set;
        }

        public string CustName
        {
            get;
            set;
        }

        public string AccOpenDate
        {
            get;
            set;
        }

        public string IsFMS
        {
            get;
            set;
        }
    }
}
