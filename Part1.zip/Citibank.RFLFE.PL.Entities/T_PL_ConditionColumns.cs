using System;
using System.Collections;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Entities
{
   public class T_PL_ConditionColumns
   {
       public Int32 ID
       {
           get;
           set;
       }

       public String TableName
       {
           get;
           set;
       }

       public String ColumnName
       {
           get;
           set;
       }

       public String DisplayName
       {
           get;
           set;
       }

   }
}

