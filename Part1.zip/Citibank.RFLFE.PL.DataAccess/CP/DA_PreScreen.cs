using System;
using System.Collections.Generic;
using System.Text;
using ISS.FrameWorkBase;
using System.Data.SqlClient;
using System.Data;
using CitiBank.LFE.DataMapping.AC;
using CitiBank.LFE.CommonData.CO;
using ISS.FrameCommon.CommonException.BusinessException;
using ISS.FrameCommon.CommonException.ServerException;
using CitiBank.LFE.DataMapping.CP;
using System.Collections;
using ISS.FrameWorkBase.DataMapping;
using ISS.FrameWorkBase.DBAccess;
using System.Reflection;
using CitiBank.LFE.DataAcess.Common;
using CitiBank.LFE.CommonData;


namespace Citibank.RFLFE.PL.DataAccess
{
    /// <summary>
    /// By Mao Feng
    /// </summary>
    public class DA_PreScreen : BaseDataAcess
    {
        private CNRFLogger Logger = new CNRFLogger(MethodBase.GetCurrentMethod().DeclaringType);

        private const string LogFormat = "{0}--{1},ִ���쳣";

        public string GetSaleNameByAppId(Guid appid)
        {
            if (appid != null && appid != Guid.Empty)
            {
                string sql = @"select CnName from TUser where soeid in 
                            (select SalesID from T_WF_INS where App_ID=@AppID)";
                try
                {
                    SqlParameter[] sqlParams = new SqlParameter[] { SqlHelper.CreateParam("@AppID", SqlDbType.UniqueIdentifier, appid) };
                    return Convert.ToString(SqlHelper.ExecuteScalarDefault(sql, sqlParams));
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                return string.Empty;
            }
        }

        public DataTable GetLTVType(Guid appid)
        {
            if (appid != null && appid != Guid.Empty)
            {
                string sql = @"SELECT B.PRODNAME,C.ORGCODE,A.COLLATERALTYPE,A.COLLATERALNAME FROM T_COLLATERALMAPPING AS A INNER JOIN T_PROD AS B 
ON A.PRODID = B.PRODID INNER JOIN T_APPLICATION AS C ON C.PRODID = B.PRODID WHERE C.APPID = @AppId and a.visible is null ";

                SqlParameter sqlParam = SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, appid);

                return SqlHelper.ExecuteDataTableDefault(sql, sqlParam);
            }
            else
            {
                return null;
            }
        }

        public string GetActualLtvValue(string AppId, int ProdId)
        {
            if (!String.IsNullOrEmpty(AppId))
            {
                string sql = @"SELECT LTV FROM T_ADR WHERE APPID = @AppId and ProdId = @ProdId";
                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(new SqlParameter("@AppId", AppId));
                Params.Add(new SqlParameter("@ProdId", ProdId));
                return Convert.ToString(SqlHelper.ExecuteScalarDefault(sql, Params.ToArray()));
            }

            return String.Empty;
        }


        public string GetPropertyValue(string AppId)
        {
            if (!String.IsNullOrEmpty(AppId))
            {
                string sql = @"SELECT HOUSEVALUE FROM T_CUSTLTV AS A WHERE EXISTS (SELECT * FROM T_APPLICATION AS B WHERE A.CUSTID = B.MBID AND B.APPID = @AppId)";

                decimal HouseValue = 0m;

                Decimal.TryParse(Convert.ToString(SqlHelper.ExecuteScalarDefault(sql, new SqlParameter("@AppId", AppId))), out HouseValue);

                sql = @"SELECT MIN(VALUE) FROM T_VRESULT WHERE APPID = @AppId";

                object result = SqlHelper.ExecuteScalarDefault(sql, new SqlParameter("@AppId", AppId));

                if (!(result is DBNull) && result != null)
                {
                    decimal Evaluation = 0m;
                    Decimal.TryParse(Convert.ToString(result), out Evaluation);
                    decimal Result = Math.Min(HouseValue, Evaluation);
                    return Result.ToString();
                }

                return HouseValue.ToString();
            }

            return String.Empty;
        }

        public string GetMbIdByAppId(Guid appid)
        {
            if (appid != null && appid != Guid.Empty)
            {
                try
                {
                    string sql = @"select mbid from t_Application where appid=@appid";
                    SqlParameter sqlParam = SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appid);
                    return Convert.ToString(SqlHelper.ExecuteScalarDefault(sql, sqlParam));
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                return String.Empty;
            }
        }

        public IList<Guid> GetCBIdsByAppId(Guid appId)
        {
            string sql = @"select custId from t_appcust where appId = @appid and BorrowType in ('CB1','CB2')";

            IList<Guid> CBIds = new List<Guid>();

            try
            {
                IDataReader dataReader = SqlHelper.ExecuteReaderDefault(sql, SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appId));
                while (dataReader.Read())
                {
                    CBIds.Add(dataReader.GetGuid(0));
                }
                dataReader.Close();
                return CBIds;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Map_T_Application GetApplicationByAppId(Guid appId)
        {
            if (appId != null && appId != Guid.Empty)
            {
                try
                {
                    Map_T_Application mapApplication = new Map_T_Application();
                    //string sql = "SELECT * from T_Application where AppId=@AppId";
                    string sql = @"SELECT [AppID],[ApplicationNo],[ProposalID],[MBID],[CustType],[ProdID],[LoanSize],[Tenor],[Installment],[LoanPurpose]
                          ,[LPRemarks],cast(Rate as float) as [Rate],[SourceCode],[AgentCode],[WhereKnow],[DebitBank],[DebitAccount],[OrgCode],[BranchCode]
                          ,[Status],[Remarks],[Column1],[Column2],[CreatID],[CreatDate],[ModiID],[ModiDate],[Time_Stamp],[CustConfirm]
                          ,[SigningDate],[ConfirmDate],[MonthlyInstallment],[ProcFee],[ValFee],[InsuranceFee],[CustNo],[RelnNo],[AccOpenDate]
                          ,[LegalFee],[PricingDeviationed],[ApprovedDate],[ApprovedTime],[Deviationed],[PendReasonCode],[IsLackDoc],[PickupDate],[PickupTime]
                          ,[isPBOCChecked],[isALSChecked],[user_defined1],[user_defined2],[user_defined3],[user_defined4],[user_defined5],[CollateralType]
                          ,[LoanPurposeDesc],[Coborrow1CustNo],[Coborrow2CustNo],[UseNewProductCode],[PaymentType],[PaymentAmount],[EntrustedPaymentAmount],[MoCount]
                          ,[DisburseDate],[Submitted],[NotSamePlace],[FMV],[LandValue],[BuildingValue],[AssessmentFee],[InsureFee],[RegisterFee]
                          ,[IsWorkerLoan],[HeadDebitBank] from T_Application where AppId=@AppId";

                    SqlParameter sqlParam = SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, appId);
                    mapApplication.DataTable = SqlHelper.ExecuteDataTableDefault(sql, sqlParam);
                    return mapApplication;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// ��ȡADR����Ϣ
        /// </summary>
        /// <param name="appID">��ƷID</param>
        /// <returns>ADR������</returns>
        public Map_T_ADR GetAdrInfo(Guid appID)
        {
            try
            {
                Map_T_ADR mapAdr = new Map_T_ADR();
                string sql = string.Empty;

                sql = @"SELECT [TID],A.[AppID]
 ,[DelegationLvl]
 ,A.[Deviationed]
 ,[MaxDeviationLvl]
 ,A.[ProdID]
 ,[Result]
 ,[LoanAmt]
 ,[LoanTenor]
 ,A.[Installment]
 ,[BaseRate]
 ,cast(A.Rate as float) as [Rate]
 ,[CurrDBR]
 ,[TotalDBR]
 ,[LTV]
 ,[MaxLTV]
 ,[CustSegm]
 ,[RiskSegm]
 ,[DSCR] FROM T_ADR as A inner join T_Application as B
 on A.AppID = B.AppID AND A.ProdID = B.ProdID WHERE A.AppId=@AppId";

                SqlParameter sqlParam = SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, appID);
                mapAdr.DataTable = SqlHelper.ExecuteDataTableDefault(sql, sqlParam);

                return mapAdr;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public Map_CreditSale GetCreditSaleByAppId(Guid appId)
        {
            if (appId != null && appId != Guid.Empty)
            {
                string sql = @"select G.*,F.CnName as SalesName from 
                                (select Q.*,C.SalesID from 
                                    (select A.ApplicationNo,A.AppID,A.MBID,A.ProdID,A.LoanSize,A.LoanPurpose,A.CustType,cast(A.Rate as float) as Rate,B.LoanAmt,B.LoanTenor,B.Installment,E.CustName,F.ProdName 
                                            from T_Application A,T_ADR B,T_Cust E,T_Prod F where A.appid=B.appid and A.prodid = B.ProdId and A.mbid=E.Custid and A.prodid=F.prodid and A.appid=@appid) as Q 
                                    left join T_WF_INS C on Q.appid=C.app_id) as G 
                                 left join TUser F on G.SalesID=F.SoeId";

                try
                {
                    DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appId));
                    Map_CreditSale map = new Map_CreditSale();
                    map.DataTable = dt;
                    return map;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                return null;
            }
        }

        public Map_T_Customer GetCustomerByCustId(Guid custId)
        {
            if (custId != null && custId != Guid.Empty)
            {
                string sql = @"SELECT A.*,C.ParameterName as CoBorrowName,
                            MarriageName=(case Marriage when 'Y' Then '{0}'
                            when 'N' Then '{1}' else '{2}' end) from
                            T_Cust A,TSys_Parameter C where C.ParameterID=A.CoBorrow and A.custid=@custid";

                sql = string.Format(sql, this.GetParaNameById("Y", "22"), this.GetParaNameById("D", "22"),
                    this.GetParaNameById("Q", "22"));
                try
                {
                    Map_T_Customer map = new Map_T_Customer();

                    map.DataTable = SqlHelper.ExecuteDataTableDefault(sql,
                        SqlHelper.CreateParam("@custid", SqlDbType.UniqueIdentifier, custId));
                    return map;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
            else
            {
                return null;
            }

        }

        public DataTable GetHouseBureau(string AppId)
        {
            if (!String.IsNullOrEmpty(AppId))
            {
                string Sql = @"SELECT AppId,A.CustId,B.CustName,PropertyValue,TotalPropertyValue,A.Remarks FROM T_MoHouseBureau as A Inner Join T_Cust as B on A.CustId = B.CustId 
WHERE AppId = @AppId;";
                return SqlHelper.ExecuteDataTableDefault(Sql, new SqlParameter("@AppId", AppId));
            }
            return null;
        }

        public void UpdateHouseBureauTotal(Guid AppId, int TotalCount, bool IsExists)
        {
            string Sql = @"SELECT TotalPropertyValue FROM T_MoHouseBureau WHERE AppId = @AppId;";

            object result = SqlHelper.ExecuteScalarDefault(Sql, new SqlParameter("@AppId", AppId));

            if (!(result is DBNull) && Convert.ToInt32(result) > 0 && !IsExists)
            {
                TotalCount = Math.Max(TotalCount, Convert.ToInt32(result));
            }

            Sql = @"UPDATE T_MoHouseBureau SET TotalPropertyValue = @TotalPropertyValue WHERE AppId = @AppId;";

            List<SqlParameter> Params = new List<SqlParameter>();
            Params.Add(new SqlParameter("@AppId", AppId));
            Params.Add(new SqlParameter("@TotalPropertyValue", TotalCount));

            SqlHelper.ExecuteNonQueryDefault(Sql, Params.ToArray());

            Sql = @"UPDATE T_MoCountCheck SET HouseBureau = @HouseBureau,ConfirmHouseBureau = @ConfirmHouseBureau,HouseBureauChecked = '1' WHERE AppId = @AppId;";

            SqlParameter[] Pam = new SqlParameter[] { 
            new SqlParameter("@HouseBureau", TotalCount),
            //new SqlParameter("@ConfirmHouseBureau", TotalCount + 1),
            new SqlParameter("@ConfirmHouseBureau", TotalCount),
            new SqlParameter("@AppId",AppId)
            };

            SqlHelper.ExecuteNonQueryDefault(Sql, Pam);

        }
        public void DeleteHouseBureau(string AppId, string CustId)
        {
            string Sql = @"DELETE FROM T_MoHouseBureau WHERE AppId = @AppId AND CustId = @CustId;";
            List<SqlParameter> TParams = new List<SqlParameter>();
            TParams.Add(new SqlParameter("@AppId", AppId));
            TParams.Add(new SqlParameter("@CustId", CustId));
            SqlHelper.ExecuteNonQueryDefault(Sql, TParams.ToArray());
        }
        public void SaveHouseBureau(Map_T_MoHouseBureau HouseBureau)
        {
            string Sql = @"SELECT TotalPropertyValue FROM T_MoHouseBureau WHERE AppId = @AppId AND CustId = @CustId;";

            List<SqlParameter> TParams = new List<SqlParameter>();
            TParams.Add(new SqlParameter("@AppId", HouseBureau.FLD_AppId));
            TParams.Add(new SqlParameter("@CustId", HouseBureau.FLD_CustId));

            object Result = SqlHelper.ExecuteScalarDefault(Sql, TParams.ToArray());

            bool IsExists = !(Result is DBNull) && Result != null;

            if (IsExists)
            {
                Sql = @"UPDATE T_MoHouseBureau SET PropertyValue = @PropertyValue,UpdateId = @UpdateId,UpdatedTime = GETDATE(),Remarks = @Remarks 
WHERE AppId = @AppId AND CustId = @CustId;";

                List<SqlParameter> Params = new List<SqlParameter>();
                Params.Add(new SqlParameter("@AppId", HouseBureau.FLD_AppId));
                Params.Add(new SqlParameter("@CustId", HouseBureau.FLD_CustId));
                Params.Add(new SqlParameter("@PropertyValue", HouseBureau.FLD_PropertyValue));
                Params.Add(new SqlParameter("@UpdateId", HouseBureau.FLD_CreateId));
                Params.Add(new SqlParameter("@Remarks", HouseBureau.FLD_Remarks));
                SqlHelper.ExecuteNonQueryDefault(Sql, Params.ToArray());

                UpdateHouseBureauTotal(HouseBureau.FLD_AppId, HouseBureau.FLD_PropertyValue, IsExists);
            }
            else
            {
                Sql = @"INSERT INTO T_MoHouseBureau (AppId,CustId,PropertyValue,CreateId,Remarks) VALUES (@AppId,@CustId,@PropertyValue,@CreateId,@Remarks);";

                List<SqlParameter> RParams = new List<SqlParameter>();
                RParams.Add(new SqlParameter("@AppId", HouseBureau.FLD_AppId));
                RParams.Add(new SqlParameter("@CustId", HouseBureau.FLD_CustId));
                RParams.Add(new SqlParameter("@PropertyValue", HouseBureau.FLD_PropertyValue));
                RParams.Add(new SqlParameter("@CreateId", HouseBureau.FLD_CreateId));
                RParams.Add(new SqlParameter("@Remarks", HouseBureau.FLD_Remarks));
                SqlHelper.ExecuteNonQueryDefault(Sql, RParams.ToArray());

                UpdateHouseBureauTotal(HouseBureau.FLD_AppId, HouseBureau.FLD_PropertyValue, IsExists);
            }
        }

        public DataTable GetBorrowers(string AppId)
        {
            string Sql = @"SELECT CustName,A.CustID,B.BorrowType FROM T_Cust as A inner join  T_AppCust as B on A.CustID = B.CustID WHERE B.AppID = @AppId;";

            SqlParameter Params = new SqlParameter("@AppId", AppId);

            return SqlHelper.ExecuteDataTableDefault(Sql, Params);
        }

        public Map_T_CustIncomeType GetCustomerIncomeType(Guid appId, Guid custId)
        {
            if (appId != null && appId != Guid.Empty && custId != null && custId != Guid.Empty)
            {
                Map_T_CustIncomeType map = new Map_T_CustIncomeType();
                string sql = @"select * from T_CustIncomeType where appid=@appid and custid=@custid";
                SqlParameter[] sqlParams = new SqlParameter[] { SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appId)
                    ,SqlHelper.CreateParam("@custid",SqlDbType.UniqueIdentifier,custId)};
                map.DataTable = SqlHelper.ExecuteDataTableDefault(sql, sqlParams);
                return map;
            }
            else
            {
                return null;
            }
        }

        public Map_T_CustIncomeType GetCustomerIncomeType(Guid? appId)
        {
            if (appId.HasValue)
            {
                Map_T_CustIncomeType map = new Map_T_CustIncomeType();
                string sql = @"SELECT * FROM T_CUSTINCOMETYPE WHERE APPID=@appid";
                map.DataTable = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appId.Value));
                return map;
            }

            return null;
        }

        public Map_T_AppCust GetAppCust(Guid appId, Guid custId)
        {
            if (appId != null && appId != Guid.Empty && custId != null && custId != Guid.Empty)
            {
                Map_T_AppCust map = new Map_T_AppCust();
                string sql = @"select * from T_Appcust where appid=@appid and custid=@custid";
                SqlParameter[] sqlParams = new SqlParameter[] { SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appId)
                    ,SqlHelper.CreateParam("@custid",SqlDbType.UniqueIdentifier,custId)};
                map.DataTable = SqlHelper.ExecuteDataTableDefault(sql, sqlParams);
                return map;
            }
            else
            {
                return null;
            }
        }

        public string GetBorrowType(Guid appId, Guid custId)
        {
            if (appId != null && appId != Guid.Empty && custId != null && custId != Guid.Empty)
            {
                string sql = @"select BorrowType from T_Appcust where AppId = @AppId and CustId = @CustId";
                SqlParameter[] sqlParams = new SqlParameter[] { SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, appId)
                    ,SqlHelper.CreateParam("@CustId",SqlDbType.UniqueIdentifier,custId)};

                return Convert.ToString(SqlHelper.ExecuteScalarDefault(sql, sqlParams));

            }

            return string.Empty;
        }

        public Map_T_CustContact GetCustContactByCustId(Guid custId, Guid appId)
        {
            if (custId != null && custId != Guid.Empty)
            {
                Map_T_CustContact map = new Map_T_CustContact();
                string sql = @"select * from T_CustContact where custid=@custid and appId=@appId";
                SqlParameter[] sqlParams = new SqlParameter[] { SqlHelper.CreateParam("@custid", SqlDbType.UniqueIdentifier, custId)
                    ,SqlHelper.CreateParam("@appId",SqlDbType.UniqueIdentifier,appId)};
                map.DataTable = SqlHelper.ExecuteDataTableDefault(sql, sqlParams);
                return map;
            }
            else
            {
                return null;
            }
        }

        public Map_T_Collateral GetCollateralByAppId(Guid appId)
        {
            if (appId != null && appId != Guid.Empty)
            {
                string sql = @"select * from T_Collateral where appid=@appid";
                DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appId));
                Map_T_Collateral map = new Map_T_Collateral();
                map.DataTable = dt;
                return map;
            }
            else
            {
                return null;
            }
        }

        public Map_T_CustBASal GetBASalByCustId(Guid custId)
        {
            if (custId != null && custId != Guid.Empty)
            {
                string sql = @"select * from T_CustBASal where CustId=@CustId";
                DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@CustId", SqlDbType.UniqueIdentifier, custId));
                Map_T_CustBASal map = new Map_T_CustBASal();
                map.DataTable = dt;
                return map;
            }
            else
            {
                return null;
            }
        }

        public Map_T_CustBAEmp GetBAEmpByCustId(Guid custId)
        {
            if (custId != null && custId != Guid.Empty)
            {
                string sql = @"select * from T_CustBAEmp where CustId=@CustId";
                DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@CustId", SqlDbType.UniqueIdentifier, custId));
                Map_T_CustBAEmp map = new Map_T_CustBAEmp();
                map.DataTable = dt;
                return map;
            }
            else
            {
                return null;
            }
        }

        public Map_T_PBOC_Aggreate GetPBOCAggreateByCustId(Guid custId, Guid appId)
        {
            if (custId != null && custId != Guid.Empty)
            {
                string sql = @"select * from T_PBOC_Aggreate where ID_Number in (select id_no from T_Cust where custid=@custid) and appid=@appid";
                SqlParameter[] pars = new SqlParameter[]{SqlHelper.CreateParam("@custid", SqlDbType.UniqueIdentifier, custId),
                    SqlHelper.CreateParam("@appid",SqlDbType.UniqueIdentifier,appId)};
                DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, pars);
                Map_T_PBOC_Aggreate map = new Map_T_PBOC_Aggreate();
                map.DataTable = dt;
                return map;
            }
            else
            {
                return null;
            }
        }

        public Map_T_PBOCLoanDtl GetPBOCLoanDtlByCustId(Guid custId, Guid appId)
        {
            if (custId != null && custId != Guid.Empty)
            {
                string sql = @"select * from T_PBOCLoanDtl where ID_Number in (select id_no from T_Cust where custid=@custid) and appid=@appid";
                SqlParameter[] pars = new SqlParameter[]{SqlHelper.CreateParam("@custid", SqlDbType.UniqueIdentifier, custId),
                    SqlHelper.CreateParam("@appid",SqlDbType.UniqueIdentifier,appId)};
                DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, pars);
                Map_T_PBOCLoanDtl map = new Map_T_PBOCLoanDtl();
                map.DataTable = dt;
                return map;
            }
            else
            {
                return null;
            }
        }

        public Map_T_PBOCCrdtCdDtl GetPBOCCrdtCdDtlByCustId(Guid custId, Guid appId)
        {
            if (custId != null && custId != Guid.Empty)
            {
                string sql = @"select * from T_PBOCCrdtCdDtl where ID_Number in (select id_no from T_Cust where custid=@custid) and appid=@appid";
                SqlParameter[] pars = new SqlParameter[]{SqlHelper.CreateParam("@custid", SqlDbType.UniqueIdentifier, custId),
                    SqlHelper.CreateParam("@appid",SqlDbType.UniqueIdentifier,appId)};
                DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, pars);
                Map_T_PBOCCrdtCdDtl map = new Map_T_PBOCCrdtCdDtl();
                map.DataTable = dt;
                return map;
            }
            else
            {
                return null;
            }
        }

        public DataTable GetVCompByBranchCode(string branchCode)
        {
            if (!string.IsNullOrEmpty(branchCode))
            {
                string sql = @"select id,companyname from T_VComp where branchcode=@branchcode";
                DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@branchcode", SqlDbType.VarChar, 4, branchCode));
                return dt;
            }
            else
            {
                return null;
            }
        }

        public DataTable GetVCompByBranchCode(Guid appid)
        {
            string sql = @"select v.id,v.companyname from T_VComp v inner join torg o on o.branchcode = v.branchcode Inner join t_application a on o.orgcode = a.orgcode where a.appid=@appid";
            DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appid));
            return dt;
        }

        public Map_T_RunResult GetRunResultByAppId(Guid? appid)
        {
            if (appid.HasValue)
            {
                Map_T_RunResult map = new Map_T_RunResult();
                string sql = @"select * from T_RunResult where appid=@appid";
                map.DataTable = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appid.Value));
                return map;
            }
            else
            {
                return null;
            }
        }

        public void UpdateCustomer(Map_T_Customer mapCust, string soeId)
        {
            try
            {
                if (mapCust != null)
                {
                    string strSql;
                    REC_T_Cust recCustomer;
                    mapCust.MoveFirst();
                    DBScriptStructure dbScriptStructure = new DBScriptStructure(new DBSqlStructureEnginer());
                    do
                    {
                        recCustomer = (REC_T_Cust)mapCust.CurrRowFields;
                        recCustomer.FLD_CustID.NeedSave = false;
                        recCustomer.FLD_ProposalID.NeedSave = false;
                        recCustomer.FLD_ModiDate.FieldValue = DateTime.Now;

                        if (!string.IsNullOrEmpty(soeId))
                        {
                            recCustomer.FLD_ModiID.FieldValue = soeId;
                        }
                        strSql = dbScriptStructure.StructureUpdateSql(recCustomer, mapCust.TableName, true);

                        SqlHelper.ExecuteNonQueryDefault(strSql);
                    }
                    while (mapCust.NextRow() == true);
                }
            }
            catch (Exception E)
            {
                throw new BusinessApplicationException(E);
            }
        }

        public void UpdateCustContact(Map_T_CustContact map, string soeId)
        {
            try
            {
                if (map != null)
                {
                    string strSql;
                    REC_T_CustContact rec;
                    map.MoveFirst();
                    DBScriptStructure dbScriptStructure = new DBScriptStructure(new DBSqlStructureEnginer());
                    do
                    {
                        rec = (REC_T_CustContact)map.CurrRowFields;
                        if (!SqlHelper.IsNullOrDbNull(rec.FLD_AppID.FieldValue) && !SqlHelper.IsNullOrDbNull(rec.FLD_CustID.FieldValue))
                        {
                            rec.FLD_ID.NeedSave = false;
                            if (this.IsExsitCustContact(rec.FLD_AppID.FieldValue, rec.FLD_CustID.FieldValue))
                            {
                                rec.FLD_ModiDate.FieldValue = DateTime.Now;
                                if (!string.IsNullOrEmpty(soeId))
                                {
                                    rec.FLD_ModiID.FieldValue = soeId;
                                }
                                strSql = dbScriptStructure.StructureUpdateSql(rec, map.TableName,
                                    " appid=@appid and custid=@custid");
                                SqlHelper.ExecuteNonQueryDefault(strSql,
                                    SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, rec.FLD_AppID.FieldValue),
                                    SqlHelper.CreateParam("@custid", SqlDbType.UniqueIdentifier, rec.FLD_CustID.FieldValue));
                            }
                            else
                            {
                                rec.FLD_CreatDate.FieldValue = DateTime.Now;
                                if (!string.IsNullOrEmpty(soeId))
                                {
                                    rec.FLD_CreatID.FieldValue = soeId;
                                }
                                strSql = dbScriptStructure.StructureInsertSql(rec, map.TableName);
                                SqlHelper.ExecuteNonQueryDefault(strSql);
                            }
                        }
                    }
                    while (map.NextRow() == true);
                }
            }
            catch (Exception E)
            {
                throw new BusinessApplicationException(E);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="houseAge"></param>
        /// <param name="appid"></param>
        public void UpdateLTVInfo(int houseAge, Guid appid)
        {
            string sql = "Update t_custLTV SET HouseAge = @HouseAge WHERE CustID = (Select MBID from T_Application where appid = @appid)";
            SqlParameter[] paras = new SqlParameter[]
            {
                SqlHelper.CreateParam("@HouseAge", SqlDbType.Int, houseAge),
                SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appid)
            };
            SqlHelper.ExecuteNonQueryDefault(sql, paras);
        }

        public void UpdateCollateral(Map_T_Collateral mapColla, string soeId)
        {
            try
            {
                if (mapColla != null)
                {
                    string strSql;

                    REC_T_Collateral recColla;
                    mapColla.MoveFirst();

                    DBScriptStructure dbScriptStructure = new DBScriptStructure(new DBSqlStructureEnginer());
                    do
                    {
                        recColla = (REC_T_Collateral)mapColla.CurrRowFields;
                        if (recColla.FLD_AppID.FieldValue != null || recColla.FLD_AppID.FieldValue.ToString() != string.Empty)
                        {
                            if (!this.IsExsitColla(recColla.FLD_AppID.FieldValue))
                            {
                                recColla.FLD_CreatID.FieldValue = soeId;
                                recColla.FLD_CreatDate.FieldValue = DateTime.Now;
                                strSql = dbScriptStructure.StructureInsertSql(recColla, mapColla.TableName);
                                SqlHelper.ExecuteNonQueryDefault(strSql);
                            }
                            else
                            {
                                recColla.FLD_ModiID.FieldValue = soeId;
                                recColla.FLD_ModiDate.FieldValue = DateTime.Now;
                                strSql = dbScriptStructure.StructureUpdateSql(recColla, mapColla.TableName, "appid=@appid");

                                SqlHelper.ExecuteNonQueryDefault(strSql, SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, 100, recColla.FLD_AppID.FieldValue));
                            }
                        }
                    }
                    while (mapColla.NextRow() == true);
                }
            }
            catch (Exception E)
            {
                throw new BusinessApplicationException(E);
            }
        }
        /// <summary>
        /// true:��н�ײ㣻false:���廧
        /// </summary>
        /// <param name="appid"></param>
        /// <returns></returns>
        public bool IsMainBoEmployee(Guid appid)
        {
            try
            {
                if (appid != null && appid != Guid.Empty)
                {
                    string sql = @"select worktype from T_Cust where custid=(select mbid from T_Application where appid = @AppID)";
                    SqlParameter[] sqlParams = new SqlParameter[] { SqlHelper.CreateParam("@AppID", SqlDbType.UniqueIdentifier, appid) };

                    return Convert.ToString(SqlHelper.ExecuteScalarDefault(sql, sqlParams)) == BAType.G.ToString();
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private string GetParaNameById(string paraId, string paraType)
        {
            try
            {
                string sql = @"select ParameterName from TSys_Parameter where 
                        ParameterType=@ParameterType and ParameterID=@ParameterID";
                SqlParameter[] sqlParams = new SqlParameter[] { 
                    SqlHelper.CreateParam("@ParameterType", SqlDbType.NVarChar,3, paraType),
                    SqlHelper.CreateParam("@ParameterID", SqlDbType.NVarChar,10, paraId)};

                return Convert.ToString(SqlHelper.ExecuteScalarDefault(sql, sqlParams));
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Map_T_Customer GetCustByIdNo(string idNo)
        {
            try
            {
                Map_T_Customer mapCustomer = new Map_T_Customer();
                string sql = @"SELECT A.*,C.ParameterName as CoBorrowName,MarriageName=(case Marriage when 'Y' Then '{0}'
when 'N' Then '{1}' else '{2}' end) from T_Cust A,TSys_Parameter C where C.ParameterID=A.CoBorrow and A.Id_no=@idno";
                sql = string.Format(sql, this.GetParaNameById("Y", "22"), this.GetParaNameById("D", "22"),
                    this.GetParaNameById("Q", "22"));

                mapCustomer.DataTable = SqlHelper.ExecuteDataTableDefault(sql,
                    SqlHelper.CreateParam("@idno", SqlDbType.VarChar, 18, idNo));

                return mapCustomer;
            }
            catch (Exception E)
            {
                throw new BusinessApplicationException(E);
            }
        }

        public DataTable GetVResultByID(int id)
        {
            string sql = @"select * from T_VResult where id=@id";
            DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@id", SqlDbType.Int, id));
            return dt;
        }

        public bool IsExsitColla(object appId)
        {
            try
            {
                string sql = "select count(*) from T_Collateral where appid=@appId";
                object obj = SqlHelper.ExecuteScalarDefault(sql, SqlHelper.CreateParam("@appId", SqlDbType.UniqueIdentifier, appId));
                return Convert.ToInt32(obj) > 0;
            }
            catch (Exception ex)
            {
                throw new BusinessApplicationException(ex);
            }
        }

        public Map_ScoringCard GetScroingCardByCustId(Guid custId)
        {
            if (custId != null && custId != Guid.Empty)
            {
                //edit by CWL 20081119 to fix bug#540,get Monthly Tax from Budget Analysis
                string sql = @"select A.CustId,A.ProWorkingYear,A.HousingStatus,A.PremiseOwner,A.CarOwner,A.MonthlyBalance,A.MonthlySSC,
                                A.LifeInsure,B.Tax as MonthlyTax,A.Operate_Year,A.JobProperty,A.HasSSC,A.HasLifeInsure,
                                B.M_Turnover,A.HasPay3YInsure from T_Cust A left join T_CustBGEmpVerf B on  A.custid=B.custid 
                                where A.custid=@custid";
                DataTable dt = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@custid", SqlDbType.UniqueIdentifier, custId));
                Map_ScoringCard map = new Map_ScoringCard();
                map.DataTable = dt;
                return map;
            }
            else
            {
                return null;
            }
        }

        public void SaveScroingCard(Map_ScoringCard map)
        {
            if (map != null && map.FLD_CustId != null && map.FLD_CustId != Guid.Empty)
            {
                map.MoveFirst();
                REC_ScoringCard rec = (REC_ScoringCard)map.CurrRowFields;
                rec.FLD_M_Turnover.NeedSave = false;
                DBScriptStructure dbScriptStructure = new DBScriptStructure(new DBSqlStructureEnginer());
                string sql = dbScriptStructure.StructureUpdateSql(rec, "T_Cust", " custid=@custid");
                SqlHelper.ExecuteNonQueryDefault(sql, SqlHelper.CreateParam("@custid", SqlDbType.UniqueIdentifier, map.FLD_CustId));
            }
        }

        public DataTable GetTLevelBySodId(string soeId, string prodName)
        {
            if (!string.IsNullOrEmpty(soeId) && !string.IsNullOrEmpty(prodName))
            {
                string sql = @"select b.maxloansize, a.IsDeviation, b.levelcode 
                                from TLevel a inner join TUser_Level b 
                                inner join T_Prod c on b.prodid = c.prodid
                                on a.levelcode = b.levelcode  
                                where b.soeid = @soeid and c.prodname = @prodname";
                return SqlHelper.ExecuteDataTableDefault(sql,
                    new SqlParameter[] { 
                        SqlHelper.CreateParam("@soeid", SqlDbType.VarChar, soeId), 
                        SqlHelper.CreateParam("@prodname", SqlDbType.VarChar, prodName)});
            }
            else
            {
                return null;
            }
        }

        public DataTable GetLtvValue(bool IsMo, string AppId)
        {
            StringBuilder Sql = new StringBuilder();

            if (IsMo)
            {
                Sql.Append(@"SELECT BaseLTV,MaxDelLTV FROM T_LTV_Value AS A INNER JOIN T_Application AS B ON 
A.CollateralType = B.CollateralType AND A.OrgCode = B.OrgCode AND A.MoCount = B.MoCount WHERE B.AppID = @AppId ");
            }
            else
            {
                Sql.Append(@"SELECT BaseLTV,MaxDelLTV FROM T_LTV_Value AS A INNER JOIN T_Application AS B ON 
A.CollateralType = B.CollateralType WHERE B.AppID = @AppId ");
            }

            return SqlHelper.ExecuteDataTableDefault(Sql.ToString(), new SqlParameter("@AppId", AppId));
        }

        public string GetMaxdevlvlByAppId(Guid appId)
        {
            if (appId != null && appId != Guid.Empty)
            {
                //����CitiBank.LFE.RulePool Stage THIRDRAC = "3RD RAC";
                string sql = @"select maxdevlvl from T_RP_Result where Mtype=@mtype and appid=@appid";
                SqlParameter[] pars = new SqlParameter[]{
                    SqlHelper.CreateParam("@mtype",SqlDbType.VarChar,30,Stage.THIRDRAC),
                    SqlHelper.CreateParam("@appid",SqlDbType.UniqueIdentifier,appId)};
                object obj = SqlHelper.ExecuteScalarDefault(sql, pars);
                return Convert.ToString(obj);
            }
            return String.Empty;
        }

        public void UpdateStageName(Guid appId)
        {
            if (appId != null && appId != Guid.Empty)
            {
                string sqlSel = @"select stagename from T_SaleAndApp where appid=@appid";
                string stageSel = EStageName.Prescreen.ToString();
                object obj = SqlHelper.ExecuteScalarDefault(sqlSel, SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appId));
                if (!SqlHelper.IsNullOrDbNull(obj))
                {
                    stageSel = obj.ToString();
                }

                if (stageSel.Trim() == EStageName.Prescreen.ToString().Trim())
                {
                    stageSel = EStageName.CreditSigner.ToString();
                }
                else if (stageSel.Trim() == EStageName.CreditSigner.ToString().Trim())
                {
                    stageSel = EStageName.FirstAppoval.ToString();
                }
                else if (stageSel.Trim() == EStageName.FirstAppoval.ToString().Trim())
                {
                    stageSel = EStageName.SecondAppoval.ToString();
                }

                string sql = @"update T_SaleAndApp set stagename=@stagename where appid=@appid";
                SqlParameter[] pars = new SqlParameter[]{
                    SqlHelper.CreateParam("@stagename",SqlDbType.VarChar,30,stageSel),
                    SqlHelper.CreateParam("@appid",SqlDbType.UniqueIdentifier,appId)};

                SqlHelper.ExecuteNonQueryDefault(sql, pars);
            }
        }

        public Map_T_CustLTV GetCustLTVByAppId(Guid appId)
        {
            if (appId != null && appId != Guid.Empty)
            {
                Map_T_CustLTV mapLTV = new Map_T_CustLTV();
                string sql = @" SELECT B.* FROM T_CUSTLTV AS B INNER JOIN T_APPLICATION AS A ON B.CUSTID = A.MBID WHERE A.APPID = @AppId";
                mapLTV.DataTable = SqlHelper.ExecuteDataTableDefault(sql,
                    SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, appId));
                return mapLTV;
            }
            else
            {
                return null;
            }
        }


        public bool IsExsitCustContact(object appId, object custId)
        {
            string sql = "select count(*) from T_CustContact where appid=@appid and custid=@custid";
            int count = (int)SqlHelper.ExecuteScalarDefault(sql,
                SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appId),
                SqlHelper.CreateParam("@custid", SqlDbType.UniqueIdentifier, custId));
            return count > 0;
        }

        public void SetDeviationedApproval(Guid appid)
        {
            string sql = @"if((select count(dtl.ReasonCode)
                    from T_RP_Result r inner join T_RP_ResultDtl dtl
                    on r.resultID = dtl.resultid 
                    where r.appid = '{0}' and r.mtype = '3RD RAC'
                    and dtl.ReasonCode <> '' and dtl.ReasonCode is not null)>0
                    and
                    (select maxdevlvl from T_RP_Result where appid= '{0}' and mtype = '3RD RAC') <> 'A')
                    begin 
	                    update T_Application set Deviationed = '{1}' where appid = '{0}'
                    end
                    else
                    begin
	                    update T_Application set Deviationed = '{2}' where appid = '{0}'
                    end;
                    update T_Application set ApprovedDate = '{3}',ApprovedTime = '{4}' where appid= '{0}'";

            sql = string.Format(sql, appid, ((int)EDeviationApproval.Deviationed).ToString(),
                ((int)EDeviationApproval.NoDeviation).ToString(), DateTime.Now.ToString("yyyy/MM/dd"),
                DateTime.Now.ToString("HH:mm:ss"));

            SqlHelper.ExecuteNonQueryDefault(sql);
        }

        public void SetDeviationedApproval(Guid appid, bool isTopup)
        {
            if (isTopup)
            {
                string sql = @"if((select count(dtl.ReasonCode) from T_RP_Result r inner join T_RP_ResultDtl dtl on r.resultID = dtl.resultid 
                    where r.appid = '{0}' and r.mtype in ('3RD RAC','Topup Fraud RAC') and dtl.ReasonCode <> '' and dtl.ReasonCode is not null)>0
                    and (select maxdevlvl from T_RP_Result where appid= '{0}' and mtype='3RD RAC') <> 'A'
                    and (select maxdevlvl from T_RP_Result where appid= '{0}' and mtype='Topup Fraud RAC') <> 'A')
                    begin 
	                    update T_Application set Deviationed = '{1}' where appid = '{0}'
                    end
                    else
                    begin
	                    update T_Application set Deviationed = '{2}' where appid = '{0}'
                    end;
                    update T_Application set ApprovedDate = '{3}',ApprovedTime = '{4}' where appid= '{0}'";

                sql = string.Format(sql, appid, ((int)EDeviationApproval.Deviationed).ToString(),
                    ((int)EDeviationApproval.NoDeviation).ToString(), DateTime.Now.ToString("yyyy/MM/dd"),
                    DateTime.Now.ToString("HH:mm:ss"));

                SqlHelper.ExecuteNonQueryDefault(sql);
            }
        }

        public void UpdateLoanPurpose(Map_T_Application T_Application)
        {
            if (String.IsNullOrEmpty(T_Application.FLD_LoanPurpose))
            {
                return;
            }
            string sql = @"UPDATE T_Application SET LOANPURPOSE = @loanpurpose,LPREMARKS = @remarks, LOANPURPOSEDESC = @loanPurposeDesc 
WHERE APPID = @appid";
            SqlHelper.ExecuteNonQueryDefault(sql,
                SqlHelper.CreateParam("@loanpurpose", SqlDbType.VarChar, 5, T_Application.FLD_LoanPurpose),
                SqlHelper.CreateParam("@remarks", SqlDbType.VarChar, 80, T_Application.FLD_LPRemarks),
                SqlHelper.CreateParam("@loanPurposeDesc", SqlDbType.VarChar, 300, T_Application.FLD_LoanPurposeDesc),
                SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, T_Application.FLD_AppID));
        }

        public DataTable GetPendRejectReasons()
        {
            string sql = "select * from T_PendRejectReason";
            return SqlHelper.ExecuteDataTableDefault(sql);
        }


        public string QueryProposalIdByProposalNo(string proposalNo)
        {
            string sql = @"select b.proposalid from t_proposal b where b.proposalNo = @ProposalNo";

            object o = SqlHelper.ExecuteScalarDefault(sql, SqlHelper.CreateParam("@ProposalNo", SqlDbType.VarChar, 20, proposalNo));

            return Convert.ToString(o);
        }

        public string GetReasonCode(Guid appId)
        {
            string sql = @"select PendReasonCode from T_Application where appid=@appId";
            object obj = SqlHelper.ExecuteScalarDefault(sql, SqlHelper.CreateParam("@appId", SqlDbType.UniqueIdentifier, appId));
            return Convert.ToString(obj);
        }

        public void UpdateReasonCode(Guid appId, string reasoncode)
        {
            if (reasoncode == null)
                reasoncode = string.Empty;
            string sql = @"update T_Application Set PendReasonCode=@code where appid = @appId";
            SqlHelper.ExecuteNonQueryDefault(sql,
                SqlHelper.CreateParam("@code", SqlDbType.VarChar, 50, reasoncode),
                SqlHelper.CreateParam("@appId", SqlDbType.UniqueIdentifier, appId));
        }


        //add by lvwei 2009022?
        public int GetFirstRACbyApp(Guid appid, string stage, string stageRAC)
        {
            string sql = @"select count(*) from T_RP_Result where MTID = 3 and AppID = @appID ";
            object obj = SqlHelper.ExecuteScalarDefault(sql,
              SqlHelper.CreateParam("@appID", SqlDbType.UniqueIdentifier, appid));
            if (!SqlHelper.IsNullOrDbNull(obj))
                return Convert.ToInt32(obj);
            else
                return 0;

        }

        //add by lvwei 2009022?
        public int GetLastRACbyApp(Guid appid)
        {
            string sql = @"select top 1 MTID from T_RP_Result where appid=@appid order by (Date + '' + Time) desc";
            object obj = SqlHelper.ExecuteScalarDefault(sql,
                SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, appid));

            if (!SqlHelper.IsNullOrDbNull(obj))
                return Convert.ToInt32(obj);
            else
                return 0;

        }

        public void InsertTAppProdDtl(Guid Appid)
        {
            string sql = "select UseNewProductCode from T_Application where appid = @appid";

            object obj = SqlHelper.ExecuteScalarDefault(sql, SqlHelper.CreateParam("@appid", SqlDbType.UniqueIdentifier, Appid));

            if (!string.IsNullOrEmpty(Convert.ToString(obj).Trim()))
            {
                sql = @"DELETE FROM T_AppProdDtl WHERE AppID = @AppId;";

                SqlHelper.ExecuteNonQueryDefault(sql, SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, Appid));

                SqlHelper.ExecuteNonQuerySpDefault("InsertAppDtl", SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, Appid));
            }
        }

        public void SaveCustomerIncomeType(Map_T_CustIncomeType map)
        {
            map.MoveFirst();

            SqlParameter[] sqlParams = new SqlParameter[2];
            sqlParams[0] = SqlHelper.CreateParam("@APPID", SqlDbType.UniqueIdentifier, map.FLD_AppID);
            sqlParams[1] = SqlHelper.CreateParam("@CUSTID", SqlDbType.UniqueIdentifier, map.FLD_CustID);

            string deleteSql = "DELETE FROM T_CUSTINCOMETYPE WHERE APPID = @APPID AND CUSTID = @CUSTID";

            SqlHelper.ExecuteNonQueryDefault(deleteSql, sqlParams);

            string insertSql = @"INSERT INTO T_CUSTINCOMETYPE (APPID, CUSTID, INCOMETYPE) VALUES (@APPID, @CUSTID, @INCOMETYPE)";

            do
            {
                sqlParams = new SqlParameter[3];
                sqlParams[0] = SqlHelper.CreateParam("@APPID", SqlDbType.UniqueIdentifier, map.FLD_AppID);
                sqlParams[1] = SqlHelper.CreateParam("@CUSTID", SqlDbType.UniqueIdentifier, map.FLD_CustID);
                sqlParams[2] = SqlHelper.CreateParam("@INCOMETYPE", SqlDbType.VarChar, map.FLD_IncomeType);

                SqlHelper.ExecuteNonQueryDefault(insertSql, sqlParams);
            }
            while (map.NextRow());
        }

        /// <summary>
        /// For Top Up use
        /// </summary>
        /// <param name="map"></param>
        /// <returns></returns>
        public void SaveCustomerIncomeType(Map_T_CustIncomeType map, bool IsTopup)
        {
            map.MoveFirst();

            string deleteSql = "DELETE FROM T_CUSTINCOMETYPE WHERE APPID = @APPID";

            SqlHelper.ExecuteNonQueryDefault(deleteSql, SqlHelper.CreateParam("@APPID", SqlDbType.UniqueIdentifier, map.FLD_AppID));

            string insertSql = @"INSERT INTO T_CUSTINCOMETYPE (APPID, CUSTID, INCOMETYPE) VALUES (@APPID, @CUSTID, @INCOMETYPE)";

            SqlParameter[] sqlParams = null;

            do
            {
                sqlParams = new SqlParameter[3];
                sqlParams[0] = SqlHelper.CreateParam("@APPID", SqlDbType.UniqueIdentifier, map.FLD_AppID);
                sqlParams[1] = SqlHelper.CreateParam("@CUSTID", SqlDbType.UniqueIdentifier, map.FLD_CustID);
                sqlParams[2] = SqlHelper.CreateParam("@INCOMETYPE", SqlDbType.VarChar, map.FLD_IncomeType);

                SqlHelper.ExecuteNonQueryDefault(insertSql, sqlParams);
            }
            while (map.NextRow());
        }

        public void SetPBOCChecked(Guid appid)
        {
            string sqlget = @"UPDATE T_APPLICATION SET ISPBOCCHECKED = 'Y' WHERE APPID = @APPID";
            SqlParameter[] sqlParams = new SqlParameter[1];
            sqlParams[0] = SqlHelper.CreateParam("@APPID", SqlDbType.UniqueIdentifier, appid);
            SqlHelper.ExecuteNonQueryDefault(sqlget, sqlParams);
        }
        public void SetALSChecked(Guid appid)
        {
            string sqlget = @"UPDATE T_APPLICATION SET ISALSCHECKED = 'Y' WHERE APPID = @APPID";
            SqlParameter[] sqlParams = new SqlParameter[1];
            sqlParams[0] = SqlHelper.CreateParam("@APPID", SqlDbType.UniqueIdentifier, appid);
            SqlHelper.ExecuteNonQueryDefault(sqlget, sqlParams);
        }
        public string GetPBOCChecked(Guid appid)
        {
            string sqlget = @"SELECT ISPBOCCHECKED FROM T_APPLICATION WHERE APPID = @APPID";
            object obj = SqlHelper.ExecuteScalarDefault(sqlget,
                SqlHelper.CreateParam("@APPID", SqlDbType.UniqueIdentifier, appid));
            if (SqlHelper.IsNullOrDbNull(obj))
            {
                return "N";
            }
            else
                return obj.ToString();
        }

        public string GetALSChecked(Guid appid)
        {
            string sqlget = @"SELECT ISALSCHECKED FROM T_APPLICATION  WHERE APPID = @APPID";
            object obj = SqlHelper.ExecuteScalarDefault(sqlget,
              SqlHelper.CreateParam("@APPID", SqlDbType.UniqueIdentifier, appid));
            if (SqlHelper.IsNullOrDbNull(obj))
            {
                return "N";
            }
            else
                return obj.ToString();
        }

        public string GetProductName(int prodId)
        {
            string sql = @"SELECT REMARKS AS PRODNAME FROM T_PROD WHERE PRODID = @PRODID";
            SqlParameter[] sqlParams = new SqlParameter[1];
            sqlParams[0] = new SqlParameter("@PRODID", prodId);
            object prodName = SqlHelper.ExecuteScalarDefault(sql, sqlParams);

            return Convert.ToString(prodName);
        }

        public string GetProductName(string prodCode)
        {
            string sql = @"SELECT REMARKS AS PRODNAME FROM T_PROD WHERE PRODNAME = @PRODCODE";
            SqlParameter[] sqlParams = new SqlParameter[1];
            sqlParams[0] = new SqlParameter("@PRODCODE", prodCode);
            object prodName = SqlHelper.ExecuteScalarDefault(sql, sqlParams);

            return Convert.ToString(prodName);
        }

        /// <summary>
        /// ��ȡԭʼ�ͻ����
        /// </summary>
        /// <param name="AppId">ApplicationId from T_Application</param>
        /// <returns>���ַ������߿ͻ����</returns>
        public string GetOriginalSegmentId(Guid AppId)
        {
            string SqlTxt = @"SELECT OriginalSegmentId FROM [T_TopupSegment] WHERE ApplicationId = @AppId";

            try
            {
                object Result = SqlHelper.ExecuteScalarDefault(SqlTxt, SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, AppId));
                return Convert.ToString(Result);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// ����OriginalSegmentId
        /// </summary>
        /// <param name="SegmentId">��Ҫ���µĿͻ�����</param>
        /// <param name="AppNo">������</param>
        public void UpdateOriginalSegmentId(string SegmentId, Guid AppId)
        {
            string SqlTxt = @"UPDATE [T_TopupSegment] SET [OriginalSegmentId] = @OriginalSegmentId,[UpdateDate] = getdate() WHERE ApplicationId = @AppId";

            try
            {
                SqlHelper.ExecuteNonQueryDefault(SqlTxt, new SqlParameter[] { SqlHelper.CreateParam("@OriginalSegmentId",SqlDbType.BigInt,Convert.ToInt64(SegmentId)),
                SqlHelper.CreateParam("@AppId",SqlDbType.UniqueIdentifier,AppId)
                });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// ��ȡ����Ͷ����Ϣ
        /// </summary>
        /// <param name="AppId">����ID</param>
        /// <returns>����Ͷ���ʵ��</returns>
        public Map_T_LoanIndustry GetLoanIndustry(Guid AppId)
        {
            try
            {
                string Sql = @"SELECT [LoanCategory],[Loan1stPurpose],[Loan2ndPurpose],[Loan3rdPurpose],[LoanCommercialFiment],[OtherLoanPurpose],
[LoanMainIndustry],[LoanSubIndustry] FROM [T_LoanIndustry] WHERE [AppId] = @AppId";

                DataTable dt = SqlHelper.ExecuteDataTableDefault(Sql, SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, AppId));

                Map_T_LoanIndustry MapLoanIndustry = new Map_T_LoanIndustry();

                //���ڴ���Ͷ����趨
                if (dt != null && dt.Rows.Count > 0)
                {
                    MapLoanIndustry.FLD_AppId = AppId;
                    MapLoanIndustry.FLD_Loan1stPurpose = Convert.ToString(dt.Rows[0]["Loan1stPurpose"]);
                    MapLoanIndustry.FLD_Loan2ndPurpose = Convert.ToString(dt.Rows[0]["Loan2ndPurpose"]);
                    MapLoanIndustry.FLD_Loan3rdPurpose = Convert.ToString(dt.Rows[0]["Loan3rdPurpose"]);
                    MapLoanIndustry.FLD_LoanCategory = Convert.ToString(dt.Rows[0]["LoanCategory"]);
                    MapLoanIndustry.FLD_LoanMainIndustry = Convert.ToString(dt.Rows[0]["LoanMainIndustry"]);
                    MapLoanIndustry.FLD_LoanSubIndustry = Convert.ToString(dt.Rows[0]["LoanSubIndustry"]);

                    //����������;
                    if (MapLoanIndustry.FLD_Loan1stPurpose.Equals("O", StringComparison.CurrentCultureIgnoreCase) || MapLoanIndustry.FLD_Loan2ndPurpose.Equals("O", StringComparison.CurrentCultureIgnoreCase) || MapLoanIndustry.FLD_Loan3rdPurpose.Equals("O", StringComparison.CurrentCultureIgnoreCase)
                       || MapLoanIndustry.FLD_Loan1stPurpose.Equals("X", StringComparison.CurrentCultureIgnoreCase) || MapLoanIndustry.FLD_Loan2ndPurpose.Equals("X", StringComparison.CurrentCultureIgnoreCase) || MapLoanIndustry.FLD_Loan3rdPurpose.Equals("X", StringComparison.CurrentCultureIgnoreCase))
                    {
                        MapLoanIndustry.FLD_OtherLoanPurpose = Convert.ToString(dt.Rows[0]["OtherLoanPurpose"]);
                    }
                    //�̶��ʲ�--��Ӫ��װ��
                    if (MapLoanIndustry.FLD_Loan1stPurpose == "C" || MapLoanIndustry.FLD_Loan2ndPurpose == "C" || MapLoanIndustry.FLD_Loan3rdPurpose == "C")
                    {
                        MapLoanIndustry.FLD_LoanCommercialFiment = Convert.ToString(dt.Rows[0]["LoanCommercialFiment"]);
                    }

                    return MapLoanIndustry;
                }
                else��//T_LoanIndustry û�д���Ͷ����趨
                {
                    dt.Clear();

                    Sql = @"SELECT [LoanPurpose],[LPRemarks],[LoanPurposeDesc] FROM [T_Application] WHERE EXISTS (SELECT [LoanPurpose],[LPRemarks],[LoanPurposeDesc]
FROM [T_Proposal] WHERE [T_Application].ProposalID = [T_Proposal].ProposalID) AND AppId = @AppId";

                    dt = SqlHelper.ExecuteDataTableDefault(Sql, SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, AppId));

                    if (dt != null && dt.Rows.Count > 0)��//T_Application,T_Proposal������ѯ������;
                    {
                        string LoanPurpose = Convert.ToString(dt.Rows[0]["LoanPurpose"]);
                        string LoanRemarks = Convert.ToString(dt.Rows[0]["LPRemarks"]);
                        string LoanPuposeDesc = Convert.ToString(dt.Rows[0]["LoanPurposeDesc"]);

                        int PurposeCount = LoanPurpose.Split(',').Length;

                        string Category1 = String.Empty;
                        string Category2 = String.Empty;
                        string Category3 = String.Empty;

                        switch (PurposeCount)
                        {
                            case 1:
                                //ֻ��һ��������;,���תΪ��������������;
                                MapLoanIndustry.FLD_Loan1stPurpose = LoanPurpose == "G" ? "O" : LoanPurpose;
                                //����������;
                                if (MapLoanIndustry.FLD_Loan1stPurpose.Equals("O", StringComparison.CurrentCultureIgnoreCase))
                                {
                                    MapLoanIndustry.FLD_OtherLoanPurpose = Convert.ToString(dt.Rows[0]["LPRemarks"]);
                                }
                                MapLoanIndustry.FLD_LoanCategory = GetLoanCategory(MapLoanIndustry.FLD_Loan1stPurpose);
                                break;
                            case 2:
                                MapLoanIndustry.FLD_Loan1stPurpose = LoanPurpose.Split(',')[0] == "G" ? "O" : LoanPurpose.Split(',')[0];��//��һ������;
                                MapLoanIndustry.FLD_Loan2ndPurpose = LoanPurpose.Split(',')[1] == "G" ? "O" : LoanPurpose.Split(',')[1];  //�ڶ�������;
                                //���ƴ������
                                Category1 = GetLoanCategory(MapLoanIndustry.FLD_Loan1stPurpose);
                                Category2 = GetLoanCategory(MapLoanIndustry.FLD_Loan2ndPurpose);

                                if (Category1 == String.Empty || Category2 == String.Empty)
                                {
                                    Logger.InfoLog(AppId.ToString() + ",������;��ʼֵ����", MethodBase.GetCurrentMethod().Name);
                                    return null;
                                }

                                //���������;���һ��
                                if (Category1 != Category2)
                                {
                                    //��յڶ������
                                    MapLoanIndustry.FLD_Loan2ndPurpose = String.Empty;
                                }
                                if (MapLoanIndustry.FLD_Loan1stPurpose.Equals("O", StringComparison.CurrentCultureIgnoreCase) || MapLoanIndustry.FLD_Loan2ndPurpose.Equals("O", StringComparison.CurrentCultureIgnoreCase))
                                {
                                    MapLoanIndustry.FLD_OtherLoanPurpose = Convert.ToString(dt.Rows[0]["LPRemarks"]);
                                }
                                //�����Ե�һ��;�Ĵ����������ֵ
                                MapLoanIndustry.FLD_LoanCategory = Category1;
                                break;
                            case 3:
                                MapLoanIndustry.FLD_Loan1stPurpose = LoanPurpose.Split(',')[0] == "G" ? "O" : LoanPurpose.Split(',')[0];  //��һ������;
                                MapLoanIndustry.FLD_Loan2ndPurpose = LoanPurpose.Split(',')[1] == "G" ? "O" : LoanPurpose.Split(',')[1];  //�ڶ�������;
                                MapLoanIndustry.FLD_Loan3rdPurpose = LoanPurpose.Split(',')[2] == "G" ? "O" : LoanPurpose.Split(',')[2];  //����������;

                                //���ƴ������
                                Category1 = GetLoanCategory(MapLoanIndustry.FLD_Loan1stPurpose);
                                Category2 = GetLoanCategory(MapLoanIndustry.FLD_Loan2ndPurpose);
                                Category3 = GetLoanCategory(MapLoanIndustry.FLD_Loan3rdPurpose);

                                if (Category1 == String.Empty || Category2 == String.Empty || Category3 == String.Empty)
                                {
                                    Logger.InfoLog(AppId.ToString() + ",������;��ʼֵ����", MethodBase.GetCurrentMethod().Name);
                                    return null;
                                }

                                if (Category1 != Category2)
                                {
                                    //��յڶ������
                                    MapLoanIndustry.FLD_Loan2ndPurpose = String.Empty;
                                }
                                if (Category1 != Category3)
                                {
                                    //��յ��������
                                    MapLoanIndustry.FLD_Loan3rdPurpose = String.Empty;
                                }
                                if (Category1 == Category2 && Category2 != Category3)
                                {
                                    //��յ��������
                                    MapLoanIndustry.FLD_Loan3rdPurpose = String.Empty;
                                }
                                if (Category1 == Category3 && Category2 != Category3)
                                {
                                    //��յڶ������
                                    MapLoanIndustry.FLD_Loan2ndPurpose = String.Empty;
                                }
                                if (MapLoanIndustry.FLD_Loan1stPurpose.Equals("O", StringComparison.CurrentCultureIgnoreCase) || MapLoanIndustry.FLD_Loan2ndPurpose.Equals("O", StringComparison.CurrentCultureIgnoreCase) || MapLoanIndustry.FLD_Loan3rdPurpose.Equals("O", StringComparison.CurrentCultureIgnoreCase))
                                {
                                    MapLoanIndustry.FLD_OtherLoanPurpose = Convert.ToString(dt.Rows[0]["LPRemarks"]);
                                }
                                //�����Ե�һ��;�Ĵ����������ֵ
                                MapLoanIndustry.FLD_LoanCategory = Category1;
                                break;
                        }
                        return MapLoanIndustry;
                    }
                    else��//û�ж�Ӧ������
                    {
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.ErrorLog(ex, MethodBase.GetCurrentMethod().Name);
                throw new ServerSqlException(ex.Message);
            }
        }

        public Map_T_LoanIndustry GetLoanIndustryShadow(Guid appId, Guid? propId)
        {
            string sql = @"SELECT [ProposalId]
      ,[AppId]
      ,[LoanCategory]
      ,[Loan1stPurpose]
      ,[Loan2ndPurpose]
      ,[Loan3rdPurpose]
      ,[LoanCommercialFiment]
      ,[OtherLoanPurpose]
      ,[LoanMainIndustry]
      ,[LoanSubIndustry]
      ,[CreatorId]
      ,[CreateTime]
  FROM [dbo].[T_LoanIndustry_Shadow] WHERE [AppId]=@AppId AND Status=0";

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@AppId", appId));

            if (propId.HasValue)
            {
                sql += " AND [ProposalId]=@ProposalId";
                param.Add(new SqlParameter("@ProposalId", propId));
            }

            DataSet ds = SqlHelper.ExecuteDatasetDefault(sql, param.ToArray());
            if (ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0)
            {
                Map_T_LoanIndustry loanIndustry = new Map_T_LoanIndustry()
                {
                    FLD_AppId = appId,
                    FLD_CreateTime = ds.Tables[0].Rows[0]["CreateTime"].ToString(),
                    FLD_Loan1stPurpose = ds.Tables[0].Rows[0]["Loan1stPurpose"].ToString(),
                    FLD_CreatorId = ds.Tables[0].Rows[0]["CreatorId"].ToString(),
                    FLD_Loan2ndPurpose = ds.Tables[0].Rows[0]["Loan2ndPurpose"].ToString(),
                    FLD_Loan3rdPurpose = ds.Tables[0].Rows[0]["Loan3rdPurpose"].ToString(),
                    FLD_LoanCategory = ds.Tables[0].Rows[0]["LoanCategory"].ToString(),
                    FLD_LoanCommercialFiment = ds.Tables[0].Rows[0]["LoanCommercialFiment"].ToString(),
                    FLD_LoanMainIndustry = ds.Tables[0].Rows[0]["LoanMainIndustry"].ToString(),
                    FLD_LoanSubIndustry = ds.Tables[0].Rows[0]["LoanSubIndustry"].ToString(),
                    FLD_OtherLoanPurpose = ds.Tables[0].Rows[0]["OtherLoanPurpose"].ToString()

                };
                if (propId.HasValue)
                {
                    loanIndustry.FLD_ProposalId = propId.Value;
                }
                return loanIndustry;
            }
            else
            {
                return null;
            }
        }

        public void SaveLoanIndustry(Map_T_LoanIndustry MapLoanIndustry)
        {

            string Sql = @"SELECT COUNT(*) FROM [T_LoanIndustry] WHERE [AppId] = @AppId";

            List<SqlParameter> Params = new List<SqlParameter>();

            try
            {
                object Result = SqlHelper.ExecuteScalarDefault(Sql, SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, MapLoanIndustry.FLD_AppId));

                if (Convert.ToInt32(Result) > 0)
                {
                    Sql = @"UPDATE [T_LoanIndustry] SET [LoanCategory] = @LoanCategory,[Loan1stPurpose] = @Loan1stPurpose,[Loan2ndPurpose] = @Loan2ndPurpose,
[Loan3rdPurpose] = @Loan3rdPurpose,[LoanCommercialFiment] = @LoanCommercialFiment,[OtherLoanPurpose] = @OtherLoanPurpose,[LoanMainIndustry] = @LoanMainIndustry,
[LoanSubIndustry] = @LoanSubIndustry,[ModifierId] = @ModifierId,[ModifiedTime] = getdate() WHERE [AppId] = @AppId";

                    Params.Add(SqlHelper.CreateParam("@LoanCategory", SqlDbType.NVarChar, MapLoanIndustry.FLD_LoanCategory));
                    Params.Add(SqlHelper.CreateParam("@Loan1stPurpose", SqlDbType.NVarChar, MapLoanIndustry.FLD_Loan1stPurpose));
                    Params.Add(SqlHelper.CreateParam("@Loan2ndPurpose", SqlDbType.NVarChar, MapLoanIndustry.FLD_Loan2ndPurpose));
                    Params.Add(SqlHelper.CreateParam("@Loan3rdPurpose", SqlDbType.NVarChar, MapLoanIndustry.FLD_Loan3rdPurpose));
                    Params.Add(SqlHelper.CreateParam("@LoanCommercialFiment", SqlDbType.NVarChar, MapLoanIndustry.FLD_LoanCommercialFiment));
                    Params.Add(SqlHelper.CreateParam("@OtherLoanPurpose", SqlDbType.NVarChar, MapLoanIndustry.FLD_OtherLoanPurpose));
                    Params.Add(SqlHelper.CreateParam("@LoanMainIndustry", SqlDbType.NVarChar, MapLoanIndustry.FLD_LoanMainIndustry));
                    Params.Add(SqlHelper.CreateParam("@LoanSubIndustry", SqlDbType.NVarChar, MapLoanIndustry.FLD_LoanSubIndustry));
                    Params.Add(SqlHelper.CreateParam("@ModifierId", SqlDbType.NVarChar, MapLoanIndustry.FLD_ModifierId));
                    Params.Add(SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, MapLoanIndustry.FLD_AppId));
                }
                else
                {
                    DA_Common CommonDA = new DA_Common();
                    Guid ProposalId = new Guid(CommonDA.GetPropIdByAppId(MapLoanIndustry.FLD_AppId));

                    Sql = @"INSERT INTO [T_LoanIndustry]([ProposalId],[AppId],[LoanCategory],[Loan1stPurpose],[Loan2ndPurpose],[Loan3rdPurpose]
,[LoanCommercialFiment],[OtherLoanPurpose],[LoanMainIndustry],[LoanSubIndustry],[CreatorId]) VALUES 
(@ProposalId,@AppId,@LoanCategory,@Loan1stPurpose,@Loan2ndPurpose,@Loan3rdPurpose,@LoanCommercialFiment,@OtherLoanPurpose,@LoanMainIndustry,@LoanSubIndustry,
@CreatorId)";

                    Params.Add(SqlHelper.CreateParam("@ProposalId", SqlDbType.UniqueIdentifier, ProposalId));
                    Params.Add(SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, MapLoanIndustry.FLD_AppId));
                    Params.Add(SqlHelper.CreateParam("@LoanCategory", SqlDbType.NVarChar, MapLoanIndustry.FLD_LoanCategory));
                    Params.Add(SqlHelper.CreateParam("@Loan1stPurpose", SqlDbType.NVarChar, MapLoanIndustry.FLD_Loan1stPurpose));
                    Params.Add(SqlHelper.CreateParam("@Loan2ndPurpose", SqlDbType.NVarChar, MapLoanIndustry.FLD_Loan2ndPurpose));
                    Params.Add(SqlHelper.CreateParam("@Loan3rdPurpose", SqlDbType.NVarChar, MapLoanIndustry.FLD_Loan3rdPurpose));
                    Params.Add(SqlHelper.CreateParam("@LoanCommercialFiment", SqlDbType.NVarChar, MapLoanIndustry.FLD_LoanCommercialFiment));
                    Params.Add(SqlHelper.CreateParam("@OtherLoanPurpose", SqlDbType.NVarChar, MapLoanIndustry.FLD_OtherLoanPurpose));
                    Params.Add(SqlHelper.CreateParam("@LoanMainIndustry", SqlDbType.NVarChar, MapLoanIndustry.FLD_LoanMainIndustry));
                    Params.Add(SqlHelper.CreateParam("@LoanSubIndustry", SqlDbType.NVarChar, MapLoanIndustry.FLD_LoanSubIndustry));
                    Params.Add(SqlHelper.CreateParam("@CreatorId", SqlDbType.NVarChar, MapLoanIndustry.FLD_ModifierId));
                }

                SqlHelper.ExecuteNonQueryDefault(Sql, Params.ToArray());
            }
            catch (Exception ex)
            {
                Logger.ErrorLog(ex, MethodBase.GetCurrentMethod().Name);
                throw new ServerSqlException(ex.Message);
            }
        }

        /// <summary>
        /// ͨ��������;��ѯ�������
        /// </summary>
        /// <param name="LoanPurpose">������;��ID</param>
        /// <returns>�������</returns>
        private string GetLoanCategory(string LoanPurpose)
        {
            string LoanCategory = String.Empty;

            switch (LoanPurpose)
            {
                case "A":
                case "D":
                case "E":
                case "H":
                case "O":
                case "S":
                    LoanCategory = "PER";
                    break;
                case "F":
                case "C":
                case "M":
                case "X":
                    LoanCategory = "PRO";
                    break;
            }
            return LoanCategory;
        }

        public Map_T_MoCountCheck GetMoCheck(Guid AppId)
        {
            Map_T_MoCountCheck Entity = new Map_T_MoCountCheck();
            //modified on 2015/03/05
            string Sql = @"SELECT [AppId],[CustDeclare],[ConfirmCustDeclare],[HouseBureau],[ConfirmHouseBureau],[HouseBureauChecked]
                    ,[PBOC],[ConfirmPBOC],[PBOCChecked],[TotalMoCount],[ConfirmTotalMoCount],PBOC_Unclear,PBOC_UnclearMatch,PBOC_ClearMatch
                    ,TotalMoCount_Orgin,ConfirmPBOC_Unclear,ConfirmPBOC_UnclearMatch,ConfirmPBOC_ClearMatch,ConfirmTotalMoCount_Orgin
                FROM [T_MoCountCheck] WHERE [AppId] = @AppId";

            DataTable result = SqlHelper.ExecuteDataTableDefault(Sql, new SqlParameter("@AppId", AppId));

            if (result != null && result.Rows.Count > 0)
            {
                Entity.FLD_APPID = AppId;
                Entity.FLD_CUSTDECLARE = Convert.ToInt32(result.Rows[0]["CustDeclare"]);
                Entity.FLD_CONFIRMCUSTDECLARE = Convert.ToInt32(result.Rows[0]["ConfirmCustDeclare"]);
                //1���ʱ�򣬻����¸�ֵ
                if (!(result.Rows[0]["HouseBureauChecked"] is DBNull) && result.Rows[0]["HouseBureauChecked"] != null && Convert.ToBoolean(result.Rows[0]["HouseBureauChecked"]))
                {
                    Entity.FLD_HOUSEBUREAU = Convert.ToInt32(result.Rows[0]["HouseBureau"]);
                    Entity.FLD_CONFIRMHOUSEBUREAU = Convert.ToInt32(result.Rows[0]["ConfirmHouseBureau"]);
                    Entity.FLD_HouseBureauChecked = Convert.ToBoolean(result.Rows[0]["HouseBureauChecked"]);
                    Entity.FLD_PBOC_UnclearMatch = Convert.ToInt32(result.Rows[0]["PBOC_UnclearMatch"]);
                    Entity.FLD_ConfirmPBOC_UnclearMatch = Convert.ToInt32(result.Rows[0]["ConfirmPBOC_UnclearMatch"]);
                    Entity.FLD_PBOC_ClearMatch = Convert.ToInt32(result.Rows[0]["PBOC_ClearMatch"]);
                    Entity.FLD_ConfirmPBOC_ClearMatch = Convert.ToInt32(result.Rows[0]["ConfirmPBOC_ClearMatch"]);
                }
                if (!(result.Rows[0]["PBOCChecked"] is DBNull) && result.Rows[0]["PBOCChecked"] != null && Convert.ToBoolean(result.Rows[0]["PBOCChecked"]))
                {
                    Entity.FLD_PBOC = Convert.ToInt32(result.Rows[0]["PBOC"]);
                    Entity.FLD_CONFIRMPBOC = Convert.ToInt32(result.Rows[0]["ConfirmPBOC"]);
                    Entity.FLD_PBOCChecked = Convert.ToBoolean(result.Rows[0]["PBOCChecked"]);
                    Entity.FLD_PBOC_Unclear = Convert.ToInt32(result.Rows[0]["PBOC_Unclear"]);
                    Entity.FLD_ConfirmPBOC_Unclear = Convert.ToInt32(result.Rows[0]["ConfirmPBOC_Unclear"]);
                }
                Entity.FLD_TotalMoCount_Orgin = Convert.ToInt32(result.Rows[0]["TotalMoCount_Orgin"]);
                Entity.FLD_ConfirmTotalMoCount_Orgin = Convert.ToInt32(result.Rows[0]["ConfirmTotalMoCount_Orgin"]);

                Entity.FLD_TOTALMOCOUNT = Convert.ToInt32(result.Rows[0]["TotalMoCount"]);
                Entity.FLD_CONFIRMTOTALMOCOUNT = Convert.ToInt32(result.Rows[0]["ConfirmTotalMoCount"]);

                return Entity;
            }

            return null;
        }

        public Map_T_MoCountCheck InitMoCheck(Guid AppId)
        {
            string Sql = @"SELECT MoCount FROM T_Application WHERE AppId = @AppId;";
            object CustDeclare = SqlHelper.ExecuteScalarDefault(Sql, new SqlParameter("@AppId", AppId));

            Map_T_MoCountCheck MapMoCheck = new Map_T_MoCountCheck();

            if (CustDeclare != null && !(CustDeclare is DBNull) && Convert.ToInt32(CustDeclare) > 0)
            {
                //MapMoCheck.FLD_CUSTDECLARE = Convert.ToInt32(CustDeclare);
                MapMoCheck.FLD_CUSTDECLARE = Convert.ToInt32(CustDeclare) - 1;
                MapMoCheck.FLD_CONFIRMCUSTDECLARE = MapMoCheck.FLD_CUSTDECLARE;

                Sql = @"SELECT TotalPropertyValue FROM T_MoHouseBureau WHERE AppId = @AppId;";

                object result = SqlHelper.ExecuteScalarDefault(Sql, new SqlParameter("@AppId", AppId));

                if (result != null && !(result is DBNull))
                {
                    MapMoCheck.FLD_HOUSEBUREAU = Convert.ToInt32(result);
                    //MapMoCheck.FLD_CONFIRMHOUSEBUREAU = MapMoCheck.FLD_HOUSEBUREAU + 1;
                    MapMoCheck.FLD_CONFIRMHOUSEBUREAU = MapMoCheck.FLD_HOUSEBUREAU;
                    MapMoCheck.FLD_HouseBureauChecked = true;
                }
                else
                {
                    MapMoCheck.FLD_HouseBureauChecked = false;
                }
            }
            return MapMoCheck;
        }

        public void SaveMoCheck(Map_T_MoCountCheck MoCheck, string SoeId)
        {
            if (MoCheck != null)
            {
                string Sql = @"SELECT COUNT(*) FROM [T_MoCountCheck] WHERE [AppId] = @AppId";

                if (Convert.ToInt32(SqlHelper.ExecuteScalarDefault(Sql, new SqlParameter("@AppId", MoCheck.FLD_APPID))) > 0)
                {
                    Sql = @"UPDATE T_MoCountCheck 
                        SET CustDeclare = @CustDeclare,ConfirmCustDeclare = @ConfirmCustDeclare,HouseBureau = @HouseBureau,
                            ConfirmHouseBureau = @ConfirmHouseBureau,HouseBureauChecked = @HouseBureauChecked,PBOC = @PBOC,
                            ConfirmPBOC = @ConfirmPBOC,PBOCChecked = @PBOCChecked,TotalMoCount = @TotalMoCount,
                            ConfirmTotalMoCount = @ConfirmTotalMoCount,UpdatedId = @UpdatedId,UpdatedTime = GETDATE(),
                            PBOC_Unclear = @Unclear,PBOC_UnclearMatch =@UnclearMatch,PBOC_ClearMatch = @ClearMatch,
                            TotalMoCount_Orgin = @TotalMoCount_Orgin,ConfirmPBOC_Unclear = @UnclearVer,
                            ConfirmPBOC_UnclearMatch = @UnclearMatchVer,ConfirmPBOC_ClearMatch = @ClearMatchVer,
                            ConfirmTotalMoCount_Orgin = @TotalMoCount_OrginVer
                        WHERE [AppId] = @AppId";
                    SqlParameter[] Params = new SqlParameter[] { 
                    new SqlParameter("@CustDeclare",MoCheck.FLD_CUSTDECLARE),
                    new SqlParameter("@ConfirmCustDeclare",MoCheck.FLD_CONFIRMCUSTDECLARE),
                    new SqlParameter("@HouseBureau",MoCheck.FLD_HOUSEBUREAU),
                    new SqlParameter("@ConfirmHouseBureau",MoCheck.FLD_CONFIRMHOUSEBUREAU),
                    new SqlParameter("@HouseBureauChecked",MoCheck.FLD_HouseBureauChecked),
                    new SqlParameter("@PBOC",MoCheck.FLD_PBOC),
                    new SqlParameter("@ConfirmPBOC",MoCheck.FLD_CONFIRMPBOC),
                    new SqlParameter("@PBOCChecked",MoCheck.FLD_PBOCChecked),
                    new SqlParameter("@TotalMoCount",MoCheck.FLD_TOTALMOCOUNT),
                    new SqlParameter("@ConfirmTotalMoCount",MoCheck.FLD_CONFIRMTOTALMOCOUNT),
                    //Added on 2015/3/5
                    new SqlParameter("@Unclear", MoCheck.FLD_PBOC_Unclear),
                    new SqlParameter("@UnclearMatch", MoCheck.FLD_PBOC_UnclearMatch),
                    new SqlParameter("@ClearMatch", MoCheck.FLD_PBOC_ClearMatch),
                    new SqlParameter("@TotalMoCount_Orgin", MoCheck.FLD_TotalMoCount_Orgin),
                    new SqlParameter("@UnclearVer", MoCheck.FLD_ConfirmPBOC_Unclear),
                    new SqlParameter("@UnclearMatchVer", MoCheck.FLD_ConfirmPBOC_UnclearMatch),
                    new SqlParameter("@ClearMatchVer", MoCheck.FLD_ConfirmPBOC_ClearMatch),
                    new SqlParameter("@TotalMoCount_OrginVer", MoCheck.FLD_ConfirmTotalMoCount_Orgin),
                    new SqlParameter("@UpdatedId",SoeId),
                    new SqlParameter("@AppId",MoCheck.FLD_APPID)
                    };

                    SqlHelper.ExecuteNonQueryDefault(Sql, Params);
                }
                else
                {
                    Sql = @"INSERT INTO T_MoCountCheck (AppId,CustDeclare,ConfirmCustDeclare,HouseBureau,ConfirmHouseBureau,HouseBureauChecked
                        ,PBOC,ConfirmPBOC,PBOCChecked,TotalMoCount,ConfirmTotalMoCount,CreatedId, PBOC_Unclear,PBOC_UnclearMatch
                        ,PBOC_ClearMatch,TotalMoCount_Orgin,ConfirmPBOC_Unclear,ConfirmPBOC_UnclearMatch,ConfirmPBOC_ClearMatch,ConfirmTotalMoCount_Orgin
                        ) VALUES (
                        @AppId,@CustDeclare,@ConfirmCustDeclare,@HouseBureau,@ConfirmHouseBureau,@HouseBureauChecked
                        ,@PBOC,@ConfirmPBOC,@PBOCChecked,@TotalMoCount,@ConfirmTotalMoCount,@CreatedId,@Unclear,@UnclearMatch
                        ,@ClearMatch,@TotalMoCount_Orgin,@UnclearVer,@UnclearMatchVer, @ClearMatchVer,@TotalMoCount_OrginVer
                        );";
                    SqlParameter[] Params = new SqlParameter[] { 
                    new SqlParameter("@AppId",MoCheck.FLD_APPID),
                    new SqlParameter("@CustDeclare",MoCheck.FLD_CUSTDECLARE),
                    new SqlParameter("@ConfirmCustDeclare",MoCheck.FLD_CONFIRMCUSTDECLARE),
                    new SqlParameter("@HouseBureau",MoCheck.FLD_HOUSEBUREAU),
                    new SqlParameter("@ConfirmHouseBureau",MoCheck.FLD_CONFIRMHOUSEBUREAU),
                    new SqlParameter("@HouseBureauChecked",MoCheck.FLD_HouseBureauChecked),
                    new SqlParameter("@PBOC",MoCheck.FLD_PBOC),
                    new SqlParameter("@ConfirmPBOC",MoCheck.FLD_CONFIRMPBOC),
                    new SqlParameter("@PBOCChecked",MoCheck.FLD_PBOCChecked),
                    new SqlParameter("@TotalMoCount",MoCheck.FLD_TOTALMOCOUNT),
                    new SqlParameter("@ConfirmTotalMoCount",MoCheck.FLD_CONFIRMTOTALMOCOUNT),
                    //Added on 2015/3/5
                    new SqlParameter("@Unclear", MoCheck.FLD_PBOC_Unclear),
                    new SqlParameter("@UnclearMatch", MoCheck.FLD_PBOC_UnclearMatch),
                    new SqlParameter("@ClearMatch", MoCheck.FLD_PBOC_ClearMatch),
                    new SqlParameter("@TotalMoCount_Orgin", MoCheck.FLD_TotalMoCount_Orgin),
                    new SqlParameter("@UnclearVer", MoCheck.FLD_ConfirmPBOC_Unclear),
                    new SqlParameter("@UnclearMatchVer", MoCheck.FLD_ConfirmPBOC_UnclearMatch),
                    new SqlParameter("@ClearMatchVer", MoCheck.FLD_ConfirmPBOC_ClearMatch),
                    new SqlParameter("@TotalMoCount_OrginVer", MoCheck.FLD_ConfirmTotalMoCount_Orgin),
                    new SqlParameter("@CreatedId",SoeId)
                    };

                    SqlHelper.ExecuteNonQueryDefault(Sql, Params);
                }
            }
        }

        public bool VerifyHouseBureau(string AppId, out bool NeedCheck)
        {
            NeedCheck = true;

            DataTable dt = new DA_Verification().GetHouseBureau(new Guid(AppId));

            if (dt != null && dt.Rows.Count > 0)
            {
                if (!(dt.Rows[0]["NeedCheckHouseBureau"] is DBNull) && dt.Rows[0]["NeedCheckHouseBureau"] != null)
                {
                    NeedCheck = Convert.ToBoolean(dt.Rows[0]["NeedCheckHouseBureau"]);
                }
            }

            if (!NeedCheck)
            {
                return true;
            }

            DataTable DtAppCust = new DA_Common().GetAppCustByAppId(AppId);
            DataTable DtBureauCust = GetHouseBureau(AppId);

            if (DtAppCust == null || DtAppCust.Rows.Count < 1 || DtBureauCust == null || DtBureauCust.Rows.Count < 1)
            {
                return false;
            }
            if (DtAppCust.Rows.Count != DtBureauCust.Rows.Count)
            {
                return false;
            }
            int AppCust = DtAppCust.Rows.Count;
            int VerifiedCust = 0;

            foreach (DataRow dr in DtAppCust.Rows)
            {
                if (DtBureauCust.Select(String.Format("CustId = '{0}'", dr["CustID"])).Length > 0)
                {
                    VerifiedCust++;
                }
            }
            if (AppCust != VerifiedCust)
            {
                return false;
            }
            return true;
        }

        public decimal GetMORateByTenor(Guid appId, int tenor)
        {
            decimal result = 0;

            string custSegm = string.Empty;
            DataTable csADR = SqlHelper.ExecuteDataTableDefault(@"select CustSegm from T_ADR where AppID=@AppID", SqlHelper.CreateParam("@AppID", SqlDbType.UniqueIdentifier, appId));
            if (csADR.Rows.Count > 0 && csADR.Rows[0]["CustSegm"] != DBNull.Value && !string.IsNullOrEmpty(csADR.Rows[0]["CustSegm"].ToString()))
            {
                custSegm = csADR.Rows[0]["CustSegm"].ToString().Trim();
            }
            else
            {
                DataTable csPDR = SqlHelper.ExecuteDataTableDefault(@"select CustSegm from T_PDR where ProposalID in (select ProposalID from T_Application where AppID=@AppID) and ProdID=5", SqlHelper.CreateParam("@AppID", SqlDbType.UniqueIdentifier, appId));
                if (csPDR.Rows.Count > 0 && csPDR.Rows[0]["CustSegm"] != DBNull.Value && !string.IsNullOrEmpty(csPDR.Rows[0]["CustSegm"].ToString()))
                {
                    custSegm = csPDR.Rows[0]["CustSegm"].ToString().Trim();
                }
            }

            int moCount = Convert.ToInt32(SqlHelper.ExecuteScalarDefault(@"SELECT ConfirmTotalMoCount FROM T_MOCOUNTCHECK WHERE AppID = @AppID;", SqlHelper.CreateParam("@AppID", SqlDbType.UniqueIdentifier, appId)));

            string sql = @"SELECT cast(G_QY_Rate as float) as G_QY_Rate,cast(G_YZ_Rate as float) as G_YZ_Rate,cast(G_YB_Rate as float) as G_YB_Rate,cast(Q_YZ_Rate as float) as Q_YZ_Rate,cast(Q_YB_Rate as float) as Q_YB_Rate,
            cast(G_QY_Rate2 as float) as G_QY_Rate2,cast(G_YZ_Rate2 as float) as G_YZ_Rate2,cast(G_YB_Rate2 as float) as G_YB_Rate2,cast(Q_YZ_Rate2 as float) as Q_YZ_Rate2,cast(Q_YB_Rate2 as float) as Q_YB_Rate2, 
            cast(G_QY_Rate_Over5 as float) as G_QY_Rate_Over5,cast(G_YZ_Rate_Over5 as float) as G_YZ_Rate_Over5,cast(G_YB_Rate_Over5 as float) as G_YB_Rate_Over5,cast(Q_YZ_Rate_Over5 as float) as Q_YZ_Rate_Over5,cast(Q_YB_Rate_Over5 as float) as Q_YB_Rate_Over5,
            cast(G_QY_Rate2_Over5 as float) as G_QY_Rate2_Over5,cast(G_YZ_Rate2_Over5 as float) as G_YZ_Rate2_Over5,cast(G_YB_Rate2_Over5 as float) as G_YB_Rate2_Over5,cast(Q_YZ_Rate2_Over5 as float) as Q_YZ_Rate2_Over5,cast(Q_YB_Rate2_Over5 as float) as Q_YB_Rate2_Over5 
            FROM [T_ProdDetail] where ProdID=5 and RateType='LeadingRate' and OrgCode=@OrgCode and CollateralType='MO2' ";

            DA_Common da_c = new DA_Common();
            DataTable rates = SqlHelper.ExecuteDataTableDefault(sql, SqlHelper.CreateParam("@OrgCode", SqlDbType.VarChar, da_c.GetOrgCodeByAppID(appId)));

            if (rates.Rows.Count > 0)
            {
                string columnName = string.Empty;
                if (custSegm == "ǩԼ��ҵְԱ")
                {
                    columnName = "G_QY_Rate";
                }
                else if (custSegm == "������ҵְԱ")
                {
                    columnName = "G_YZ_Rate";
                }
                else if (custSegm == "һ����ҵְԱ")
                {
                    columnName = "G_YB_Rate";
                }
                else if (custSegm == "���ʸ��廧")
                {
                    columnName = "Q_YZ_Rate";
                }
                else if (custSegm == "һ����廧")
                {
                    columnName = "Q_YB_Rate";
                }

                if (moCount == 2)
                {
                    columnName += "2";
                }
                if (tenor > 60)    //over 5 years
                {
                    columnName += "_Over5";
                }

                result = Convert.ToDecimal(rates.Rows[0][columnName].ToString());
            }

            return result;
        }

        public void SaveLoanIndustryShadow(Map_T_LoanIndustry loanIndustry)
        {
            try
            {
                string sql = "SELECT COUNT(*) FROM dbo.T_LoanIndustry_Shadow WHERE AppId=@AppId AND ProposalId=@ProposalId AND Status=0";
                SqlParameter[] param = new SqlParameter[]{
                new SqlParameter("@AppId", loanIndustry.FLD_AppId),
                new SqlParameter("@ProposalId", loanIndustry.FLD_ProposalId),
            };
                List<SqlParameter> Params = new List<SqlParameter>();
                if (Convert.ToInt32(SqlHelper.ExecuteScalarDefault(sql, param)) > 0)
                {
                    sql = @"UPDATE [T_LoanIndustry_Shadow] SET [LoanCategory] = @LoanCategory,[Loan1stPurpose] = @Loan1stPurpose,[Loan2ndPurpose] = @Loan2ndPurpose,
[Loan3rdPurpose] = @Loan3rdPurpose,[LoanCommercialFiment] = @LoanCommercialFiment,[OtherLoanPurpose] = @OtherLoanPurpose,[LoanMainIndustry] = @LoanMainIndustry,
[LoanSubIndustry] = @LoanSubIndustry, [ModifierId]=@ModifierId, [ModifiedTime]=GETDATE() WHERE [AppId] = @AppId AND ProposalId=@ProposalId AND Status=0";

                    Params.Add(SqlHelper.CreateParam("@LoanCategory", SqlDbType.NVarChar, loanIndustry.FLD_LoanCategory));
                    Params.Add(SqlHelper.CreateParam("@Loan1stPurpose", SqlDbType.NVarChar, loanIndustry.FLD_Loan1stPurpose));
                    Params.Add(SqlHelper.CreateParam("@Loan2ndPurpose", SqlDbType.NVarChar, loanIndustry.FLD_Loan2ndPurpose));
                    Params.Add(SqlHelper.CreateParam("@Loan3rdPurpose", SqlDbType.NVarChar, loanIndustry.FLD_Loan3rdPurpose));
                    Params.Add(SqlHelper.CreateParam("@LoanCommercialFiment", SqlDbType.NVarChar, loanIndustry.FLD_LoanCommercialFiment));
                    Params.Add(SqlHelper.CreateParam("@OtherLoanPurpose", SqlDbType.NVarChar, loanIndustry.FLD_OtherLoanPurpose));
                    Params.Add(SqlHelper.CreateParam("@LoanMainIndustry", SqlDbType.NVarChar, loanIndustry.FLD_LoanMainIndustry));
                    Params.Add(SqlHelper.CreateParam("@LoanSubIndustry", SqlDbType.NVarChar, loanIndustry.FLD_LoanSubIndustry));
                    Params.Add(SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, loanIndustry.FLD_AppId));
                    Params.Add(SqlHelper.CreateParam("@ProposalId", SqlDbType.UniqueIdentifier, loanIndustry.FLD_ProposalId));
                    Params.Add(SqlHelper.CreateParam("@ModifierId", SqlDbType.VarChar, loanIndustry.FLD_ModifierId));
                }
                else
                {
                    sql = @"INSERT INTO [T_LoanIndustry_Shadow]([ProposalId],[AppId],[LoanCategory],[Loan1stPurpose],[Loan2ndPurpose],[Loan3rdPurpose]
,[LoanCommercialFiment],[OtherLoanPurpose],[LoanMainIndustry],[LoanSubIndustry],[CreatorId],[Status]) VALUES 
(@ProposalId,@AppId,@LoanCategory,@Loan1stPurpose,@Loan2ndPurpose,@Loan3rdPurpose,@LoanCommercialFiment,@OtherLoanPurpose,@LoanMainIndustry,@LoanSubIndustry,
@CreatorId,0)";

                    Params.Add(SqlHelper.CreateParam("@ProposalId", SqlDbType.UniqueIdentifier, loanIndustry.FLD_ProposalId));
                    Params.Add(SqlHelper.CreateParam("@AppId", SqlDbType.UniqueIdentifier, loanIndustry.FLD_AppId));
                    Params.Add(SqlHelper.CreateParam("@LoanCategory", SqlDbType.NVarChar, loanIndustry.FLD_LoanCategory));
                    Params.Add(SqlHelper.CreateParam("@Loan1stPurpose", SqlDbType.NVarChar, loanIndustry.FLD_Loan1stPurpose));
                    Params.Add(SqlHelper.CreateParam("@Loan2ndPurpose", SqlDbType.NVarChar, loanIndustry.FLD_Loan2ndPurpose));
                    Params.Add(SqlHelper.CreateParam("@Loan3rdPurpose", SqlDbType.NVarChar, loanIndustry.FLD_Loan3rdPurpose));
                    Params.Add(SqlHelper.CreateParam("@LoanCommercialFiment", SqlDbType.NVarChar, loanIndustry.FLD_LoanCommercialFiment));
                    Params.Add(SqlHelper.CreateParam("@OtherLoanPurpose", SqlDbType.NVarChar, loanIndustry.FLD_OtherLoanPurpose));
                    Params.Add(SqlHelper.CreateParam("@LoanMainIndustry", SqlDbType.NVarChar, loanIndustry.FLD_LoanMainIndustry));
                    Params.Add(SqlHelper.CreateParam("@LoanSubIndustry", SqlDbType.NVarChar, loanIndustry.FLD_LoanSubIndustry));
                    Params.Add(SqlHelper.CreateParam("@CreatorId", SqlDbType.NVarChar, loanIndustry.FLD_ModifierId));
                }

                SqlHelper.ExecuteNonQueryDefault(sql, Params.ToArray());
            }
            catch (Exception ex)
            {
                Logger.ErrorLog(ex, MethodBase.GetCurrentMethod().Name);
                throw new ServerSqlException(ex.Message);
            }
        }

        public void RefreshRate(string AppId, decimal Rate)
        {
            string Sql = @"Update T_SaleAndApp set RateForYear = @Rate,RefreshedRate = 1 where AppID = @AppId;
update T_Application set Rate = @Rate where AppID = @AppId";
            SqlParameter[] Params = new SqlParameter[] { new SqlParameter("@Rate", Rate), new SqlParameter("@AppId", AppId) };
            SqlHelper.ExecuteNonQueryDefault(Sql, Params);
        }
    }
}
