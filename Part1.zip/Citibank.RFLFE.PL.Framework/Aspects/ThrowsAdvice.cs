﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Spring.Aop;
using System.Reflection;
namespace Citibank.RFLFE.PL.Framework.Aspects
{
    public class ThrowsAdvice : IThrowsAdvice
    {
        public void AfterThrowing(Exception ex)
        {
            Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);
            log.DebugLog(ex.ToString(), "AfterThrowing");
        }
    }
}
