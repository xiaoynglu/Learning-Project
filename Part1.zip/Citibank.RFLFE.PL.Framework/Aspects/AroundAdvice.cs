﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using AopAlliance.Intercept;
using System.Reflection;

namespace Citibank.RFLFE.PL.Framework.Aspects
{
    public class AroundAdvice : IMethodInterceptor
    {
        public object Invoke(IMethodInvocation invocation)
        {
            Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);

            log.DebugLog(string.Format("Before: invocation=[{0}]", invocation), "Invoke");
            object result = invocation.Proceed();
            log.DebugLog(string.Format("After : invocation=[{0}]", invocation), "Invoke");
            return result;
        }
    }
}
