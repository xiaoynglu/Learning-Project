﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Citibank.RFLFE.PL.Framework
{ 
    public class ParamKeyDictionary
    {
        #region

        public class SysParamID 
        {
            public const string CollateralType = "CT";

            public const string PropertyType = "LT";

            public const string CustomSegment = "CS";

            public const string OccupationType = "10014";

            public const string SubType = "2";

            public const string PER_LoanPurpose = "3";

            public const string PRO_LoanPurpose = "4";

            public const string PERM_LoanPurpose = "6";

            public const string HouseStatus = "7";

            public const string CommunicationAddress = "8";

            public const string LoanDirection = "11";

            public const string HitType = "12";

            public const string HouseType = "13";

            public const string OccupyStatus = "15";

            public const string PropertyStatus = "15";//todo

            public const string RelationShip = "16";

            public const string SourceCode = "17";

            public const string WhereKnow = "18";

            public const string EducationType = "21";

            public const string MarriageStatus = "22";

            public const string PositionType = "24";

            public const string EnterpriseProperty = "25";

            // public const string CompanyType = "25";

            public const string DeviationLvl = "27";

            public const string EnterpriseLevel = "30";

            public const string EmploymentType = "31";

            public const string EnterpriseScale = "32";

            public const string IncomeType = "35";

            public const string WFStatus = "36";

            public const string G_IndustryType = "40";

            public const string Q_IndustryType = "41";

            public const string HasProperty = "42";

            public const string CustomerApprove = "46";

            public const string MortgagorRelation = "47";

            public const string BorrowingPeriod = "51";

            public const string HEBorrowingPeriod = "52";

            public const string ApprovalStatus = "58";

            public const string DealOriginations = "61";

            public const string BranchCompanyType = "64";

            public const string FamilyRelation = "65";

            public const string BranchVCTCompanyType = "66";

            public const string BorrowerType = "69";

            public const string Gender = "70";

            public const string BooleanType = "71";

            public const string MortgageCount = "75";

            public const string GuaranteeType = "GT";

            public const string ReportType = "ECD";

            public const string CAType = "CAType";

            public const string LandType = "ST";

            public const string LocationType = "LocT";

            public const string MortgageProperty = "MP";

            public const string MortgageType = "GM";

            public const string PayMethod = "99";

            public const string Month = "Month";

            public const string Year = "Year";
        }

        public const string PoliDevia = "poliDevia";

        public const string PricDevia = "pricDevia";

        public const string ProcDevia = "procDevia";

        public const string BorrowType_MB = "MB";

        public const string BorrowType_CB1 = "CB1";

        public const string BorrowType_CB2 = "CB2";

        public const string Relation_BR = "BR";

        public const string G_EmploymentType = "G";

        public const string Q_EmploymentType = "Q";

        public const string Q_EmploymentType_Desc = "企业主";

        public const string Gender_Male = "男";

        public const string Gender_Female = "女";

        public const string Yes = "是";

        public const string Have = "有";

        public const string No = "否";

        public const string None = "无";

        public const string True = "true";

        public const string False = "false";

        /// <summary>
        /// 未完成
        /// </summary>
        public const string Unfinished = "A";
        public const string Unfinished_Name = "未完成";
        /// <summary>
        /// 警告
        /// </summary>
        public const string Alert = "A";
        public const string Alert_Name = "警告";

        /// <summary>
        /// 通过
        /// </summary>
        public const string Pass = "P";
        public const string Pass_eng = "pass";
        public const string Pass_Name = "通过";

        /// <summary>
        /// 失败
        /// </summary>
        public const string Fail = "F";
        public const string Fail_eng = "fail";
        public const string Fail_Name = "失败";

        public const string CheckFree = "免查";

        /// <summary>
        /// 不存在
        /// </summary>
        public const string NA_eng = "N/A";
        public const string NA_Name = "N/A";

        /// <summary>
        /// 是否存在决策异常(是)
        /// </summary>
        public const string yesDevl_Name = "存在决策异常";

        /// <summary>
        /// 是否存在决策异常(否)
        /// </summary>
        public const string noDevl_Name = "无决策异常";

        #endregion

        #region stageId

        public const string NewProposalStageId = "1";

        public const string AmendApplicationStageId = "2";

        public const string AppCheckerStageId = "3";

        public const string ExceptionApproveStageId = "4";

        public const string AppReviewStageId = "5";

        public const string PreCheckStageId = "6";

        public const string CreditApproval = "8";

        public const string  docSuffixName = ".docx";

        #endregion

        //将ProvinceCacheKey作为省份信息保存在Cache中的key
        public const string ProvinceCacheKey="ProvinceCacheKey";

        public const string TreeMenuCacheKey = "TreeMenuKey";

        public const string RoleTypeCacheKeyPrefix = "TreeMenuRoleType";

        public class Stage
        {
             public const int NewProposalId = 1;//新建贷款建议

             public const int AmendApplicationId = 2;//补充申请信息

             public const int  AppCheckerId = 3;//申请提交检查

             public const int ExceptionApproveId = 4;//异常审批

             public const int AppReviewId = 5;//申请复查

             public const int PreChecker = 6;

             public const int FirstndApproval = 10; 
            
             public const int SecondndApproval = 11;
        }

        public static Dictionary<string, string> paramsDictionary = new Dictionary<string, string> {
           {"SubType","2"},
           {"PER_LoanPurpose","3"},
           {"PRO_LoanPurpose","4"},
           {"PERM_LoanPurpose","6"},
           {"HouseStatus","7"},
           {"CommunicationAddress","8"},
           {"LoanDirection","11"},
           {"HitType","12"},
           {"HouseType","13"},
           {"OccupyStatus","15"},
           {"RelationShip","16"},
           {"SourceCode","17"},
           {"WhereKnow","18"},
           {"EducationType","21"},
           {"MarriageStatus","22"},
           {"PositionType","24"},
           {"EnterpriseProperty","25"},
           {"DeviationLvl","27"},
           {"EnterpriseLevel","30"},
           {"EmploymentType","31"},
           {"EnterpriseScale","32"},
           {"IncomeType","35"},
           {"WFStatus","36"},
           {"G_IndustryType","40"},
           {"Q_IndustryType","41"},
           {"HasProperty","42"},
           {"CustomerApprove","46"},
           {"MortgagorRelation","47"},
           {"BorrowingPeriod","51"},
           {"HEBorrowingPeriod","52"},
           {"ApprovalStatus","58"},
           {"DealOriginations","61"},
           {"BranchCompanyType","64"},
           {"FamilyRelation","65"},
           {"BranchVCTCompanyType","66"},
           {"BorrowerType","69"},
           {"Gender","70"},
           {"BooleanType","71"},
           {"MortgageCount","75"},
           {"GuaranteeType","GT"},
           {"CollateralType","CT"},
           {"PropertyType","LT"},
           {"CustomSegment","CS"},
           {"OccupationType","10014"},
           {"ReportType","ECD"},
           {"CAType","CAType"},
           {"LandType","ST"},
           {"LocationType","LocT"},
           {"MortgageProperty","MP"},
           {"MortgageType","GM"},
           {"PayMethod","99"},
           {"RateType","72"},
           {"LoanGrade","73"},
           {"PoliDevia","PoliDevia"},
           {"PricDevia","PricDevia"},
           {"ProcDevia","ProcDevia"},
           {"IDQueryStatus","77"},        
           {"IDQueryBorrowType","78"},
           {"Banks","74"},
           {"Year","Year"},
           {"Month","Month"}
        };

        public class BooleanValue_Format1 
        {
            public static readonly string Y = "Y";

            public static readonly string N = "N";
        }

        public class BooleanValue_Format2
        {
            public static readonly string BooleanValue_Format2_是= "是";

            public static readonly string BooleanValue_Format2_否 = "否";
        }

        public class BooleanValue_Format3
        {
            public static readonly string True = "True";

            public static readonly string False = "False";
        }

        public class StageDescription
        {
            public static readonly string PROPOSAL = "PROPOSAL";

            public static readonly string INTERNALFILEMATCHING = "Internal File Matching";

            public static readonly string FIRSTRAC = "1ST RAC";

            public static readonly string SECONDRAC = "2ND RAC";

            public static readonly string THIRDRAC = "3RD RAC";
        }

        public class ProdName 
        {

            public static readonly string UPL = "UPL";

            public static readonly string HE = "HE";
            
            public static readonly string CRE = "CRE";
            
            public static readonly string TopUp = "TopUp";
            
            public static readonly string MO = "MO";
        }

        public class ProdID
        {
            public static readonly int UPL_ID = 1;

            public static readonly int HE_ID = 2;

            public static readonly int CRE_ID = 3;

            public static readonly int TopUp_ID =4;

            public static readonly int MO_ID = 5;        
        
        }

        public class Action 
        {
            public static readonly string SUBMIT = "SUBMIT";

            public static readonly string PICKUP = "PICKUP";
        }

        public class WFStatus 
        {
            public static readonly string IN = "IN";

            public static readonly string RT = "RT";

            public static readonly string UL = "UL";

            public static readonly string FR = "FR";

            public static readonly string CO = "CO";

            public static readonly string WO = "WO";

            public static readonly string PE = "PE";
        }

        public class WFStepID 
        { 
                
            public static readonly int Step1 = 1;

            public static readonly int Step171 = 171;
        }

        public class DateTimeFormat 
        {
            public static readonly string DateTimeFormat1 = "yyyy-MM-dd HH:mm:ss";

            public static readonly string DateTimeFormat2 = "YYYY-MM-DD";

            public static readonly string DateTimeFormat3 = "yyyy/MM/dd";

            public static readonly string DateTimeFormat4 = "yyyyMMdd";

            public static readonly string DateTimeFormat5 = "yyyy-MM-dd";

            public static readonly string DateTimeFormat6 = "yyyyMMdd_hhmmss";

            public static readonly string DateTimeFormat7 = "yyyyMMddhhmmsss";

            public static readonly string DateTimeFormat8 = "dd/MM/yyyy";

            public static readonly string DateTimeFormat9 = "yyyyMMddHHmmss";

            public static readonly string DateTimeFormat10 = "yyyyMMddHHmm";
        }

        public class MimeType 
        {
            /// <summary>
            /// Word
            /// </summary>
            public static readonly string msWord = "application/ms-word";

            /// <summary>
            /// Excel
            /// </summary>
            public static readonly string execl = "application/octet-stream";
        
        }

        public class PropertyTypeValue 
        {
            public static readonly string MO = "MO";
        }

        public class HasPropertyValue 
        {
            /// <summary>
            /// 拥有(无房贷)
            /// </summary>
            public static readonly string HasProperty_0 = "0";
            
            /// <summary>
            /// 拥有(有房贷)
            /// </summary>
            public static readonly string HasProperty_1 = "1";
            
            /// <summary>
            /// 不拥有
            /// </summary>
            public static readonly string HasProperty_2 = "2";

            /// <summary>
            /// 
            /// </summary>
            public static readonly string HasProperty_3 = "3";
        }

        public class EnterpriseLevelValue 
        {
            /// <summary>
            /// 签约企业
            /// </summary>
            public static readonly string EnterpriseLevel_A = "A";

            /// <summary>
            /// 优质企业
            /// </summary>
            public static readonly string EnterpriseLevel_B = "B";

            /// <summary>
            /// 一般企业
            /// </summary>
            public static readonly string EnterpriseLevel_C = "C";
        }

        public class MoCount
        {
            public static readonly string MoCount_1 = "1";

            public static readonly string MoCount_2 = "2";

            public static readonly string MoCount_3 = "3";
        }

        public class Category 
        {
            /// <summary>
            /// 用于个人消费用途
            /// </summary>
            public static readonly string PER = "PER";

            /// <summary>
            /// 用于个人消费用途(买房)
            /// </summary>
            public static readonly string PERM = "PERM";

            /// <summary>
            /// 用于生产经营用途
            /// </summary>
            public static readonly string PRO = "PRO";          
        }

        public class PER_LoanPurpose 
        {
            /// <summary>
            /// 汽车、配件及相关
            /// </summary>
            public const string A = "A";

            /// <summary>
            /// 房产装修及改造
            /// </summary>
            public const string D = "D";

            /// <summary>
            /// 医疗费用及相关
            /// </summary>
            public const string E = "E";

            /// <summary>
            /// 家电及大额耐用消费品
            /// </summary>
            public const string H = "H";

            /// <summary>
            /// 其他个人综合消费用途
            /// </summary>
            public const string O = "O";

            /// <summary>
            /// 教育及相关
            /// </summary>
            public const string S = "S";
        
        }

        public class PRO_LoanPurpose 
        {
            /// <summary>
            /// 固定资产——经营性装修
            /// </summary>
            public const string C = "C";

            /// <summary>
            /// 固定资产——经营性机器设备
            /// </summary>
            public const string F = "F";

            /// <summary>
            /// 流动资金
            /// </summary>
            public const string M = "M";

            /// <summary>
            /// 其他生产经营用途
            /// </summary>
            public const string X = "X";    
        }

        public class PERM_LoanPurpose
        {
            /// <summary>
            /// 用于购买新建房
            /// </summary>
            public const string N = "N";

            /// <summary>
            /// 用于购买二手房
            /// </summary>
            public const string P = "P";

            /// <summary>
            /// 用于购买期房
            /// </summary>
            public const string T = "T";

        }

        public class IndustryValue 
        {
            /// <summary>
            /// 
            /// </summary>
            public const string PR = "PR";
        
        }

        public class CustType 
        {
            public const string QM = "QM";
        }

        public class CustType_Suffix 
        {
            public const string C = "C";

            public const string M = "M";
        }

        public class PayTypeValue 
        {
            /// <summary>
            /// 受托支付
            /// </summary>
            public const string A = "A"; 

            /// <summary>
            /// 部分受托支付
            /// </summary>
            public const string B = "B"; 

            /// <summary>
            /// 自主支付
            /// </summary>
            public const string C = "C";
        }

        public class DisbursementMethodValue 
        {
            public const string E = "E";

            public const string P = "P";
        }

        public class Branch 
        {
            public const string GA = "GA";

            public const string CB = "CB";

            public const string WFD = "WFD";

            public const string BB = "BB";
        }

        public class City 
        {
            /// <summary>
            /// 重庆
            /// </summary>
            public const string CQ = "CQ";

            /// <summary>
            /// 北京
            /// </summary>
            public const string BJ = "BJ";

            /// <summary>
            /// 天津
            /// </summary>
            public const string TJ = "TJ";

            /// <summary>
            /// 上海
            /// </summary>
            public const string SH = "SH";

            /// <summary>
            /// 澳门特别行政区
            /// </summary>
            public const string AMT = "AMT";

            /// <summary>
            /// 台湾
            /// </summary>
            public const string TW = "TW";

            /// <summary>
            /// 香港特别行政区
            /// </summary>
            public const string XGT = "XGT";
        }

        public class CurrentStatus 
        {
            /// <summary>
            /// 出租
            /// </summary>
            public const string L = "L";

            /// <summary>
            /// 自住
            /// </summary>
            public const string R = "R";

            /// <summary>
            /// 自用
            /// </summary>
            public const string S = "S";

            /// <summary>
            /// 空置
            /// </summary>
            public const string U = "U";
        }

        //FIELDTERMINATOR [ = 'field_terminator' ]
        //指定用于 char 和 widechar 数据文件的字段终止符。默认的字段终止符是 /t（制表符）。 

        //ROWTERMINATOR [ = 'row_terminator' ]
        //指定对于 char 和 widechar 数据文件要使用的行终止符。默认值是 /n（换行符）。 

        //FIRSTROW [ = first_row ]
        //指定要复制的第一行的行号。默认值是 1，表示在指定数据文件的第一行。 

        //CODEPAGE [ = 'ACP' | 'OEM' | 'RAW' | 'code_page' ]
        //指定该数据文件中数据的代码页。仅当数据含有字符值大于 127 或小于 32 的 char、varchar 或 text 列时，
        //CODEPAGE 才是适用的。CODEPAGE 值 描述 ACP char、varchar 或 text 数据类型的列从 ANSI/Microsoft Windows® 
        //代码页 ISO 1252 转换为 SQL Server 代码页。 OEM（默认值） char、varchar 或 text 数据类型的列被从系统 OEM 
        //代码页转换为 SQL Server 代码页。 RAW 并不进行从一个代码页到另一个代码页的转换；这是最快的选项。 
        //code_page 特定的代码页号码，例如 850。 

        //FIRE_TRIGGERS
        //指定目的表中定义的任何插入触发器将在大容量复制操作过程中执行。如果没有指定 FIRE_TRIGGERS，将不执行任何插入触发器。 

        public const string SQLInsertCmd = @"bulk insert {0}
                                                from '{1}'
                                                with
                                                (
	                                                FIELDTERMINATOR = '\t',
	                                                ROWTERMINATOR = '\n',
	                                                FIRSTROW = 2,
	                                                CODEPAGE ='65001',
	                                                FIRE_TRIGGERS
                                                );";

        public const string SQLInsertCmdWithCodePage = @"bulk insert {0}
                                                from '{1}'
                                                with
                                                (
	                                                FIELDTERMINATOR = '\t',
	                                                ROWTERMINATOR = '\n',
	                                                FIRSTROW = 2,
	                                                CODEPAGE ='{2}',
	                                                FIRE_TRIGGERS
                                                )";
        public const string SQLInsertCmdWithCodePageComma = @"bulk insert {0}
                                                from '{1}'
                                                with
                                                (
	                                                FIELDTERMINATOR = '{3}',
	                                                ROWTERMINATOR = '\n',
	                                                FIRSTROW = 2,
	                                                CODEPAGE ='{2}',
	                                                FIRE_TRIGGERS
                                                )";

        public const string T_PL_PR_ExchRate = "T_PL_PR_ExchRate";

        public const string T_PL_TempPR_Body = "T_PL_TempPR_Body";

        public enum ReportFileMode
        {
            TextFile = 1,
            BinaryFile = 2,
        }

        public enum DataSource
        {
            ReportHead = 1,
            Body = 2,
            Footer = 3,
        }

        public enum ReportType
        {
            ByRows = 1,
            ByFieldCaption = 2,
        }

        public enum DataType
        {
            Int = 1,
            Long = 2,
            Double = 3,
            Date = 4,
            Time = 5,
            Text = 6,
        }

        public const string PrefixFileName = "GRBMAST";

        public const string ALSPrefixfileName = "AMPBOC";

        public const string LineSign = "/";
        public const string JingSign = "#";
    }
}
