﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Citibank.RFLFE.PL.IBll;
using Citibank.RFLFE.PL.Entities;
using System.Reflection;
using CitiAES;
using System.IO;
using System.Data;
using DocumentFormat.OpenXml.Packaging;
using System.Xml.Linq;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Wordprocessing;
using System.Security.Cryptography;
using DocumentFormat.OpenXml;
using Constants = Citibank.RFLFE.PL.Framework.ParamKeyDictionary;
using System.Configuration;

namespace Citibank.RFLFE.PL.Framework
{
    public class CommonUtility
    {
        private FileInfo mergeTemplate;
        public static Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);
        public FileInfo Template { get { return this.mergeTemplate; } private set { this.mergeTemplate = value; } }
        public XNamespace XMLNS { get { return XNamespace.Get(WORDMLNS); } }
        public const string WORDMLNS = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
        public static int _codePage = 936;

        public static bool MapPath(IReportGenerateHandler GenerateHandler, string fileType, ref IList<T_Sys_PathConfiguration> ShareFolderPath)
        {
            CommonTResult<T_Sys_PathConfiguration> PathConfig = null;
            string FileName = string.Empty;
            PathConfig = GenerateHandler.GetPathConfigByName(fileType);
            if (PathConfig.ResultCount == 0 || PathConfig == null)
            {
                return false;
            }
            clsAES AES = new clsAES();
            MapPath.MapPath map = new MapPath.MapPath();

            string strShareFolder = PathConfig.ResultList[0].ShareFilePath.ToString();
            if (!Directory.Exists(strShareFolder)) 
            {
                Directory.CreateDirectory(strShareFolder);
            }
            string strDomainUser = PathConfig.ResultList[0].FileAccessFunctionID.ToString();
            string password = AES.Decrypt(PathConfig.ResultList[0].FileAccessFunctionPWD.ToString());
            var msg = string.Empty;
            if (!map.IsMapPath(strDomainUser, password, strShareFolder, ref msg))
            {
                return false;
            }
            ShareFolderPath = PathConfig.ResultList;
            return true;
        }

        public CommonUtility(string templatePath)
        {
            if (string.IsNullOrEmpty(templatePath)) throw new ArgumentNullException("The Template cannot be null.");

            FileInfo template = new FileInfo(templatePath);
            if (!template.Exists) throw new ArgumentNullException("The Template File does not exists.");
            Template = template;
        }

        public int MailMerge(DataTable dt, string uniqueFileName,Boolean isApplyDocumentProtection)
        {
            File.Copy(Template.FullName, uniqueFileName, true);

            using (WordprocessingDocument wordDocument = WordprocessingDocument.Open(uniqueFileName, true), doc = WordprocessingDocument.Open(Template.FullName, true))
            {
                XElement body = XElement.Parse(wordDocument.MainDocumentPart.Document.Body.OuterXml);
                wordDocument.MainDocumentPart.Document.Body.RemoveAllChildren();
                int RowNum = 1;
                foreach (DataRow row in dt.Rows)
                {
                    try
                    {
                        XElement newBody = XElement.Parse(doc.MainDocumentPart.Document.Body.OuterXml);

                        IList<XElement> mailMergeFields =
                    (from el in newBody.Descendants()
                     where ((el.Name == (XMLNS + "t") && el.Value != null && el.Value.Contains("«") && el.Value.Contains("»")))
                     select el).ToList();

                        string fieldName = string.Empty;
                        XElement newElement = null;

                        foreach (XElement field in mailMergeFields)
                        {
                            fieldName = field.Value.Replace("«", "").Replace("»", "").Replace("-", "_");
                            if (row.Table.Columns.Contains(fieldName))
                            {
                                if (row[fieldName] == DBNull.Value)
                                    row[fieldName] = string.Empty;
                                newElement = field;
                                newElement.Value = Regex.Replace(row.Field<string>(fieldName).Trim(), "\\s+", " ", RegexOptions.IgnoreCase);
                                field.ReplaceWith(newElement);
                            }
                        }
                        Body bo = new Body(newBody.ToString());
                        wordDocument.MainDocumentPart.Document.Body.AppendChild<Body>(bo);

                        log.DebugLog(String.Format("Merge Succ,{0}", uniqueFileName), "WordMerge");
                    }
                    catch (Exception ex)
                    {
                        log.ErrorLog(String.Format("Merge Failed,{0},{1}", uniqueFileName, ex.Message), "WordMerge");
                    }
                }
                wordDocument.MainDocumentPart.Document.Save();

                DocumentSettingsPart settingsPart = wordDocument.MainDocumentPart.GetPartsOfType<DocumentSettingsPart>().First();


                if (settingsPart.GetPartsOfType<MailMergeRecipientDataPart>().Count() > 0)
                {
                    MailMergeRecipientDataPart mmrPart = settingsPart.GetPartsOfType<MailMergeRecipientDataPart>().First();
                    settingsPart.DeletePart(mmrPart);
                }

                XElement settings = XElement.Parse(settingsPart.RootElement.OuterXml);

                IList<XElement> mailMergeElements =
                    (from el in settings.Descendants()
                     where el.Name == (XMLNS + "mailMerge")
                     select el).ToList();

                foreach (XElement field in mailMergeElements)
                {
                    field.Remove();
                }

                settingsPart.RootElement.InnerXml = settings.ToString();
                settingsPart.RootElement.Save();

                if (isApplyDocumentProtection) {
                    this.ApplyDocumentProtection(wordDocument, DocumentProtectionValues.Forms);
                }

                return RowNum;
            }
        }

        public void ApplyDocumentProtection(WordprocessingDocument wdDocument, DocumentProtectionValues ProtectionValues)
        {
            string strPassword = string.Format("Loan_{0}", DateTime.Now.ToString("yyyyMMdd"));

            int[] InitialCodeArray = { 0xE1F0, 0x1D0F, 0xCC9C, 0x84C0, 0x110C, 0x0E10, 0xF1CE, 0x313E, 0x1872, 0xE139, 0xD40F, 0x84F9, 0x280C, 0xA96A, 0x4EC3 };
            int[,] EncryptionMatrix = new int[15, 7]
    {
            
            /* char 1  */ {0xAEFC, 0x4DD9, 0x9BB2, 0x2745, 0x4E8A, 0x9D14, 0x2A09},
            /* char 2  */ {0x7B61, 0xF6C2, 0xFDA5, 0xEB6B, 0xC6F7, 0x9DCF, 0x2BBF},
            /* char 3  */ {0x4563, 0x8AC6, 0x05AD, 0x0B5A, 0x16B4, 0x2D68, 0x5AD0},
            /* char 4  */ {0x0375, 0x06EA, 0x0DD4, 0x1BA8, 0x3750, 0x6EA0, 0xDD40},
            /* char 5  */ {0xD849, 0xA0B3, 0x5147, 0xA28E, 0x553D, 0xAA7A, 0x44D5},
            /* char 6  */ {0x6F45, 0xDE8A, 0xAD35, 0x4A4B, 0x9496, 0x390D, 0x721A},
            /* char 7  */ {0xEB23, 0xC667, 0x9CEF, 0x29FF, 0x53FE, 0xA7FC, 0x5FD9},
            /* char 8  */ {0x47D3, 0x8FA6, 0x0F6D, 0x1EDA, 0x3DB4, 0x7B68, 0xF6D0},
            /* char 9  */ {0xB861, 0x60E3, 0xC1C6, 0x93AD, 0x377B, 0x6EF6, 0xDDEC},
            /* char 10 */ {0x45A0, 0x8B40, 0x06A1, 0x0D42, 0x1A84, 0x3508, 0x6A10},
            /* char 11 */ {0xAA51, 0x4483, 0x8906, 0x022D, 0x045A, 0x08B4, 0x1168},
            /* char 12 */ {0x76B4, 0xED68, 0xCAF1, 0x85C3, 0x1BA7, 0x374E, 0x6E9C},
            /* char 13 */ {0x3730, 0x6E60, 0xDCC0, 0xA9A1, 0x4363, 0x86C6, 0x1DAD},
            /* char 14 */ {0x3331, 0x6662, 0xCCC4, 0x89A9, 0x0373, 0x06E6, 0x0DCC},
            /* char 15 */ {0x1021, 0x2042, 0x4084, 0x8108, 0x1231, 0x2462, 0x48C4}
      };



            // Generate the Salt
            byte[] arrSalt = new byte[16];
            RandomNumberGenerator rand = new RNGCryptoServiceProvider();
            rand.GetNonZeroBytes(arrSalt);

            //Array to hold Key Values
            byte[] generatedKey = new byte[4];

            //Maximum length of the password is 15 chars.
            int intMaxPasswordLength = 15;


            if (!String.IsNullOrEmpty(strPassword))
            {
                // Truncate the password to 15 characters
                strPassword = strPassword.Substring(0, Math.Min(strPassword.Length, intMaxPasswordLength));

                // Construct a new NULL-terminated string consisting of single-byte characters:
                //  -- > Get the single-byte values by iterating through the Unicode characters of the truncated Password.
                //   --> For each character, if the low byte is not equal to 0, take it. Otherwise, take the high byte.

                byte[] arrByteChars = new byte[strPassword.Length];

                for (int intLoop = 0; intLoop < strPassword.Length; intLoop++)
                {
                    int intTemp = Convert.ToInt32(strPassword[intLoop]);
                    arrByteChars[intLoop] = Convert.ToByte(intTemp & 0x00FF);
                    if (arrByteChars[intLoop] == 0)
                        arrByteChars[intLoop] = Convert.ToByte((intTemp & 0xFF00) >> 8);
                }

                // Compute the high-order word of the new key:

                // --> Initialize from the initial code array (see below), depending on the strPassword’s length. 
                int intHighOrderWord = InitialCodeArray[arrByteChars.Length - 1];

                // --> For each character in the strPassword:
                //      --> For every bit in the character, starting with the least significant and progressing to (but excluding) 
                //          the most significant, if the bit is set, XOR the key’s high-order word with the corresponding word from 
                //          the Encryption Matrix

                for (int intLoop = 0; intLoop < arrByteChars.Length; intLoop++)
                {
                    int tmp = intMaxPasswordLength - arrByteChars.Length + intLoop;
                    for (int intBit = 0; intBit < 7; intBit++)
                    {
                        if ((arrByteChars[intLoop] & (0x0001 << intBit)) != 0)
                        {
                            intHighOrderWord ^= EncryptionMatrix[tmp, intBit];
                        }
                    }
                }

                // Compute the low-order word of the new key:

                // Initialize with 0
                int intLowOrderWord = 0;

                // For each character in the strPassword, going backwards
                for (int intLoopChar = arrByteChars.Length - 1; intLoopChar >= 0; intLoopChar--)
                {
                    // low-order word = (((low-order word SHR 14) AND 0x0001) OR (low-order word SHL 1) AND 0x7FFF)) XOR character
                    intLowOrderWord = (((intLowOrderWord >> 14) & 0x0001) | ((intLowOrderWord << 1) & 0x7FFF)) ^ arrByteChars[intLoopChar];
                }

                // Lastly,low-order word = (((low-order word SHR 14) AND 0x0001) OR (low-order word SHL 1) AND 0x7FFF)) XOR strPassword length XOR 0xCE4B.
                intLowOrderWord = (((intLowOrderWord >> 14) & 0x0001) | ((intLowOrderWord << 1) & 0x7FFF)) ^ arrByteChars.Length ^ 0xCE4B;

                // Combine the Low and High Order Word
                int intCombinedkey = (intHighOrderWord << 16) + intLowOrderWord;

                // The byte order of the result shall be reversed [Example: 0x64CEED7E becomes 7EEDCE64. end example],
                // and that value shall be hashed as defined by the attribute values.

                for (int intTemp = 0; intTemp < 4; intTemp++)
                {
                    generatedKey[intTemp] = Convert.ToByte(((uint)(intCombinedkey & (0x000000FF << (intTemp * 8)))) >> (intTemp * 8));
                }
            }

            // Implementation Notes List:
            // --> In this third stage, the reversed byte order legacy hash from the second stage shall be converted to Unicode hex 
            // --> string representation 
            StringBuilder sb = new StringBuilder();
            for (int intTemp = 0; intTemp < 4; intTemp++)
            {
                sb.Append(Convert.ToString(generatedKey[intTemp], 16));
            }
            generatedKey = Encoding.Unicode.GetBytes(sb.ToString().ToUpper());

            // Implementation Notes List:
            //Word appends the binary form of the salt attribute and not the base64 string representation when hashing
            // Before calculating the initial hash, you are supposed to prepend (not append) the salt to the key
            byte[] tmpArray1 = generatedKey;
            byte[] tmpArray2 = arrSalt;
            byte[] tempKey = new byte[tmpArray1.Length + tmpArray2.Length];
            Buffer.BlockCopy(tmpArray2, 0, tempKey, 0, tmpArray2.Length);
            Buffer.BlockCopy(tmpArray1, 0, tempKey, tmpArray2.Length, tmpArray1.Length);
            generatedKey = tempKey;


            // Iterations specifies the number of times the hashing function shall be iteratively run (using each
            // iteration's result as the input for the next iteration).
            int iterations = 50000;

            // Implementation Notes List:
            //Word requires that the initial hash of the password with the salt not be considered in the count.
            //    The initial hash of salt + key is not included in the iteration count.
            HashAlgorithm sha1 = new SHA1Managed();
            generatedKey = sha1.ComputeHash(generatedKey);
            byte[] iterator = new byte[4];
            for (int intTmp = 0; intTmp < iterations; intTmp++)
            {

                //When iterating on the hash, you are supposed to append the current iteration number.
                iterator[0] = Convert.ToByte((intTmp & 0x000000FF) >> 0);
                iterator[1] = Convert.ToByte((intTmp & 0x0000FF00) >> 8);
                iterator[2] = Convert.ToByte((intTmp & 0x00FF0000) >> 16);
                iterator[3] = Convert.ToByte((intTmp & 0xFF000000) >> 24);

                generatedKey = concatByteArrays(iterator, generatedKey);
                generatedKey = sha1.ComputeHash(generatedKey);
            }

            // Apply the element
            DocumentProtection documentProtection = new DocumentProtection();
            documentProtection.Edit = ProtectionValues;

            OnOffValue docProtection = new OnOffValue(true);
            documentProtection.Enforcement = docProtection;

            documentProtection.CryptographicAlgorithmClass = CryptAlgorithmClassValues.Hash;
            documentProtection.CryptographicProviderType = CryptProviderValues.RsaFull;
            documentProtection.CryptographicAlgorithmType = CryptAlgorithmValues.TypeAny;
            documentProtection.CryptographicAlgorithmSid = 4; // SHA1
            //    The iteration count is unsigned
            UInt32Value uintVal = new UInt32Value();
            uintVal.Value = (uint)iterations;
            documentProtection.CryptographicSpinCount = uintVal;
            documentProtection.Hash = Convert.ToBase64String(generatedKey);
            documentProtection.Salt = Convert.ToBase64String(arrSalt);
            wdDocument.MainDocumentPart.DocumentSettingsPart.Settings.AppendChild(documentProtection);
            wdDocument.MainDocumentPart.DocumentSettingsPart.Settings.Save();

        }

        private static byte[] concatByteArrays(byte[] array1, byte[] array2)
        {
            byte[] result = new byte[array1.Length + array2.Length];
            Buffer.BlockCopy(array2, 0, result, 0, array2.Length);
            Buffer.BlockCopy(array1, 0, result, array2.Length, array1.Length);
            return result;
        }

        public static string ChangeCNName(string columnValue)
        {
            string cnfail = Constants.Fail_Name;
            string cnpass = Constants.Pass_Name;
            string cnna = Constants.NA_Name;

            string cnyesDevl = Constants.yesDevl_Name;
            string cnnoDevl = Constants.noDevl_Name;

            string cnyes = Constants.Yes;
            string cnno = Constants.No;

            string result = columnValue;
            switch (columnValue)
            {
                case "fail": result = cnfail;
                    break;
                case "pass": result = cnpass;
                    break;
                case "N/A": result = cnna;
                    break;
                case "": result = string.Empty;
                    break;
                case "NO": result = cnnoDevl;
                    break;
                case "YES": result = cnyesDevl;
                    break;
                case "true": result = cnyes;
                    break;
                case "false": result = cnno;
                    break;
            }
            return result;
        }

        public static string GetRelaceTextInAttachment()
        {
            return ConfigurationSettings.AppSettings["RelaceTextInAttachment"];
        }

        public static string GetRefreshCachePeriod()
        {
            return ConfigurationSettings.AppSettings["RefreshCachePeriod"];
        }

        public static string GetWord2007Postfix()
        {
            return ConfigurationSettings.AppSettings["Word2007Postfix"];
        }

        public static string ContractPath()
        {
            return ConfigurationSettings.AppSettings["ContractPath"];
        }

        public static string ContractOutputPath()
        {
            return ConfigurationSettings.AppSettings["ContractOutputPath"];
        }

        public static string ProposalAppFormPath()
        {
            return ConfigurationSettings.AppSettings["ProposalAppFormPath"];
        }

        public static string ClientPath()
        {
            return ConfigurationSettings.AppSettings["ClientPath"];
        }

        public static string ContractHEDocName()
        {
            return ConfigurationSettings.AppSettings["ContractHEDocName"];
        }
        public static string ContractMODocName()
        {
            return ConfigurationSettings.AppSettings["ContractMODocName"];
        }
        public static string ContractUPLDocName()
        {
            return ConfigurationSettings.AppSettings["ContractUPLDocName"];
        }

        public static string ProposalAppFormDocName()
        {
            return ConfigurationSettings.AppSettings["ProposalAppFormDocName"];
        }

        public static string ProposalSalAppFormDocName()
        {
            return ConfigurationSettings.AppSettings["ProposalSalAppFormDocName"];
        }

        public static string ApplicationEmpAppFormDocName()
        {
            return ConfigurationSettings.AppSettings["ApplicationEmpAppFormDocName"];
        }

        public static string ApplicationSalAppFormDocName()
        {
            return ConfigurationSettings.AppSettings["ApplicationSalAppFormDocName"];
        }
        public static string ApplicationCB2AppFormDocName()
        {
            return ConfigurationSettings.AppSettings["ApplicationAppFormCB2DocName"];
        }

        public static string TextEncoding() {
            return ConfigurationSettings.AppSettings["TextEncoding"];
        }

        #region pboc
        public static string PBOCSourcePathForRate() 
        {
            return ConfigurationSettings.AppSettings["PBOCSourcePathForRate"];
        }

        public static string PBOCTempFilePath()
        {
            return ConfigurationSettings.AppSettings["PBOCTempFilePath"];
        }

        public static string PBOCSeparatedCharForRate()
        {
            return ConfigurationSettings.AppSettings["PBOCSeparatedCharForRate"];
        }

        public static string PBOCSourcePathForALS() {
            return ConfigurationSettings.AppSettings["PBOCSourcePathForALS"];
        }

        public static string PBOCBackupPathForALS()
        {
            return ConfigurationSettings.AppSettings["PBOCBackupPathForALS"];

        }

        public static string PBOCLineLengthForALS()
        {
            return ConfigurationSettings.AppSettings["PBOCLineLengthForALS"];
        }

        public static string PBOCMapDriver()
        {
            return ConfigurationSettings.AppSettings["PBOCMapDriver"];
        }

        public static string PBOCShareFolder()
        {
            return ConfigurationSettings.AppSettings["PBOCShareFolder"];
        }

        public static string PBOCDomainUser()
        {
            return ConfigurationSettings.AppSettings["PBOCDomainUser"];
        }

        public static string PBOCPasswordForJob()
        {
            return ConfigurationSettings.AppSettings["PBOCPasswordForJob"];
        }

        public static string PBOCExportPath() {
            return ConfigurationSettings.AppSettings["PBOCExportPath"];
        }

        public static string PBOCFinInsCode() {
            return ConfigurationSettings.AppSettings["PBOCFinInsCode"];
        }

        public static string PBOCFinInsCodeCB()
        {
            return ConfigurationSettings.AppSettings["PBOCFinInsCodeCB"];
        }

        public static string PBOCFinInsCodeWCF()
        {
            return ConfigurationSettings.AppSettings["PBOCFinInsCodeWCF"];
        }

        public static string PBOCFinInsCodeBB() {
            return ConfigurationSettings.AppSettings["PBOCFinInsCodeBB"];
        }

        public static string PBOCExportCVSPath() {
            return ConfigurationSettings.AppSettings["PBOCExportCVSPath"];
        }

        public static string PBOCFormatNo() {
            return ConfigurationSettings.AppSettings["PBOCFormatNo"];
        }

        public static string PBOCContributionRefNo() {
            return ConfigurationSettings.AppSettings["PBOCContributionRefNo"];
        }

        public static string PBOCResubmissionCode() {
            return ConfigurationSettings.AppSettings["PBOCResubmissionCode"];
        }

        public static string PBOCContactPerson() {
            return ConfigurationSettings.AppSettings["PBOCContactPerson"];
        }

        public static string PBOCContactPhone() {
            return ConfigurationSettings.AppSettings["PBOCContactPhone"];
        }

        public static string PBOCReportType() {
            return ConfigurationSettings.AppSettings["PBOCReportType"];
        }

        public static string PBOCInfoType() {
            return ConfigurationSettings.AppSettings["PBOCInfoType"];
        }

        public static string PBOCMaxValueStatus() {
            return ConfigurationSettings.AppSettings["PBOCMaxValueStatus"];
        }

        public static string PBOCIP() {
            return ConfigurationSettings.AppSettings["PBOCIP"];
        }

        public static string RMIP() 
        {
            return ConfigurationSettings.AppSettings["RMIP"];
        }

        public static string RMSourceFile() {
            return ConfigurationSettings.AppSettings["RMSourceFile"];
        }

        public static string RMMapDriver()
        {
            return ConfigurationSettings.AppSettings["RMMapDriver"];
        }

        public static string RMShareFolder()
        {
            return ConfigurationSettings.AppSettings["RMShareFolder"];
        }

        public static string RMDomainUser()
        {
            return ConfigurationSettings.AppSettings["RMDomainUser"];
        }

        public static string RMPasswordForJob()
        {
            return ConfigurationSettings.AppSettings["RMPasswordForJob"];
        }

        public static string IsDev()
        {
            return ConfigurationSettings.AppSettings["IsDev"];
        }
        #endregion
         

        public static string Arabia_to_Chinese(decimal Money)
        {
            if (Money < 0)
            {
                Money = 0 - Money;
            }

            return ConvertSum(Convert.ToString(Money));

        }

        /// <summary>
        /// 转换数字金额主函数（包括小数）
        /// </summary>
        /// <param name="str">数字字符串</param>
        /// <returns>转换成中文大写后的字符串或者出错信息提示字符串</returns>
        public static string ConvertSum(string str)
        {
            if (!IsPositveDecimal(str))
                return "输入的不是正数字！";
            if (Double.Parse(str) > 999999999999.99)
                return "数字太大，无法换算，请输入一万亿元以下的金额";
            char[] ch = new char[1];
            ch[0] = '.'; //小数点
            string[] splitstr = null; //定义按小数点分割后的字符串数组
            splitstr = str.Split(ch[0]);//按小数点分割字符串
            if (splitstr.Length == 1) //只有整数部分
                return ConvertData(str) + "圆整";
            else //有小数部分
            {
                string rstr;
                rstr = ConvertData(splitstr[0]) + "圆";//转换整数部分
                rstr += ConvertSDigit(splitstr[1]);//转换小数部分
                return rstr;
            }

        }

        /// 
        /// 判断是否是正数字字符串
        /// 
        /// 判断字符串
        /// 如果是数字，返回true，否则返回false
        public static bool IsPositveDecimal(string str)
        {
            Decimal d;
            try
            {
                d = Decimal.Parse(str);

            }
            catch (Exception)
            {
                return false;
            }
            if (d >= 0)
                return true;
            else
                return false;
        }

        /// 
        /// 转换数字（整数）
        /// 
        /// 需要转换的整数数字字符串
        /// 转换成中文大写后的字符串
        public static string ConvertData(string str)
        {
            string tmpstr = "";
            string rstr = "";
            int strlen = str.Length;
            if (strlen <= 4)//数字长度小于四位
            {
                rstr = ConvertDigit(str);

            }
            else
            {

                if (strlen <= 8)//数字长度大于四位，小于八位
                {
                    tmpstr = str.Substring(strlen - 4, 4);//先截取最后四位数字
                    rstr = ConvertDigit(tmpstr);//转换最后四位数字
                    tmpstr = str.Substring(0, strlen - 4);//截取其余数字
                    //将两次转换的数字加上萬后相连接
                    rstr = String.Concat(ConvertDigit(tmpstr) + "萬", rstr);
                    rstr = rstr.Replace("零萬", "萬");
                    rstr = rstr.Replace("零零", "零");

                }
                else
                    if (strlen <= 12)//数字长度大于八位，小于十二位
                    {
                        tmpstr = str.Substring(strlen - 4, 4);//先截取最后四位数字
                        rstr = ConvertDigit(tmpstr);//转换最后四位数字
                        tmpstr = str.Substring(strlen - 8, 4);//再截取四位数字
                        rstr = String.Concat(ConvertDigit(tmpstr) + "萬", rstr);
                        tmpstr = str.Substring(0, strlen - 8);
                        rstr = String.Concat(ConvertDigit(tmpstr) + "億", rstr);
                        rstr = rstr.Replace("零億", "億");
                        rstr = rstr.Replace("零萬", "零");
                        rstr = rstr.Replace("零零", "零");
                        rstr = rstr.Replace("零零", "零");
                    }
            }
            strlen = rstr.Length;
            if (strlen >= 2)
            {
                switch (rstr.Substring(strlen - 2, 2))
                {
                    case "佰零": rstr = rstr.Substring(0, strlen - 2) + "佰"; break;
                    case "仟零": rstr = rstr.Substring(0, strlen - 2) + "仟"; break;
                    case "萬零": rstr = rstr.Substring(0, strlen - 2) + "萬"; break;
                    case "億零": rstr = rstr.Substring(0, strlen - 2) + "億"; break;

                }
            }

            return rstr;
        }

        /// 
        /// 转换数字（小数部分）
        /// 
        /// 需要转换的小数部分数字字符串
        /// 转换成中文大写后的字符串
        public static string ConvertSDigit(string str)
        {
            int strlen = str.Length;
            string rstr;
            if (strlen == 1)
            {
                rstr = ConvertChinese(str) + "角";
                return rstr;
            }
            else
            {
                string tmpstr = str.Substring(0, 1);
                rstr = ConvertChinese(tmpstr) + "角";
                tmpstr = str.Substring(1, 1);
                rstr += ConvertChinese(tmpstr) + "分";
                rstr = rstr.Replace("零分", "");
                rstr = rstr.Replace("零角", "");
                return rstr;
            }
        }

        /// 
        /// 转换数字
        /// 
        /// 转换的字符串（四位以内）
        /// 
        public static string ConvertDigit(string str)
        {
            int strlen = str.Length;
            string rstr = "";
            switch (strlen)
            {
                case 1: rstr = ConvertChinese(str); break;
                case 2: rstr = Convert2Digit(str); break;
                case 3: rstr = Convert3Digit(str); break;
                case 4: rstr = Convert4Digit(str); break;
            }
            rstr = rstr.Replace("拾零", "拾");
            strlen = rstr.Length;
            return rstr;
        }

        /// 
        /// 转换四位数字
        /// 
        public static string Convert4Digit(string str)
        {
            string str1 = str.Substring(0, 1);
            string str2 = str.Substring(1, 1);
            string str3 = str.Substring(2, 1);
            string str4 = str.Substring(3, 1);
            string rstring = "";
            rstring += ConvertChinese(str1) + "仟";
            rstring += ConvertChinese(str2) + "佰";
            rstring += ConvertChinese(str3) + "拾";
            rstring += ConvertChinese(str4);
            rstring = rstring.Replace("零仟", "零");
            rstring = rstring.Replace("零佰", "零");
            rstring = rstring.Replace("零拾", "零");
            rstring = rstring.Replace("零零", "零");
            rstring = rstring.Replace("零零", "零");
            rstring = rstring.Replace("零零", "零");
            return rstring;
        }
        /// 
        /// 转换三位数字
        /// 
        public static string Convert3Digit(string str)
        {
            string str1 = str.Substring(0, 1);
            string str2 = str.Substring(1, 1);
            string str3 = str.Substring(2, 1);
            string rstring = "";
            rstring += ConvertChinese(str1) + "佰";
            rstring += ConvertChinese(str2) + "拾";
            rstring += ConvertChinese(str3);
            rstring = rstring.Replace("零佰", "零");
            rstring = rstring.Replace("零拾", "零");
            rstring = rstring.Replace("零零", "零");
            rstring = rstring.Replace("零零", "零");
            return rstring;
        }
        /// 
        /// 转换二位数字
        /// 
        public static string Convert2Digit(string str)
        {
            string str1 = str.Substring(0, 1);
            string str2 = str.Substring(1, 1);
            string rstring = "";
            rstring += ConvertChinese(str1) + "拾";
            rstring += ConvertChinese(str2);
            rstring = rstring.Replace("零拾", "零");
            rstring = rstring.Replace("零零", "零");
            return rstring;
        }
        /// 
        /// 将一位数字转换成中文大写数字
        /// 
        public static string ConvertChinese(string str)
        {
            //"零壹贰叁肆伍陆柒捌玖拾佰仟萬億圆整角分"
            string cstr = "";
            switch (str)
            {
                case "0": cstr = "零"; break;
                case "1": cstr = "壹"; break;
                case "2": cstr = "贰"; break;
                case "3": cstr = "叁"; break;
                case "4": cstr = "肆"; break;
                case "5": cstr = "伍"; break;
                case "6": cstr = "陆"; break;
                case "7": cstr = "柒"; break;
                case "8": cstr = "捌"; break;
                case "9": cstr = "玖"; break;
            }
            return (cstr);
        }

        public static string GetFormatedDate1(string dateTime)
        {
            if (dateTime == "") return "";
            var year = "";
            var month = "";
            var day = "";
            var tempDate = new DateTime();
            tempDate = DateTime.Parse(dateTime);
            year = tempDate.Year.ToString();
            if (tempDate.Month < 10 && tempDate.Month > 0) month = "0" + tempDate.Month.ToString(); else month = tempDate.Month.ToString();
            if (tempDate.Day < 10 && tempDate.Day > 0) day = "0" + tempDate.Day.ToString(); else day = tempDate.Day.ToString();
            return year + "/" + month + "/" + day;
        }

        public static bool chkNumber(string strValue, bool hasDot)
        {
            string strData = "";
            if (hasDot)
            {
                strData = "0123456789.";
            }
            else
            {
                strData = "0123456789";
            }
            //"0123456789.";


            bool isNumber = true;
            //check the specified field's value is zero
            if (strValue == null || strValue.Trim().Length == 0)
            {
                return false;
            }
            //trim the space 
            strValue = strValue.Trim();
            for (int i = 0; i < strValue.Length; i++)
            {
                if (strData.IndexOf(strValue[i]) == -1)
                {
                    isNumber = false;
                    break;
                }
            }
            return isNumber;
        }

        public static string chkDate(ref string errMessage, string strValue, string strFormatDate)
        {
            string rtnValue = strValue;
            errMessage = "";
            string[] str;
            DateTime dt;
            try
            {
                switch (strFormatDate.ToLower())
                {
                    case "yyyy-mm-dd":
                        rtnValue = strValue;
                        break;
                    case "yyyy/mm/dd":
                        rtnValue = strValue;
                        break;
                    case "mm-dd-yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('-');
                        rtnValue = "20" + str[2] + "/" + str[0] + "/" + str[1];
                        break;
                    case "mm/dd/yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('/');
                        rtnValue = "20" + str[2] + "/" + str[0] + "/" + str[1];
                        break;
                    case "dd/mm/yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('/');
                        rtnValue = "20" + str[2] + "/" + str[1] + "/" + str[0];
                        break;
                    case "dd-mm-yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('-');
                        rtnValue = "20" + str[2] + "/" + str[1] + "/" + str[0];

                        break;
                    case "dd.mm.yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('.');
                        rtnValue = "20" + str[2] + "/" + str[1] + "/" + str[0];
                        break;
                }
                rtnValue = Convert.ToDateTime(rtnValue).ToString("yyyy/MM/dd").Replace("-", "/");
                return rtnValue;
            }
            catch (Exception ex)
            {
                errMessage = ex.ToString();
                return "";
            }
        }

        public static string chkTime(ref string errMessage, string strValue, string strFormatTime)
        {
            string rtnValue = strValue;
            errMessage = "";
            string[] str;
            DateTime dt;
            try
            {
                switch (strFormatTime.ToLower())
                {
                    case "hh.mm.ss":
                        rtnValue = strValue.Replace(".", ":");
                        break;
                    case "hhmmss":
                        rtnValue = string.Format("{0}:{1}:{2}", strValue.Substring(0, 2), strValue.Substring(2, 2), strValue.Substring(4, 2));
                        break;
                    case "mm-dd-yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('-');
                        rtnValue = "20" + str[2] + "/" + str[0] + "/" + str[1];

                        break;

                    case "mm/dd/yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('/');
                        rtnValue = "20" + str[2] + "/" + str[0] + "/" + str[1];

                        break;
                    case "dd/mm/yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('/');
                        rtnValue = "20" + str[2] + "/" + str[1] + "/" + str[0];

                        break;
                    case "dd-mm-yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('-');
                        rtnValue = "20" + str[2] + "/" + str[1] + "/" + str[0];

                        break;
                    case "dd.mm.yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('.');
                        rtnValue = "20" + str[2] + "/" + str[1] + "/" + str[0];

                        break;


                }


                dt = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd") + " " + rtnValue);
                return rtnValue;

            }
            catch (Exception ex)
            {
                errMessage = ex.ToString();
                return "";
            }
        }

        public static bool mapDriverPath(string strMapPath, string strShareFolder, string strDomainUser, string strPassword)
        {
            MapPath.MapPath map = new MapPath.MapPath();
            clsAES AES = new clsAES();
            var msg = string.Empty;
            var password = strPassword;
            if (!map.IsMapPath(strDomainUser, password, strShareFolder, ref msg))
            {
                log.ErrorLog(msg, MethodBase.GetCurrentMethod().Name);
                return false;
            }
            else
            {
                return true;
            }
        }

        public static string GetString(DataRow drParam, string colName)
        {
            string rtString = "";
            if (colName.CompareTo("") == 0)
                return "";
            else
            {
                if (drParam[colName] == System.DBNull.Value)
                    rtString = "";
                else
                    rtString = drParam[colName].ToString();
            } return rtString;
        }

        public static int GetInt(IDataReader drParam, string colName)
        {
            if (colName.CompareTo("") == 0)
                return 0;
            else
                return drParam.GetInt32(drParam.GetOrdinal(colName));
        }

        public static Double GetDouble(IDataReader drParam, string colName)
        {
            if (colName.CompareTo("") == 0)
                return 0;
            else
                return drParam.GetDouble(drParam.GetOrdinal(colName));
        }

        public static int DateDiff(string Interval, DateTime Date1, DateTime Date2)
        {
            int intDateDiff = 0;
            TimeSpan time = Date1 - Date2;
            int timeHours = Math.Abs(time.Hours);
            int timeDays = Math.Abs(time.Days);
            switch (Interval.ToLower())
            {
                case "h": // hours          
                    intDateDiff = timeHours;
                    break;
                case "d": // days       
                    intDateDiff = timeDays;
                    break;
                case "w": // weeks          
                    intDateDiff = timeDays / 7;
                    break;
                case "bw": // bi-weekly          
                    intDateDiff = (timeDays / 7) / 2;
                    break;
                case "m": // monthly      
                    timeDays = timeDays - ((timeDays / 365) * 5);
                    intDateDiff = timeDays / 30;
                    break;
                case "bm": // bi-monthly        
                    timeDays = timeDays - ((timeDays / 365) * 5);
                    intDateDiff = (timeDays / 30) / 2;
                    break;
                case "q": // quarterly       
                    timeDays = timeDays - ((timeDays / 365) * 5);
                    intDateDiff = (timeDays / 90);
                    break;
                case "y": // yearly               
                    intDateDiff = (timeDays / 365);
                    break;
            }
            return intDateDiff;
        }

        public static string MakeString(string source, int length, string lor)
        {
            try
            {
                string mkString;
                //int i = source.Length;          
                int i = System.Text.Encoding.GetEncoding(_codePage).GetBytes(source).Length;
                if (i > length)
                    mkString = leftByUnicode(source, length);
                else
                    if (lor.Equals("L") == true)
                        mkString = source + Space(length - i); //mkString = source.PadRight(length,' ');      
                    else
                        mkString = Space(length - i) + source; // mkString = source.PadLeft(length, ' ');       
                return mkString;
            }
            catch (Exception ex)
            { 
                throw ex;
            }
        }

        public static string MakeString(string source, int length, string lor, string strChar)
        {
            try
            {
                string mkString;
                //int i = source.Length;   

                int i = System.Text.Encoding.GetEncoding(_codePage).GetBytes(source).Length;
                if (i > length)
                {
                    if (lor.Equals("L") == true)
                        mkString = leftByUnicode(source, length);
                    else
                        mkString = rightByUnicode(source, length);
                }
                else
                {
                    if (lor.Equals("L") == true)
                        mkString = source + Space(length - i, strChar); //mkString = source.PadRight(length,' ');      
                    else
                        mkString = Space(length - i, strChar) + source; // mkString = source.PadLeft(length, ' ');  
                }
                return mkString;
            }
            catch (Exception ex)
            {
                log.ErrorLog(ex.Message + source + "MakeString 4", MethodBase.GetCurrentMethod().Name);
                throw ex;
            }
        }

        public  static string Space(int num)
        {
            string strSpace = "";
            string spaceValue = " ";
            for (int i = 0; i < num; i++)
                strSpace = strSpace + spaceValue;
            return strSpace;
        }

        public static string Space(int num, string strChar)
        {
            string strSpace = "";
            for (int i = 0; i < num; i++)
                strSpace = strSpace + strChar;
            return strSpace;
        }

        public static string leftByUnicode(string strsrc, int icount)
        {
            try
            {
                byte[] bytes = System.Text.Encoding.GetEncoding(_codePage).GetBytes(strsrc);

                if (strsrc == null || bytes.Length <= icount)
                    return strsrc;
                byte[] tmpBytes = new byte[icount];
                for (int i = 0; i < icount; i++)
                {
                    tmpBytes[i] = bytes[i];
                }
                return System.Text.Encoding.GetEncoding(_codePage).GetString(tmpBytes);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private static string rightByUnicode(string strsrc, int icount)
        {
            byte[] bytes = System.Text.Encoding.GetEncoding(_codePage).GetBytes(strsrc);

            if (strsrc == null || bytes.Length <= icount)
                return strsrc;
            byte[] tmpBytes = new byte[icount];
            int j = 0;
            for (int i = bytes.Length - icount; i < bytes.Length; i++)
            {
                tmpBytes[j] = bytes[i];
                j = j + 1;
            }
            return System.Text.Encoding.GetEncoding(_codePage).GetString(tmpBytes); 
        }
    }
}
