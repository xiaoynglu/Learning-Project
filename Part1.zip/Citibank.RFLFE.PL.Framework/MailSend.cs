﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using log4net;
using System.Configuration;

namespace Citibank.RFLFE.PL.Framework
{
    public class MailSend
    {
        private static readonly Logger Log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);

        /// <summary>
        /// SendMailBySMTP
        /// </summary>
        /// <param name="smtpServer">smtpServer</param>
        /// <param name="from">from</param>
        /// <param name="to">to</param>
        /// <param name="cc">cc</param>
        /// <param name="subject">subject</param>
        /// <param name="message">message</param>
        /// <param name="attachment">attachment</param>
        /// <returns></returns>
        private static void SendMailBySMTP(string smtpServer, string from, string to, string subject, string message, string emailCC, string emailBcc)
        {
            try
            {
                System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();
                if (to.Contains(";"))
                {
                    string[] mails = to.Split(';');
                    foreach (string v in mails)
                    {
                        if (!String.IsNullOrEmpty(v.Trim()))
                            msg.To.Add(v);
                    }
                }
                else
                {
                    msg.To.Add(to.Trim());
                }
                if (emailCC.Contains(";"))
                {
                    if (emailCC.Substring(emailCC.Length - 1, 1) == ";")
                        emailCC = emailCC.Substring(0, emailCC.Length - 1);
                    emailCC = emailCC.Replace(';', ',');
                    msg.CC.Add(emailCC);
                }
                else
                {
                    if (!String.IsNullOrEmpty(emailCC))
                    {
                        msg.CC.Add(emailCC.Trim());
                    }
                }
                if (emailBcc.Contains(";"))
                {
                    if (emailBcc.Substring(emailBcc.Length - 1, 1) == ";")
                        emailBcc = emailBcc.Substring(0, emailBcc.Length - 1);
                    emailBcc = emailBcc.Replace(';', ',');
                    msg.Bcc.Add(emailBcc);
                }
                else
                {
                    if (!String.IsNullOrEmpty(emailBcc))
                    {
                        msg.Bcc.Add(emailBcc.Trim());
                    }
                }
                msg.From = new System.Net.Mail.MailAddress(from);
                msg.Subject = subject;
                msg.SubjectEncoding = System.Text.Encoding.UTF8;
                msg.Body = message;
                msg.BodyEncoding = System.Text.Encoding.UTF8;
                msg.IsBodyHtml = true;
                msg.Priority = System.Net.Mail.MailPriority.High;
                System.Net.Mail.SmtpClient client = new System.Net.Mail.SmtpClient();
                client.Host = smtpServer;

                Log.DebugLog(" msg.To:" + msg.To, MethodBase.GetCurrentMethod().Name);
                Log.DebugLog(" msg.CC:" + msg.CC, MethodBase.GetCurrentMethod().Name);
                Log.DebugLog(" msg.Bcc:" + msg.Bcc, MethodBase.GetCurrentMethod().Name);
                Log.DebugLog(" smtpServer:" + smtpServer, MethodBase.GetCurrentMethod().Name);
                client.Send(msg);
            }
            catch (Exception ex)
            {
                Log.ErrorLog(ex, MethodBase.GetCurrentMethod().Name);
            }
        }

        public static void SendByAddress(string Msg, string Subject, string ToAddress)
        {
            string emailSendFrom = ConfigurationManager.AppSettings["EmailFromAddress"];
            string sMTPServer = ConfigurationManager.AppSettings["SMTPServer"];
            string emailCC = ConfigurationManager.AppSettings["EmailCCAddress"];
            string emailBcc = ConfigurationManager.AppSettings["EmailBccAddress"];
            SendMailBySMTP(sMTPServer, emailSendFrom, ToAddress, Subject, Msg, emailCC, emailBcc);
        }

        public static void SendByDefault(string msg)
        {
            string mailSubject = ConfigurationManager.AppSettings["EmailSubject"];
            string emailSendFrom = ConfigurationManager.AppSettings["EmailFromAddress"];
            string emailSendTo = ConfigurationManager.AppSettings["EmailToAddress"];
            string sMTPServer = ConfigurationManager.AppSettings["SMTPServer"];
            string emailCC = ConfigurationManager.AppSettings["EmailCCAddress"];
            string emailBcc = ConfigurationManager.AppSettings["EmailBccAddress"];
            SendMailBySMTP(sMTPServer, emailSendFrom, emailSendTo, mailSubject, msg, emailCC, emailBcc);
        }
    }
}
