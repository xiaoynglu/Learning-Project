﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Framework.Extensions
{
    public class DataReaderRowFilter
    {
        public static bool RowFilter(IDataReader dataReader, string columnName)
        {
            dataReader.GetSchemaTable().DefaultView.RowFilter = string.Format("ColumnName='{0}'", columnName);
            return dataReader.GetSchemaTable().DefaultView.Count > 0;
        }
    }
}
