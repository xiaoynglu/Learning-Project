﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace Citibank.RFLFE.PL.Framework.Extensions
{
    public static class DataReaderExtensions
    {
        /// <SUMMARY>
        /// This method will return the value of the specified columnName, cast to
        /// the type specified in T. However, if the value found in the reader is
        /// DBNull, this method will return the default value of the type T.
        /// </SUMMARY>
        /// <TYPEPARAM name="T">The type to which the value found in the reader should be cast.</TYPEPARAM>
        /// <PARAM name="reader">The reader in which columnName is found.</PARAM>
        /// <PARAM name="columnName">The columnName to retrieve.</PARAM>
        /// <RETURNS>The column value within the reader typed as T.</RETURNS>
        public static T GetValueOrDefault<T>(this IDataReader reader, string columnName)
        {
            int index = reader.GetOrdinal(columnName);
            T returnValue = default(T);
            if (!reader.IsDBNull(index))
            {
                returnValue = (T)Convert.ChangeType(reader[columnName], typeof(T));

                //returnValue = (T)reader[columnName];
            }
            return returnValue;
        }
    }
}
