﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Reflection;

namespace Citibank.RFLFE.PL.Framework
{
    public class FileDownloadUtility
    {
        private const long BUFFER_SIZE = 4096;
        public static Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);
        public static byte[] DownloadFile(string outFileName)
        {            
            log.DebugLog("<=====FileDownloadUtility DownloadFile=====> ", "DownloadFile");
            log.DebugLog("outFileName: " + outFileName, "DownloadFile");
            using (FileStream fs = new FileStream(outFileName, FileMode.Open, FileAccess.Read, FileShare.Read))
            {
                // Read the source file into a byte array.
                byte[] bytes = new byte[fs.Length];
                int numBytesToRead = (int)fs.Length;
                int numBytesRead = 0;
                while (numBytesToRead > 0)
                {
                    // Read may return anything from 0 to numBytesToRead.
                    int n = fs.Read(bytes, numBytesRead, numBytesToRead);
                    // Break when the end of the file is reached.
                    if (n == 0)
                        break;
                    numBytesRead += n;
                    numBytesToRead -= n;
                }
                numBytesToRead = bytes.Length;
                log.DebugLog("<=====FileDownloadUtility DownloadFile=====> ", "DownloadFile");
                return bytes;
            }
        }

        public static bool DownloadFile(string file, StringBuilder value)
        {
            try
            {
                FileInfo fileInfo = new FileInfo(file);
                if (!Directory.Exists(fileInfo.DirectoryName))
                {
                    Directory.CreateDirectory(fileInfo.DirectoryName);
                }
                using(FileStream fs = new FileStream(file, FileMode.CreateNew, FileAccess.Write))
                {
                    StreamWriter sw = new StreamWriter(fs);
                    sw.Write(value);
                    sw.Close();
                    fs.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                log.DebugLog("<=====FileDownloadUtility DownloadFile=====> ", "DownloadFile");
                return false;
            }
        }

        //public static byte[] DownloadFile(string[] files)
        //{
        //    string folderName = AppDomain.CurrentDomain.BaseDirectory + @"\temp\";
        //    if (!Directory.Exists(folderName))
        //    {
        //        Directory.CreateDirectory(folderName);
        //    }
        //    string zipFileName = folderName + DateTime.Now.Ticks.ToString() + ".zip";
        //    ZipFiles(files, zipFileName);
        //    return DownloadFile(zipFileName);
        //}

        //private static void ZipFiles(string[] files, string zipFilename)
        //{
        //    int count = 0;
        //    string name = string.Empty;
        //    using (Package zip = System.IO.Packaging.Package.Open(zipFilename, FileMode.OpenOrCreate))
        //    {
        //        foreach (string file in files)
        //        {
        //            if (count == 0)
        //            {
        //                name = "ProductionTemplate";
        //            }
        //            else
        //            {
        //                name = "PendingTemplate";
        //            }
        //            string destFilename = ".\\" + name + Path.GetFileName(file);
        //            destFilename = Encoding.UTF8.GetString(Encoding.Default.GetBytes(destFilename));
        //            Uri uri = PackUriHelper.CreatePartUri(new Uri(destFilename, UriKind.Relative));

        //            //Uri uri = PackUriHelper.CreatePartUri(new Uri(destFilename, UriKind.Relative));
        //            if (zip.PartExists(uri))
        //            {
        //                zip.DeletePart(uri);
        //            }
        //            PackagePart part = zip.CreatePart(uri, "", CompressionOption.Normal);
        //            using (FileStream fileStream = new FileStream(file, FileMode.Open, FileAccess.Read))
        //            {
        //                using (Stream dest = part.GetStream())
        //                {
        //                    CopyStream(fileStream, dest);
        //                }
        //            }
        //            count++;
        //        }
        //    }
        //}

        private static void CopyStream(System.IO.FileStream inputStream, System.IO.Stream outputStream)
        {
            long bufferSize = inputStream.Length < BUFFER_SIZE ? inputStream.Length : BUFFER_SIZE;
            byte[] buffer = new byte[bufferSize];
            int bytesRead = 0;
            long bytesWritten = 0;
            while ((bytesRead = inputStream.Read(buffer, 0, buffer.Length)) != 0)
            {
                outputStream.Write(buffer, 0, bytesRead);
                bytesWritten += bufferSize;
            }
        }
    }
}
