﻿using System;
using System.Linq;
using System.Globalization;
using System.Data;
using System.Reflection;

namespace Citibank.RFLFE.PL.Framework
{
    public static class ConvertUtility
    {
        public static Logger log = new Logger(MethodBase.GetCurrentMethod().DeclaringType);
       
        public static byte[] StringToByte(string str)
        {
            byte[] bytes = new byte[str.Length * sizeof(char)];
            System.Buffer.BlockCopy(str.ToCharArray(), 0, bytes, 0, bytes.Length);
            return bytes;
        }

        public static string ByteToString(byte[] bytes)
        {
            char[] chars = new char[bytes.Length / sizeof(char)];
            System.Buffer.BlockCopy(bytes, 0, chars, 0, bytes.Length);
            return new string(chars);
        }

        public static string DateToString(DateTime? dateTime)
        {
            string dateString = String.Empty;
            if (dateTime != null)
            {
                DateTime date = (DateTime)dateTime;
                dateString = date.ToString("yyyy/MM/dd", CultureInfo.InvariantCulture);
            }

            return dateString;
        }

        public static DateTime? StringToDate(String dateString)
        {
            DateTime? date = null;

            try
            {
                date = DateTime.ParseExact(dateString, "yyyy/MM/dd", CultureInfo.InvariantCulture);
            }
            catch
            {
                //
            }

            return date;
        }

        public static decimal? StringToDecimal(String decimalString)
        {
            decimal vaule;

            if (decimal.TryParse(decimalString, out vaule))
            {
                return vaule;
            }
            else
            {
                return null;
            }
        }

        public static decimal CutDecimalWithN(decimal d, int n)
        {
            string strDecimal = d.ToString();
            int index = strDecimal.IndexOf(".");
            if (index == -1 || strDecimal.Length < index + n + 1)
            {
                strDecimal = string.Format("{0:F" + n + "}", d);
            }
            else
            {
                int length = index;
                if (n != 0)
                {
                    length = index + n + 1;
                }
                strDecimal = strDecimal.Substring(0, length);
            }
            return Decimal.Parse(strDecimal);
        }

        public static string NullIfEmpty(string value)
        {
            return string.IsNullOrEmpty(value) ? null : value;
        }

        public static T2 ConvertT<T1, T2>(T1 t)
        {
            var output = Activator.CreateInstance(typeof(T2));
            var props = t.GetType().GetProperties();
            var propsOutput = output.GetType().GetProperties();
            PropertyInfo propOut;
            foreach (PropertyInfo p in props)
            {
                propOut = propsOutput.FirstOrDefault(c => c.Name == p.Name);
                if (propOut != null)
                {
                    propOut.SetValue(output, p.GetValue(t, null), null);
                }
            }
            return (T2)output;
        }

        public static string ConvertToChinese(double amount)
        {
            if (amount == 0.00f)
                return "零元";

            string buf = "";                                // 存放返回结果 
            string strDecPart = "";                   // 存放小数部分的处理结果 
            string strIntPart = "";                    //存放整数部分的处理结果 

            //将数据分为整数和小数部分 
            char[] cDelim = { '.' };
            string[] tmp = null;
            string strDigital = amount.ToString();
            if (strDigital[0] == '.')
            {
                //处理数据首位为小数点的情况 
                strDigital = "0" + strDigital;
            }
            tmp = strDigital.Split(cDelim, 2);

            // 整数部分的处理 
            if (tmp[0].Length > 15)
            {
                throw new Exception("数值超出处理范围。");
            }
            //标示整数部分是否为零
            bool flag = true;
            if (amount >= 1.00f)
            {
                strIntPart = ConvertInteger(tmp[0]);
                flag = false;
            }

            // 存在小数部分，则处理小数部分
            if (tmp.Length == 2)
                strDecPart = ConvertDecimal(tmp[1], flag);
            else
                strDecPart = "整";

            buf = strIntPart + strDecPart;
            return buf;
        }

        private static string ConvertInteger(string intPart)
        {
            string buf = "";
            int length = intPart.Length;
            int curUnit = length;

            //处理除个位以上的数据
            string tmpValue = "";                    // 记录当前数值的中文形式 
            string tmpUnit = "";                     // 记录当前数值对应的中文单位 
            int i;
            for (i = 0; i < length - 1; i++, curUnit--)
            {
                if (intPart[i] != '0')
                {
                    tmpValue = DigToCC(intPart[i]);
                    tmpUnit = GetUnit(curUnit - 1);
                }
                else
                {

                    // 如果当前的单位是"万、亿"，则需要把它记录下来 
                    if ((curUnit - 1) % 4 == 0)
                    {
                        tmpValue = "";
                        tmpUnit = GetUnit(curUnit - 1);
                    }
                    else
                    {
                        tmpUnit = "";

                        // 如果当前位是零，则需要判断它的下一位是否为零，再确定是否记录'零'
                        if (intPart[i + 1] != '0')
                        {
                            tmpValue = "零";
                        }
                        else
                        {
                            tmpValue = "";
                        }
                    }
                }
                buf += tmpValue + tmpUnit;
            }

            // 处理个位数据 
            if (intPart[i] != '0')
                buf += DigToCC(intPart[i]);
            buf += "元";

            return buf;
        }

        /// <summary>
        /// 小数部分的处理
        /// </summary>
        /// <param name="decPart">需要处理的小数部分</param>
        /// <param name="flag">标示整数部分是否为零</param>
        /// <returns></returns>
        private static string ConvertDecimal(string decPart, bool flag)
        {
            string buf = "";
            if ((decPart[0] == '0') && (decPart.Length > 1))
            {
                if (flag == false)
                {
                    buf += "零";
                }
                if (decPart[1] != '0')
                {
                    buf += DigToCC(decPart[1]) + "分";
                }
            }
            else
            {
                buf += DigToCC(decPart[0]) + "角";
                if ((decPart.Length > 1) && (decPart[1] != '0'))
                {
                    buf += DigToCC(decPart[1]) + "分";
                }
            }
            //buf += "整";
            return buf;
        }

        /// <summary>
        /// 获取人民币中文形式的对应位置的单位标志
        /// </summary>
        /// <param name="n"></param>
        /// <returns></returns>
        private static string GetUnit(int n)
        {
            switch (n)
            {
                case 1:
                    return "拾";
                case 2:
                    return "佰";
                case 3:
                    return "仟";
                case 4:
                    return "万";
                case 5:
                    return "拾";
                case 6:
                    return "佰";
                case 7:
                    return "仟";
                case 8:
                    return "亿";
                case 9:
                    return "拾";
                case 10:
                    return "佰";
                case 11:
                    return "仟";
                case 12:
                    return "万";
                case 13:
                    return "拾";
                case 14:
                    return "佰";
                case 15:
                    return "仟";
                default:
                    return " ";
            }
        }

        /// <summary>
        /// 数字转换为相应的中文字符 ( Digital To Chinese Char )
        /// </summary>
        /// <param name="c">以字符形式存储的数字</param>
        /// <returns></returns>
        private static string DigToCC(char c)
        {
            switch (c)
            {
                case '1':
                    return "壹";
                case '2':
                    return "贰";
                case '3':
                    return "叁";
                case '4':
                    return "肆";
                case '5':
                    return "伍";
                case '6':
                    return "陆";
                case '7':
                    return "柒";
                case '8':
                    return "捌";
                case '9':
                    return "玖";
                case '0':
                    return "零";
                default:
                    return "  ";
            }
        }

        public static Decimal DecimalTryParse(string param) 
        {
            try{
                decimal result;
                Decimal.TryParse(param, out result);
                return result;
            }
            catch(Exception e){               
                log.ErrorLog(e, MethodBase.GetCurrentMethod().Name);
                return 0;
            }
        }

        public static Int32 Int32TryParse(string param)
        {
            Int32 result;
            Int32.TryParse(param, out result);
            return result;
        }

        public static decimal ConvertStringToDecimal(string param) {
            try 
            {
                decimal returnValue = 0;
                returnValue =DecimalTryParse(param.Replace(",","")) ;
                return returnValue;
            }
            catch (Exception e)
            {
                log.ErrorLog(e, MethodBase.GetCurrentMethod().Name);
                return 0;
            }
        }

        public static string chkTime(ref string errMessage, string strValue, string strFormatTime)
        {
            string rtnValue = strValue;
            errMessage = "";
            string[] str;
            DateTime dt;
            try
            {
                switch (strFormatTime.ToLower())
                {
                    case "hh.mm.ss":
                        rtnValue = strValue.Replace(".", ":");
                        break;
                    case "hhmmss":
                        rtnValue = string.Format("{0}:{1}:{2}", strValue.Substring(0, 2), strValue.Substring(2, 2), strValue.Substring(4, 2));
                        break;
                    case "mm-dd-yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('-');
                        rtnValue = "20" + str[2] + "/" + str[0] + "/" + str[1];
                        break;

                    case "mm/dd/yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('/');
                        rtnValue = "20" + str[2] + "/" + str[0] + "/" + str[1];
                        break;
                    case "dd/mm/yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('/');
                        rtnValue = "20" + str[2] + "/" + str[1] + "/" + str[0];
                        break;
                    case "dd-mm-yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('-');
                        rtnValue = "20" + str[2] + "/" + str[1] + "/" + str[0];

                        break;
                    case "dd.mm.yy":
                        rtnValue = strValue;
                        str = rtnValue.Split('.');
                        rtnValue = "20" + str[2] + "/" + str[1] + "/" + str[0];
                        break;
                }
                dt = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd") + " " + rtnValue);
                return rtnValue;

            }
            catch (Exception ex)
            {
                errMessage = ex.ToString();
                return "";
            }
        }
    }
}
