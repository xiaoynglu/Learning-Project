﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using Citibank.RFLFE.PL.Entities;

namespace Citibank.RFLFE.PL.Framework
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false)]
    public class AuthorizeFilterAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (filterContext.HttpContext.Session != null)
            {

                if (filterContext.HttpContext.Session.IsNewSession)// || !filterContext.HttpContext.User.Identity.IsAuthenticated)
                {
                    var sessionCookie = filterContext.HttpContext.Request.Headers["Cookie"];

                    if ((sessionCookie != null) && (sessionCookie.IndexOf("ASP.NET_SessionId", StringComparison.OrdinalIgnoreCase) >= 0))
                    {
                        filterContext.Result = new JsonResult
                        {
                            Data = new
                            {
                                SessionTimeOut = true
                            },
                            JsonRequestBehavior = JsonRequestBehavior.AllowGet
                        };
                    }
                }
            }

            base.OnActionExecuting(filterContext);
        }
    }
}
